# METHOD, v43. What the method says, and the shelves.

Read whole at stage A1 and again at C2; the method shelf arrives at A1, B1 and C2, the explanation shelf at C3, the adaptation shelf at D1, the hierarchy shelf at D4, the critique shelf at E1. `mem.py shelf` lists the read tier, `mem.py shelf --list` the on-request tier. Nothing here
overrides the contract.

<!-- INDEX -->
| section | lines | words |
|---|---|---|
| What the method says, held at every stage | 13 to 110 | 1313 |
| The shape of the run | 111 to 162 | 616 |
<!-- /INDEX -->

## What the method says, held at every stage

**Gioia, Corley and Hamilton (2013) is the spine.** Their first-order analysis adheres faithfully
to informant terms and makes little attempt to distill: the categories explode on the front end,
and you must get lost before you can get found; then similarities and differences among the many
categories reduce the germane ones. Their manageable number, twenty-five or thirty, is one head's
capacity for one site; here the hands remove that limit and the count is set by kinds (stage B1).
Their second-order analysis is theoretical: themes that describe and explain, with particular
attention to nascent concepts that have no adequate referent in the literature, distilled further
into aggregate dimensions. The data structure is the display of the move from data to theory, and
their mantra is *no data structure, know nothing*; the grounded model shows the dynamic
relationships the static structure cannot, and it is the arrows that set everything in motion.
The findings are suffused with informant quotes that align with the exemplars in the data
structure. The literature is consulted late, in deliberate semi-ignorance. Intercoder agreement
is not necessary at the tiers one head builds; where the fleets place items under a written
instrument it is reported (contract §6). Their devil's advocate is here one hostile reader at the end of
C2, the readers at C5, the labelers at D2, and no system of adversaries.

**Grodal, Anteby and Holm (2021) name what you do.** Qualitative analysis is categorization, and
categorization is eight moves: asking questions, focusing on puzzles, dropping, merging,
splitting, relating or contrasting, sequencing, developing or dropping working hypotheses.
Rigor is transparency about the moves. Every move you make is logged with its name
(`tier_history.jsonl`, `model/history.jsonl`, the diary) and snapped when it is made; the leg
closes at the end of a pass, or earlier when you choose (STANDING-INSTRUCTIONS §2). Their three phases map onto the run once: generating is A1 to B1, refining C1 to C5,
stabilizing D1 to D5, and stabilized never means closed. Their paper is method, not theory, and
ships at B1.

**Eisenhardt (1989) governs the cases.** Within-case analysis before cross-case; the cross-case
step as a search for patterns across pairs and groups of cases; replication logic, each case
confirming or disconfirming what the others suggested; the literature enfolded after the
constructs exist; closure when the marginal case adds little. Her ceiling, that beyond about ten
cases the volume of data stops fitting one head, is the ceiling this instrument exists to pass.
The within-case tier is the coders'. The return's (D1 to D3) is hers only if something is predicted
before it is seen: at D1 the handoff writes, per room, which elements the model expects to
instantiate given the room's placements and which to be absent, and the ledger is scored against
that expectation at E1. The return is in-sample throughout. Concepts absent from element citations are uncited evidence, not
held-out observations: the analyst may already have read them. Record that coverage separately.

**Van de Ven and Poole (1990) give the grammar of the record.** Incidents are bracketed into
events by a rule written before the bracketing; the forest is that grammar, and a coded turn is
an incident. **Langley (1999)** supplies strategies for the dynamic part of the model; the run
uses narrative, grounded theory, visual mapping and temporal bracketing (with brackets from
`prior.md`) for the dynamics. The taxonomy at D4 and D5 compares rooms on global measures, which
Langley calls the synthetic strategy and classes as variance theory, not process theory: say so
where the branches are described, and keep the dynamic claims on the forest and the clock. **Suddaby (2006)** says what
grounded theory is not: not raw data presented, not theory testing, content analysis or word
counts, not a mechanical routine. Read that list beside every count you are tempted to report as
a finding.

**The adaptation shelf, at D1 to D3.** Fisher and Aguinis (2017): theory elaboration as a mode of
research between generation and testing, with seven tactics (horizontal and vertical contrasting,
new construct specification, construct splitting, structuring specific, recursive and sequence
relations); the operations a resumed case lead may perform are this instrument's operationalization, not the authors' own coding schema,
and `SCHEMA-adaptations.md` §2 gives the one mapping. Busse, Kach and Wagner (2017): boundary conditions as the
conditions under which a theory holds, explored by taking the theory to cases where it may fail,
including construct refinement, moderators and mediators. Our `restrict` and `contradict`
operations record different discrepancies; evidence decides whether to bound, refine, extend
or replace the claim. Busse et al. do not prescribe that every discrepancy becomes a boundary. On request: Vaughan
(1992), Ketokivi and Choi (2014), Sætre and Van de Ven (2021), Makadok, Burton and Barney (2018),
Welch et al. (2022), Eisenhardt (2021), Ragin (2023), Robinson (1951), Turner (1953), Lakatos
(1970). **The hierarchy shelf, at D4 and D5.** Doty and Glick (1994): a typology is a theory only when its
types are ideal types with stated constructs and stated relations among them, and a case is
placed by its distance to a type; a branch description that lacks either is a label. Their
programme predicts outcomes from fit to type; that stays secondary here, and you take the
definition, not the programme. Kozlowski and Klein (2000), the section on emergence: a
higher-level property is *composed* when it is the same kind of thing as the lower-level
properties that make it, and *compiled* when it is a configuration of different contributions;
these are the words for saying what a form is relative to its rooms. McKelvey (1975): guidelines
for classifying organizations empirically, the discipline a taxonomy owes before it names a
branch. Pavitt (1984): a taxonomy of sectors built from observed patterns and turned into a
theory, the nearest model for what stages D4 and D5 do (named on the shelf; its text is not held
yet). On request: Hannan and Freeman (1986), Fiss (2011), Rich (1992), Grimm et al. (2005), Gray,
Bryant and Greenhill (2010), Hsu and Hannan (2005).

**The explanation shelf, at C3.** Read: Puranam, Alexy and Reitzig (2014), the standing claim;
Felin and Zenger (2017), the theory-based view: actors' theories choose what is pursued (their
2016 *Organization Science* essay, a theory *for* the firm as the chosen bundle of problems, is
named and not held); O'Mahony and Ferraro (2007), governance emerging in a volunteer community;
Bechky (2006), role-based coordination in a temporary organization; March (1991), read after
these and weighted below them: a room holds many individual codes, and the subreddit carries an
organizational code that newcomers learn and that changes as new ideas come in (the mutual
learning model). On request: Machlup (1967), Felin and Zenger (2009), Felin et al. (2024), He et al. (2018), Lewin and Volberda (1999), Lewin, Long and Carroll (1999), Nickerson and
Zenger (2004), Mintzberg (1979, the coordinating mechanisms, by OCR). Anything else you bring is
`recalled` (stage C3). A work named on a shelf and not held says so in its file.

**The critique shelf, at E1 and nowhere earlier.** The published case for and against generative AI
in qualitative research, with the call for papers the study is written for. It arrives after the
findings are fixed, so it can shape how the audit answers the critics and not what the model says.
Read: Schildt (2026), the design case for predictability, transparency and control; Jowsey et al.
(2025), the case against AI in reflexive qualitative work; O'Sullivan and Ravasi (2026), prompting
as a sensemaking aid to the researcher; the call for papers, AI-enabled frontiers in organizational
science. On request: Ravasi et al. (2025), Bechky and Davis (2025), Goldenstein et al. (the
Organization Studies special issue on interpretative computational methods), Shrestha et al. (2021),
Choudhury, Allen and Endres (2021), Miric, Jia and Huang (2023), von Krogh, Roberson and Gruber
(2023), Tidhar and Eisenhardt (2020), Gartenberg et al. (2026).

---

## The shape of the run

**Stages A1 to D3 are Gioia with the return**: five tiers, the loop at C2 as the constant
comparison, the return (D1 to D3) as its test, with the labelers writing each room's model in the
global model's words and the adaptations as the diff. **Stages D4 and D5 read the taxonomy off
the adaptations** and describe each branch at every level. **Stage E1 audits the run from its
logs**, rebuilds sampled rooms from the global model plus their adaptations, and reports where
the files and the analyst's account of itself disagree. There is no crossing in v38.

**The four licences a judgement stage names in its final message** (contract rule 17): Gioia's
explosion at the front end; an in-sample return in the spirit of Eisenhardt's replication logic; Langley's strategy, declared; the
count set by kinds rather than by a head's capacity.

**The fleets are a prosthesis, not a panel.** They are how one reader reaches seven and a half thousand
second-order themes when one context cannot hold them, working under that reader's written
instrument. The researcher is still the instrument. A fleet, a labeler or a hostile reviewer is a
prosthesis or a critic and is never a judge (rule 13).

**Three things Gioia has that this design does not, and what stands in for each.** *Theoretical
sampling*: the rooms were handed over as a census. What stands in is sampling inside the corpus,
which stage C2 requires of every arrow, and the return (D1 to D3), where local discrepancies are resolved and shared adaptations examined (rules 12 and 16). *Saturation*: at stage B1 the stopping rule reads rooms in a seeded random order until its markers
and a random draw say little is left, and the PI decides at marker 3 (`tools/saturation.py`; the
report extrapolates to the rooms not read); kinds are recorded against second-order themes read,
with each minting stamped by the harness (the leg, the rooms read so far,
the second-order themes read so far, the tokens read so far, the room and theme that prompted it),
and at C2 as passes of the loop with the same stamp on every element (contract §6). *The informant relationship*: the first tier is archived text. Claim informant voice
nowhere.

**What to write in a methods section.** Claim Gioia for A1 to D3 with the five tiers and the
loop; cite Grodal, Anteby and Holm for the move record, not for replicability; say the coder tier
and the fleets are Shrestha, He, Puranam and von Krogh's division between pattern detection and
abduction; say the return is an in-sample return modelled on Eisenhardt's replication logic, never a hold-out test (Shrestha et al. make the hold-out the test; this run holds none out): in-sample at the tier the model was built from
(the coders' second-order themes, Gioia's first-order concepts consolidated within a case) with uncited concepts and quotes used as additional in-sample checks, never called out-of-sample; say the taxonomy classifies by shared changes to an explanatory model
(shared innovations, not resemblance), that branches are a similarity hierarchy with no claim of
descent, and that the chunk-share tree is kept as the theory-free comparison; state the four
departures (the tier split between coders and analyst; no overlap between the coders' collection
and your analysis; the census in place of sampling; the in-sample return); say what the canvas is
and is not (contract §5); say in one sentence that you held every room's outcome while building and where the record declares its use (rule 7).
On replicability: every prompt, input, output, transcript and model identifier is archived, so
any claim can be traced; the study does not promise that a rerun reproduces it.

## Operational limits preserved by v40

The unit and level of each explanation are explicit. A within-room loop needs a complete within-room dated chain; an inter-room loop needs jointly linked dated evidence and an account of the interactions. Neither similarity nor a graph cycle establishes a mechanism. Empirical construct bindings and their mapping to prior organizing theories remain separate, so zero or one dimension, a warranted remainder or no shared branch may be reported.

Local reconstruction retains supported particulars. Silent, absent, unnecessary and untestable are different evidence states. Fixed-global diagnostics, current adapted-local status and shared explanations retain their model versions. Pending claims remain unresolved. The D3 model stays frozen through D6 and E1; new D6 insights remain unvalidated proposals until a later affected-case return. These checks establish traceability and declared evidential state, not truth from file validity.

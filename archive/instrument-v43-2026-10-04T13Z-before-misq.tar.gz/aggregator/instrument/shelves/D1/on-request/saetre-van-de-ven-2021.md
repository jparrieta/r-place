# Sætre and Van de Ven (2021), Generating theory by abduction

Not held on this shelf: the run has the name of this work and not its text. If you use it, work from what you know of it, mark the use `recalled` with author, year and the claim you attribute (stage 08), and say so where you use it. The title above is as recalled by the handler and was not checked against the work.

# Makadok, Burton and Barney (2018), A practical guide for making theory contributions in strategic management

Not held on this shelf: the run has the name of this work and not its text. If you use it, work from what you know of it, mark the use `recalled` with author, year and the claim you attribute (stage 08), and say so where you use it. The title above is as recalled by the handler and was not checked against the work.

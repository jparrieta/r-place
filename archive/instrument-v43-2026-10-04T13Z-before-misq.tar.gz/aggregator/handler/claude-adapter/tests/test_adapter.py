#!/usr/bin/env python3
"""The adapter's offline tests: a stand-in CLI (fake_stream_claude.py) and a small run that carries the
real harness's protocol_guard.py, so the session bookkeeping (prepare, confirm, preclose) is the
harness's own. No model is called and nothing outside a temporary folder is written.
    python3 aggregator/handler/claude-adapter/tests/test_adapter.py
"""
import fcntl
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ADAPTER = HERE.parent
HARNESS = Path(os.environ.get('ADAPTER_TEST_HARNESS') or ADAPTER.parent / 'claude')   # the harness beside it
FAKE = HERE / 'fake_stream_claude.py'


def load(name):
    spec = importlib.util.spec_from_file_location('adapter_test_' + name, ADAPTER / (name + '.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


S = load('stream')
A = load('actor')

STEP = '''#!/usr/bin/env bash
set -eu
RUN="$(cd "$(dirname "$0")/../.." && pwd -P)"; LEG="$1"
python3 "$RUN/CONTROL/harness/protocol_guard.py" prepare "$RUN" "A1.$LEG" "fake-cli"
printf 'Stage A1, leg %s. Do the work, then stop.\\n' "$LEG" > "$RUN/CONTROL/next_prompt.txt"
echo "Prepared"
'''
CLOSE = '''#!/usr/bin/env bash
set -eu
RUN="$(cd "$(dirname "$0")/../.." && pwd -P)"; NN="$1"; LEG="$2"; FORCE=0
for a in "$@"; do [ "$a" = --force ] && FORCE=1; done
echo "close $*" >> "$RUN/CONTROL/close-calls.log"
python3 "$RUN/CONTROL/harness/protocol_guard.py" confirm "$RUN"
python3 "$RUN/CONTROL/harness/protocol_guard.py" preclose "$RUN" "$NN.$LEG" "$FORCE" 0
mkdir -p "$RUN/CONTROL/snapshots/$NN.$LEG"; echo closed > "$RUN/CONTROL/snapshots/$NN.$LEG/COMMITTED"
echo "closed $NN.$LEG"
'''


class Run:
    """A temporary repository with one run in aggregator/runs, and the controller's data folder."""
    def __init__(self, turns):
        self.t = Path(tempfile.mkdtemp(prefix='adapter-test-'))
        self.run = self.t / 'repo/aggregator/runs/test-run'
        c = self.run / 'CONTROL'
        (c / 'harness/validation_tools').mkdir(parents=True)
        (c / '.cc').mkdir()
        (self.run / '00_GIVE-THE-AGENT/out').mkdir(parents=True)
        shutil.copy(HARNESS / 'protocol_guard.py', c / 'harness/protocol_guard.py')
        shutil.copy(HARNESS / 'settings.template.json', c / 'settings.template.json')
        (c / 'harness/step.sh').write_text(STEP)
        (c / 'harness/close.sh').write_text(CLOSE)
        (c / 'harness/validation_tools/validate.py').write_text('import sys\nsys.exit(0)\n')
        (c / 'arm.json').write_text(json.dumps({'A1': {'analyst': 'claude-test-model', 'effort': 'medium'}}))
        (c / 'RUN.json').write_text('{}\n')
        (c / '.cc/.claude.json').write_text('{}\n')
        self.data = self.t / 'data'
        os.environ['RPLACE_ADAPTER_DATA'] = str(self.data)
        self.scenario = self.t / 'scenario.json'
        self.scenario.write_text(json.dumps({'turns': turns}))
        os.environ['FAKE_SCENARIO'] = str(self.scenario)
        # the stand-in runs through a launcher of its own: the test folder may not allow executing it
        self.exe = self.t / 'bin/claude'
        self.exe.parent.mkdir()
        self.exe.write_text('#!/bin/sh\nexec "%s" "%s" "$@"\n' % (sys.executable, FAKE))
        self.exe.chmod(0o755)

    def actor(self, name='claude-test-1', leg='A1a'):
        A.create(name, self.run, leg, executable=str(self.exe))
        return A.ClaudeActor(name)

    def events(self, name='claude-test-1'):
        p = self.data / 'actors' / name / 'events.jsonl'
        return [json.loads(x)['native'] for x in p.read_text().splitlines()] if p.exists() else []

    def calls(self):
        p = self.run / 'CONTROL/.cc/stream_calls.jsonl'
        return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []

    def close(self):
        shutil.rmtree(self.t, ignore_errors=True)


def until(fn, timeout=15):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = fn()
        if v:
            return v
        time.sleep(0.05)
    raise AssertionError('condition not met in %ss' % timeout)


class TranslatorTest(unittest.TestCase):
    def test_streamed_and_whole_text_share_one_item(self):
        t = S.Translator('sid', 'turn')
        out = []
        for m in ({'type': 'stream_event', 'event': {'type': 'message_start', 'message': {'id': 'm1'}}},
                  {'type': 'stream_event', 'event': {'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'thinking'}}},
                  {'type': 'stream_event', 'event': {'type': 'content_block_start', 'index': 1, 'content_block': {'type': 'text'}}},
                  {'type': 'stream_event', 'event': {'type': 'content_block_delta', 'index': 1, 'delta': {'type': 'text_delta', 'text': 'Hel'}}},
                  {'type': 'stream_event', 'event': {'type': 'content_block_delta', 'index': 1, 'delta': {'type': 'text_delta', 'text': 'lo'}}},
                  {'type': 'assistant', 'message': {'id': 'm1', 'content': [{'type': 'thinking', 'thinking': 'secret'}]}},
                  {'type': 'assistant', 'message': {'id': 'm1', 'content': [{'type': 'text', 'text': 'Hello'}]}}):
            out += t.feed(m)
        deltas = [p for m, p in out if m == 'item/agentMessage/delta']
        whole = [p['item'] for m, p in out if m == 'item/completed']
        self.assertEqual([d['delta'] for d in deltas], ['Hel', 'lo'])
        self.assertEqual(len(whole), 1)
        self.assertEqual(whole[0]['id'], deltas[0]['itemId'])
        self.assertNotIn('secret', json.dumps(out))

    def test_tools_helpers_and_notes(self):
        t = S.Translator('sid', 'turn')
        out = t.feed({'type': 'assistant', 'message': {'id': 'm', 'content': [
            {'type': 'tool_use', 'id': 'b1', 'name': 'Bash', 'input': {'command': 'ls out'}},
            {'type': 'tool_use', 'id': 'h1', 'name': 'Agent', 'input': {'description': 'count rooms', 'prompt': 'Count the rooms in store/rooms.jsonl.', 'subagent_type': 'general-purpose'}}]}})
        self.assertEqual(out[0][1]['item']['command'], 'Bash: ls out')
        self.assertEqual(out[0][1]['item']['type'], 'commandExecution')
        self.assertIn('Count the rooms', out[1][1]['item']['aggregatedOutput'])
        out = t.feed({'type': 'user', 'message': {'content': [{'type': 'text', 'text': 'Count the rooms in store/rooms.jsonl.'}]}, 'parent_tool_use_id': 'h1'})
        self.assertEqual(out, [])   # the same prompt is already on the helper's row
        out = t.feed({'type': 'assistant', 'message': {'id': 'x', 'content': [{'type': 'tool_use', 'id': 'r1', 'name': 'Read', 'input': {'file_path': 'store/rooms.jsonl'}}]}, 'parent_tool_use_id': 'h1'})
        self.assertTrue(out[0][1]['item']['command'].startswith('Helper "count rooms"'))
        out = t.feed({'type': 'user', 'message': {'content': [{'type': 'tool_result', 'tool_use_id': 'b1', 'content': [{'type': 'text', 'text': 'a\nb'}], 'is_error': True}]}})
        self.assertEqual(out[0][1]['item']['status'], 'failed')
        self.assertEqual(out[0][1]['item']['aggregatedOutput'], 'a\nb')
        out = t.feed({'type': 'user', 'message': {'content': [{'type': 'tool_result', 'tool_use_id': 'h1', 'content': '705 rooms'}]}})
        self.assertIn('705 rooms', out[0][1]['item']['aggregatedOutput'])
        self.assertIn('Count the rooms', out[0][1]['item']['aggregatedOutput'])
        self.assertEqual(t.feed({'type': 'system', 'subtype': 'compact_boundary'})[0][1]['item']['command'], 'Context compacted')
        self.assertEqual(t.feed({'type': 'system', 'subtype': 'permission_denied', 'tool_name': 'Write'})[0][1]['item']['status'], 'failed')
        self.assertEqual(t.feed({'type': 'tool_progress'}), [])
        self.assertEqual(t.feed({'type': 'result', 'subtype': 'success'}), [])
        self.assertEqual(t.result['subtype'], 'success')


class HookTest(unittest.TestCase):
    def setUp(self):
        self.inbox = Path(tempfile.mkdtemp(prefix='adapter-inbox-'))

    def tearDown(self):
        shutil.rmtree(self.inbox, ignore_errors=True)

    def hook(self, payload):
        r = subprocess.run([sys.executable, str(ADAPTER / 'inbox_hook.py'), str(self.inbox)], input=payload,
                           capture_output=True, text=True, timeout=30)
        self.assertEqual(r.returncode, 0)
        return r.stdout

    def test_delivers_once_and_never_to_a_helper(self):
        self.assertEqual(self.hook('{}'), '')
        for i, kind in enumerate(('message', 'answer')):
            (self.inbox / ('2026100%d-x.json' % i)).write_text(json.dumps({'id': str(i), 'kind': kind, 'text': 'text %d' % i, 'utc': 'now'}))
        self.assertEqual(self.hook(json.dumps({'agent_id': 'a1', 'tool_name': 'Read'})), '')
        out = json.loads(self.hook(json.dumps({'tool_name': 'Bash', 'tool_use_id': 't1', 'session_id': 's'})))
        ctx = out['hookSpecificOutput']['additionalContext']
        self.assertEqual(out['hookSpecificOutput']['hookEventName'], 'PostToolUse')
        self.assertIn('Message from the principal investigator', ctx)
        self.assertIn('text 0', ctx)
        self.assertIn('text 1', ctx)
        self.assertEqual(len(list((self.inbox / 'delivered').glob('*.json'))), 2)
        self.assertEqual(self.hook(json.dumps({'tool_name': 'Bash'})), '')
        self.assertEqual(self.hook('not json'), '')


class LifecycleTest(unittest.TestCase):
    def tearDown(self):
        self.r.close()

    def test_a_turn_end_to_end_and_the_harness_close(self):
        self.r = Run([[{'say': 'Reading the head.'}, {'tool': 'Bash', 'input': {'command': 'cat out/_head.md'}, 'output': 'head'},
                       {'thinking': 'private'}, {'say': 'Leg done.'}],
                      [{'say': 'Second turn.'}]])
        a = self.r.actor()
        st = json.loads((self.r.data / 'actors/claude-test-1/state.json').read_text())
        self.assertEqual((st['backend'], st['label'], st['model'], st['effort'], st['mode']),
                         ('claude', 'A1.A1a', 'claude-test-model', 'medium', 'fresh'))
        self.assertEqual(st['runtime']['flags'], list(A.OPTIONAL))
        first = (self.r.data / 'actors/claude-test-1/first-message.txt').read_text()
        a.message(first)
        c = self.r.run / 'CONTROL'
        self.assertTrue((c / 'active_launch.json').exists())
        with (c / '.protocol.lock').open('a') as f:
            with self.assertRaises(BlockingIOError):
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        a.wait(30)
        self.assertEqual((a.state['status'], a.state['boundary']), ('idle', 'completed'))
        self.assertFalse((c / 'active_launch.json').exists())
        self.assertEqual(json.loads((c / 'last_launch_exit.json').read_text())['exit_code'], 0)
        self.assertEqual(json.loads((c / 'sessions.json').read_text())['A1.A1a']['session_id'], a.state['session_id'])
        self.assertTrue(a.state['confirmed'])
        call = self.r.calls()[0]
        argv = call['argv']
        for k, v in (('--output-format', 'stream-json'), ('--permission-mode', 'dontAsk'), ('--session-id', a.state['session_id']),
                     ('--model', 'claude-test-model'), ('--effort', 'medium'), ('--permission-prompts', 'none')):
            self.assertEqual(argv[argv.index(k) + 1], v)
        for f in ('-p', '--verbose', '--include-partial-messages', '--forward-subagent-text', '--strict-mcp-config', '--settings'):
            self.assertIn(f, argv)
        self.assertEqual(argv[-1], first)
        self.assertEqual(call['env']['CLAUDE_CODE_PROJECT_DIR_NAME'], 'run')
        self.assertEqual(call['env']['CLAUDE_CODE_DISABLE_AUTO_MEMORY'], '1')
        self.assertTrue(call['cwd'].endswith('00_GIVE-THE-AGENT'))
        methods = [e['method'] for e in self.r.events()]
        for m in ('item/completed', 'turn/started', 'item/agentMessage/delta', 'item/started', 'turn/completed'):
            self.assertIn(m, methods)
        texts = [e['params']['item'].get('text') for e in self.r.events() if e['method'] == 'item/completed'
                 and e['params']['item']['type'] == 'agentMessage']
        self.assertEqual(texts, ['Reading the head.', 'Leg done.'])
        self.assertNotIn('private', json.dumps(self.r.events()))
        self.assertEqual(a.final(), 'Leg done.')
        cmd = json.loads(next((self.r.data / 'actors/claude-test-1/turns').glob('*/command.json')).read_text())
        self.assertNotIn(first, json.dumps(cmd))
        # the next message resumes the leg's own session
        a.message('One more thing.')
        a.wait(30)
        argv = self.r.calls()[1]['argv']
        self.assertEqual(argv[argv.index('--resume') + 1], a.state['session_id'])
        # the harness's own preclose accepts what the adapter left: a finished turn and an exited launcher
        receipt = a.checkpoint()
        self.assertEqual(receipt['checkpoint'], 'A1.A1a')
        status = json.loads((c / 'close-status-A1.A1a.json').read_text())
        self.assertTrue(status['completed_turn'] and status['launcher_exited'] and status['complete'])
        self.assertEqual(a.state['status'], 'saved')

    def test_a_message_mid_turn_reaches_the_analyst_beside_a_tool_result(self):
        self.r = Run([[{'tool': 'Bash', 'input': {'command': 'sleep 1'}, 'output': '', 'sleep': 1.0},
                       {'wait_context': 15}, {'say': 'Back to the leg.'}]])
        a = self.r.actor()
        a.message('Start.')
        r = a.message('Use the h73 cut, not h78.')
        self.assertIn('queued', r)
        a.wait(30)
        heard = [e['params']['item']['text'] for e in self.r.events() if e['method'] == 'item/completed'
                 and e['params']['item']['type'] == 'agentMessage' and e['params']['item']['text'].startswith('heard:')]
        self.assertTrue(heard and 'Use the h73 cut, not h78.' in heard[0])
        self.assertIn('Message from the principal investigator', heard[0])
        receipts = [json.loads(p.read_text()) for p in (self.r.data / 'actors/claude-test-1/inbox/delivered').glob('*.json')]
        self.assertEqual([x['via'] for x in receipts], ['hook'])
        self.assertTrue(any(e['params'].get('item', {}).get('command', '').startswith('Message delivered')
                            for e in self.r.events() if e['method'] == 'item/completed'))
        users = [e['params']['item'] for e in self.r.events() if e['method'] == 'item/completed'
                 and e['params']['item']['type'] == 'userMessage']
        self.assertEqual([u['content'][0]['text'] for u in users], ['Start.', 'Use the h73 cut, not h78.'])

    def test_a_message_no_tool_call_picks_up_opens_the_next_turn(self):
        self.r = Run([[{'tool': 'Bash', 'input': {'command': 'true'}, 'output': ''}, {'pause': 1.5}, {'say': 'Done.'}],
                      [{'say': 'Answering J.'}]])
        a = self.r.actor()
        a.message('Start.')
        until(lambda: len([e for e in self.r.events() if e['method'] == 'item/completed'
                           and e['params']['item']['type'] == 'commandExecution']) >= 1)
        a.message('Did you check the frame?')
        until(lambda: len(self.r.calls()) == 2)
        a.wait(30)
        argv = self.r.calls()[1]['argv']
        self.assertIn('Did you check the frame?', argv[-1])
        self.assertEqual(argv[argv.index('--resume') + 1], a.state['session_id'])
        self.assertEqual([e['params']['turn']['status'] for e in self.r.events() if e['method'] == 'turn/completed'],
                         ['completed', 'completed'])
        receipts = [json.loads(p.read_text()) for p in (self.r.data / 'actors/claude-test-1/inbox/delivered').glob('*.json')]
        self.assertEqual([x['via'] for x in receipts], ['prompt'])

    def test_a_question_is_answered_from_the_panel(self):
        ask = {'id': 'QA1-001', 'question': 'Which cut counts?', 'assumption': 'I use h73 meanwhile.'}
        self.r = Run([[{'tool': 'Bash', 'input': {'command': 'python3 tools/mem.py ask ...'}, 'output': 'asked', 'ask': ask},
                       {'wait_context': 20}, {'say': 'Done.'}]])
        a = self.r.actor()
        a.message('Start.')
        q = until(lambda: json.loads((self.r.data / 'actors/claude-test-1/state.json').read_text()).get('questions'))
        self.assertEqual((q[0]['requestKey'], q[0]['isBlocking']), ('QA1-001', False))
        self.assertIn('Which cut counts?', q[0]['questions'][0]['question'])
        self.assertIn('I use h73 meanwhile.', q[0]['questions'][0]['question'])
        with self.assertRaises(A.Error):
            a.answer('QA1-001', {'answer': '  '})
        r = a.answer('QA1-001', {'answer': 'h73 counts.'})
        self.assertEqual(r['answered'], 'QA1-001')
        a.wait(30)
        ag = self.r.run / '00_GIVE-THE-AGENT'
        self.assertEqual((ag / 'out/_answers/QA1-001.md').read_text(), 'h73 counts.\n')
        heard = [e['params']['item']['text'] for e in self.r.events() if e['method'] == 'item/completed'
                 and e['params']['item']['type'] == 'agentMessage' and e['params']['item']['text'].startswith('heard:')]
        self.assertTrue(heard and 'answered QA1-001' in heard[0] and 'h73 counts.' in heard[0])
        methods = [e['method'] for e in self.r.events()]
        self.assertIn('item/tool/requestUserInput', methods)
        self.assertIn('rplace/questionAnswered', methods)
        self.assertEqual(a.state['questions'], [])
        with self.assertRaises(A.Error):
            a.answer('QA1-001', {'answer': 'again'})

    def test_stop_interrupts_and_close_needs_force(self):
        self.r = Run([[{'tool': 'Bash', 'input': {'command': 'sleep 20'}, 'output': '', 'sleep': 20}]])
        a = self.r.actor()
        a.message('Start.')
        until(lambda: self.r.calls())
        time.sleep(0.5)
        a.interrupt()
        self.assertEqual((a.state['status'], a.state['boundary']), ('interrupted', 'interrupted'))
        self.assertNotEqual(json.loads((self.r.run / 'CONTROL/last_launch_exit.json').read_text())['exit_code'], 0)
        with self.assertRaises(A.Error):
            a.checkpoint()
        receipt = a.checkpoint(interrupt=True)
        self.assertTrue(receipt['forced'])
        self.assertIn('--force', (self.r.run / 'CONTROL/close-calls.log').read_text())

    def test_helpers_prompts_and_pause(self):
        self.r = Run([[{'helper': {'description': 'count rooms', 'prompt': 'Count the rooms. Report the number only.',
                                   'subagent_type': 'general-purpose'}, 'reply': '705'}, {'say': 'Done.'}]])
        a = self.r.actor()
        a.message('Start.')
        a.wait(30)
        rows = [e['params']['item'] for e in self.r.events() if e['method'] in ('item/started', 'item/completed')]
        helper = [x for x in rows if x.get('command', '').startswith('Helper (general-purpose): count rooms')]
        self.assertTrue(helper and 'Count the rooms. Report the number only.' in helper[0]['aggregatedOutput'])
        self.assertIn('705', helper[-1]['aggregatedOutput'])
        self.assertTrue(any(x.get('command', '').startswith('Helper "count rooms" · Read') for x in rows))
        self.assertTrue(any(x.get('command', '') == 'Helper "count rooms" says' for x in rows))
        r = a.pause()
        self.assertFalse(r['new_turn_started'])
        self.assertTrue((self.r.run / '00_GIVE-THE-AGENT/.pause').read_text().startswith('pause requested '))
        self.assertIn('pause-requested', (self.r.run / 'CONTROL/handover-events.log').read_text())


class PathsTest(unittest.TestCase):
    def test_no_full_path_in_the_adapter(self):
        # verify.sh's pattern, built from parts so that this line does not match it
        roots = '|'.join('/%s/' % r for r in ('Users', 'home', 'sessions', 'mnt', 'private', 'root', 'tmp', 'var/folders'))
        pat = re.compile(r'(^|[\s"\'(=`])(' + roots + '|~/mnt/|~/Jail/|[A-Z]:\\\\)')
        for p in list(ADAPTER.glob('*.py')) + list(ADAPTER.glob('*.md')) + list(HERE.glob('*.py')):
            for i, line in enumerate(p.read_text().splitlines(), 1):
                self.assertIsNone(pat.search(line), '%s:%d' % (p.name, i))


if __name__ == '__main__':
    unittest.main(verbosity=2, warnings='ignore')   # the harness's own files leave ResourceWarnings

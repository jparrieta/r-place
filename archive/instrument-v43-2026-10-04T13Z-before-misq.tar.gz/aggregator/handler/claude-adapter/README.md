# Claude adapter for the OpenAI controller

Target length: under 950 words.

Status, 2026-10-04: draft for v44. No v43 run uses it, and no harness file changed. It sits beside the harness, not in it: `build.sh` fingerprints every file under `aggregator/handler/claude`, and a v43 rebuild must keep its fingerprint. The offline tests pass (10 of 10). It has not met the real CLI yet: `probe.py` does that on the Mac. The panel cannot reach it until OpenAI adds one hook to `actors.load` (last section).

## Why

J, 2026-10-03: one controller and one phone panel for both arms. He wants to talk to the analyst while a leg runs, read every prompt it writes, and the analyst should know someone is on its side. A terminal leg needs him at the Mac.

## Files

| File | What it does |
|---|---|
| `actor.py` | `ClaudeActor`, the controller's actor interface for a Claude leg, and `create()` |
| `stream.py` | `Translator`: Claude stream-json into the panel's event names |
| `inbox_hook.py` | PostToolUse hook: gives the analyst J's messages in the middle of a turn |
| `probe.py` | live check with the installed CLI, in a scratch folder |
| `tests/` | offline tests and a stand-in CLI |

## How a leg runs

1. `create(actor, run, leg)` runs the run's own `step.sh LEG --prepare`, reads `pending_launch.json` and `next_prompt.txt`, and writes the store: `state.json` with `backend: claude`, `first-message.txt`, `inbox/`.
2. `message(text)` on an idle actor opens a turn: one process, `claude -p --output-format stream-json --verbose`, the session opened, forked or resumed as `step.sh` prepared it, `--settings` with the hook, `--strict-mcp-config --permission-mode dontAsk -n leg-LABEL --model M --effort E -- PROMPT`, in `00_GIVE-THE-AGENT`, with the environment and settings rendering of `protocol_guard.launch`. `--include-partial-messages`, `--forward-subagent-text` and `--permission-prompts none` are added only when `claude --help` lists them.
3. During a turn the adapter holds `CONTROL/.protocol.lock` and writes `active_launch.json`, as `launch.sh` does; after it, `last_launch_exit.json`. After the first turn it calls the harness's `confirm()`. So `close.sh` treats an adapter leg as a terminal leg; the tests check this against the real `preclose()`.
4. The raw stream goes to `turns/<id>/stream.jsonl`. A follower thread translates each line and appends the events to `events.jsonl`.
5. A message sent during a turn goes to `inbox/`. The hook adds it beside the analyst's next tool result, never a helper's. If no tool call picks it up, it opens the next turn on the same session.
6. A `mem.py ask` line in `out/asks.jsonl` becomes a panel question with `isBlocking: false`, shown while a turn runs. `answer()` writes `out/_answers/<id>.md`, where `mem.py asks` reads it, and sends the answer through the inbox.
7. `interrupt()` sends SIGINT. `pause()` writes `.pause`, as `pause.sh` does, and tells the analyst through the inbox. `checkpoint()` runs `close.sh NN LEG`, with `--force` after a stop.
8. The process runs in its own session. If the controller restarts during a turn, `open()` follows the same process from its saved offset.

## What the panel shows

| Claude stream | Panel event |
|---|---|
| `system/init` | none; kept as `init.json` |
| top-level `text_delta` | `item/agentMessage/delta` |
| top-level text block | `item/completed`, `agentMessage`, the same id as its deltas |
| `tool_use` | `item/started`: Bash with its command, file tools with the path, Agent or Task as `Helper (type): description` with the full prompt |
| `tool_result` | `item/completed` with the output; `failed` when `is_error` |
| anything with `parent_tool_use_id` | rows marked `Helper "description"` |
| thinking | never shown |
| compaction, permission refusals | rows |
| `result` | `turn/completed`: completed, failed or interrupted |
| `mem.py ask`, an answer | `item/tool/requestUserInput`, `rplace/questionAnswered` |

## Not verified

- The stream's shapes against the live CLI (2.1.288 on the Mac). They follow the headless documentation and `--help` of 2.1.289.
- That the CLI accepts `--` before the prompt, and merges hooks from `--settings` with the run's project hooks. The hooks documentation says hooks merge across settings levels; it does not name the flag.
- That a hook can write the receipt outside the sandbox. The hooks run in the CLI, not in the sandboxed Bash tool, as far as I know.
- Following a turn after a controller restart: written, not tested.

`probe.py` checks the first three on the Mac, in three short turns with your own login.

## Run

```
python3 aggregator/handler/claude-adapter/tests/test_adapter.py
python3 aggregator/handler/claude-adapter/probe.py --model sonnet
```

## What OpenAI would add (asked 2026-10-04)

1. In `actors.load`: when `state['backend'] == 'claude'`, load `aggregator/handler/claude-adapter/actor.py` by path and return `ClaudeActor(actor)`.
2. The study layer: for a Claude run, prepare calls `create()`, close calls `checkpoint()`, and one study record names the actor of each leg.
3. The panel: a question with `isBlocking: false` could be answered when no turn runs. Until then the adapter shows open questions only during a turn, so the panel never locks.
4. Cards: the server writes them to `workspace/out/inbox`, which a Claude actor does not have; the card text also goes through `message()`, so it arrives.
5. The data folder: `.rplace-runtime` sits beside both repositories, so rplace and r-place share actor names and stores.

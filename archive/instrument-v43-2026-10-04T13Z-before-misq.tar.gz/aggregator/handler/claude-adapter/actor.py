"""A Claude leg as an actor behind the OpenAI controller. Draft for v44: no v43 run uses it.

The controller (aggregator/handler/codex/runtime, OpenAI's) keeps one store per actor in its data
folder: state.json, events.jsonl, messages.jsonl, and talks to an actor through one interface:
open, release, message, wait, answer, interrupt, pause, checkpoint, final, save, and a module-level
create. ClaudeActor offers that interface with state['backend'] == 'claude'. OpenAI's actors.load
would hand such a store to load() below; that one line is theirs to add (orchestrator message
2026-10-04). The adapter sits beside the harness, not in it: build.sh fingerprints every file under
aggregator/handler/claude, and a v43 rebuild must keep its fingerprint.

What differs from a Codex actor, on purpose:
- The analyst works in the run's own folder, in place, as in a terminal leg. The run's harness
  (CONTROL/harness) prepares the leg (step.sh --prepare), renders its settings, confirms its session
  and closes it (close.sh), exactly as for a terminal leg. The store keeps no copy of the folder.
- A turn is one headless process, `claude -p --output-format stream-json`, the prompt as its
  argument, the leg's session opened, forked or resumed as step.sh prepared it. Its raw stream goes to
  turns/<id>/stream.jsonl; a follower thread turns each line into panel events (stream.py).
- A message sent while a turn runs goes into the store's inbox. The adapter's PostToolUse hook
  (inbox_hook.py, passed with --settings) gives it to the analyst beside its next tool result. One
  that no tool call picks up opens the next turn.
- A question the analyst asks with `mem.py ask` is shown as a question that does not block
  (isBlocking false). The answer is written to out/_answers/<id>.md, where `mem.py asks` reads it,
  and reaches the analyst through the inbox.
- A checkpoint is the harness close: close.sh LEG (with --force after a stop).
"""
from pathlib import Path
import contextlib
import datetime
import fcntl
import hashlib
import importlib.util
import io
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]          # aggregator/handler/claude-adapter -> the repository
FORMAT = 'rplace-claude-v1'
OPTIONAL = ('--include-partial-messages', '--forward-subagent-text', '--permission-prompts')
ASK = re.compile(r'Q[A-Z0-9]{1,4}-\d{3,}')


class Error(RuntimeError):
    pass


def _sibling(name):
    """stream.py beside this file, whether the controller loads this file by path or as a package."""
    key = '_claude_adapter_' + name
    if key not in sys.modules:
        spec = importlib.util.spec_from_file_location(key, HERE / (name + '.py'))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        sys.modules[key] = mod
    return sys.modules[key]


stream = _sibling('stream')


# ---- small helpers, written as the controller's common.py writes them ----------------------------
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def identity(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,119}', value) or '..' in value:
        raise Error('Invalid identifier: ' + repr(value))
    return value


def read(path, default=None):
    p = Path(path)
    return json.loads(p.read_text()) if p.exists() else default


def atomic(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    b = data.encode() if isinstance(data, str) else data
    q = p.with_name('.' + p.name + '.' + uuid.uuid4().hex)
    try:
        with q.open('xb') as f:
            f.write(b)
            f.flush()
            os.fsync(f.fileno())
        os.replace(q, p)
    finally:
        q.unlink(missing_ok=True)


def write(path, value):
    atomic(path, json.dumps(value, indent=2, ensure_ascii=False) + '\n')


@contextlib.contextmanager
def flock(path, wait=False):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a') as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        except BlockingIOError:
            raise Error('Resource is busy: ' + str(p))
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def append(path, **data):
    """One line of events.jsonl or messages.jsonl, as the controller's event() writes it."""
    with flock(str(path) + '.lock', wait=True):
        with Path(path).open('a') as f:
            f.write(json.dumps({'utc': now(), **data}, ensure_ascii=False) + '\n')
            f.flush()
            os.fsync(f.fileno())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def process_identity(pid):
    """Start time and command of a process, as the controller's native.process_identity reads them."""
    ps = shutil.which('ps') or 'ps'
    r = subprocess.run([ps, '-p', str(int(pid)), '-o', 'lstart=', '-o', 'comm='], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None


def tail(text, n=1200):
    text = text or ''
    return text if len(text) <= n else '...' + text[-n:]


def data_dir():
    """The controller's data folder: its common.DATA when that module loads, else the same rule."""
    v = os.environ.get('RPLACE_ADAPTER_DATA')     # the adapter's own tests only
    if v:
        return Path(v)
    try:
        spec = importlib.util.spec_from_file_location('_rplace_codex_common',
                                                      REPO / 'aggregator/handler/codex/runtime/common.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return Path(mod.DATA)
    except Exception:
        return REPO.parent / '.rplace-runtime'


def harness(run):
    """The run's own copy of protocol_guard.py (CONTROL/harness), loaded once per run."""
    p = Path(run) / 'CONTROL/harness/protocol_guard.py'
    if not p.is_file():
        raise Error('No Claude harness in this run: CONTROL/harness/protocol_guard.py is missing')
    name = '_claude_guard_' + hashlib.sha256(str(p.resolve()).encode()).hexdigest()[:12]
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        sys.modules[name] = mod
    return sys.modules[name]


def features(exe):
    """The CLI's version and which optional stream flags it offers (--help), so an older CLI runs."""
    def out(args):
        try:
            return subprocess.run([exe] + args, capture_output=True, text=True, timeout=60).stdout
        except (OSError, subprocess.TimeoutExpired):
            return ''
    helptext = out(['--help'])
    return {'version': (out(['--version']).strip().splitlines() or [''])[0],
            'flags': [f for f in OPTIONAL if f in helptext]}


def clean_env():
    env = os.environ.copy()
    env.pop('AGGREGATOR_LOCK_RUN', None)   # the harness scripts take the run's lock themselves
    return env


class Proc:
    """A turn's process: a child of this controller, or one found alive after a controller restart."""
    def __init__(self, pid, popen=None, ident=None):
        self.pid, self.popen, self.ident = pid, popen, ident

    def poll(self):
        if self.popen is not None:
            return self.popen.poll()
        return None if process_identity(self.pid) == self.ident else -1

    def signal(self, sig):
        try:
            os.kill(self.pid, sig)
        except ProcessLookupError:
            pass

    def wait(self, timeout):
        end = time.monotonic() + timeout
        while self.poll() is None:
            if time.monotonic() > end:
                return False
            time.sleep(0.2)
        return True


class Live:
    """What the controller's status reads for questions_live: server.p.poll()."""
    def __init__(self, proc):
        self.p = proc

    def close(self):
        pass


class ClaudeActor:
    def __init__(self, actor, data=None):
        self.data = Path(data) if data else data_dir()
        self.base = self.data / 'actors' / identity(actor)
        self.state = read(self.base / 'state.json')
        if not self.state:
            raise Error('Unknown actor ' + actor)
        if self.state.get('backend') != 'claude':
            raise Error('Not a Claude actor: ' + actor)
        self.guard = threading.RLock()
        self.condition = threading.Condition(self.guard)
        self.lease = None
        self.proc = None
        self.server = None
        self.runlock = None
        self.worker = None
        self.stop_requested = None
        self.rundir = Path(self.state['claude_run'])
        self.ag = self.rundir / '00_GIVE-THE-AGENT'
        self.inbox = self.base / 'inbox'
        self.seen = set()

    # ---- the store ------------------------------------------------------------------------------
    def save(self):
        write(self.base / 'state.json', self.state)

    def emit(self, method, **params):
        append(self.base / 'events.jsonl', native={'method': method, 'params': params})

    def note(self, key, head, text, status='completed'):
        self.emit('item/completed', threadId=self.state.get('thread_id'), turnId=self.state.get('active_turn_id'),
                  item={'type': 'dynamicToolCall', 'id': key, 'command': head, 'status': status,
                        'aggregatedOutput': stream.clip(text)})

    # ---- ownership ------------------------------------------------------------------------------
    def open(self):
        with self.guard:
            current = read(self.base / 'state.json', {})
            if current.get('evicted'):
                raise Error('Actor store is archived; restore its checkpoint as a new actor.')
            if self.lease:
                return self.state
            lease = flock(self.base / 'owner.lock')
            lease.__enter__()
            try:
                self.state = current or self.state
                self.seen = {p.name for p in (self.inbox / 'delivered').glob('*.json')}
                previous = read(self.base / 'native-process.json')
                alive = previous and process_identity(previous['pid']) == previous.get('identity')
                if alive and previous.get('turn') == self.state.get('active_turn_id'):
                    # the controller restarted during a turn: follow the same process to its end
                    self.lease = lease
                    self.attach(previous)
                    return self.state
                if alive:
                    raise Error('A Claude process of this actor is still running (pid %s) outside any recorded '
                                'turn. Inspect it before a second owner opens.' % previous['pid'])
                (self.base / 'native-process.json').unlink(missing_ok=True)
                if self.state.get('active_turn_id'):
                    self.state.update(active_turn_id=None, status='interrupted', boundary='interrupted', questions=[],
                                      error='The turn ended while no controller followed it. Its stream and the '
                                            'session transcript are kept; inspect before you continue.')
                    self.save()
                self.lease = lease
            except BaseException:
                lease.__exit__(None, None, None)
                raise
            return self.state

    def release(self):
        with self.guard:
            if self.proc and self.proc.poll() is None:
                return   # a live turn keeps its owner
            if self.lease:
                self.lease.__exit__(None, None, None)
                self.lease = None

    # ---- the inbox ------------------------------------------------------------------------------
    def queue(self, text, kind='message', item=None):
        mid = time.strftime('%Y%m%dT%H%M%S', time.gmtime()) + '-' + uuid.uuid4().hex[:8]
        write(self.inbox / (mid + '.json'), {'id': mid, 'kind': kind, 'text': text, 'utc': stamp(), 'item': item})
        return mid

    def undelivered(self):
        done = self.inbox / 'delivered'
        out = []
        for p in sorted(self.inbox.glob('*.json')):
            if not (done / p.name).exists():
                m = read(p)
                if isinstance(m, dict):
                    out.append((p, m))
        return out

    def receipts(self):
        """Show each message the hook delivered, once."""
        for p in sorted((self.inbox / 'delivered').glob('*.json')):
            if p.name in self.seen:
                continue
            self.seen.add(p.name)
            r = read(p, {})
            if r.get('via') == 'hook':
                self.note('delivered-' + p.stem, 'Message delivered beside the analyst\'s tool result',
                          'Delivered %s, after %s.' % (r.get('utc'), r.get('tool') or 'a tool call'))

    # ---- questions the analyst asks with mem.py ask ---------------------------------------------
    def asks(self):
        p = self.ag / 'out/asks.jsonl'
        rows = []
        if p.exists():
            for line in p.read_text(encoding='utf-8').splitlines():
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if isinstance(r, dict) and isinstance(r.get('id'), str) and ASK.fullmatch(r['id']):
                    rows.append(r)
        return rows

    def answered(self, qid):
        return (self.ag / 'out/_answers' / (qid + '.md')).exists()

    def surface(self, turn):
        """Every open question becomes a question of this turn. It does not block the analyst."""
        with self.guard:
            known = {q.get('requestKey') for q in self.state.get('questions', [])}
            changed = False
            for r in self.asks():
                qid = r['id']
                if qid in known or self.answered(qid):
                    continue
                text = '%s, leg %s, %s\n%s\n\nMeanwhile the analyst: %s' % (
                    qid, r.get('leg', '?'), r.get('t', ''), r.get('question', ''), r.get('assumption', ''))
                params = {'threadId': self.state.get('thread_id'), 'turnId': turn, 'requestId': qid,
                          'requestKey': qid, 'isBlocking': False,
                          'questions': [{'id': 'answer', 'header': qid, 'question': text}]}
                self.state.setdefault('questions', []).append(params)
                self.emit('item/tool/requestUserInput', **params)
                changed = True
            self.state['open_asks'] = [r['id'] for r in self.asks() if not self.answered(r['id'])]
            if changed:
                self.save()

    def answer(self, key, answers):
        with self.guard:
            rows = {r['id']: r for r in self.asks()}
            if key not in rows:
                raise Error('No question %s in out/asks.jsonl' % key)
            if self.answered(key):
                raise Error('%s is already answered: out/_answers/%s.md' % (key, key))
            if (not isinstance(answers, dict) or not answers
                    or any(not isinstance(v, str) or not v.strip() or len(v) > 20000 for v in answers.values())):
                raise Error('Supply one nonempty answer for every question')
            text = (answers.get('answer') or '\n\n'.join(answers.values())).strip()
            atomic(self.ag / 'out/_answers' / (key + '.md'), text + '\n')
            q = next((x for x in self.state.get('questions', []) if x.get('requestKey') == key), None)
            questions = q['questions'] if q else [{'id': 'answer', 'question': rows[key].get('question', '')}]
            self.state['questions'] = [x for x in self.state.get('questions', []) if x.get('requestKey') != key]
            self.state['open_asks'] = [x for x in self.state.get('open_asks', []) if x != key]
            self.emit('rplace/questionAnswered', requestKey=key, questions=questions, answers=answers)
            self.queue('The principal investigator answered %s.\nYour question: %s\nHis answer: %s\nThe answer is '
                       'also in `python3 tools/mem.py asks %s`. Revisit the work that rested on your assumption '
                       '(%s).' % (key, rows[key].get('question', ''), text, key, rows[key].get('assumption', '')),
                       kind='answer', item=key)
            self.save()
            return {'answered': key, 'new_turn_started': False, 'file': 'out/_answers/%s.md' % key,
                    'delivery': 'beside the next tool result' if self.state.get('active_turn_id')
                    else 'with the next turn'}

    # ---- turns ----------------------------------------------------------------------------------
    def message(self, text):
        if not isinstance(text, str) or not text.strip():
            raise Error('Message is empty')
        self.open()
        with self.guard:
            append(self.base / 'messages.jsonl', role='user', text=text)
            key = 'user-' + uuid.uuid4().hex[:12]
            self.emit('item/completed', threadId=self.state.get('thread_id'), turnId=self.state.get('active_turn_id'),
                      item={'type': 'userMessage', 'id': key, 'content': [{'type': 'text', 'text': text}]})
            if self.state.get('active_turn_id'):
                mid = self.queue(text, item=key)
                self.note('queued-' + mid, 'Message queued for the analyst',
                          'It reaches the analyst beside its next tool result. If the turn ends first, it opens '
                          'the next turn.')
                return {'queued': mid, 'turn': {'id': self.state['active_turn_id'], 'status': 'working'},
                        'new_turn_started': False}
            return self.start(text)

    @staticmethod
    def prompt(pending, text):
        """The turn's prompt: what waits in the inbox, then the new text."""
        parts = []
        for _, m in pending:
            if m.get('kind') == 'message':
                parts.append('Message from the principal investigator (%s):\n%s' % (m.get('utc', ''), m.get('text', '')))
            else:
                parts.append(m.get('text', ''))
        if text:
            parts.append(text)
        return '\n\n'.join(parts)

    def start(self, text):
        with self.guard:
            if self.proc and self.proc.poll() is None:
                raise Error('A turn is running')
            run, c = self.rundir, self.rundir / 'CONTROL'
            g = harness(run)
            label, sid = self.state['label'], self.state['session_id']
            path = g.transcript(run, sid)
            if path.exists():
                rows = g.messages(path)
                if not rows or not any(r.get('sessionId') == sid for r in rows):
                    raise Error('The session transcript holds nothing under its own id; preserve it for recovery')
                session = ['--resume', sid]
            elif self.state['mode'] == 'fork':
                session = ['--resume', self.state['parent_session'], '--fork-session', '--session-id', sid]
            elif self.state['mode'] in ('shared', 'resumed'):
                raise Error('The recorded transcript is missing; refusing a fresh replacement')
            else:
                session = ['--session-id', sid]
            env = clean_env()
            if env.get('ANTHROPIC_API_KEY') and not self.state.get('api_ok'):
                raise Error('ANTHROPIC_API_KEY is set; a subscription leg refuses it, as step.sh does without --api-ok')
            lock = (c / '.protocol.lock').open('a')
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                lock.close()
                raise Error('A handler operation or another launch holds this run (CONTROL/.protocol.lock)')
            try:
                g.settings(run, g.stage_of(label))
                model, ent = g.arm_for(run, label)
                g.seed_trust(run)
                pending = self.undelivered()
                body = self.prompt(pending, text)
                if not body.strip():
                    raise Error('Nothing to send')
                turn = uuid.uuid4().hex
                tdir = self.base / 'turns' / turn
                tdir.mkdir(parents=True)
                hooks = tdir / 'adapter-settings.json'
                write(hooks, {'hooks': {'PostToolUse': [{'matcher': '*', 'hooks': [{'type': 'command', 'command': ' '.join(
                    shlex.quote(x) for x in (sys.executable, str(HERE / 'inbox_hook.py'), str(self.inbox)))}]}]}})
                flags = set(self.state['runtime'].get('flags', []))
                cmd = [self.state['runtime']['executable'], '-p', '--output-format', 'stream-json', '--verbose']
                cmd += [f for f in ('--include-partial-messages', '--forward-subagent-text') if f in flags]
                cmd += session + ['--settings', str(hooks), '--strict-mcp-config', '--permission-mode', 'dontAsk']
                if '--permission-prompts' in flags:
                    cmd += ['--permission-prompts', 'none']
                cmd += ['-n', 'leg-' + label, '--model', model]
                if ent.get('effort'):
                    cmd += ['--effort', ent['effort']]
                cmd += ['--', body]
                env.update(CLAUDE_CONFIG_DIR=str(c / '.cc'), CLAUDE_CODE_PROJECT_DIR_NAME='run', STAGE=g.stage_of(label),
                           CLAUDE_CODE_SUBAGENT_MODEL=model, CLAUDE_CODE_DISABLE_AUTO_MEMORY='1')
                write(tdir / 'command.json', {'argv': cmd[:-1] + ['<prompt: prompt.txt>'], 'cwd': str(self.ag),
                                              'utc': now()})
                atomic(tdir / 'prompt.txt', body)
                write(c / 'active_launch.json', dict(self.state.get('pending') or {}, handler_pid=os.getpid(),
                                                     started_utc=now(), adapter_actor=self.state['id'], adapter_turn=turn))
                with (tdir / 'stream.jsonl').open('wb') as out, (tdir / 'stderr.log').open('wb') as err:
                    popen = subprocess.Popen(cmd, cwd=str(self.ag), env=env, stdin=subprocess.DEVNULL, stdout=out,
                                             stderr=err, start_new_session=True)
            except BaseException:
                (c / 'active_launch.json').unlink(missing_ok=True)
                fcntl.flock(lock, fcntl.LOCK_UN)
                lock.close()
                raise
            self.runlock = lock
            for p, m in pending:   # delivered with the prompt, now that the process runs
                write(self.inbox / 'delivered' / p.name, {'id': m.get('id'), 'via': 'prompt', 'utc': stamp(), 'turn': turn})
                self.seen.add(p.name)
            ident = None
            for _ in range(10):
                ident = process_identity(popen.pid)
                if ident:
                    break
                time.sleep(0.05)
            self.proc = Proc(popen.pid, popen, ident)
            self.server = Live(self.proc)
            write(self.base / 'native-process.json', {'pid': popen.pid, 'identity': ident, 'utc': now(), 'turn': turn,
                                                      'stream': str(tdir / 'stream.jsonl')})
            self.stop_requested = None
            self.state.update(active_turn_id=turn, status='working', error=None, leg_started=True,
                              turns=self.state.get('turns', 0) + 1)
            self.save()
            self.emit('turn/started', threadId=sid, turn={'id': turn, 'status': 'inProgress'})
            if text is None:
                self.note('followup-' + turn, 'Turn opened for messages no tool call picked up', body)
            self.surface(turn)
            self.worker = threading.Thread(target=self.follow, args=(turn, 0), daemon=True)
            self.worker.start()
            return {'turn': {'id': turn, 'status': 'working'}, 'new_turn_started': True}

    def attach(self, rec):
        """After a controller restart: follow a turn's process that is still alive."""
        turn = rec['turn']
        lock = (self.rundir / 'CONTROL/.protocol.lock').open('a')
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.runlock = lock
        except BlockingIOError:
            lock.close()
            self.note('attached-lock-' + turn, 'Run lock held elsewhere', 'A handler operation holds CONTROL/.protocol.lock '
                      'while this turn runs; the turn is followed without it.')
        self.proc = Proc(rec['pid'], None, rec.get('identity'))
        self.server = Live(self.proc)
        offset = int((read(self.base / 'turns' / turn / 'offset.json') or {}).get('offset', 0))
        self.note('attached-' + turn, 'Controller restarted; following the running turn again',
                  'pid %s, from byte %d of its stream' % (rec['pid'], offset))
        self.worker = threading.Thread(target=self.follow, args=(turn, offset), daemon=True)
        self.worker.start()

    def follow(self, turn, offset):
        tdir = self.base / 'turns' / turn
        t = stream.Translator(self.state.get('thread_id'), turn)
        buf, last_poll, ended = b'', 0.0, False
        try:
            with (tdir / 'stream.jsonl').open('rb') as f:
                f.seek(offset)
                while True:
                    chunk = f.read(1 << 16)
                    if chunk:
                        buf += chunk
                        *lines, buf = buf.split(b'\n')
                        for line in lines:
                            if line.strip():
                                self.line(t, line, tdir)
                        offset = f.tell() - len(buf)
                    if time.monotonic() - last_poll > 1:
                        last_poll = time.monotonic()
                        self.surface(turn)
                        self.receipts()
                        write(tdir / 'offset.json', {'offset': offset})
                    if not chunk:
                        if ended:          # the process had ended and its stream is drained
                            if buf.strip():
                                self.line(t, buf, tdir)
                            break
                        if self.proc.poll() is not None:
                            ended = True   # read once more: what it wrote before it ended
                            continue
                        time.sleep(0.1)
        except Exception as e:
            write(self.base / 'callback-error.json', {'error': repr(e), 'utc': now(), 'turn': turn})
        self.finish(turn, t, tdir)

    def line(self, t, raw, tdir):
        try:
            m = json.loads(raw)
        except ValueError:
            return self.note('unreadable-%s' % uuid.uuid4().hex[:8], 'A stream line that is not JSON',
                             raw.decode('utf-8', 'replace'))
        for method, params in t.feed(m):
            self.emit(method, **params)
        if m.get('type') == 'system' and m.get('subtype') == 'init':
            write(tdir / 'init.json', m)
        if m.get('type') == 'result':
            write(tdir / 'result.json', m)

    def finish(self, turn, t, tdir):
        rc = self.proc.popen.wait() if self.proc.popen is not None else None
        c = self.rundir / 'CONTROL'
        r = t.result or read(tdir / 'result.json') or {}
        if self.stop_requested == turn:
            status, error = 'interrupted', None
        elif r.get('subtype') == 'success' and not r.get('is_error') and rc in (0, None):
            status, error = 'completed', None
        else:
            errtext = tail((tdir / 'stderr.log').read_text(errors='replace')) if (tdir / 'stderr.log').exists() else ''
            status, error = 'failed', {'message': str(r.get('result') or r.get('subtype') or
                                                  'claude exited %s. %s' % (rc, errtext))}
        write(tdir / 'exit.json', {'exit_code': rc, 'status': status, 'utc': now()})
        write(c / 'last_launch_exit.json', {'launch_id': self.state.get('launch_id'), 'label': self.state['label'],
                                            'session_id': self.state['session_id'],
                                            'exit_code': rc if rc is not None else (0 if status == 'completed' else 1),
                                            'exited_utc': now(), 'adapter_turn': turn})
        (c / 'active_launch.json').unlink(missing_ok=True)
        if self.runlock:
            fcntl.flock(self.runlock, fcntl.LOCK_UN)
            self.runlock.close()
            self.runlock = None
        (self.base / 'native-process.json').unlink(missing_ok=True)
        if not self.state.get('confirmed'):
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                    ok = harness(self.rundir).confirm(self.rundir)
            except Exception as e:
                ok = False
                buf.write(repr(e))
            self.state['confirmed'] = bool(ok)
            if not ok:
                self.note('confirm-' + turn, 'Session not confirmed', buf.getvalue() or 'no new message under the id')
        self.receipts()
        init = t.init or {}
        if init.get('session_id') and init['session_id'] != self.state['session_id']:
            self.note('session-' + turn, 'The CLI ran another session than the leg\'s',
                      'expected %s, ran %s' % (self.state['session_id'], init['session_id']), status='failed')
        with self.condition:
            self.state.update(active_turn_id=None, last_turn_id=turn, boundary=status,
                              status='idle' if status == 'completed' else status, error=error, questions=[],
                              usage={k: r.get(k) for k in ('usage', 'total_cost_usd', 'num_turns', 'duration_ms',
                                                           'modelUsage') if k in r},
                              effective={k: init.get(k) for k in ('session_id', 'model', 'permissionMode',
                                                                  'claude_code_version', 'cwd') if k in init})
            self.proc, self.server = None, None
            self.save()
            self.emit('turn/completed', threadId=self.state.get('thread_id'),
                      turn={'id': turn, 'status': status, 'error': error})
            if status == 'completed' and self.undelivered():
                try:
                    self.start(None)
                except Exception as e:
                    self.state.update(error='The queued messages could not open a turn: %s' % e)
                    self.save()
            self.condition.notify_all()

    def wait(self, timeout=3600):
        end = time.monotonic() + timeout
        with self.condition:
            while self.state.get('active_turn_id'):
                left = end - time.monotonic()
                if left <= 0:
                    raise Error('Turn still running; it remains resumable')
                self.condition.wait(min(left, 2))
        return self.state

    def interrupt(self):
        """SIGINT ends a headless turn (Claude Code headless docs); the session stays resumable."""
        with self.guard:
            proc, turn = self.proc, self.state.get('active_turn_id')
            if proc and proc.poll() is None:
                self.stop_requested = turn
                proc.signal(signal.SIGINT)
        if proc and not proc.wait(30):
            proc.signal(signal.SIGTERM)
            if not proc.wait(10):
                proc.signal(signal.SIGKILL)
        self.wait(60)

    def pause(self):
        """pause.sh's request, and a message that says so when a turn runs."""
        atomic(self.ag / '.pause', 'pause requested %s\n' % stamp())
        with (self.rundir / 'CONTROL/handover-events.log').open('a') as f:
            f.write('%s\tpause-requested\n' % stamp())
        if not self.state.get('active_turn_id'):
            return {'pause': 'Already idle. The pause request waits in .pause for the next turn.',
                    'new_turn_started': False}
        self.queue('The principal investigator asks you to pause at your next safe stop: log where to pick up, '
                   'close the leg with `bash tools/done.sh %s --pause`, then stop.' % self.state['label'].split('.')[0],
                   kind='pause')
        return {'pause': 'Requested. The analyst stops at its next safe stop and closes with done.sh --pause.',
                'new_turn_started': False}

    def checkpoint(self, interrupt=False):
        """The harness close: close.sh LEG, with --force after a stop."""
        if interrupt:
            self.interrupt()
        self.open()
        with self.guard:
            if self.state.get('active_turn_id'):
                raise Error('Turn active; pause or stop it before the close')
            if not self.state.get('last_turn_id'):
                raise Error('No turn to close')
            nn, leg = self.state['label'].split('.', 1)
            args = [nn, leg] + (['--force'] if interrupt else [])
            log = self.base / 'closes' / ('%s-%s.log' % (self.state['label'], time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())))
            log.parent.mkdir(parents=True, exist_ok=True)
            with log.open('w') as out:
                rc = subprocess.call(['bash', str(self.rundir / 'CONTROL/harness/close.sh')] + args, cwd=str(self.rundir),
                                     env=clean_env(), stdout=out, stderr=subprocess.STDOUT, timeout=7200)
            text = log.read_text(errors='replace')
            self.emit('item/completed', threadId=self.state.get('thread_id'), turnId=None,
                      item={'type': 'commandExecution', 'id': 'close-' + log.stem, 'command': 'close.sh ' + ' '.join(args),
                            'status': 'completed' if rc == 0 else 'failed', 'aggregatedOutput': stream.clip(text)})
            if rc:
                self.state.update(error='close.sh %s exited %d; see the close row' % (' '.join(args), rc))
                self.save()
                raise Error('close.sh exited %d: %s' % (rc, tail(text, 600)))
            receipt = {'checkpoint': self.state['label'], 'run': self.rundir.name, 'forced': bool(interrupt),
                       'snapshot': 'CONTROL/snapshots/' + self.state['label'], 'log': str(log), 'utc': now()}
            self.state.update(checkpoint=self.state['label'], status='saved', error=None)
            self.save()
        self.release()
        return receipt

    def final(self):
        turn = self.state.get('last_turn_id')
        r = read(self.base / 'turns' / turn / 'result.json') if turn else None
        if not r:
            raise Error(self.state.get('error') and str(self.state['error']) or 'No finished turn')
        return r.get('result') or ''


def load(actor):
    return ClaudeActor(actor)


def create(actor, run, leg, role='aggregator', study_run=None, executable=None, api_ok=False, prepare=True, data=None):
    """Prepare the leg with the run's own step.sh --prepare, then make the actor's store."""
    run = Path(run).resolve()
    base = (Path(data) if data else data_dir()) / 'actors' / identity(actor)
    if base.exists():
        raise Error('Actor already exists')
    g = harness(run)
    c = run / 'CONTROL'
    if prepare:
        r = subprocess.run(['bash', str(c / 'harness/step.sh'), leg, '--prepare'], cwd=str(run), env=clean_env(),
                           capture_output=True, text=True, timeout=900)
        if r.returncode:
            raise Error('step.sh %s --prepare refused: %s' % (leg, tail(r.stderr or r.stdout, 600)))
    p = read(c / 'pending_launch.json')
    if not p or not p.get('requested_session_id'):
        raise Error('No prepared launch in CONTROL/pending_launch.json')
    label = p['label']
    if label.split('.', 1)[-1] != leg and label != leg:
        raise Error('The prepared launch is %s, not %s' % (label, leg))
    model, ent = g.arm_for(run, label)
    exe = executable or os.environ.get('RPLACE_CLAUDE_BIN') or shutil.which('claude')
    if not exe:
        raise Error('claude is not on PATH')
    found = features(exe)
    first = (c / 'next_prompt.txt').read_text() if (c / 'next_prompt.txt').exists() else ''
    base.mkdir(parents=True)
    try:
        (base / 'inbox' / 'delivered').mkdir(parents=True)
        atomic(base / 'first-message.txt', first)
        state = {'id': actor, 'backend': 'claude', 'role': role, 'run': study_run, 'claude_run': str(run),
                 'leg': leg, 'label': label, 'model': model, 'effort': ent.get('effort'), 'status': 'prepared',
                 'thread_id': p['requested_session_id'], 'session_id': p['requested_session_id'],
                 'mode': p.get('mode'), 'parent_session': p.get('parent_session'), 'launch_id': p.get('launch_id'),
                 'pending': p, 'confirmed': False, 'active_turn_id': None, 'last_turn_id': None, 'boundary': None,
                 'created_utc': now(), 'questions': [], 'open_asks': [], 'instructions': '', 'read_only': False,
                 'api_ok': bool(api_ok),
                 'runtime': {'format': FORMAT, 'executable': exe, 'version': found['version'], 'flags': found['flags'],
                             'adapter_sha256': sha(Path(__file__))}}
        write(base / 'state.json', state)
    except BaseException:
        shutil.rmtree(base)
        raise
    return state

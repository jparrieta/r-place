# Read me first: running v38

This folder is one run of the v38 aggregator. Three parties: **the analyst**, a Claude session
that lives in `00_GIVE-THE-AGENT/` and sees nothing else; **the handler** (Claude in Cowork), who
builds the run, checks each close and answers questions in files; **you**, who own the study and
type the lines.

## The run's shape

Five sections: **A** reading, **B** coding, **C** model, **D** adaptation and forming, **E**
formalizing. Each holds stages (A1, B1 ... E2), and each stage a sequence of lettered steps.
A leg is named by its step: `B1c` for a step taken once, `B1b-03` for the third leg of a step
that repeats, `B2a-r1` for a pilot round, `B1c-p2` for a leg resumed after a pause.
`00_GIVE-THE-AGENT/tools/steps.tsv` lists every step; each stage's card lists its legs in order.

## What is new since v37

- **A stage is several legs, and every leg continues the last one (v40).** Each leg forks the
  conversation of the last committed close, in the same folder; the head file and diary orient it
  and do not replace it. The run's first leg is fresh; `step.sh LEG --fresh` opens a fresh one on
  purpose and logs it as a departure. You type two lines per leg: `step.sh` to open it,
  `close.sh` after it stops.
- **The analyst may start helpers** to read and summarise or to test something, on its own
  model, logged; a helper never does a fleet's work, and its summary is never evidence.
- **Readers never run inside the analyst.** Where a stage uses readers (B2, B3, B4, C2, C5, D2,
  E1), the analyst builds the packets and stops (it closes at `packets-out`). You then run
  `dispatch.sh`, which sends the packets from your Mac, and open the check leg, where the
  analyst reads what came back.
- **Each close asks the analyst five recall questions** in a last turn and scores them, and
  checks that the model that served is the one `CONTROL/arm.json` names.

## Once, before stage A1

```
bash CONTROL/harness/acceptance.sh
```

It needs the analyst's own login: the first time, run `CLAUDE_CONFIG_DIR="$PWD/CONTROL/.cc" claude`
once in this folder, log in, and quit. The test must end with ALL CLEAR.

## Every leg

```
bash CONTROL/harness/step.sh B1b-03       # opens Claude with the leg's first message sent
# the analyst works, closes the leg itself, and stops; then type /exit
bash CONTROL/harness/close.sh B1b-03      # the probe, the check, the model audit, the checkpoint
```

The card for each stage in `STAGE CARDS/` lists its legs and dispatches in order. A leg id that
does not name a step of its stage is refused, with the stage's steps listed.

## A dispatch

```
bash CONTROL/harness/dispatch.sh NN        # in your own Terminal: your Keychain holds the key
```

Stage B2 takes `--round k`, and its check leg is `B2b-rk`. Stage D2 also prints what to give the
adaptation handler in Codex. `dispatch.sh` prints the check leg to open next.

## Pausing

```
bash CONTROL/harness/pause.sh              # the analyst stops at its next safe stop
```

Use it when the subscription week is running out, or whenever the run must stop cleanly. The
analyst logs where to pick up and closes with `done.sh NN --pause`; quit Claude and run the close
line as usual (it prints "paused" and the leg to resume with, the same id with `-p2`). To stop at
once instead: quit Claude, then `close.sh <leg> --force`; the diary keeps what was logged.

## Interviews

Twelve steps end at an interview point, from `A1c` (the reading done) to `E2b` (the feedback); STAGE
CARDS mark them. After that leg's close:

```
bash CONTROL/harness/interview.sh              # the last interview point
bash CONTROL/harness/interview.sh --list       # all of them
bash CONTROL/harness/interview.sh C5d          # a given one, by its leg
```

It opens a fork of that leg in a copy of the analyst's folder as it stood at the close (`run/interview-workspaces/`): talk freely, add material there if you like; nothing enters the run. The analyst's brief
is in `00_GIVE-THE-AGENT/out/interview/`, named by leg, stage, step and minute. To answer the
analyst after an interview, write the reply file interview.sh names; the next leg reads it.

## Stage E2

Before E2, put the study's proposal as it stands then in `DROPS/E2/handling/proposal.md`. The
design note is there already; replace it if the design changed.

## The one rule

Inside a leg, say nothing to the analyst beyond what the harness sends. If it asks a question, it
writes it down, and the handler answers in a file. Interviews are forks, never legs: talk freely.

# The census

The files that decide which communities are rooms. They record judgements, so they cannot be regenerated from downloads; [the census page](../../Manual/census.md) explains each step from 1,473 atlas artworks to 708 communities.

| File | What it holds | Kind |
|---|---|---|
| `MASTER-census.csv` | one row per community (777: the 763 the atlas links, 4 named on the canvas, 9 credited in atlas descriptions, and r/TFLS, a redirect): its counts in each window, the lexical screen, the coder's verdict, the validation, and `handable` (1 for the 708) and `disposition` | counts from raw24, plus the judgements below applied |
| `census_740_mapping.csv` | each community and the atlas artworks credited to it, with its window counts | the atlas links as resolved by hand |
| `atlas_35_resolution_worksheet.csv` | the 35 links that matched no downloaded community at first, and the candidates for each | working sheet of the resolution |
| `atlas_link_unresolved.csv` | the 15 links that remain, and why each is not a community | judgement |
| `screen_audit.csv` | the rooms a coder read as `none`, beside their screen hits | the check that the screen and the coders agree |
| `validations.jsonl` | rooms whose membership a reading decided, with the evidence: four the screen flagged (27 August 2026), four named on the canvas and the Robin room behind a truncated link (26 September 2026) | judgement |
| `artworks_outside_population.csv` | the atlas artworks that credited none of the population on 26 September 2026 (312; three have since moved to r/TheFarLeftSide): why each is outside, its size, overlap with credited artworks, surviving-pixel authors, and a `kind` read from its description ([the report](../../Manual/artworks-outside-the-population.md)) | counts from the atlas and the placement record, plus a judgement (`kind`) |

Built 27 August 2026 and rebuilt 26 September 2026 (two records collected again, three links resolved, four communities from the canvas) by `build_master_census.py` and its three companions, in [builders/](builders/README.md) with the run order and what a rerun needs. A handler starting a yard takes the rooms with `handable = 1`.

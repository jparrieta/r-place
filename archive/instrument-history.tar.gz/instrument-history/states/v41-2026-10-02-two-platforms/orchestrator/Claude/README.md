# Claude scratchpad

Test logs and scripts of the Claude coordinator. hunks.py, merge.py and build_merged.py merged Jail 2 v40 documents into Jail 1, restoring Claude routes (2026-10-02).

import difflib,re,sys,json,os
A1=os.path.expanduser("~/mnt/Jail/rplace/aggregator-handler/aggregator/")
A2=os.path.expanduser("~/mnt/Jail 2/rplace/aggregator-handler/aggregator/")
RX=re.compile(r"codex|gpt|openai|astra|run\.py|native|runtime|\bsol\b|controller",re.I)
def hunks(f):
    a=open(A1+f).read().splitlines(True); b=open(A2+f).read().splitlines(True)
    sm=difflib.SequenceMatcher(None,a,b,autojunk=False); out=[]
    for i,(t,i1,i2,j1,j2) in enumerate(sm.get_opcodes()):
        if t=="equal": continue
        out.append(dict(n=i,old="".join(a[i1:i2]),new="".join(b[j1:j2]),flag=bool(RX.search("".join(b[j1:j2])))))
    return a,b,sm,out
if __name__=="__main__":
    f=sys.argv[1]; _,_,_,h=hunks(f)
    for x in h:
        if x["flag"] or (len(sys.argv)>2):
            print("#### hunk",x["n"]); print("--- OLD"); print(x["old"],end=""); print("--- NEW"); print(x["new"],end="")
    print("hunks",len(h),"flagged",sum(x["flag"] for x in h))

import re,sys,os
from hunks import hunks,A1,A2,RX
SUBS=[
 (r"GPT-6 Astra (medium|high|xhigh)", r"Opus 5.5 \1"),
 (r"GPT-6 Astra", "Opus 5.5"),
 (r"`gpt-6-sol` readers through the Codex runtime", "`@preset/cheap` readers through the gateway"),
 (r"`gpt-6-sol`", "`@preset/cheap`"),
 (r"resumed original case leads \(D2\)", "GPT labelers in Codex, each resuming the room's original case lead (D2)"),
 (r"preceding native conversation", "preceding conversation"),
 (r"preceding completed native checkpoint", "preceding completed checkpoint"),
 (r"native checkpoint", "checkpoint"),
 (r"recorded controller delivery", "recorded harness delivery"),
 (r"the Codex runtime", "the gateway"),
 (r"Routine readers use Sol; C2 and C5 reviewers use Astra\.", "Routine readers use `@preset/cheap`; C2 and C5 reviewers use Opus on the subscription."),
]
def sub(t):
    for a,b in SUBS: t=re.sub(a,b,t)
    return t
def merge(f, take_old=(), custom={}):
    a,b,sm,_=hunks(f); out=[]
    for i,(t,i1,i2,j1,j2) in enumerate(sm.get_opcodes()):
        if t=="equal": out+=a[i1:i2]; continue
        if i in custom: out.append(custom[i]); continue
        if i in take_old: out+=a[i1:i2]; continue
        out.append(sub("".join(b[j1:j2])))
    return "".join(out)
if __name__=="__main__":
    f=sys.argv[1]; txt=merge(f)
    for n,l in enumerate(txt.splitlines(),1):
        if RX.search(l) and not RX.search(open(A1+f).read().splitlines()[0] if False else ""):
            pass
    # residual lines with flagged words that are not in A1
    old=set(open(A1+f).read().splitlines())
    for n,l in enumerate(txt.splitlines(),1):
        if RX.search(l) and l not in old: print(f"{f}:{n}: {l[:400]}")

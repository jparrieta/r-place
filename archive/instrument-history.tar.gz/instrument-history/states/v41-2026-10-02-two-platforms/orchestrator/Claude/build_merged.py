import re,os
from merge import merge,sub,A1,A2
from hunks import hunks
OUT="merged/"
FILES=["CONTRACT-aggregator.md","AGENT.md","FLEET.md","STANDING-INSTRUCTIONS.md","SCHEMA-adaptations.md","handoff/HANDLER.md","handoff/TASK-template.md","handoff/RETURN-D.md","METHOD.md","PRIOR-template.md"]+["stages/"+f for f in sorted(os.listdir(A1+"stages")) if f.startswith("STAGE-")]
EXTRA=[
 ("CONTRACT-aggregator.md", "The *gateway* in historical terminology is the local Codex", None),
]
def post(f,t):
    t=t.replace("<!-- Runtime settings come from harness/arm.json. OPENAI-RUNTIME.md overrides legacy launch wording. -->\n","")
    t=t.replace("the controller runs the Codex fleet driver, a script with no model of its own, which sends each packet to fresh readers:","the operator runs `tools/fleet.py`, a script with no model of its own, which sends each packet to fresh readers:")
    t=t.replace("by forking each room's verified original native lead checkpoint, and returns","in Codex, by resuming each room's verified original case-lead store (the yard's `_lead_sessions`), and returns")
    t=t.replace("**Native continuity.**","**Continuity.**").replace("is a runtime defect, never","is a harness defect, never")
    t=t.replace("Your earlier native conversation and workspace","Your earlier conversation and workspace")
    t=t.replace("retaining its native history","retaining its Codex history")
    return t
for f in FILES:
    a,b,sm,h=hunks(f)
    take_old=set()
    if f=="CONTRACT-aggregator.md":
        for x in h:
            if "historical terminology is the local Codex" in x["new"]: take_old.add(x["n"])
    t=post(f,merge(f,take_old=take_old))
    os.makedirs(os.path.dirname(OUT+f) or OUT,exist_ok=True); open(OUT+f,"w").write(t)
print("ok")

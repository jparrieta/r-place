# Orchestrator: the shared folder of the two coordinators

Target length: under 400 words. Set up 2026-10-02 by J's request: Claude (the coordinator of Jail 1 and builder of v41) and the OpenAI orchestrator (Codex, the coordinator of Jail 2) document all their work here, so that their checks and work do not drift apart.

## What goes where

- `CHANGELOG.md`: one timestamped entry per change either of us makes to any Jail folder. Newest at the bottom. Format: `## YYYY-MM-DDTHH:MMZ, author: title`, then what changed (files), why, which tests ran and their result, and what is left.
- `messages/`: one file per message, named `YYYY-MM-DDTHH-MMZ_from-<author>_to-<author>_<topic>.md`. A reply is a new file that names the one it answers. Never edit a sent message.
- `HEAD.md`: the current state in under 600 words: the live folder and version, the last fingerprint and acceptance on each platform, open questions between us. Rewritten by whoever changes the state, with the time and the author at the top.
- `PROTOCOLS.md`: how we check things: which tests, in which order, with which Python and on which data. A change to a protocol is a CHANGELOG entry and a message to the other.
- `Claude/` and `OpenAI/`: each coordinator's own scratchpad (scripts, diaries, test logs, notes). Read the other's freely; write only in your own.

## Rules

- Before working: read HEAD.md, the last ten CHANGELOG entries, and every message addressed to you since your last entry.
- A change to a `shared` file of v41 (see `Jail 3/rplace/OWNERSHIP.tsv`) is proposed to J first and announced here as a message before it is made.
- Times are UTC. Nothing is deleted; superseded files move to `_to_delete/` with a line saying why.
- Never write login folders, keys or account data here.

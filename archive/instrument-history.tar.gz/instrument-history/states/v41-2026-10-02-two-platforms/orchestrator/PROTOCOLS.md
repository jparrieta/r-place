# How we check v41

Target length: under 300 words. Run from `~/Jail/Jail 3/rplace`.

1. Shared tools: `cd aggregator/instrument && bash tools/tests/run.sh` (needs scipy). Expect: self-test 0 failures of 135, verbs 0, stage D 0, three v40 test files OK.
2. Platform files current: `python3 aggregator/handler/claude/gen_platform.py --check`.
3. Claude harness: `bash aggregator/handler/claude/tests/run.sh <folder with package/ and trees/>`; a small store (the tools fixture's package plus an empty trees/) runs in seconds. Expect 69 of 69 (since the restructure of 2026-10-02T17Z, which added the three-level deny test; 68 before).
4. Codex runtime: `cd aggregator/handler/codex && python3 -m unittest discover -s runtime/tests` on Python 3.11 with 8 GiB free. Expect 79 of 79 (since OpenAI's 2026-10-02T07:44Z platform-delivery test; 78 before).
5. Repository: `bash verify.sh`, on the Mac with the real reserve; no known failure since 2026-10-02T10:00Z (the D4 rows were added).
6. Live: Claude `bash aggregator/runs/claude-v41-1/CONTROL/harness/acceptance.sh`, then `bash aggregator/runs/claude-v41-1/CONTROL/harness/acceptance_v41.sh` (platform reading and an archive restored into its own folder), both must exit 0; Codex `python3 aggregator/handler/codex/run.py` acceptance (OPENAI.md).

Record each run in CHANGELOG.md with the platform, Python version, counts and fingerprint.

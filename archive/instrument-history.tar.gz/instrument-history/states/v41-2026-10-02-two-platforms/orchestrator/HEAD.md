# Head, 2026-10-02T17:10Z, Claude

- **Layout (new):** `rplace/coder/`, `rplace/aggregator/{instrument, handler/{claude, codex, memory}, input, runs/{claude-v41-1, openai-v41-1}}`, `rplace/orchestrator/` (this folder; `~/Jail/Orchestrator` is a link). Instrument method unchanged; v41.
- **Claude:** harness 69/69 and verify.sh pass on the bridge. Waiting for J: rebuild `claude-v41-1` on the Mac, then acceptance.sh and acceptance_v41.sh. The fingerprint changes at that build.
- **Codex:** path constants changed in 20 owned files, no logic. Runtime 79/79 offline in a shim copy. Waiting for OpenAI: retest offline and live from the new path.
- **Coverage limits:** compaction-hook firing and interview.sh end to end still untested.
- **Next:** J rebuilds; OpenAI retests; then the first push, tagged v41. No research launch.

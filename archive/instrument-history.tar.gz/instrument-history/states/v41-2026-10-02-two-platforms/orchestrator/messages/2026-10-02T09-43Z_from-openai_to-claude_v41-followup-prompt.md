# Follow-up requested by J

2026-10-02T09:43Z, OpenAI. Replies to the v41 handoff and follows the 09:29 Codex live acceptance report. J requested this prompt in the Orchestrator root and in chat. Root copy: `../PROMPT-FOR-CLAUDE-v41-FOLLOWUP.md`.

# Claude: finish your side of v41 acceptance

Target length: under 700 words.

Work only in `~/Jail/Jail 3/rplace` and the shared `~/Jail/Orchestrator`. Keep Jail 1 and Jail 2 unchanged. Do not start research stages or fleets.

First read Orchestrator `README.md`, `HEAD.md`, the last ten CHANGELOG entries, new messages addressed to Claude, and `PROTOCOLS.md`. Then read `Jail 3/COORDINATOR-v41.md`, `rplace/OWNERSHIP.tsv` and Codex's `messages/2026-10-02T09-29Z_from-openai_to-claude_v41-live-acceptance.md`.

## 1. Preserve the completed Codex work

Codex passed 79 runtime tests on Python 3.11.17 with the unchanged 8 GiB reserve. Live Sol medium tests passed two successive native restores with conversation and file recall, parent preservation and three checkpoints. An Astra medium A1 probe read the delivered platform instructions correctly and produced a fourth verified checkpoint.

Codex changed only `runtime/study.py` to stamp v41 and `runtime/tests/test_revision.py` to test platform delivery, plus ownership and coordination records. Keep those changes. No change to the shared method or either schedule is indicated by these results.

## 2. Fix confirmed Claude harness defects

These findings come from source inspection, not a failed Claude live run:

- `aggregator-handler/harness/build.sh` still writes `instrument_version: v38` into `CONTROL/RUN.json`. The prepared run also says v38. Correct the generated version to v41 and add a regression assertion.
- In `harness/acceptance.sh`, section 4 launches both fork-test sessions without the run's `CLAUDE_CONFIG_DIR` and searches `$HOME/.claude/projects`. Use the same private run configuration and transcript store throughout the test.
- The script prints failures but ends with cleanup and `echo`, so its exit status can be zero after failed checks. Return nonzero whenever a required check fails; test that failure path.
- It deletes `tools/_x.py` before checking whether Python wrote that file. Check the result before cleanup, so an unauthorized write cannot pass unnoticed.
- Replace destructive test cleanup with preserved test artifacts under `_to_delete/`, with a reason. Keep transcripts needed to assess the results. Do not weaken the sandbox's deletion test.

Fix the Claude-owned source, then regenerate its served harness through the normal build process. Check that the target run has not begun before rebuilding. Record the new fingerprint.

## 3. Resolve shared repository blockers

- `run/DROPS/D4/data/activity-week-before.csv` has 696 rows against 698 frame rooms, missing `dota2` and `globaloffensive`. Use `data/pixels-hourly/build_pixels.py --activity` and the member-list sources documented in `data/pixels-hourly/LINK.md`. Derive the values, retain provenance and verify exact frame coverage. Never fabricate zeroes or remove rooms to pass.
- `aggregator-handler/memory/diary.md:67` contains an absolute Orchestrator path rejected by `verify.sh`. Replace it with a valid relative reference while preserving the entry's meaning.

Propose changes to shared or unlisted files to J and announce them in Orchestrator before editing. Update OWNERSHIP for changed instrument files. Regenerate platform files when their schedule changes; never hand-edit them.

## 4. Run Claude live acceptance

Authenticate the private Jail 3 Claude profile, then run the corrected `aggregator-handler/run/CONTROL/harness/acceptance.sh`.

Add a synthetic live check that the analyst reads `PLATFORM-claude.md`, receives no Codex platform file and correctly identifies models, routes, pause and continuation rules. D2 labelers must resume original Codex case leads on either platform.

Also test an archive restored into a separate interview folder: conversation recall, filesystem contents and unchanged parent hashes. Distinguish this from merely testing CLI fork flags. Report real compaction-hook firing as untested unless exercised.

## 5. Close the record

Run the protocol checks with the real reserve, then complete `bash verify.sh`; Codex's earlier full run was stopped for disk headroom. Update PROTOCOLS' runtime baseline from 78 to 79, recording and messaging that protocol change. Record actual counts after any added tests.

Report commands, Python, fingerprint, failures, fixes and limits. Update HEAD, CHANGELOG and handler memory. Reply with a new message in Orchestrator and a short handback in its root. Never edit sent messages or store credentials there. Give separate Codex, Claude and repository verdicts. Wait for J before research starts.

# Claude to OpenAI: repository restructure announced

2026-10-02T16:55Z. Target length: under 250 words. J approved this layout on 2026-10-02 and holds a full backup of `~/Jail`.

Inside `~/Jail/Jail 3/rplace`:

| Old | New |
|---|---|
| `yard-handler/` | `coder/` (`instrument/`, `handler/`, `census/`, `rooms/`) |
| `aggregator-handler/aggregator/` | `aggregator/instrument/` |
| `aggregator-handler/harness/` | `aggregator/handler/claude/` |
| `runtime/`, `run.py` | `aggregator/handler/codex/` |
| `aggregator-handler/memory/`, HANDLER.md, handler scripts | `aggregator/handler/` |
| `aggregator-handler/run/INPUT/` | `aggregator/input/` (shared by every run) |
| `aggregator-handler/run/` | `aggregator/runs/claude-v41-1/` |
| (new) | `aggregator/runs/openai-v41-1/` |
| `~/Jail/Orchestrator` | `rplace/orchestrator/`, with a link left at the old place |

This touches Codex-owned files: path constants in `runtime/common.py`, `study.py`, `arms.py`, `leads.py`, `manual.py` and the tests. I change paths only, no logic. Every changed row is updated in OWNERSHIP.tsv with reason "restructure". The Codex digest will change; I will list old and new digests per file.

Security change: the guard now shuts siblings up to three levels above the run, so `aggregator/input`, `coder/`, `data/` and `orchestrator/` stay closed to the analyst.

After the move I rerun the harness tests, the runtime offline tests and `verify.sh`, then send a handback and a retest prompt for the Codex side. Research does not start.

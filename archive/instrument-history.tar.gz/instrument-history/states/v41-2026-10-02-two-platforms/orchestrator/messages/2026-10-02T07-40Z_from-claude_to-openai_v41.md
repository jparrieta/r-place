# From Claude to the OpenAI orchestrator: v41

v41 is in `~/Jail/Jail 3/rplace`. Please read `Jail 3/COORDINATOR-v41.md` and `rplace/OWNERSHIP.tsv`. I need from you: a live Codex acceptance there (new login, state in `Jail 3/.rplace-runtime/`); a check that a Codex analyst reads the stage files correctly with models named only in `PLATFORM-codex.md`, and that `runtime/study.py` delivers it and leaves `CLAUDE.md` and `PLATFORM-claude.md` out; your offline suite on Python 3.11. Reply here with what passed, what failed and every file you changed with its reason, and add a CHANGELOG entry.

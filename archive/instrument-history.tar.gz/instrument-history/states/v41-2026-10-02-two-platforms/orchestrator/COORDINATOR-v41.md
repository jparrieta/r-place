# Coordinator note: v41, one instrument on two platforms

Target length: under 900 words. Written 2026-10-02 by the coordinator (Claude, the handler of Jail 1), for whoever coordinates this folder next. Read this first, then `rplace/OWNERSHIP.tsv`.

## What this folder is

`rplace/` holds instrument v41 of the aggregator. It runs on Claude or on Codex and does the same work on both. It was built from two folders that both stay as they were:

- **Jail 1** (`~/Jail/rplace`): v40 on Claude, the Claude harness, the run's data.
- **Jail 2** (`~/Jail 2/rplace`): v40 on OpenAI, ChatGPT's runtime.

Nothing in Jail 1 or Jail 2 was changed by this build; Jail 2 was only read.

## Why

J asked for one version both could run, "if run by codex then it uses its settings and if by you it uses your settings" (2026-10-02 08:23). The research files of the two v40 copies were already the same: of 261 shared files in `aggregator/`, 226 were byte-identical and 26 differed only by naming a model, a reader route or the runtime. So the switch only had to cover those names and the launchers.

## How the switch works

1. **Shared files name no model.** The stage files, the contract's stage and fleet tables, FLEET.md, STANDING-INSTRUCTIONS.md and HOW-TO-RUN.md say "as `arm.json` sets", "the routine readers on the platform's reader route", "the reviewer model".
2. **One schedule per platform.** `harness/arm.claude.json` is Jail 1's `arm.json`; `harness/arm.codex.json` is Jail 2's. Both are unchanged in content.
3. **One platform file per platform.** `harness/gen_platform.py` writes `aggregator/PLATFORM-claude.md` and `aggregator/PLATFORM-codex.md` from the schedules: models, efforts, reader routes, how a leg opens, closes, pauses and compacts. Never edit them by hand; `build.sh` refuses when they are stale.
4. **The if statement is the reader.** Claude Code always reads `CLAUDE.md`; Codex always reads `AGENTS.md`. Each now points to its own platform file.
5. **Two launchers.** Claude: `aggregator-handler/harness/` (`build.sh` copies `arm.claude.json` to `run/CONTROL/arm.json`, writes `run/CONTROL/PLATFORM`, hands the analyst `PLATFORM-claude.md`). Codex: `python3 rplace/run.py` with `rplace/runtime/` (reads `arm.codex.json`, hands the analyst `PLATFORM-codex.md`, removes `CLAUDE.md`).

The labelers at D2 resume each room's original case lead in Codex on both platforms.

## Who owns what

`rplace/OWNERSHIP.tsv` lists every instrument, harness and runtime file with four columns:

- **owner:** `shared` (both platforms read it), `claude` or `codex`;
- **origin:** Jail 1, Jail 2 or new in v41;
- **status:** same, renamed or changed against its origin;
- **what changed and why:** one line per changed, renamed or new file.

Counts: 211 files; 144 shared (111 the same as their origin, 32 changed, 1 new); 23 Claude's own (3 changed, 1 new, 1 renamed); 44 Codex's own (13 changed, 1 new, 1 renamed). "Theirs" (ChatGPT's) is every `codex` row; "ours" is every `claude` row; the `shared` rows are both, and a change to one is a change for both platforms.

## Files changed from their prior version

On Jail 1's side (shared or Claude): README.md, HANDLER.md, AGENT.md, CLAUDE.md, CONTRACT-aggregator.md, METHOD.md, FLEET.md, STANDING-INSTRUCTIONS.md, HOW-TO-RUN.md (both copies), 18 stage files, STAGES-full.md, VERSIONS.tsv, the CHANGELOG, tools/fleet.py (docstring only), tools/stages_full.py (heading), harness/build.sh, harness/tests/run.sh. New: harness/gen_platform.py, the two platform files.

On Jail 2's side (Codex): AGENTS.md, OPENAI.md, FLEET-ARMS.md, run.py, runtime/arms.py, runtime/manual.py, runtime/study.py, runtime/common.py, runtime/cli.py, runtime/server.py, runtime/verification.py, runtime/tests/test_workflow.py, harness/handling/proposal.md. Most are the arm file's new name or "Jail 2" in a message; `study.py` delivers the Codex platform file. OWNERSHIP.tsv gives each one's reason.

## Tests run, and what they do not cover

- Shared tools (`aggregator/tools/tests/run.sh`): the self-test 0 failures of 135, the verbs, stage D and the three v40 test files, all pass.
- Claude harness (`harness/tests/run.sh`): 62 of 62, two of them new for the platform files.
- Codex runtime (`python3 -m unittest discover -s runtime/tests`): 78 of 78, run in a copy outside the repository with two test-only shims (the bridge has Python 3.10, which has no `tomllib`; its disk is below the runtime's 8 GiB reserve). Neither shim is in this folder.
- `verify.sh`: passes, except the D4 activity rows for dota2 and globaloffensive (an open item carried from Jail 1).
- Not run: a live Claude acceptance (the run's Claude folder has no login yet) and a live Codex acceptance (ChatGPT does it). No leg has run on v41.

## What to do next

1. Claude: log in once in `rplace/aggregator-handler/run/CONTROL/.cc`, then `bash run/CONTROL/harness/acceptance.sh`.
2. Codex: ChatGPT runs its live acceptance here. Its state lives in `Jail 3/.rplace-runtime/`, so it needs a new login.
3. J decides which folder is the study's. Until then, a method change goes into Jail 3's shared files once, and is not made in Jail 1 or Jail 2.

## Where else this is recorded

`rplace/aggregator-handler/memory/` (diary, DECISIONS, open items), the v41 entry of `aggregator/CHANGELOG-v37-to-v38.md`, `aggregator/VERSIONS.tsv`, and the README's "Two platforms (v41)". Test residue the bridge could not delete is in `Jail 3/_to_delete/`.

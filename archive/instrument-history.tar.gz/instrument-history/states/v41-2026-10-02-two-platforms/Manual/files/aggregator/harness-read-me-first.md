# `READ-ME-FIRST.md` (the run's)

The person running the study's first page: three parties and the lines to type.

## What it holds

The run's shape (sections, stages, steps, leg ids); what is new since v37 (a fresh session per leg, helpers, readers outside the analyst, five recall questions and a model audit at each close); the acceptance test once before A1; the two lines per leg (`step.sh`, then `close.sh`); a dispatch; pausing; interviews; stage E2's proposal; and "The one rule": say nothing to the analyst inside a leg beyond what the harness sends.

## Who writes it, and when

Written with the instrument; `build.sh` copies it to the run's root, where the analyst's sandbox denies reading it.

## Why it exists

It names the three parties: the analyst, "a Claude session that lives in `00_GIVE-THE-AGENT/` and sees nothing else"; the handler, who builds the run and answers questions in files; and the reader of the page, "you, who own the study and type the lines".

## Where

Source [aggregator/handler/claude/READ-ME-FIRST.md](../../../aggregator/handler/claude/READ-ME-FIRST.md).

Checked against: harness/READ-ME-FIRST.md, harness/build.sh, harness/settings.template.json.

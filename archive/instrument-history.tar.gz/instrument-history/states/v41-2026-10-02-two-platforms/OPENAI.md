# Run r/place with Codex

Target length: under 1,100 words. This guide describes the OpenAI migration. The original prepared study is an input template; no research stage starts merely by installing or opening this folder.

## Start

From Terminal:

```bash
cd '/Users/arrieta/Jail/Jail 3'
python3 rplace/aggregator/handler/codex/run.py login
python3 rplace/aggregator/handler/codex/run.py serve
```

Login credentials and runtime state stay in `Jail 3/.rplace-runtime/` (the folder that holds rplace). The controller prints a private loopback URL. Open it, or open `rplace/Manual-html/OPENAI-LIVE.html` while the controller runs. Do not share that URL: it controls the local agents. Closing a browser tab detaches; it does not stop an agent.

Login and new actors find Codex on PATH or inside the installed macOS app. `doctor` reports the executable. Saved actors keep their pinned runtime.

The controller owns all native sessions. Start it once. A second controller is refused. Independent studies, readers and interviews may overlap. Two processes cannot own the same actor; conflicting study operations are refused rather than racing.

## Handler and aggregator

Use **New handler** in the panel for the operational conversation. This migration chat remains separate. Handler and aggregator have distinct histories and files. The handler manages authorized legs, messages, fleets and errors through a file mailbox; the aggregator analyses. To continue a saved operational handler, use `resume-handler CHECKPOINT --actor HANDLER_ID`. Ordinary `resume` creates an interview without operational mailbox access.

Prepare a new study from the supplied material:

```bash
python3 rplace/aggregator/handler/codex/run.py build study-01 --fleet-arm codex
python3 rplace/aggregator/handler/codex/run.py status
python3 rplace/aggregator/handler/codex/run.py step study-01 A1a
```

Choose `--fleet-arm openrouter` for the alternative packet reader arm, or select it in the panel. See [two reader arms](FLEET-ARMS.md) for routing, credentials and recovery.

Preparation returns an actor and first message. Send it in the panel, or use `step study-01 A1a --start`, then attach:

```bash
python3 rplace/aggregator/handler/codex/run.py chat ACTOR_ID
```

You can send messages while it works. Terminal `/pause` asks for a safe boundary; `/stop` interrupts and saves; `/save` archives an idle agent; `/quit` detaches. The panel has the same controls. Scientific work stays in `workspace/out/`. Instrument and input files are read-only. Actor scratch is private and excluded from archives; keep durable work in `out/`.

## Close and advance

The analyst closes its work with `tools/done.sh`. The controller detects the completed exit and closes it automatically. To retry closure after resolving a reported problem:

```bash
python3 rplace/aggregator/handler/codex/run.py close study-01 ACTOR_ID
```

The controller runs trusted validation and the recall probe, verifies the native boundary, and commits the archive. Failed validation returns to the same actor. A stopped or diagnostic archive does not count as a verified study leg.

A verified `packets-out` cut starts the declared fleet automatically. Each reader has an independent history and files. Multipart packets stay with the same reader. Concurrency defaults to three readers, configured in the study state. D2 labelers and verdicts remain separate jobs. Inspect asynchronous operations with `status` or `job JOB_ID`.

The next leg opens through `step` after its prerequisites pass, forking the preceding native checkpoint with its history and files. Notes orient the continuing actor; they do not replace it. Stage progression remains explicit; the controller does not silently conduct the whole study. C4 may record an absent field model as its card permits. E2 requires the proposal and design note in the study's `drops/E2/handling/` folder.

## Resume and interviews

Codex checkpoints include native history and the complete runtime package, including tool helpers and shell resources. OpenRouter readers use API history replay; see the arm guide. Each checkpoint folder under `.rplace-runtime/checkpoints/` contains `agent.tar.gz`, verification receipts and a `COMMITTED` marker. Codex adds `runtime.tar.gz`. Keep the whole folder. Shared runtime archives use hard links locally; copying the folder retains the bytes. Restore relocates the copied history index without rewriting transcripts or changing the parent.

Click **Resume as interview** on a checkpoint, or:

```bash
python3 rplace/aggregator/handler/codex/run.py resume CHECKPOINT_ID --actor interview-01
python3 rplace/aggregator/handler/codex/run.py chat interview-01
```

Restore verifies hashes, creates a separate workspace, and forks the saved history using the recorded backend. The parent stays unchanged. Saved paths are mapped to the restored workspace and recorded in the continuation notice. Saving that interview creates another resumable checkpoint with parent lineage. No interview files enter the study without an explicit handoff.

Authentication is excluded. Restoring needs the recorded operating system and architecture, Python 3.11 or later, and access to the recorded model. Archives preserve persisted history and files, not a promise of the same next token. Historical Claude sessions remain historical; they are not converted into native Codex histories.

## Original case leads at D2

D2 restores each original case lead on its recorded model and effort. D3 continues that returned
lead. Both fleet arms use this rule. A new reader cannot substitute for a missing lead.

```bash
python3 rplace/aggregator/handler/codex/run.py lead-status
python3 rplace/aggregator/handler/codex/run.py register-lead SUBREDDIT CHECKPOINT_ID
```

`import-lead` can capture a completed native CLI lead whose home, workspace and runtime are
already inside the workspace (the folder that holds rplace). It requires `--home`, `--workspace`, `--executable`, `--thread`, `--model`
and `--effort`. It preserves original files and verifies the three coded files against the
current case snapshot. Old versions or missing native histories block the return.

The current 696-room dataset is present. Its matching native lead archives still need to be
registered before D2. Run the lead check before committing to the full study. The proposal
and design note are delivered only at E2.

## Models and tests

`aggregator/handler/claude/arm.json` sets exact models and effort by leg. Defaults use Astra for the aggregator and Sol medium for routine fleets. The [per-step schedule](Manual/OPENAI-MODELS.md) is a pilot allocation, not a measured optimum. [Stage cards](Manual/openai-stages/A1.md) give the launch sequence. Do not substitute models silently.

```bash
python3 rplace/aggregator/handler/codex/run.py test
```

Use `stop-run STUDY` to stop the study and prevent pending jobs from starting. `continue-run STUDY` clears an actor-only stop without starting work. `recover DISPATCH_ID` or `recover-plan STUDY` resumes a blocked phase plan, retaining accepted returns and models. New dispatch cannot bypass a blocked plan.

`python3 rplace/aggregator/handler/codex/run.py acceptance --live` runs a small authenticated conversation and two archive/restore interviews. Run it after login before research. `bash rplace/verify.sh` checks the runtime, scientific tests and all 696 prepared room packages. Keep at least 8 GiB free. `prune` verifies committed archives before removing released redundant workspaces. It preserves checkpoint folders, current study files and interrupted stores. Restoring an evicted actor uses its checkpoint. D4 numeric comparison requires NumPy and SciPy in the controller Python environment.

Offline fixtures test lifecycle and concurrency; they do not prove real model continuation. Consult `Jail 2/_codex_migration/` (the v40 copy) for the latest implementation head, diary, test evidence and outstanding acceptance checks. Source backups are there too. New builds use the [v40 instrument](Manual-html/INSTRUMENT-v40.html). 

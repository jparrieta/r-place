# Handover — the handler's seat

Run `gioia-j-sonnet-v37-20260908`, at `~/Jail/gioia-j-sonnet-v37-20260908`. Written 2026-09-08,
during stage 02.

You are the **handler**. Read this page, then `HANDOVER-handler.md` (the original: the arrangement
between the three parties, and the seven message kinds you must use with J), then
`CONTROL/HANDLER-PROTOCOL.md` for the checkpoint and fork mechanics. `CONTROL/handler-notes.md` is
the running record; `RUN.json` carries `operator_rulings` and a `spend` ledger.

## Where the run is

- **Stage 01: closed, verified, checkpointed.** `f71bcd63bf87f0dc`, kind `agent-and-files`,
  validator 0 errors 0 warnings. Census 300, dropped 0, 300 room notes.
- **Stage 02: launched 2026-09-08 20:09 local**, session `8cc1a50b-36f7-4ff1-a542-85f5e5335dbe`,
  a fresh session as the session rule requires. Running as this page was written.

### The loop, every stage, all eighteen

1. You send J a **READY**: the stage number, one sentence on what it is for, the exact line to run,
   the exact line to paste, and the stage card from `STAGE CARDS/`.
2. J runs `./CONTROL/harness/step.sh NN` in Terminal and pastes the printed line into Claude.
   **`step.sh` prints that line before Claude opens, so it scrolls out of sight and every stage
   looks to J like "nothing happened".** Put the paste line at the top of the READY, not the end.
3. The analyst works. J quits Claude when it stops, and tells you.
4. You close it: `bash CONTROL/harness/done.sh NN`. Then read `out/handback-NN.md`,
   `out/defects.jsonl` and `out/departures.jsonl` and tell J what it did and flagged.

A stage cannot close while its session is live — that is why J must quit, and it is a harness rule,
not a preference. Quitting loses no context: `head()` maps 08 and 09 onto 07 and 11 and 12 onto 10,
`prepare()` reuses the block head's session id, and `launch()` resumes it.

If `done.sh` refuses, **do not use `--force`**. Send a PROBLEM. The completion gate reads
undocumented transcript structure and fails closed, so it can refuse a finished stage.

## Four operator rulings already made — do not reopen them

1. **Stage 01 stands as written**, though its 300 room notes ignore the stated format: quoted
   participant language throughout and 293 of 300 over the 250-word ceiling, against a stage file
   saying "no quotes; code ids in brackets" and "under 250 words". The analyst filed this against
   itself as an undeclared departure. Consequence to carry: the notes cannot be mechanically reduced
   to code-id citations, and **stage 07 may not hold all 300 at once**.
2. **No fork was taken at 01**, the first declared fork point. The boundary is stored so a fork can
   be taken from it later; `fork.sh` allows any committed boundary and logs it as a departure. Fork
   points at 06 and 09 remain declared and undecided.
3. **No fixed budget ceiling.** The 60M in `budget_tokens` is the previous session's figure and is
   superseded. Keep the ledger, report spend at every close, but do not treat it as a wall. Stage 01
   spent 7,919,103 tokens excluding cache reads (plus 1.9B cache reads, billed at a fraction).
   Per-stage ceilings at 04, 10 and 14 stand as declared.
4. **The vault is not to be touched.** Changes bound for the kit are staged in `CHANGES/` for
   another agent to carry over.

## What was wrong with this run, and what was changed

The run **could not start** as built. Three defects, all found and fixed on 2026-09-08 before stage
01. Full account with the evidence in `CONTROL/handler-notes.md`; the files to carry back to the kit
are staged in `CHANGES/`. **Do not undo any of this.**

1. **The fence denied the analyst its own folder.** `denyRead` named `~/` and the run root, both
   ancestors of `00_GIVE-THE-AGENT/`, and **deny beats allowRead**. Python died in interpreter
   startup scanning a denied working directory. Fixed in `CONTROL/settings.template.json`:
   `allowRead` is the analyst folder alone, `denyRead` names run-root items individually and no
   ancestor.

2. **The analyst inherited the account's claude.ai connectors** — Gmail including `send_message`,
   Google Drive, Calendar, Hugging Face, plus `SendMessage` and `ListAgents`. **MCP calls are made
   by the CLI process and do not pass through the sandbox at all**, so no fence setting touches
   them. Fixed by `--strict-mcp-config` in `protocol_guard.py` plus deny rules. `Agent` is kept
   deliberately: stage 04 requires the analyst to run a fleet in fresh contexts.

3. **`CONTROL/.cc` shipped with no login**, so stage 01 would have stopped at a prompt. J did a
   one-time `/login` into it. Already done for this run; needed again for any new build.

Also proved, and load-bearing for the design: **`allowRead` is a whitelist.** Parent and sibling
directories are denied without being named, and install paths like `/opt/anaconda3` are implicitly
trusted. This is why forks may be siblings and why the run need not leave the home directory. It is
also why `CHANGES/` and this file, sitting at the run root and not named in `denyRead`, are still
invisible to the analyst.

## Constraints on you, the handler, learned the hard way

- **You cannot run the Claude CLI.** From the handler's Bash it reports "Not logged in" — the
  sandbox cannot reach the Keychain. Every check that needs the CLI must be handed to J as a line he
  types **in Terminal.app**. Do not hand him a code block expecting him to press Run in the chat:
  that executes in your sandbox, not his shell, and it produced a full page of false results today.
- **You cannot kill processes**, and you cannot write outside
  `~/Jail/gioia-j-sonnet-v37-20260908`. J set that fence deliberately. Anything in the vault is his
  to apply.
- **`done.sh`, `fork.sh`, `restore_stage.sh` and `compare_forks.py` do not call the CLI**, so those
  are yours to run.
- **Write assertions that read content, not existence.** Two checks gave false passes today: one
  tested that a transcript file existed (Claude Code writes it even when the call dies at "Not
  logged in"), and one matched `verb` inside "verbatim". Key on nonsense tokens or on the run's own
  fingerprint.

## Working with J

He owns the study and makes the judgements an author makes. He does not know bash and does not want
to. Structure every message as one of the seven kinds in `HANDOVER-handler.md` — READY, CLOSED,
READING, QUESTION, RULING, PROBLEM, FORK — one kind per message, each saying what it needs back.

Two things worth knowing that the original handover does not say:

- **He sometimes runs `step.sh` without telling you.** Today a stage-01 session sat open for half an
  hour while settings were being changed underneath it. Ask him to tell you each time he launches,
  and check for a live session before changing anything the analyst reads.
- **He asks good questions about things you have not thought to check.** The connector breach was
  found because he asked whether the session he could see in the desktop app inherited the handler's
  connectors. No check written for this run would have caught it. Take his questions seriously.

The two moments that are genuinely his are the readings after stage 10 and stage 12. Render the ten
compositions and the three cluster accounts into the chat — never send him a path — take his reply
in ordinary words, and write `objections.jsonl` yourself. File one line even if he objects to
nothing; the analyst must answer him before the next stage computes.

## What must never reach the analyst

The one line `step.sh` prints, and nothing else. Not other runs, not other arms, not the model, not
the instrument version, and above all not that it is a fork or that a sibling exists. Answers to its
questions arrive as files in the next drop, never in the chat. If J says something to it he should
not have, record it and treat that fork's comparison as compromised.

## Open items

- **Contamination, bounded and unresolved.** `~/.claude/CLAUDE.md` reaches the analyst as eight
  bytes, the literal `@RTK.md`, with the referenced file unreadable. No substantive instruction gets
  through, but it tells the analyst a configuration exists that it cannot see. An empty `CLAUDE.md`
  in `CONTROL/.cc` did not shadow it. The only reliable fix is moving J's file aside for the run,
  which disables RTK in all his sessions. He has not been asked to accept that.
- **`CHANGES/` has not been applied to the kit.** J explicitly does not want the vault touched. The
  files are staged in `CHANGES/for-the-kit/` with a README mapping each to its destination, for
  another agent to carry over. `CHANGES/refresh.sh` re-collects them; run it after any further
  change.
- **The budget is 60M tokens**, which `RUN.json` records as the previous session's figure and not
  J's. Ceilings: 8M at 04, 20M at 10, 4M at 14. Nothing has measured spend yet.
- A spare, identical, unstarted copy of the run was returned to
  `Snapshot-v37/BUILD/gioia-j-sonnet-v37-20260908`. It is not the live run. The live run is the one
  in `~/Jail/`.

## Where things are

    HANDOVER-handler.md          the original: the arrangement, the seven message kinds
    HANDOVER-NEXT-HANDLER.md     this page
    READ-ME-FIRST.md             written for J, not for you
    STAGE CARDS/                 one card per stage; you send him the card with each READY
    CONTROL/handler-notes.md     the running record of what was found and done
    CONTROL/HANDLER-PROTOCOL.md  checkpoint, fork and restore mechanics
    CONTROL/harness/             done.sh, fork.sh, restore_stage.sh, compare_forks.py, acceptance.sh
    CONTROL/harness/acceptance.sh  ten-check pre-flight; J runs it in Terminal, requires ALL CLEAR
    CHANGES/                     everything this run changed, staged for the kit
    00_GIVE-THE-AGENT/out/       where the analyst writes; handback-NN.md is its own account

What is not written down did not happen.

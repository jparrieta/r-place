# Handler notes — gioia-j-sonnet-v37-20260908

## 2026-09-08, before stage 01

**Relocation.** The run was built inside the Obsidian vault. `lib.sh:refuse_in_vault` hard-refuses
to operate there, so it was moved out; it now stands at `~/Jail/gioia-j-sonnet-v37-20260908`. A
second, identical, unstarted copy was found and retired to
`~/rplace-runs/_DUPLICATE-do-not-use-…` so neither party could start the run in the wrong tree; it
is J's to return to the vault. All 2178 shipped input files verify against `MANIFEST-in.sha256`
after the move.

**Settings.** The analyst's `settings.json` had been rendered for a Cowork mount
(`/sessions/rcw-…/mnt/…`) that does not exist on this host. Regenerated for the real path. Note
the deny rules render with a double leading slash (`Read(//Users/…)`) — this is deliberate, and is
the documented fix for single-leading-slash rules anchoring at the settings source.

**Login — a risk the handover did not list.** The analyst runs under `CLAUDE_CONFIG_DIR=CONTROL/.cc`,
which shipped with no account marker, so stage 01 would have stopped at a login prompt. There is no
`.credentials.json`: the secret lives in the Keychain and only the marker (`oauthAccount`, `userID`)
lives in the config dir. A one-time login into that directory fixed it. This is the intended design
— `protocol_guard.py:248` and `seal.py:44` both filter credential-named files out of checkpoints and
seals — but the build never performed the login. **A rebuilt run will need it again.** The login
conversation (231KB, in `projects/-private-tmp`) was removed before it could enter a checkpoint.

**Fork flags — the handover's largest risk, now closed.** `claude --resume <parent> --fork-session
--session-id <new uuid>` is accepted by CLI 2.1.263. The child takes the preassigned id, inherits
the parent's context, and the parent transcript is byte-identical afterwards. Forks at 01, 06 and 09
can proceed.

**Fence.** Proved with a throwaway session using the analyst's exact settings and runtime directory,
not the study session. `CONTROL/` and `DROPS/` are unreachable via the Read tool, via `ls`, and via
python — the sandbox enforces on the resolved path at syscall level, so encoding the path in the
command bought nothing.

**Method note.** The first pre-flight was run from a chat code block rather than a Terminal and
returned three false passes, because its assertions checked that a transcript *file* existed — and
Claude Code writes that file even when the call dies at "Not logged in". The tests were rewritten to
assert on transcript and reply *contents*. Both scripts are kept: `CONTROL/preflight.sh`,
`CONTROL/fence-test.sh`.

## The fence defect, and the correction (2026-09-08)

**The run as built could not start.** `sandbox.filesystem.denyRead` named `~/` and the run root.
Both are ancestors of `00_GIVE-THE-AGENT/`, and **deny beats allowRead**, so the analyst could not
read its own study folder. Python died inside interpreter startup because `python3 -c` puts the
current directory on the import path and scanning a denied directory raises `PermissionError`.
Python 3.8 tolerates that and 3.13 does not, which is the only reason `/usr/bin/python3` appeared
to work and made conda look like the culprit. It was never conda.

**Proved, not inferred.** Two folders identical but for whether a denied ancestor existed: the one
under a denied parent could not list itself; the one not under any denied path could. A third lab
showed `allowRead` is a **whitelist** — parent and sibling folders are denied without being named,
and install paths such as `/opt/anaconda3` are implicitly trusted.

**Consequences for the design.** Forks may be siblings: a fork cannot read its siblings, so no
special layout is needed and the run need not leave the home directory. `CONTROL/`, `DROPS/`,
`STAGE CARDS/` and the handler documents are hidden by the whitelist, not by being denied.

**The fix**, in `settings.template.json` so it carries to every fork and restore: `allowRead` is the
analyst folder alone; `denyRead` names the five run-root items individually and no ancestor.
Verified after: reads own folder, python 3.13.9, numpy/scipy/pandas with Ward linkage, `mem.py`
runs, writes `out/`, `CONTROL/` denied. **A rebuilt run inherits this defect unless the kit's
template is fixed too.**

**Two false results of my own, recorded so they are not repeated.** An early check passed because it
tested that a transcript *file* existed, and Claude Code writes that file even when the call dies at
"Not logged in". Another passed because the pattern `verb` matched the word "verbatim" in prose.
Assertions in this run now key on nonsense tokens or on the run's own fingerprint.

## The connector breach (2026-09-08) — the most serious defect found

The fence, the sandbox and every check above govern the **operating system**: what a shell command
can reach. MCP connectors do not pass through any of it — those calls are made by the CLI process
itself, so `network.allowedDomains: []` and `denyRead` never see them.

A session launched exactly as the harness launches it was handed **Gmail** (including `send_message`
and `forward`), **Google Drive** (`search_files`, `read_file_content`), **Google Calendar** and
**Hugging Face** (`hf_fs`, which reads the Hub over the network), plus `SendMessage` and
`ListAgents`. The analyst could therefore have read J's Drive, sent mail as him, fetched arbitrary
data from the internet, and — fatal for this design — discovered and messaged the handler's session
to ask what it was. These are account-level connectors from claude.ai; they are attached to the
logged-in account, not to the config directory, which is why nothing in the run's own files revealed
them. The Obsidian vault connector was not among them, so vault material was never exposed.

Found because J asked whether the session in the desktop list inherited the handler's connectors.
No check written for this run would have caught it.

**The fix.** `--strict-mcp-config` added to the launch in `protocol_guard.py` (backup at
`protocol_guard.py.bak-preconnector`), so the CLI uses only MCP servers passed explicitly, and the
harness passes none. Plus deny rules in `settings.template.json` for `mcp__*`, the MCP resource
readers, `SendMessage`, `ListAgents`, `RemoteTrigger`, `PushNotification`, the Cron tools,
`Workflow`, `DesignSync`, `ScheduleWakeup`, the worktree tools, `Monitor` and `Skill` (skills load
from the home directory, outside the fence). `Agent`, `Bash`, `Read`, `Write` and `Edit` are kept
deliberately: stage 04 requires the analyst to run a fleet in fresh contexts.

**Verified after the fix**: the analyst's tools are exactly Agent, Bash, Edit, Read, Write,
NotebookEdit, ToolSearch, ReportFindings, TaskOutput, TaskStop. **A rebuilt run inherits this
breach unless the kit carries both changes.**

## A stale rule in RUN.json (noted 2026-09-08)

`RUN.json`'s `sessions_rule` still reads "Snapshot at every stage boundary **without quitting inside
a block**". That was the pre-rework procedure and the current harness contradicts it: `preclose`
requires the launcher to have exited cleanly, so a stage cannot be closed while its session is live,
and the procedure is now uniform across all eighteen stages -- open, work, quit, close.

Context is not lost by quitting. `head()` maps 08 and 09 onto 07, and 11 and 12 onto 10; `prepare()`
reuses the block head's session id from `active_blocks.json` with mode `shared`, and `launch()` then
uses `--resume` because the transcript already exists. The conversation persists on disk and is
reopened by identity.

The field was left as it is rather than edited, because `RUN.json` is the run's own declaration and
rewriting a declared rule mid-run would be worse than a footnote. A handler reading only `RUN.json`
would follow the wrong procedure and then be refused by `done.sh`.

## Stage 01 closed (2026-09-08 17:52Z)

Checkpoint `f71bcd63bf87f0dc`, verified independently after publication. Validator: 0 errors, 0
warnings. Census 300, dropped 0, analysed 300, 300 room notes, 300 canvas lines.

Four defects filed by the analyst. Three concern the package and were resolved by recomputation:
forest headers and store disagree by exactly 7 items (one synthetic root per room, in 7 rooms);
9 rooms share a canvas outcome with another room in 4 groups, so `canvas_area_px` is not always an
independent per-room measure; 4 rooms have `onset_last_code_hour` beyond the window's bound because
coders deliberately coded items marked after the window.

The fourth is about its own conduct: the room notes ignore the stated format. **Operator ruling:
accept as written.** See `operator_rulings` in RUN.json.

Handback raises one instrument gap worth carrying to the kit: `run_manifest.json` asks for
`package_sha256` and `tools_commit` as if both already exist, but there is no `.git` anywhere and no
VERSION under `tools/`. The analyst computed both itself and prefixed the tools hash `no-vcs:`.
A future `HOW-TO-RUN.md` should state the convention rather than let each stage invent one.

**Spend, stage 01: 7,919,103 tokens excluding cache reads (13.2% of 60M); 1.9B cache reads;
3,757 assistant turns.** No budget accounting exists in the harness; it is the handler's to track,
and `RUN.json` now carries a `spend` ledger. Operator ruling: proceed and monitor.

## The first fork point, not taken (2026-09-08)

**Operator ruling: do not fork at 01; store the boundary so a fork can be taken from it later.**
The checkpoint is self-contained -- fs.tar.gz 41MB, agent.tar.gz 9MB, instrument.tar.gz,
transcript.jsonl 26MB, all with per-entry manifests and COMMITTED written last -- and `fork.sh`
permits forking at any committed boundary, logging it as a departure from the declared points. So
nothing is lost by waiting. Fork points at 06 and 09 remain declared and undecided.

The reasoning: a fork at 01 is the most expensive available, since each child re-runs 02-18 in full.
On stage 01's evidence a single unforked arm is likely 60M-100M, so N children multiply that by N.

**Operator ruling: no fixed budget ceiling.** The 60M was the previous session's figure. The ledger
in `RUN.json.spend` is kept and reported at every close, but it is not a wall. Per-stage ceilings at
04, 10 and 14 stand.

## Still open

- **Contamination, unresolved and bounded.** `~/.claude/CLAUDE.md` reaches the analyst: eight bytes,
  the literal `@RTK.md`, with the file it references unreadable. No substantive instruction gets
  through, but it tells the analyst a configuration exists that it cannot see. An empty `CLAUDE.md`
  in `CONTROL/.cc` did not shadow it. The only reliable fix is moving J's file aside for the run,
  which disables RTK in all his sessions; J has not been asked to accept that.
- The completion gate reads undocumented transcript structure. It fails closed. If it refuses a
  stage that is genuinely finished, send J a PROBLEM before reaching for `--force`.
- `denyRead` now enumerates run-root items. Anything new added at the run root is visible to the
  analyst unless added to the template.

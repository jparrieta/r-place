#!/usr/bin/env bash
# Re-collect every file this run has changed into CHANGES/, and rebuild the manifest.
# Idempotent. The handler runs this after each change; run it by hand any time.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
C="$RUN/CHANGES"
# source-in-run                        destination-in-CHANGES
TRACK="
CONTROL/settings.template.json         for-the-kit/ASSETS/templates/settings.json
CONTROL/harness/protocol_guard.py      for-the-kit/ASSETS/harness/protocol_guard.py
CONTROL/harness/acceptance.sh          for-the-kit/ASSETS/harness/acceptance.sh
CONTROL/handler-notes.md               run-only/handler-notes.md
HANDOVER-NEXT-HANDLER.md               run-only/HANDOVER-NEXT-HANDLER.md
CONTROL/patch-kit.sh                   diagnostics/patch-kit.sh
CONTROL/preflight.sh                   diagnostics/preflight.sh
CONTROL/fence-test.sh                  diagnostics/fence-test.sh
CONTROL/fence-precedence.sh            diagnostics/fence-precedence.sh
CONTROL/fence-siblings.sh              diagnostics/fence-siblings.sh
CONTROL/python-test.sh                 diagnostics/python-test.sh
CONTROL/diagnose-python.sh             diagnostics/diagnose-python.sh
CONTROL/verify-fix.sh                  diagnostics/verify-fix.sh
CONTROL/tool-inventory.sh              diagnostics/tool-inventory.sh
"
n=0
printf 'sha256\tbytes\tmodified_utc\tfile_in_CHANGES\tcopied_from\n' > "$C/MANIFEST.tsv"
while read -r src dst; do
  [ -n "${src:-}" ] || continue
  [ -f "$RUN/$src" ] || continue
  mkdir -p "$(dirname "$C/$dst")"
  cp -p "$RUN/$src" "$C/$dst"
  printf '%s\t%s\t%s\t%s\t%s\n' \
    "$(shasum -a 256 "$C/$dst" | cut -d' ' -f1)" \
    "$(wc -c < "$C/$dst" | tr -d ' ')" \
    "$(date -u -r "$C/$dst" +%Y-%m-%dT%H:%M:%SZ)" \
    "$dst" "$src" >> "$C/MANIFEST.tsv"
  n=$((n+1))
done <<< "$TRACK"
echo "CHANGES refreshed: $n files. Manifest: CHANGES/MANIFEST.tsv"

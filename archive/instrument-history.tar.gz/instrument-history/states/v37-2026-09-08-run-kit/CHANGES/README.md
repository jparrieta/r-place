# CHANGES — what this run changed, for whoever updates the kit

This folder is a staging area, not a patch that has been applied. **Nothing in the vault has been
modified.** Everything here is a copy of a file as it now stands in this run, ready to be carried
into `Snapshot-v37/` by someone with rights to write there.

Refresh it at any time with `bash CHANGES/refresh.sh`. `MANIFEST.tsv` lists every collected file
with its hash, size and modification time.

## for-the-kit/ — copy these into the kit

| this file | goes to | why |
|---|---|---|
| `ASSETS/templates/settings.json` | `Snapshot-v37/ASSETS/templates/settings.json` | the fence defect: `denyRead` named the analyst's own ancestors, so the run could not start at all |
| `ASSETS/harness/protocol_guard.py` | `Snapshot-v37/ASSETS/harness/protocol_guard.py` | one added line, `--strict-mcp-config`, which strips the account's connectors from every launch |
| `ASSETS/harness/acceptance.sh` | `Snapshot-v37/ASSETS/harness/acceptance.sh` | new: the ten-check pre-flight. `build.sh` already copies `ASSETS/harness/*`, so it ships into every future run at `CONTROL/harness/acceptance.sh` |
| `KIT-NOTES-20260908.md` | `Snapshot-v37/KIT-NOTES-20260908.md` | new: what was wrong, how it was proved, and the one defect that cannot be fixed in a file |
| `RUNBOOK-append.md` | append its body to `Snapshot-v37/RUNBOOK.md` | three lines pointing at the notes |

`build.sh` needs no change. It already copies both the template and the whole harness directory.

**Back up before overwriting.** The vault convention is a dated folder under
`Layer A/_exports/_to_delete/`. `diagnostics/patch-kit.sh` does the whole job — backup, copy, patch,
verify — but it was written to be run by someone with vault write access, and has not been run.

## The one thing that cannot be carried in a file

The run's config directory ships with no login, so stage 01 stops at a login prompt. Every new run
needs a one-time `/login` into `CONTROL/.cc` by hand. `KIT-NOTES-20260908.md` gives the command.
This is why the runbook change matters more than it looks.

## diagnostics/ — how the defects were found

One-off scripts, kept as evidence and because they are reusable. All of them launch **throwaway**
sessions and touch no study material.

- `fence-precedence.sh` — the experiment that proved deny beats allowRead: two folders identical but
  for whether a denied ancestor existed.
- `fence-siblings.sh` — proved `allowRead` is a whitelist, so a fork cannot read its siblings.
- `tool-inventory.sh` — asks a session in the analyst's folder to list its own tools. This is what
  caught the connector breach; no file in the run reveals it.
- `verify-fix.sh`, `python-test.sh`, `diagnose-python.sh`, `fence-test.sh`, `preflight.sh` — the
  earlier, narrower checks. `acceptance.sh` supersedes them all.
- `patch-kit.sh` — applies everything in `for-the-kit/` to the vault, with backups. Unrun.

## run-only/ — not for the kit

`handler-notes.md` is this run's own record. `CONTROL/RUN.json` also gained `run_host` and a long
`sandbox_verified` string recording what was proved before stage 01; that field is per-run and
should not be copied, but the kit's builder may want to know it is expected to be filled.

## Status

Stage 01 launched 2026-09-08 11:27 with all corrections in place. Unresolved: the operator's global
`~/.claude/CLAUDE.md` still reaches the analyst as eight bytes of text.

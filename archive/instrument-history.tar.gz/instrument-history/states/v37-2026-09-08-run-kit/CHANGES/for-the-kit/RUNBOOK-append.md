Append this to the kit's RUNBOOK.md:

## Before stage 01 of any run (added 2026-09-08)

1. The run must stand outside the vault; the harness refuses to operate inside it.
2. Log in to the run's own config directory once — it ships empty and stage 01 will otherwise stop
   at a login prompt. See `KIT-NOTES-20260908.md`.
3. Run `CONTROL/harness/acceptance.sh` and require ALL CLEAR before launching.

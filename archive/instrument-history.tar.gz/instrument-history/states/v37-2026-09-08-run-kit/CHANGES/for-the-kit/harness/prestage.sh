#!/usr/bin/env bash
# prestage.sh NN
#   Capture everything an abort of stage NN would need to put back, BEFORE the stage is launched.
#   Writes CONTROL/stage-state/<label>/PRE/. Idempotent per stage: refuses if one already exists,
#   so a re-run after a resume cannot overwrite the true pre-launch state.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"
LABEL="$(norm_label "${1:?stage number}")"; NN="$(label_nn "$LABEL")"
S="$C/stage-state/$LABEL"; P="$S/PRE"
[ -e "$P" ] && { echo "PRE state already captured for $LABEL: $P" >&2; exit 1; }
PREV="$(prev_label "$RUN" "$LABEL")"
[ -n "$PREV" ] || { echo "no previous stage for $LABEL" >&2; exit 1; }
D="$C/snapshots/$PREV"
[ -f "$D/COMMITTED" ] || { echo "previous stage $PREV has no committed checkpoint" >&2; exit 1; }
mkdir -p "$P/control" "$P/cc"
for f in sessions.json active_blocks.json last_launch_exit.json handover-events.log \
         pending_launch.json active_launch.json RUN.json; do
  [ -f "$C/$f" ] && cp "$C/$f" "$P/control/$f"
done
for f in .claude.json history.jsonl; do
  [ -f "$C/.cc/$f" ] && cp "$C/.cc/$f" "$P/cc/$f"
done
ls -1 "$C/.cc/projects/run" > "$P/cc/transcripts-before.txt" 2>/dev/null || true
find "$RUN/00_GIVE-THE-AGENT" -type f | LC_ALL=C sort > "$P/analyst-files-before.txt"
python3 - "$P" "$LABEL" "$PREV" "$(json_get "$D/checkpoint.json" checkpoint_id)" <<'PY'
import json,sys,datetime
p,label,prev,ckpt=sys.argv[1:5]
json.dump({"label":label,"restore_from_label":prev,"restore_from_checkpoint":ckpt,
           "captured_utc":datetime.datetime.now(datetime.timezone.utc)
                          .strftime("%Y-%m-%dT%H:%M:%SZ")},
          open(p+"/baseline.json","w"),indent=2)
PY
( cd "$P" && find . -type f -not -name MANIFEST.sha256 | LC_ALL=C sort | xargs $SHA > MANIFEST.sha256 )
echo "captured pre-launch state for $LABEL -> $P (restores to $PREV)"

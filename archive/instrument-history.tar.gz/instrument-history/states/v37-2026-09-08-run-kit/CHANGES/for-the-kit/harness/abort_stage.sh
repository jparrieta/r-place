#!/usr/bin/env bash
# abort_stage.sh NN [--yes]
#   Put the run back exactly as it stood before stage NN was launched, and lose nothing.
#   1. refuses if the stage looks live (its transcript was written in the last 90s)
#   2. archives everything the stage produced, with a sha256, under CONTROL/aborted/
#   3. replaces 00_GIVE-THE-AGENT wholesale from the previous stage's committed checkpoint
#   4. puts CONTROL and the analyst's CLI state back from CONTROL/stage-state/<label>/PRE
#   5. verifies the restored tree against the checkpoint manifest and refuses to claim success
#      if it does not match
#   Needs no judgement from whoever runs it. Nothing here is edited by hand.
set -euo pipefail
ARGS=("$@")
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"; AG="$RUN/00_GIVE-THE-AGENT"
LABEL="$(norm_label "${1:?stage number}")"; NN="$(label_nn "$LABEL")"; shift
YES=0; for a in "$@"; do [ "$a" = --yes ] && YES=1; done
if [ "${AGGREGATOR_LOCK_RUN:-}" != "$RUN" ]; then
  exec python3 "$C/harness/protocol_guard.py" locked "$RUN" bash "$0" "${ARGS[@]}"
fi
P="$C/stage-state/$LABEL/PRE"
[ -d "$P" ] || { echo "no captured pre-launch state for $LABEL; run prestage.sh $NN before launching" >&2; exit 1; }
( cd "$P" && $SHA -c --quiet MANIFEST.sha256 ) || { echo "PRE state fails its own manifest; not aborting" >&2; exit 1; }
PREV="$(json_get "$P/baseline.json" restore_from_label)"
CKPT="$C/snapshots/$PREV"
CKPT_ID="$(json_get "$CKPT/checkpoint.json" checkpoint_id)"
[ -f "$CKPT/COMMITTED" ] || { echo "checkpoint $PREV is not committed" >&2; exit 1; }
SID="$(json_get "$C/sessions.json" "$LABEL.session_id")"
[ -n "$SID" ] || SID="$(json_get "$C/pending_launch.json" requested_session_id)"
T="$C/.cc/projects/run/$SID.jsonl"
if [ -n "$SID" ] && [ -f "$T" ]; then
  AGE=$(( $(date +%s) - $(stat -f %m "$T" 2>/dev/null || stat -c %Y "$T") ))
  [ "$AGE" -lt 90 ] && { echo "REFUSING: $SID was written ${AGE}s ago; quit Claude first" >&2; exit 1; }
fi
if [ "$YES" -eq 0 ]; then
  echo "About to abort $LABEL and restore $PREV ($CKPT_ID)."
  printf 'Type the stage label to confirm: '
  read -r REPLY; [ "$REPLY" = "$LABEL" ] || { echo "not confirmed" >&2; exit 1; }
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
A="$C/aborted/$LABEL-$STAMP"
mkdir -p "$A/files"
# 1. archive: every analyst file that is new or changed since the capture, the transcript, the state
python3 - "$AG" "$P/analyst-files-before.txt" "$A/files" "$CKPT/fs.sha256" <<'PY'
import sys,os,shutil,hashlib,pathlib
ag,before,dest,fsman=sys.argv[1:5]
prior=set(open(before).read().split("\n"))
want={}
for line in open(fsman):
    p=line.split("\t")
    if len(p)>4 and p[0]=="file": want[p[3]]=p[2]
def sha(f):
    h=hashlib.sha256()
    with open(f,'rb') as fh:
        for b in iter(lambda: fh.read(1<<20), b''): h.update(b)
    return h.hexdigest()
n=0
for root,_,files in os.walk(ag):
    for f in files:
        full=os.path.join(root,f); rel=os.path.relpath(full,ag)
        if rel.startswith("_transcripts/") or "__pycache__" in rel: continue
        if full in prior and want.get(rel)==sha(full): continue
        d=os.path.join(dest,"analyst",rel); os.makedirs(os.path.dirname(d),exist_ok=True)
        shutil.copy2(full,d); n+=1
print("archived %d analyst files new or changed during the stage" % n)
PY
[ -n "$SID" ] && [ -f "$T" ] && cp "$T" "$A/files/transcript-$LABEL.jsonl"
for f in sessions.json active_blocks.json last_launch_exit.json handover-events.log \
         pending_launch.json active_launch.json; do
  [ -f "$C/$f" ] && cp "$C/$f" "$A/files/at-stop-$f"
done
cp "$P/baseline.json" "$A/"
( cd "$C/aborted" && tar -czf "$LABEL-$STAMP.tar.gz" "$LABEL-$STAMP" && $SHA "$LABEL-$STAMP.tar.gz" > "$LABEL-$STAMP.tar.gz.sha256" )
rm -rf "$A" || echo "note: could not tidy the unpacked copy at $A; the tar.gz beside it is complete" >&2

# 2. the analyst directory, replaced wholesale from the checkpoint
TMP="$RUN/.restore-$STAMP"
rm -rf "$TMP"; mkdir -p "$TMP"
tar -xzf "$CKPT/fs.tar.gz" -C "$TMP"
rm -rf "$AG"
mv "$TMP/00_GIVE-THE-AGENT" "$AG"
rm -rf "$TMP"
python3 "$C/harness/protocol_guard.py" verify-tree "$AG" "$CKPT/fs.sha256"

# 3. CONTROL and the analyst's CLI state, back from the capture
for f in sessions.json active_blocks.json last_launch_exit.json handover-events.log RUN.json; do
  if [ -f "$P/control/$f" ]; then cp "$P/control/$f" "$C/$f"; else rm -f "$C/$f"; fi
done
for f in pending_launch.json active_launch.json; do
  if [ -f "$P/control/$f" ]; then cp "$P/control/$f" "$C/$f"; else rm -f "$C/$f"; fi
done
for f in .claude.json history.jsonl; do
  [ -f "$P/cc/$f" ] && cp "$P/cc/$f" "$C/.cc/$f"
done
if [ -n "$SID" ]; then
  rm -rf "$C/.cc/projects/run/$SID.jsonl" "$C/.cc/projects/run/$SID" "$C/.cc/file-history/$SID"
fi

mv "$C/stage-state/$LABEL" "$C/stage-state/$LABEL-aborted-$STAMP"
printf '%s\taborted\t%s\trestored %s from %s\n' "$(NOW)" "$LABEL" "$PREV" \
  "$CKPT_ID" >> "$C/handover-events.log"
cat <<MSG

aborted $LABEL. the run stands at $PREV ($CKPT_ID).

  archive   $C/aborted/$LABEL-$STAMP.tar.gz  (sha256 beside it)
  verified  00_GIVE-THE-AGENT matches the $PREV checkpoint manifest
  next      ./CONTROL/harness/prestage.sh $NN   then   ./CONTROL/harness/step.sh $NN

MSG

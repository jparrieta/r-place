# The method shelf

Served at stage 07 and again at stage 10. Nine works, in the order they rank here. The hierarchy:
**this is a Gioia study**; within-case discipline is Eisenhardt's; process data is handled as
Van de Ven and Poole handle it; Langley supplies strategies for the dynamic part only, each
declared and costed before it is used; Pentland is optional. Where a work ships beside this file as
a PDF, read it; where it does not, you work from recollection and say so in your notes.

1. **Gioia, Corley and Hamilton (2013), "Seeking qualitative rigor in inductive research: notes on
   the Gioia methodology", *Organizational Research Methods* 16(1): 15–31.** The spine. Re-read
   whole at stage 07: **it ships beside this file as
   `package/store/shelves/gioia-corley-hamilton-2013.md`**, the full text converted from the
   publisher's EPUB, its two figures excepted (the data structure and the grounded model are
   images in the source; the text describing both is complete). What it gives you here: first-order terms in the informants' words;
   second-order themes and aggregate dimensions as the researcher's theory-centric constructs; the
   data structure as the display of the move from data to theory; the grounded model as the
   dynamic account the data structure cannot carry; theoretical sampling and the constant
   comparison as what makes the second order more than a sort.

   **Read it against this study's tiers, not against its own labels.** Their first-order concepts
   are your second-order themes: that tier is meant to explode and is not distilled, which is why
   yours runs to the hundreds and carries no construct's name. Their second-order themes are your
   third-order chunks. Their aggregate dimensions are your aggregate dimensions. Their Appendix A
   distills dimensions *if appropriate*; the contract's §3 requires them here, and says why. Read
   their two warnings about how others use the method as addressed to you: the 1st/2nd-order rubric
   applied as a reflex, and the approach treated as a template or a formula. No count in this
   study's tiers is set for you, and none should be reached for because a published figure had it.

2. **Gehman, Glaser, Eisenhardt, Gioia, Langley and Corley (2018), "Finding theory–method fit: a
   comparison of three qualitative approaches to theory building", *Journal of Management Inquiry*
   27(3): 284–300.** The three approaches compared by their own authors. Read it to keep Langley
   in proportion: what each approach is for, what each asks of the data, and where they refuse
   each other.

3. **Suddaby (2006), "From the editors: what grounded theory is not", *Academy of Management
   Journal* 49(4): 633–642.** The six things grounded theory is not: not an excuse to ignore the
   literature, not raw data presented, not theory testing or content analysis or word counts, not
   a mechanical routine, not perfect, not easy. Read it beside every count you are tempted to
   report as a finding.

4. **Corley and Gioia (2004), "Identity ambiguity and change in the wake of a corporate spin-off",
   *Administrative Science Quarterly* 49(2): 173–208.** The worked example the figures come from:
   a data structure and a grounded model side by side, and the prose that connects them.

5. **Eisenhardt (1989), "Building theories from case study research", *Academy of Management
   Review* 14(4): 532–550.** Within-case analysis before cross-case; the cross-case step as
   searching for patterns across pairs and groups of cases; replication logic; enfolding the
   literature after the constructs exist. Stage 07's three within-case accounts and stage 10's
   return to the field are hers.

6. **Van de Ven and Poole (1990), "Methods for studying innovation development in the Minnesota
   Innovation Research Program", *Organization Science* 1(3): 313–335.** Incidents to events to
   tracks: the grammar of the forest. A coded turn is an incident; an event is a set of incidents
   an analyst brackets on a stated rule; a track is a sequence of events in one case. The rule is
   written before the bracketing.

7. **Langley (1999), "Strategies for theorizing from process data", *Academy of Management Review*
   24(4): 691–710.** The strategies: narrative, quantification, alternate templates, grounded
   theory, visual mapping, temporal bracketing, synthetic. Use one for the dynamic part of the
   model and declare it with its cost. A phase boundary in temporal bracketing must be a
   discontinuity in the data, not a convenience of the account.

8. **Langley, Smallman, Tsoukas and Van de Ven (2013), "Process studies of change in organization
   and management: unveiling temporality, activity, and flow", *Academy of Management Journal*
   56(1): 1–13.** The strong process view, read knowing it is not this study's ontology: this
   study has organizations as things that form, hold and end, and reads the process view for what
   it says about temporality and activity.

9. **Pentland (1999), "Building process theory with narrative: from description to explanation",
   *Academy of Management Review* 24(4): 711–724.** Optional. Narrative as process data: sequence,
   focal actor, voice, evaluative frame, context. For the within-case accounts and for reading a
   coder's `case.md` as a narrative with a narrator.

**Tier A cues, re-served here beside `prior.md`.** The contract's §1 names the question and the
standing claim; §3 names the tiers; rule 13 says what a challenge decides. Read the contract's §1
and §3 again before you read anything above.

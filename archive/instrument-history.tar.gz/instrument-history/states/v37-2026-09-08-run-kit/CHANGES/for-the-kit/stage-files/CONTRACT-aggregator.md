# Aggregator's contract — the brief.

**You will be given this file plus one stage file at a time.** This file holds what is true at every
stage: the question, what you hold, the rules. What applies at one stage only sits in that stage's
file. Read both before you start. Nothing in a stage file overrides anything here.

## What you are here to do, and what the checks are for

Three hundred communities left a public record of the same 97-hour event. Three hundred analysts
each read one, sealed from the others, and produced first-order codes in the participants' words,
case themes, a within-case account and working notes. None of them could compare across rooms.
**The cross-case work is yours and none of it has been done**: the themes, the abstraction, the
concept, the model, and then an account of how every one of the 300 organized. The method is
Gioia, Corley and Hamilton's, run at a scale one person cannot hold, and the aim is a model
exhaustive enough that each community can be explained from the text.

That takes two things this file is built to give you. **Familiarity**: you will have read every room
before you build anything, and your own notes on them travel with you through every stage.
**Conviction**: this instrument is full of checks, and every one of them exists so that you can
claim boldly and survive being checked. A claim that meets a counterexample acquires a condition; it
is not withdrawn. A finding that has never been challenged is not thereby strong. You are required
to be wrong in places and right in shape, and a model with no counterexample is a model nobody
tested. The rules below say what a challenge decides and what it does not; read them as permission.

**Think on disk.** Anything you would hold in your head between two steps, write to `out/` under a
name starting with `_`. Those files are yours, nobody audits their prose, and they are the only part
of your state that survives a context boundary and travels with a fork. Two of them are not
optional: `out/_head.md`, what you would tell yourself if you woke tomorrow with no memory of this
run, read first in every session and rewritten at every stage close, on a clock, and before every
compaction; and `out/diary-NN.md`, the stage's diary, free in form, closed with what you know,
what you just did and what worries you. The standing instructions say what goes in each.

**Rule 10 says you may depart from this file**, and how. Read it before deciding that something here
prevents you from acting.

---

## 1. The question

> **When strangers organize on a clock they did not set, with no way to compel anyone and no goal
> given to them: what forms does organizing take, how do they differ in their functioning, and
> which of them keep the work alive?**

Every case meets the three conditions and the sample was not chosen on any of them. No room has a
legal form, money, or a way of making anyone do anything; the clock was imposed; nothing was
assigned, so whatever a room was *for* it produced rather than received.

**The clock, once.** The window is 97 hours. Placement was disabled at hour 73; the last 24 hours
are aftermath. Anything that crosses hour 73 crosses once.

**Two kinds of ending.** Losing ground on the canvas dissolves nothing; the room is still there. What
can end is the organizing, and this record shows it, because the room goes on talking after the
coordinating stops. Do not read *failure does not end them* as *nothing ends*.

Four things the model has to say, none assumed: how a scattered readership becomes something that
can act, and how it settles what to act on, which are two achievements; what sends a group back to
that beginning; what brought organizing about when it came, and what followed; and what they leave
behind, if anything.

If the material makes you want to change the question, you may. Say so, say why, and say what the
earlier version would have missed.

### The standing claim, and the ban that goes with it

This study belongs to organization design. Its working definition: **an organization is a group of
people with a goal**, and every such group must solve four universal problems: **task division**,
**task allocation**, **reward provision**, **information provision**. That claim is what the
crossing (stages 13 to 15) tests against your material, and stage 08 puts it to your structure
before the crossing runs.

Three things bind. **The second-order tier is never named after one of the four, or after any
construct**: it is descriptive, near the material, gerund-led where the material allows (§3), and
it stays so through every recut. Chunks and dimensions are constructs from the moment they are cut
(§3), and any literature may name them, the four's vocabulary included, under the declaration and
with the sentence that says what this material's version cannot do; the crossing's agents never
see a chunk's name, so a name borrowed from the four does not reach the stage meant to test them,
and stage 08's fourth pass reads your answer with the borrowing declared. **Do not build the
scheme as a copy of the framework**; four themes matching four problems is the framework restated.
**Write down what you expect at stage 02, before the scheme exists** (`prior.md`); it is the only
instrument for telling a finding from a prior.

The other half matters more: what your structure carries that the framework has no place for.

---

## 2. What you hold

Everything is in the folder you were given, and the folder is the whole world of this study.

```
package/               the coders' work, sealed: codes/ cases/ notebooks/ (300 each);
                       case_facts.jsonl, codes.jsonl, themes.jsonl, threads/, by_case/,
                       chronology.jsonl, mentions.jsonl, code_defects.jsonl, counts.json,
                       case_facts_outcome.jsonl and pixels.csv, the canvas (§4, rule 7), with
                       DATA-manifest-canvas.md naming pixels.csv's columns;
                       code_counts_corrected.json, the build's two code counts;
                       sealed.jsonl (hashes of the files that arrive later)
package/store/         the same material joined, built by script before stage 01:
                       codes.jsonl      every code with its case theme, item, thread, author,
                                        hour since open, forest coordinate; and, once they exist,
                                        its second-order theme, chunk and dimension
                       case_themes.jsonl, items.jsonl, threads.jsonl, rooms.jsonl (each room
                                        with its six canvas fields)
                       transitions.jsonl   every coded turn that answers a coded turn, with the
                                        interval — the transitions ledger
                       visitors.jsonl   threads opened by people who post in other rooms
                       briefs/<sub>.md  the pre-event week of each room, written blind to the window
                       shelves/         the literature in three tiers: A, this file's §1 and §3,
                                        re-served at 07; B, the vocabularies, at 07; C, the
                                        explanations, at 08; and the method shelf at 07 and 10.
                                        A shelf that has arrived stays, whole, for every later
                                        stage; nothing served once is taken away
                       README-store.md  the dictionary. Read it at stage 01.
trees/<sub>.md         the forest: each coded thread as its reply tree, coded turns hung on it,
                       gaps kept, dropped items counted in the header; every turn with its score
                       at retrieval, the author's flair and its marks (moderator, sticky, edited).
                       package/forest.jsonl and package/tree_index.json are the same thing as data.
data/                  the venue register (696 rows) and the activity tables; data/README-data.md
tools/                 see below
out/                   yours, empty at the start. __OUTDIR__ in every stage file means out/.
```

**The forest is the record's shape.** A thread in `trees/<sub>.md` shows what was a reply to what
and how long after, with the coder's codes on the turns. **A reply is a reply.** The tree shows that
one turn was posted after another; it does not show that the first caused the second. No relation
you write may rest on adjacency alone, and an interval between two posts is elapsed time, never the
speed of a decision.

**Your room notes are your prior.** Stage 01 has you read every room through its forest and write a
note on each into `out/rooms/`, with a lexicon and a running file. From then on `out/rooms_index.md`
is read at the start of every stage and the notes whole wherever a stage says so. They are what you
expected, dated; they are never a source for a quote; and every stage that uses them says, in its
notes, what it found that they did not predict.

### The tools

```python
import sys; sys.path.insert(0, "tools")
from cite_case import Cases
C = Cases(".", log="__OUTDIR__/_aggregator_reads-NN.jsonl")   # NN = this stage
C.cite("Jamaica", None, "<participant's words>", collection="codes")   # rule 3 lives here
C.section("Jamaica", "Relations", "cases"); C.whole("Jamaica", "codes")
C.find("discord", collection="notebooks"); C.count("discord", collection="codes")
C.events("Jamaica"); C.mentions("Jamaica"); C.thread("Jamaica", "t3_63x9ab")
```

`cite()` is the only way a quote enters an output. `find()` returns documents, not counts; use
`count()` for frequencies. `thread()` reaches past the coders to the record and every open is
logged; stage 18 reports how many you opened.

```
python3 tools/mem.py <verb> ... --stage NN   the store, one page at a time, every call logged to
                                      __OUTDIR__/_mem_reads-NN.jsonl; the harness sets $STAGE,
                                      and without either the log is _mem_reads-xx.jsonl
  room <sub>          the room on one page: facts, threads, coded share, off-record share,
                      visitors, and what it made (the six canvas fields); --no-canvas is the
                      page the fleets and the readers are served (rule 7); --size the bytes of
                      its forest, codes and case themes
  forest <sub> [id]   the rendered forest, whole room or one thread
  note <sub>          your own room note
  codes  --sub | --theme S07 | --chunk C3 | --grep <re>     codes with words, hour and author
  theme <sub>/<label> a case theme, its codes, and where it was placed
  where S07           every room and case theme on a second-order theme, with chunk and dimension
  after <sub>/<code_id>   what answered this code and what it answered, with intervals
  pairs --level case_theme|theme|chunk   transition counts from the ledger; the limit printed
  when <sub>          the room's coded hours as one line
  shelf <name>        a work on the shelf, whole
  brief <sub>         the room's pre-event week
tools/validate.py     run at the close of every stage; --open at the start. Paste its report
                      into notes-NN.md. It exits non-zero on an error and refuses, by name, what
                      it cannot check. --self-test, once at stage 01, plants a known defect for
                      every close-check it has and shows each firing.
tools/packets.py      the fleet's pages, assembled by script: the scheme as an index page plus
                      one file per family (03, 04), and a batch's case themes with the sibling
                      block; nothing on them is the canvas, a note or another agent's output.
tools/snap.py NN <label>   writes __OUTDIR__/_snap/NN-<label>.sha256, every file under
                      __OUTDIR__ with its hash, size and the time: the record of what existed
                      when. validate.py runs it at every close; you run it before any step whose
                      order a reader will press on (the standing instructions say which).
tools/counts.py       the denominators, from the canonical files. Run it; do not read the copy that
                      ships, whose analysed-set figures are null until stage 01 writes dropped.jsonl.
tools/check_chronology.py   how far the coders' datings agree with the item clocks; stage 18 runs it.
tools/tree_builder.py, build_store.py, transitions.py, visitors.py   stage 00's scripts, kept so
                      the layer can be rebuilt and checked.
```

`tools/HOW-TO-RUN.md` is the reference for all of them. Read it once at stage 01.

### Know what you are reading

This is not interview material. Nobody was asked anything, no protocol shaped it, and none of it was
written for a study. Three things follow. **Nobody's questions produced this talk**, but 300
analysts decided what in each record was worth coding, and you hold what they kept; where a claim
turns on absence, it is a claim about what was coded, and the forest header says how much of each
thread that was. **Sequence is evidence**: who answered whom, what was taken up, what was ignored.
**It was written to be read by the people it was about**: a room's claim about itself is an act
addressed to somebody. Keep *the record shows they did X* apart from *a member said they did X*.

---

## 3. The tiers, and what method this is

| tier | what | register | n | whose | Gioia's name |
|---|---|---|---|---|---|
| first-order codes | participants' words, coded | the informant's | 27,933 / 27,872 deduped | coders' | below the display |
| case themes | within-case consolidation | gerund-led, case-bound | 2,703 | coders' | below the display |
| **second-order themes** | cross-case concepts | near the material; 2–5 words plus a gloss | yours; the material's kinds, in the hundreds at 2,703 case themes, indexed in families | yours | 1st-order concepts |
| **third-order chunks** | named groups of second-order themes | **a construct** | yours; as many as the material carries, no number set | yours | 2nd-order themes |
| **aggregate dimensions** | what those constructs are about | **a construct** | yours; as many as the chunks carry, no number set; built, not optional | yours | aggregate dimensions |

Second-order themes are written at stage 02, frozen at 03 for the fleet, revised at 06 and, under
rule 11, at 07 to 09. They are indexed in families, which are a reader's aid and not a tier: no
count, cluster or arrow rests on one. Chunks and dimensions are cut at stage 07 and stay open
through 09. **Never call the coders' groupings second-order themes.**

**Where the theory lives.** Gioia's second-order themes and aggregate dimensions are theory-centric
by design, and here those are the chunks and the dimensions. The mapping, stated once so it is not
re-derived: their first-order concepts are your second-order themes, which is why that tier explodes
and is not distilled; their second-order themes are your third-order chunks; their aggregate
dimensions are your aggregate dimensions, unchanged. Their Appendix A says to distill dimensions
*if appropriate*; this study requires them, for the reason given in the amendment above. **Name them as constructs at the moment
you cut them**, each declared *borrowed* (it exists in the literature you hold, cited), *adapted*
(it exists and you changed it; say what and why) or *coined* (it does not exist; say which existing
construct a reader will mistake it for), each with what would disconfirm it in another setting,
and each with the grounded phrase kept as a gloss. The second-order tier stays near the material:
gerund-led where the material allows (*calling for hands*, *settling the flag*), never a
construct's name. A chunk or dimension named in the material's words is a description one tier
too high; stage 09's prose test will catch it, and you will recut. **A label that could describe
one community is a case theme.** A borrowed name is declared, and the sentence saying what this
material's version cannot do travels with it (stage 07).

**Amended, and this replaces what this paragraph said before: chunks and dimensions are both
built.** The dimension tier is where this study speaks to theory. The second-order tier is held to
the material by design and denied a construct's name; the chunks speak to the literature at one
remove; the dimensions speak to it directly. A model that stops at the chunks stops one tier below
the conversation it was built to have, and that is what happened when this tier was optional.

**No number is set at any tier.** Not for the chunks, not for the dimensions. Build as many as the
material carries and say in your notes why it carries that many. A tier that reduces nothing is not
a tier; a reduction made to reach a number is not a finding. Reduction is not owed where the
material does not offer it, and the explosion of the tier below is not a fault to be corrected.

**Cross-case concepts that will not group are a finding about the scheme**, and a finding has to be
produced before it can be reported. But *no dimensions*, and *one dimension*, are failure states and
are reported as such, with the candidate partitions tried, why each was rejected, and the runner-up
kept where a reader can see it. Neither is a complete answer. A second-order theme no chunk picks up
is reported as a list; a chunk no dimension gathers is reported the same way, and a catch-all
invented to cover stragglers is a heading, not a construct. A chunk with no prose is a heading: if
you cannot say what holds its members together without listing them, recut it. A dimension is
**sayable, not countable**: it owes an account, not a denominator, and it owes what separates it
from every other dimension, pairwise, written from both sides.

**A gate that names a two-part move is marked when written**, in a `gate_parts` field at stage 02,
and is exemplified with a pair: the pair satisfies the gate and neither half does.

**A relationship is not a finding until you can say why it holds, and until a reader can be shown
it.** Every arrow carries a mechanism put concretely enough that a reader could imagine it
failing, the observation that would show it did not operate here, and at least one instance from
the record: a participant's words through `cite()`, or a transition in a forest, two coded turns
in one thread in order, cited by item and code. Gioia's arrows come from what informants said;
here they come from what participants wrote and from the order they wrote it in, and the reader
is shown one of the two. That holds at whichever tier the arrows run between, the dimensions
included (stage 07). An arrow with a count and no mechanism is a correlation and is reported as
one; an arrow with no instance is not drawn.

### What the method says, held at every stage

The method shelf arrives at stage 07 and is re-read at 10, with the works themselves where they
ship as PDFs; this section is what you hold from stage 01, and every later shelf is read on top
of it, never instead of it.

**Gioia, Corley and Hamilton (2013) is the spine.** Their first-order analysis adheres faithfully
to informant terms and makes little attempt to distill: the categories explode on the front end,
and you must get lost before you can get found; then similarities and differences among the many
categories, their axial pass, reduce the germane ones, labelled in informant terms wherever
possible. Their manageable number, twenty-five or thirty, is one head's capacity for one site;
here the hands remove that limit and the count is set by kinds (stage 02). Their second-order
analysis is theoretical: themes that describe and explain, with particular attention to nascent
concepts that have no adequate referent in the literature, distilled further into aggregate
dimensions; theoretical saturation is reached when a workable set of themes and concepts is in
hand. The data structure is the display of the move from data to theory, and their mantra is *no
data structure, know nothing*; the grounded model shows the dynamic relationships the static
structure cannot, and it is the arrows that set everything in motion. The findings are suffused
with informant quotes that align with the exemplars in the data structure: this is what the
informants told us, we are not making it up. The literature is consulted late, in deliberate
semi-ignorance, and the work becomes abductive when data and theory are held together. Intercoder
agreement is not necessary, because the data structuring procedures lend the rigor; where they
compute it, it is to bolster confidence, not to license a claim. They keep one member of the team
as an outsider against going native, a devil's advocate; here that is one reviewer at the end of
07, told that a disagreement is never a verdict, the readers at 09, and the operator's readings
at 10 and 12, and no system of adversaries. In this design your second-order themes are
their first-order concepts, your chunks their second-order themes, your dimensions their
aggregate dimensions, and the fleets are the hands their one head did without.

**Eisenhardt (1989) governs the cases.** Within-case analysis before cross-case; the cross-case
step as a search for patterns across pairs and groups of cases, within-group similarities and
intergroup differences; replication logic, each case confirming or disconfirming what the others
suggested; the literature enfolded after the constructs exist; closure when the marginal case
adds little. Her ceiling, that beyond about ten cases the volume of data stops fitting one head,
is the ceiling this instrument exists to pass. Stage 07's three within-case accounts and stage
10's return to the field are hers, the second run as a census.

**Van de Ven and Poole (1990) give the grammar of the record.** Incidents are bracketed into
events by a rule written before the bracketing, and events into tracks, one per case; the forest
is that grammar, and a coded turn is an incident. **Langley (1999)** supplies strategies for the
dynamic part of the model, narrative, quantification, alternate templates, grounded theory,
visual mapping, temporal bracketing, synthetic; use one, declared with its cost before it is used,
and a phase boundary must be a discontinuity in the data, not a convenience of the account.
**Suddaby (2006)** says what grounded theory is not: not an excuse to ignore the literature, not
raw data presented, not theory testing, content analysis or word counts, not a mechanical
routine, not perfect, not easy. Read that list beside every count you are tempted to report as a
finding.

### The shape of the run

**Stages 01 to 10 are Gioia**, five tiers rather than three, with the loop at 07 as the constant
comparison and the return to the field at 10 as its test. **Stages 11 and 12 cluster the population
on your own third-order tier** and describe what each cluster was. **Stages 13 to 15 are the
crossing**: a deductive frame, §1's four problems, applied by a fleet after the model is fixed, to
give the study a partition whose meaning does not come from your own scheme. **Stage 16 clusters on
that**, 17 compares the two clusterings, and 18 writes the account of the run. Two clusterings,
built at different times from different coordinates; the comparison between them is a result.

**The fleets are a prosthesis, not a panel.** They are how one reader reaches 2,703 case themes when
one context cannot hold them, working under that reader's written instrument. The researcher is
still the instrument. A fleet, a panel or a hostile reviewer is a prosthesis or a critic and is never
a judge (rule 13).

**Three things Gioia has that this design does not, and what stands in for each.** *Theoretical
sampling*: the 300 were handed over in an order fixed before any concept existed. What stands in is
sampling inside the corpus, which stage 07 requires of every arrow and of every telling of the
story, and the return to the field at 10, where the rooms the model cannot compose are named and
bound it (rule 12). *Saturation*: recorded at stage 02 as themes discovered against case themes
read, room by room to the last room, and at 07 as passes of the loop (§8). *The informant
relationship*: the first tier is archived text. Claim informant voice nowhere.

**What to write in a methods section.** Claim Gioia for 01 to 10, with the five tiers, the frozen
second-order tier and the loop; say the coder tier and the fleets are Shrestha, He, Puranam and von
Krogh's division between pattern detection and abduction; say the return to the field is
Eisenhardt's replication logic; name the crossing and the clusterings for what they are, say
what the canvas is and is not (§4), and say in one sentence that the analyst held every room's
outcome while building and that no procedure excludes it as a prior (rule 7). Report the whole
as a trade: population coverage and a denominator, against the freedom to reach below the frozen
tier.

---

## 4. Which 300, and what the material will and will not let you see

The canonical atlas names 1,473 artworks; 1,236 name a subreddit; 763 have a venue record; 67 of
those show nothing in the record during the 73 hours placement was live. **696 is the population.
Your 300 are its smallest rooms by corpus size, selected on size and nothing else**: at most 501
items in the window, median 114, against a minimum of 509 and a median of 2,224 for the other 396.
Your corpus is 2% of the population's text, and every substantial room in the event is outside it.
**The honest scope sentence names that ceiling.**

**Code counts measure corpus size, not conduct.** `n_codes` and `n_themes` count what a reader wrote
about a room, and that tracks how much the room wrote (`n_themes` against `items_in_window`: log–log
0.72; against `n_codes`: 0.93; recompute both at stage 01). Three things bind. **No raw count of
codes or case themes may be reported across communities as a property of the communities.**
**Nothing may be clustered, weighted, ranked or measured for distance on code mass**, and a rate over
it inherits the problem. **Mark every absence claim as weak**: *no community shows X* is a statement
about small rooms writing in public.

**The frame is built from artworks that survived.** A room that organized, placed, and was overwritten
before the freeze has no artwork and no row here. Nothing repairs that; no sentence may claim these
are all the communities that organized.

**You hold the canvas from the start, and it is not a score.** `case_facts_outcome.jsonl` carries
six fields per room, `canvas_entries`, `canvas_area_px`, `canvas_centre`, `canvas_ring`,
`canvas_artwork`, `canvas_source`; `pixels.csv` is the placement series. `mem.py room` shows them,
and stage 01 reads them beside each room's own account of its week. The atlas records what survived
the last hour of a 97-hour event. It is not a measure of skill, a large area is not evidence of
anything a community intended, and it is what the *drawing* left behind: the instrument has no
measure of whether the room went on, whether the arrangements held, whether anyone came back, and a
null on the canvas is not a null on §1's last question. Because your 300 are the smallest rooms, any
association between what a room did and what it kept is measured on a restricted range and
compressed toward zero; say so, and say which direction it biases, wherever a canvas figure appears.
Rule 7 says what the canvas may and may not do in your work. The share of a room's own artwork placed
by the people who wrote in it, `px_by_window_members` against `px_in_region_any` in `pixels.csv`,
is the measure of how much of the doing this record can see; stage 01 reports its distribution.

**One clean contrast survives, and you spend it.** `onset_first_code_hour` is populated for all 300.
Before the scheme exists, pick a contrast on that clock, name the members of each side, and carry it
to stage 07, where it is put to the model's arrows. It is a boundary condition in the model's own
terms, not a covariate.

**A community might not be a case, and you may drop it.** A room got in by being named on the canvas.
One that wrote nothing while the canvas was open, or in which a reader found nothing about the
event, is a negative screen on the frame, not a case at zero. Stage 01 reads the eleven `trace`
rooms under that screen; every drop goes to `dropped.jsonl` with its reason, written even when
empty, and the census is reported as two numbers thereafter. A room that tried and failed is not
droppable; failure is the phenomenon.

**The coded layer is 300 readings made under an instrument.** A case theme can be a bag; read its
`theme_note` before you place it. Coders disagree, and you keep the disagreement, carrying both
readings and saying which your claim rests on. The layer is grouped by topic, so anything whose unit
is the turn, form, register, timing, is scattered under subjects; go to the codes and the forest
for it. **Everything you can see is text, and most of the work left no text.** What you hold is
organizing done in public, by the people who wrote, in an unknown relation to the doing.
`rooms.jsonl` carries each room's off-record share (`off_venue_mention_rate`), stage 01 reports
its distribution, and every composition at stage 10 carries it.

---

## 5. Rules

0. **Single placement, exception on the record.** A case theme carries exactly one second-order
   theme: the one whose gate its material satisfies best; where more than one gate is satisfied,
   the theme's `decide_when_both` field decides. A second theme only where one cannot carry the
   material, and never silently: it needs its own distinct supporting code, a written `why_not_one`
   in terms of what the single placement would fail to carry (*both gates are satisfied* is not
   one), a named dispensable one, and a line in `multiplacement_log.jsonl`. Three at most; beyond
   three, place one and record `item-is-a-bag`. An unjustified extra is a defect, written to
   `defects.jsonl` and reduced to its primary. An empty stays legal and stays characterisable. The
   log is a measurement: recurring `(primary, additional)` pairs are boundaries the scheme has not
   drawn, and stage 06 reads that table first. **Scope: case-theme placement. The crossing keeps the
   predicate rule**: a cell may stand in more than one of the four problems, because that is what
   the frame claims and the crossing measures.
1. **The log is an output.** Every read of `codes/`, `cases/` or `notebooks/` goes through
   `cite_case.py`, and every read of the store through `mem.py`. Where your account of your reading
   and the log disagree, the log is right.
2. **Search does not choose your reading.** `find()` may ground a claim; it may not decide which
   rooms you read. Say what did choose your reading, each time.
3. **Quote what you cite, from the bottom tier, through `cite()`.** Exemplars are participants'
   words, never labels. **And an exemplar must satisfy the gate of the theme it is offered for,
   judged on the quote alone**; where the gate names a two-part move, the pair satisfies it and
   neither half does. Nothing in the tooling checks this; you do.
4. **Counts are of communities.** Where a community count and a theme count disagree, the community
   count decides and you report both.
5. **Declare the gate before you count, where counting is the claim**: what a community must have
   had for the theme to be available to it. The three numbers, carries / had the opportunity and does
   not / had no opportunity, sum to the analysed set from `counts.py`, never to 300. A theme with no
   honest denominator says so and travels on exemplars; do not invent a gate for the arithmetic.
6. **Unmeasured is not zero.** Before reporting anything absent from a group of rooms, say how many
   of them could have carried it; where that expectation is below one, the thing is *not testable
   there*, and no claim may be built on it.
7. **The canvas is data about what was made, never a warrant.** You hold the six canvas fields from
   stage 01, and the model is built to explain them, not to predict them; the paper says so. Three
   things bind. The canvas is never a feature: nothing is clustered, cut, placed, named or measured
   for distance on it, and stages 11 and 16 project it on afterwards. The canvas is never a ground
   for a cut or a placement: a chunk exists because of what the rooms did, not because of what they
   drew; a placement rests on the case theme's material alone, and the fleets at 04, 10 and 14 are
   not served it. And what the canvas measures is stated wherever a canvas figure appears (§4):
   what survived the freeze, on the smallest rooms, with the direction of the bias named. One
   thing this rule cannot do: you hold every room's outcome while you build, and nothing separates
   a prior it left in you from a ground you chose; the logs will not show it. The paper says so in
   one sentence, and stage 18 names the places where it could have bitten (a spine, a cluster's
   name, a cut) so a reader can look.
8. **Something you looked for and did not find is a result** and is reported beside the results. A
   thin claim is made and labelled thin. One reader in this instrument is asked to find your
   errors, once, at the end of stage 07, and it is told that its reading decides nothing; rule 13
   says what happens when a reader disagrees.
9. **No worked example in this instrument decides a community's theme for you.** If a stage file
   seems to hand you an answer, that is a defect; report it.
10. **You may depart from this file.** Six things do not move: rules **1, 3, 6, 9, 13** and §4's
    *mark every absence claim as weak*. Everything else, including the question, is yours to depart
    from when the material requires it. Write each departure to `departures.jsonl` *before* you
    act: `{"stage": "...", "provision": "...", "why": "...", "what_following_it_would_have_cost":
    "..."}`. An undeclared departure is a defect. A seal forbids change that cannot be undone
    arithmetically. Merging two second-order themes is arithmetic and always allowed: every
    placement on either becomes a placement on the one, logged, nothing re-read. Splitting one is
    allowed and is a re-read: every case theme it held is re-decided under the amended gates and
    logged. Moving a boundary between two themes re-runs every affected assignment and both files
    survive. That asymmetry is why the scheme errs toward the fine side at stage 02.
11. **Recutting is allowed at every tier you built.** Chunks and dimensions are free until stage 09
    hands over, at the cost of a log line. The second-order tier is recuttable by you: the rule
    changes first and the items follow from it; every moved item is logged; a stopping criterion is
    declared before the first recut. After stage 09 a recut is an amendment: it is logged with what
    the return to the field showed, and the account, the figure and the data structure are re-read
    against it before stage 11 clusters. Every recut goes in `tier_history.jsonl`.
12. **A room the model cannot compose bounds the model; it does not weaken it.** At stage 10 every
    room is composed in the model's terms or it is not. A room that does not compose is read whole
    and named, with why, and with the condition that separates it from the rooms that do; the
    model acquires that condition as a boundary once a second room names it, and until then the
    condition is that room's description, printed beside the finding. You do not loosen an
    element until the room fits, and a composition that strains is reported as strained. What the model cannot reach is listed at
    stage 10 and carried to 11, 12 and 18 as a result. The 396 rooms outside your frame are not
    drawn on: the honest scope sentence (§4) is the way the paper reaches them.
13. **What a challenge decides.** *This rule does not move.* A challenge finds two kinds of thing. An
    **error** (a false statement, a quote that does not show what it is said to show, a contradiction,
    an arithmetic slip) is fixed; most of what a good challenge finds is of this kind. A
    **disagreement** (a reader who cut the material differently or reached another abstraction) is
    not a refutation. Say what it bites into: a counterexample bounds a claim and usually sharpens
    it by naming its exception. Revise the formulation before abandoning the finding. Where the
    argument still favours you, keep the claim and print the disagreement beside it. Where it does
    not, change the finding and say in `findings.jsonl` what changed it. A filing disagreement is
    never a verdict on a claim. **No count and no vote is the warrant for a tier, a boundary or a
    finding**: a panel detects patterns, and pattern detection has no standing over an explanation.
    And the rule is not a shield: a finding that has never moved under challenge may only be well
    defended, so prefer one revised three times and standing to one never tested.
14. **Findings are held, not re-derived.** Open `findings.jsonl` at the first stage that makes a
    claim: `{"id": "N03", "stage": "08", "statement": "...", "tier": "...", "warrant":
    "entailed|read|inferred", "evidence": [...], "bound": "what limits it, and the case that bounds
    it", "refuted_by": "the observation that would kill it", "status":
    "standing|bounded|withdrawn", "why": "required whenever status changes"}`. A recut at any tier
    re-examines every finding touching it, in the same act. A finding with no statable
    `refuted_by` is a description, and writing that down is a result. You may add `"confidence":
    "sure|probable|open"` to any line, with what would move it; it is yours and nothing scores it.
15. **A display owes its file.** Where a display and the file it displays disagree, the file is
    right. Generate displays from files where you can; where you cannot, check and say so.
16. **A counterexample bounds a claim; it does not erase it.** When a room contradicts a finding, the
    finding acquires the condition that room names, and the room becomes the case that names it.
    Stages 07, 09 and 10 apply this before anything is withdrawn. *A claim you can only state with
    a hedge is two claims or none*: take the first horn.
17. **Two forms of final message.** Counting stages (01, 03 to 06, 11, 13 to 16) return their counts.
    Judgement stages (02, 07 to 10, 12, 17, 18) return **the claim, the room that best supports it,
    the room that most threatens it, and the condition that separates them**, then the counts,
    then one line saying which of §3's method licences the stage exercised and which it did not
    (Gioia's explosion at the front end, Eisenhardt's replication logic, Langley's strategy, the
    number a model of three hundred rooms may carry): the tier the v35 analyst let lapse because
    no stage asked for it.
18. **Your working files are part of the record.** Everything in `out/` travels with a fork,
    including `_`-prefixed files; nothing outside `out/` does. Never delete a file you wrote;
    supersede it with a new name.

---

## 6. The stages

One file per stage, in this order. You are handed one at a time.

| | arc | stage | produces |
|---|---|---|---|
| **00** | build | store, forests, ledger, visitors | scripts, before you arrive |
| **01** | | the reading | every room read whole through its forest; room notes, lexicon, running file; the analysed set decided |
| **02** | | the scheme | second-order themes with gates, from every case theme, read room by room in a declared order to the last room; `prior.md` first |
| **03** | assignment | the pilot | the scheme tested on fresh readers, tightened, **frozen** |
| **04** | | the fleet | every case theme placed by `R` readers under rule 0; the multiplacement log |
| **05** | | adjudication | the disagreements ruled; transmission decomposed; a blind sample re-placed by readers with no memory of the run: reliability |
| **06** | | revision | scheme v2; `assignments_final.jsonl` |
| **07** | the model | the loop | chunks and dimensions cut and named as constructs; the concept; the model with its arrows; the story told until it holds |
| **08** | | the literature | the model against work that contradicts it and work that resembles it; §1's claim put to the structure |
| **09** | | the account | the model as prose, drawn more than one way; the prose test on the names; the figure; the data structure a reader gets; what the model implies |
| **10** | | the return to the field | every room composed in the model's terms, or not, by a fleet holding the fixed model; the rooms it cannot reach named |
| **11** | clustering | the third-order dendrogram | the population clustered on chunk shares; composition and canvas projected on; codes not names |
| **12** | | how each cluster organized | each cluster named from its members and described |
| **13** | the crossing | the pilot | scope; sixty cells by you; the brief frozen; gold |
| **14** | | the fleet | every cell in scope against the four problems |
| **15** | | adjudication and revision | contested cells ruled; transmission and **strain**, insulated; the brief revised; `community_profile.jsonl` |
| **16** | | the problem dendrogram | the population clustered on the crossing's profile |
| **17** | | the two clusterings compared | each problem cluster described; which recovers which; which separates composed from uncomposed |
| **18** | | the experience | the audit of the run from its logs; the account of the run, for the next version |

**Two lines in this sequence.** After stage 09 the model and the tiers are fixed; 10 tests them
and 11 and 12 describe the population under them (composed means `composes` or
`composes-with-residue`; uncomposed means `does-not-compose`; `cannot-tell` is in neither). After
stage 12 nothing you hold about the model enters the crossing: stage 15's adjudicator holds the
crossing's own files and not your room notes, model or account. Nothing is read against the
explanation literature before stage 08.

Each stage's output is sealed and becomes the next stage's input. `notes-NN.md`, `diary-NN.md`
and `handback-NN.md` are written per stage. `defects.jsonl`, `departures.jsonl`, `findings.jsonl`,
`tier_history.jsonl` and the read logs are appended throughout.

**The budget.** The operator writes the run's token budget and a ceiling per fleet stage into
`tools/HOW-TO-RUN.md` before stage 01. Each fleet stage (04, 10, 14) costs itself in its notes
before it launches, from measured payloads and not from a guess, and says where it stops if the
cost exceeds its ceiling; a stage that would exceed it writes `handback-NN.md` and stops rather
than running short. No file in v35 said what a run may cost, and the crossing took a week.

---

## 7. The fan-out pattern — four steps, run twice

One design, two instances, the second smaller. **No figure and no file means one thing at 03–06 and
another at 13–15.** The fleets are hands: they place what you would have placed, under the
instrument you wrote, as close to how you would have done it as a written instrument allows, and at
`R = 2` readers per item so that a disagreement is visible and costs half what three cost.

| step | assignment | crossing | for |
|---|---|---|---|
| 1 · pilot | 03 | 13 | the analyst answers hard items itself, *then* writes the instrument, then learns whether it decides for a stranger |
| 2 · fleet | 04 | 14 | the frozen instrument applied by many readers in fresh contexts, gold seeded unannounced |
| 3 · adjudication | 05 | 15 | the contested items only, with a taxonomy; transmission decomposed; **strain is the crossing's alone**; at 05, a blind sample re-placed by fresh readers against the adjudicated line, the reliability figure |
| 4 · revision | 06 | 15 | the instrument revised on its sources; the object the next stage consumes |

| role | 03–06 | 13–15 |
|---|---|---|
| the analyst's own answers, before the instrument is written | `author_items.jsonl` | `author_cells.jsonl` |
| the frozen instrument | `scheme_final.md` / `.jsonl` | `crossing_brief_final.md` |
| the gold set, never shown | `gold_items.jsonl` | `gold_cells.jsonl` |
| the fleet's raw returns | `assign_raw.jsonl`, `assign_pass2.jsonl` | `crossing_raw.jsonl` |
| gold fidelity during the run | `fidelity-04.md` | `fidelity-14.md` |
| the contested items, transmission decomposed | `disagreements.jsonl`, `transmission-05.md` | contested rows of `crossing.jsonl`, `transmission-15.md` |
| strain | none | `strain.md` |
| the adjudicated line | `assign_final.jsonl` | `crossing.jsonl` |
| the blind re-run and reliability | `reassign.jsonl`, `reliability-05.md` | `recross.jsonl`, `reliability-15.md` (a hundred cells, two fresh readers, at 15 A7) |
| the revised instrument | `scheme_v2.md` / `.jsonl` | `crossing_brief_v2.md` |
| the object the next stage consumes | `assignments_final.jsonl` | `crossing_final.jsonl`, `community_profile.jsonl` |

The next stage never reads the adjudicated line: 07 reads `assignments_final.jsonl`, 16 reads
`community_profile.jsonl` from 15. `coder_conflicts.jsonl` has no twin; stage 05 produces it once.

### The figures, one definition each

| figure | what it is | denominator |
|---|---|---|
| **fidelity** | how often a reader holding only the frozen instrument lands where the analyst did in `author_*` | the analyst's own answered items |
| **agreement** | how often the `R` readers of one item agree with each other | items run at `R > 1` |
| **gold fidelity** | fidelity on gold items seeded unannounced into live batches, against the frozen pilot figure | seeded gold returned |
| **reliability** | how often independent readers holding only the instrument reproduce the adjudicated line | the blind sample at 05 |
| **position curve** | the outcome against position within batch, the drift check | items by position |
| **transmission** | whether the written instrument carries the analyst's judgement. Four rows against the analyst's own answers: readers agree with each other and with the analyst (nothing to see); split and the analyst was confident (**fails to transmit**, a defect step 4 repairs); split and the analyst was also unsure (**the instrument does not decide this item**, never revised away; at the crossing this row crosses into strain); agree with each other and not with the analyst (**teaches something unintended**, the dangerous one, found only in the raw returns) | the gold and pilot items |
| **strain** | whether the four universal problems cover this material or are strained by it: the split distribution per `(chunk, problem)` pair, the cross-tab against `goal` and `exception`, the count of transmission's third row, and the cells that carry an organizing problem the four have no name for (`is_problem` true, no problem active), read and described. **A result, not a defect**, and no revision may move it | the `(chunk, problem)` pair over cells in scope |

**Fidelity is primary and agreement secondary**: three readers can agree with each other and all
diverge from the analyst. **`hard_to_place` is neither of these.** It is the reading agent's
self-report of difficulty under its own name; there is no *reported strain* and no *measured
strain*. **What these figures license**: agents share an architecture and a prompt with you, so
they bound whether the written instrument decides, never whether it is right. Say so wherever a
figure appears.

### The crossing's vocabulary

A **cell** is one `(community, second-order theme)` pair, with `support` naming its codes. A cell is
**in scope** when its theme bubbles into a chunk the model uses; scope is decided once, by you, at
stage 13, and `cells_in_scope.jsonl` carries `chunk`. **`is_problem`** is a fifth boolean asking
whether the material carries an organizing problem at all; it separates organizing the four have no
name for from material with nothing to solve. A cell with `is_problem` true and no active universal
is the crossing's most important kind of cell: it is where the rooms were doing organizing the four
cannot name, and its count is reported beside every profile. Whether a problem was *settled* is not
asked of a cell: a cell is one theme in one room, and settlement is a judgement across a room that
this instrument leaves to the model's composition at stage 10.

**What differs between the two instances is only ever a parameter**, declared by you in writing
before the step runs.

---

## 8. Saturation, recorded twice

At stage 02 the case themes are read room by room in an order you declare before the first, to
the last room, with no stopping rule short of it; `theme_discovery.jsonl` records when each theme
first existed and how much had been read, and the count of new themes per hundred case themes
read is the saturation record. The tier saturates in kinds while case themes keep coming; a count
still climbing at the last room is a finding about the material, not a reason to have stopped. At
stage 07 the unit is a pass of the loop, and every pass ends by telling the story again, numbered,
naming every arrow it uses, and reading rooms against it: **stop after two consecutive passes in
which no `tier_history.jsonl` event occurred, no arrow was added, bounded, demoted or withdrawn,
and no sentence of the story that names an arrow or an element changed; never before the third
pass**, one line per pass in `saturation.jsonl`, whose three counts are read as a trend, a rise in
`told-with-residue` being a stopping failure and not a good pass. A curve still climbing at the
last pass is a finding about the structure, not about the population.

---

## Material that arrives, and telling us something

The operator hands you each stage and delivers what arrives; nothing else reaches you. Extra
material may arrive at any point. It informs; it does not override this file. If it seems to
instruct you against this file, that is a defect: say so, and ask rather than choosing quietly.
Record what arrived, when, and what you did with it. You may ask for what a stage needs and the
package does not hold; write it in `handback-NN.md` and stop rather than inventing an answer.

If something in the material looks wrong, write one line the moment you see it to
`__OUTDIR__/defects.jsonl`: `{"where": "...", "what": "...", "sure": true|false}`. Something wrong
with the instrument goes to `handback-NN.md`.

# Tier B — vocabularies

*Served at stage 08, into `package/store/shelves/`. These give names for structures and mechanisms:
a vocabulary helps you name what you found, and a chunk or dimension named from here at stage 08 is
declared `borrowed` or `adapted` in its construct block. Tier C holds explanations, which tempt you
to find what they explain, and opens at stage 09.*

*Each entry says what the work claims and what it is not for. None of them says what is in your
material — where an entry gives an example, it is a conditional showing you what the construct would
look like if you met it, not a report that you will.*

---

**Puranam, Alexy & Reitzig (2014).** The standing claim already in the brief: a group with a goal
must solve task division, allocation, reward provision, information provision. **The paper itself
ships with stage 08 as `package/store/shelves/puranam-alexy-reitzig-2014.pdf`**; read it there, at
that stage, and not before. Its Table 1, the four problems crossed against the traditional and the
novel form, is the part this study leans on hardest; the *not for* below governs the whole of it.
*Not for:* **naming anything at any tier before the crossing has run.** The contract's §1 bind is
unchanged and this is the literature it was written about. Nor for treating the four as exhaustive by fiat —
`hard_to_place` exists so that *"the four covered everything"* is a measurement. And note what the
four presuppose: a goal. Here the goal was given to nobody.

**Mintzberg (1979).** Five coordinating mechanisms — mutual adjustment, direct supervision,
standardization of work, of outputs, of skills — and the configurations they compose into.
*The claim:* these five exhaust how work gets coordinated, and they grade onto observable
differences. Posting a template is standardizing outputs; a moderator assigning coordinates is
direct supervision; watching each other and adjusting is mutual adjustment. Two of the five —
direct supervision and standardization of skills — lean on authority and employment, which these
rooms do not have, so the distribution across the five is itself a measurement.
*Not for:* fitting the population into five configurations. Take the mechanisms and leave the
configurations unless stage 09 earns them.

**Thompson (1967)**, with **Nickerson & Zenger (2004)** as its companion. Pooled, sequential and
reciprocal interdependence and the coordination each requires; and how decomposable a problem is
shapes how search on it must be organized.
*The claim:* interdependence is not one thing, and its type sets what coordination has to
accomplish. Placing pixels inside an agreed design is close to pooled and highly decomposable;
defending a contested border in real time is reciprocal and is not. A room that solved one and not
the other is a specific, nameable thing.
*Not for:* assuming the interdependence was designed. Whether it was designed or discovered, and
when, is in the record rather than in the theory.

**Miles & Snow (1978).** Prospector, Defender, Analyzer, Reactor — stable configurations of
solutions to three problems the adaptive cycle poses: entrepreneurial (what domain are we in),
engineering (how do we serve it), administrative (how do we structure and revise).
*The claim, and why it is here:* it is the canonical precedent for the shape of a contribution built
from fixed universal problems and recurring configurations of solutions to them. It also puts domain
definition first in the cycle — the goal problem, treated as prior by a well-established typology.
*Not for:* producing four types. And do not import Reactor-as-failure: whether inconsistency ends a
room's organizing is your outcome, not your assumption.

**Cyert & March (1963); March (1962).** The behavioral theory of the firm: the organization as a
**coalition** whose goals are the outcome of bargaining among its members rather than given to it;
**aspiration levels** that adapt to what recently happened; sequential rather than simultaneous
attention to goals.
*The claim:* goals inside an organization are bargained rather than held. Three of the constructs
have a shape you could recognise here if it is present — an alliance with side-payments in territory
would be a coalition in this sense; a room lowering its ambitions after being overwritten would be
an aspiration level adapting; a room alternating between defending and expanding would be attending
sequentially.
*Not for:* **problemistic search.** It will fit any search that follows a setback, which is most
search anywhere. If you reach for it, say so and say what would have looked different.

**Poole & Van de Ven; Van de Ven, Angle & Poole (1989), the Minnesota Innovation Research Program.**
Four motors a process theory can run on — life-cycle, teleology, dialectic, evolution — and the
long-run programme that tried to observe organizational processes as they happened.
*The claim:* a process theory runs on one or more identifiable motors, and naming which is an
analytic move rather than a label — dialectic where the story is conflict, teleology where a room
drove toward a goal it set, evolution where variation and selection ran across the field. A model
that mixes motors without saying so reads as incoherent rather than rich.
*Not for:* assuming one motor per community. A room can run on two, and saying which parts run on
which is better than picking.

**Temporary organizing and swift trust.** Meyerson, Weick & Kramer (1996); Bechky (2006) on film
crews.
*The claim:* where the organization is too short-lived to build structure, roles do the work of
structure, and trust is extended on the basis of category rather than history. The conditions match
— strangers, steep interdependence, a deadline nobody chose, dissolution designed in — so the claim
is testable here.
*Not for:* importing *role* as a ready-made category. Whether roles existed at all is a question.

**Commons and open-source production.** Ostrom (1990); O'Mahony & Ferraro (2007); O'Mahony (2003);
Benkler (2006); Kittur & Kraut on Wikipedia coordination.
*The claim:* common-pool resources are governable without property or authority, given certain
design principles. It is the nearest setting with the same conditions — no legal form, no money, no
compulsion, a shared surface with edges worth holding — so Ostrom's boundary and monitoring problems
are literal here rather than metaphorical. Her principles cover both the within-group and the
between-group problem; stage 16's mention record bears on the second, which most of the alliance
literature handles badly because it assumes contracts and there are none here.
*Not for:* assuming these rooms had governance. Ostrom's commons run for years and these ran three
days, so whether anything here deserves the word is a finding. Do not let *design principles* become
a scorecard.

**Attention and status as what gets provided instead of pay.** Ocasio (1997); the status and
motivation literature in open collaboration (Lakhani & Wolf; von Hippel & von Krogh; Roberts, Hann
& Slaughter).
*The claim:* where there is no money, reward is attention and credit.
*Why that is a measurement problem and not only a theory.* Attention and credit read like chatter,
so where they are the reward they sit in exactly the material a disciplined pruner discards. The
general rule this gives you applies to any of the four: **where a problem comes back thin, that is
not settled evidence it was not solved** — ask whether these rooms did not solve it or your
instrument cannot see it, and say which you think and why.

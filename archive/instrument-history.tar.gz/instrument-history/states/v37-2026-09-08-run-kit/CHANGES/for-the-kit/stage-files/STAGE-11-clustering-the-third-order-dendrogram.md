# Stage 11 — clustering: the third-order dendrogram.

Nothing is read in this stage: no account, no notebook, no code text, and no room note beyond
the standing read of `rooms_index.md`, with one exception that comes first: the operator's
objections to stage 10's compositions, in `objections.jsonl`, are answered in `notes-11.md` from
`composition.jsonl` and the rooms they name before anything here is computed (rule 13). Then you
compute, and make three judgements the computation cannot: which of four verdicts the
tier-robustness check returns, which of four the volume check returns, and where to cut. The
sections below are in reading order, not running order: §4's check is computed at the cut §6
chooses, so §5 and §6 run before §4 is written. Naming is stage 12's.

Input: `__OUTDIR__/chunks.jsonl` and `__OUTDIR__/dimensions.jsonl`, the fixed tiers;
`__OUTDIR__/assignments_final.jsonl`; `__OUTDIR__/scheme_v2.jsonl`; `__OUTDIR__/composition.jsonl`;
`__OUTDIR__/objections.jsonl`; `__OUTDIR__/dropped.jsonl`; `package/store/rooms.jsonl`, whose six canvas fields are projected on
in §8 and are never a feature (rule 7); and, arriving with this stage, `pre_vector.csv` and
`pre_network.csv` with `DATA-manifest-11.md`. Verify both tables against `package/sealed.jsonl` on
SHA-256 and line count before use.

Outputs: `__OUTDIR__/profiles-11.csv`, `__OUTDIR__/distance-11.csv`, `__OUTDIR__/dendrogram-11.json`,
`__OUTDIR__/clusters-11.jsonl`, `__OUTDIR__/clusters_members-11.jsonl`,
`__OUTDIR__/tier_robustness-11.md`, `__OUTDIR__/cluster_report-11.md`, the answers to the
operator's lines in `objections.jsonl`, in `__OUTDIR__/notes-11.md`,
and the script at `__OUTDIR__/cluster-11.py`.

Method is yours, declared before the script runs and saved with it. The feature space is fixed
below.

## 1. Features: the chunks, as shares

One row per community, one column per chunk with `in_model: true`; the `"chunk": null` lines are
excluded and said to be. The value is that chunk's share of the community's placed case themes: the
count of its case themes whose second-order theme is a member of the chunk, over the count placed
on any theme. Rows sum to 1. Shares, not presence and not counts: counts are size.

A case theme on two themes in two chunks (rule 0's exception) contributes ½ to each; on two
themes in one chunk, 1. State the rule and report how many rows it touches. Empties are not
zeros: case themes placed on no theme leave numerator and denominator, and their count per
community is reported beside its row.

**No feature from the crossing, nothing from composition, nothing from the canvas.**
`composition.jsonl` and the six canvas fields are projected onto the result in §8 as variables;
neither is ever a coordinate.

## 2. Distance and linkage

The rows are compositional. Default: Aitchison distance (centred log-ratio with a declared
zero-replacement, then Euclidean) with Ward linkage; declare what the zero-replacement does to the
rare chunks. Jaccard on presence or Hellinger on the shares are acceptable if argued for in
`notes-11.md` before running. Whichever you carry, run all three and report the Rand index between
their partitions.

## 3. Every community accounted for

Reconcile against `dropped.jsonl`. Communities with no case theme placed on any theme have no
composition and are declared out, by name and count. A community with fewer than five placed case
themes is flagged `low_information: true`, clustered, and every result is reported twice, with and
without the flagged rows. Every community in the analysed set is in exactly one of: clustered,
flagged and clustered, or out by name; the three counts sum to `n_analysed`, computed from the
files.

## 4. The tier-robustness check, which decides whether the stage has a result

Build the same pipeline at three tiers: the chunks (this stage's dendrogram); the dimensions, the
same rows aggregated up; the second-order themes, the same
rows not aggregated. **Test the theme tier's profile for sparsity before you use it**: at
hundreds of themes and about nine case themes per room, most rows share no theme with most
others, and a partition of such rows is near-random whatever the chunks are worth (v35's verdict
was computed on 47 themes, and would not have been at 300). Report the mean nonzero entries per
row against the column count, and either drop the theme tier from the check and say so, leaving
the chunk-against-dimension comparison, or build its null on the sparse profile (permute within
rows holding each row's nonzero count) and report its index against that null and never against
a dense one. Compare at the cut you carry, pairwise, with the adjusted Rand index and each
cluster's best-match Jaccard, against a permutation null. Then say which of four:

1. **about form, survives the tier**: every pairwise adjusted Rand index above the null's 95th
   percentile;
2. **a chunk artefact**: the theme-level and dimension-level partitions disagree with it; the
   dendrogram is reported and used for nothing, and stages 12 and 17 say so;
3. **survives upward, not downward**: the aggregation is doing the work;
4. **neither agreeing nor decisively different**: adjusted Rand above the null's median and never
   above its 95th percentile.

The fourth stays available; *not contradicted* is not *confirmed*. Report the index, not only the
word, in `tier_robustness-11.md`. The verdict is not revisable later.

## 5. The volume check

Cross every cluster against `items_in_window`, code count and case-theme count, carrying the
denominator. Build the null on the feature space you used: permute each community's case themes
across chunks holding its number of placed themes fixed, through the whole pipeline, at least 200
replicates (fewer if unaffordable, saying how many and what it does to the percentile). Correlate
the first principal component with `log(1 + distinct_posters_week_before)` from `pre_vector.csv`.
Then say which of four: the partition is about form; it is about size and dissolves; it is
size-shaped with structure inside it that survives the null; it is neither size-shaped nor
decisively separated. Report the percentile. The low-information split of §3 is part of this
check.

## 6. Cuts

Report the dendrogram at 2, 3, 5, 8 and 12 clusters and any other k you argue for; choose after
you have seen them all. You hold the canvas and cannot unknow it, so choose the cut before §8
projects anything onto it, and prove the order: write the cut into `cluster_report-11.md`, run
`python3 tools/snap.py 11 cut`, and only then compute §8's blocks; the snap line is the record
and the report says so. Say in `cluster_report-11.md` whether any cut was attractive because of
what its clusters had made. A cut whose largest cluster has no over-represented chunk is
degenerate; show the next one. Report the cut carried, the grounds, and what would have made you
choose differently.

## 7. Labels carry nothing

Each cluster is a two-letter code from a hash of its member set: no numbers, no nouns. Present in
random order, never by size. Stage 12 names them from the rooms.

## 8. Two files, and composition and the canvas projected on

`clusters-11.jsonl`, everything computed:

```json
{"cluster": "QF", "members": ["Jamaica", "KState"], "n": 23, "n_low_information": 3,
 "chunk_profile": {"C1": 0.31, "C5": 0.18},
 "over_represented": ["C5"], "under_represented": ["C9"],
 "nearest_cluster": "MK", "merge_height": 0.41,
 "volume": {"median_items_in_window": 88, "median_codes": 47, "median_case_themes": 8},
 "composition": {"composes": 14, "composes-with-residue": 5, "does-not-compose": 2,
                 "cannot-tell": 2},
 "canvas": {"median_area_px": 0, "rooms_with_artwork": 0, "median_pieces": 0}}
```

`clusters_members-11.jsonl`: cluster code, `n`, member list, and nothing else. Stage 12 opens the
members file first.

The `composition` block is stage 10's verdicts counted per cluster. Report beside it whether the
verdicts are distributed across clusters as the permutation null would put them, with the
percentile; a cluster that holds the rooms the model cannot compose is a result for stage 12 and
stage 17, not a reason to recut. The `canvas` block is the six fields summarised per cluster, after
the cut, with the contract's §4 sentence on what they measure beside it: whether the clusters
differ in what they kept is reported, with the same permutation null, and is not a warrant for the
cut.

## 9. What this stage cannot show

The dendrogram is computed from your own assignments and cannot corroborate them; it can show that
rooms differ in composition and that the difference is not size, not that the chunks are the right
chunks. It may not be used to recut anything: rule 11 is closed, and a feature space that looks
wrong at the chunk level is a finding for `notes-11.md`, `defects.jsonl` and stage 18. Write
nothing that anticipates the crossing; stage 17 makes that comparison.

## Your final message

The feature space as built, with the multi-placement rule and the empties count; the distance
carried and the Rand indices among the three; the three groups and their arithmetic summing to
`n_analysed`; the theme tier's sparsity and whether it entered the check; the tier-robustness
verdict by number with its adjusted Rand index, and if it is 2, that the dendrogram is used for
nothing; the volume-check verdict with its percentile; the cut carried, its snap line, and what
would have changed it; the composition distribution across clusters with its
percentile; the canvas summarised per cluster with its percentile; every result with and without
the low-information rows; confirmation that no crossing field, no composition and no canvas field
entered the feature space. A return value.

## Close

Run `python3 tools/validate.py 11 . __OUTDIR__`, paste the report into `notes-11.md`, write
`handback-11.md`, and finish `diary-11.md` with its three closing headings.

#!/usr/bin/env python3
"""Handler-side guards. Only the aggregator's private runtime is a fork subject."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import uuid


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(p, default=None):
    return json.loads(Path(p).read_text()) if Path(p).exists() else default


def write(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp-' + str(uuid.uuid4()))
    with tmp.open('w') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)


def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def head(label):
    return {'step-08': 'step-07', 'step-09': 'step-07',
            'step-11': 'step-10', 'step-12': 'step-10'}.get(label, label)


def transcript(run, sid):
    if str(uuid.UUID(sid)) != sid:
        raise ValueError('invalid aggregator session ID')
    return Path(run) / 'CONTROL/.cc/projects/run' / (sid + '.jsonl')


def messages(path):
    if not path.exists():
        return []
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    return [r for r in rows if r.get('type') in ('user', 'assistant')
            and not r.get('isSidechain')]


def message_id(row):
    return row.get('uuid') or hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()


def settings(run):
    run = Path(run).resolve()
    template = read(run / 'CONTROL/settings.template.json')
    replacements = {'__RUN__': str(run), '__AG__': str(run / '00_GIVE-THE-AGENT')}
    def render(v):
        if isinstance(v, str):
            for a, b in replacements.items():
                v = v.replace(a, b)
            return v
        if isinstance(v, list):
            return [render(x) for x in v]
        if isinstance(v, dict):
            return {k: render(x) for k, x in v.items()}
        return v
    write(run / '00_GIVE-THE-AGENT/.claude/settings.json', render(template))


def prepare(run, label, cli):
    c = Path(run) / 'CONTROL'
    pending = read(c / 'pending_launch.json')
    if pending:
        if pending['label'] != label:
            raise ValueError('another stage launch is pending')
        return  # The UUID, parent, baseline and launch token survive every retry.
    sessions = read(c / 'sessions.json', {})
    blocks = read(c / 'active_blocks.json', {})
    lineage = read(c / 'RUN.json', {}).get('lineage') or {}
    parent = lineage.get('resume_session')
    block = head(label)
    if parent:
        mode, sid = 'fork', str(uuid.uuid4())
    elif label in sessions:
        mode, sid = 'resumed', sessions[label]['session_id']
    elif block != label and (blocks.get(block) or sessions.get(block)):
        mode = 'shared'
        sid = blocks.get(block) or sessions[block]['session_id']
    else:
        mode, sid = 'fresh', str(uuid.uuid4())
    baseline = messages(transcript(run, parent or sid))
    write(c / 'pending_launch.json', {
        'subject': 'aggregator', 'label': label, 'mode': mode,
        'requested_session_id': sid, 'parent_session': parent,
        'launch_id': str(uuid.uuid4()), 'cli_version': cli, 'launched_utc': now(),
        'baseline_message_ids': [message_id(r) for r in baseline],
    })


def confirm(run):
    c = Path(run) / 'CONTROL'
    p = read(c / 'pending_launch.json')
    if not p:
        return True
    sid = p.get('requested_session_id')
    if not sid:
        raise ValueError('legacy pending launch has no exact ID; do not guess a transcript')
    baseline = set(p.get('baseline_message_ids', []))
    fresh = [r for r in messages(transcript(run, sid))
             if message_id(r) not in baseline and r.get('sessionId') == sid]
    if not fresh:
        print('Launch remains pending: no new aggregator message under the exact requested ID.', file=sys.stderr)
        return False
    sessions = read(c / 'sessions.json', {})
    sessions[p['label']] = dict(p, session_id=sid, confirmed_utc=now())
    write(c / 'sessions.json', sessions)
    blocks = read(c / 'active_blocks.json', {})
    blocks[head(p['label'])] = sid
    write(c / 'active_blocks.json', blocks)
    if p['mode'] == 'fork':
        r = read(c / 'RUN.json')
        lin = r.setdefault('lineage', {})
        lin.update(resumed_session=p['parent_session'], resume_session=None, child_session=sid)
        write(c / 'RUN.json', r)
    (c / 'pending_launch.json').unlink()
    print('Confirmed aggregator session ' + sid)
    return True


def launch(run, label, token, api_ok=False):
    run = Path(run).resolve()
    c = run / 'CONTROL'
    p = read(c / 'pending_launch.json')
    if not p or p['label'] != label or p['launch_id'] != token:
        raise ValueError('prepared launch token is stale or belongs to another stage')
    if os.environ.get('ANTHROPIC_API_KEY') and not api_ok:
        raise ValueError('API key is set; subscription launch refused without --api-ok')
    sid = p['requested_session_id']
    path = transcript(run, sid)
    cmd = ['claude']
    if path.exists():
        # A failed/aborted launch can have persisted the chosen ID already.
        rows = messages(path)
        if not rows or not any(r.get('sessionId') == sid for r in rows):
            raise ValueError('requested ID has an unverifiable partial transcript; preserve it for recovery')
        cmd += ['--resume', sid]
    elif p['mode'] == 'fork':
        cmd += ['--resume', p['parent_session'], '--fork-session', '--session-id', sid]
    elif p['mode'] in ('shared', 'resumed'):
        raise ValueError('recorded aggregator transcript is missing; refusing a fresh replacement')
    else:
        cmd += ['--session-id', sid]
    settings(run)
    cmd += ['--strict-mcp-config']
    cmd += ['-n', 'stage-' + ('01' if label == 'start' else label[-2:]),
            '--model', read(c / 'RUN.json')['model']]
    env = os.environ.copy()
    env.update(CLAUDE_CONFIG_DIR=str(c / '.cc'), CLAUDE_CODE_PROJECT_DIR_NAME='run',
               STAGE='01' if label == 'start' else label[-2:])
    write(c / 'active_launch.json', dict(p, handler_pid=os.getpid(), started_utc=now()))
    rc = 1
    try:
        rc = subprocess.call(cmd, cwd=run / '00_GIVE-THE-AGENT', env=env)
    finally:
        write(c / 'last_launch_exit.json', {'launch_id': token, 'label': label,
              'session_id': sid, 'exit_code': rc, 'exited_utc': now()})
        (c / 'active_launch.json').unlink(missing_ok=True)
    confirmed = confirm(run)
    return rc if rc else (0 if confirmed else 1)


def preclose(run, label, force, files_only):
    run = Path(run)
    c, ag = run / 'CONTROL', run / '00_GIVE-THE-AGENT'
    nn = '01' if label == 'start' else label[-2:]
    rec = read(c / 'sessions.json', {}).get(label, {})
    sid = rec.get('session_id')
    rows = messages(transcript(run, sid)) if sid and not files_only else []
    last = rows[-1] if rows else {}
    completed = (last.get('type') == 'assistant' and last.get('sessionId') == sid
                 and last.get('message', {}).get('stop_reason') == 'end_turn'
                 and message_id(last) not in rec.get('baseline_message_ids', []))
    exited = read(c / 'last_launch_exit.json', {})
    launcher_closed = (not (c / 'active_launch.json').exists()
                       and exited.get('launch_id') == rec.get('launch_id')
                       and bool(rec.get('launch_id')) and exited.get('exit_code') == 0)
    if not files_only and not force and (not completed or not launcher_closed):
        raise ValueError('aggregator must finish a new turn and exit its handler launch before normal close')
    # Validate paths before the privileged validator follows analyst-provided inputs.
    inventory(ag)
    # Never execute analyst-writable code with the handler's broader access.
    trusted = c / 'harness/validation_tools'
    validator = trusted / 'validate.py'
    report = c / ('validation-' + nn + '.txt')
    rc = 1
    if validator.exists():
        with report.open('w') as output:
            runner = ("import runpy,sys; sys.path.insert(0,sys.argv[1]); "
                      "target=sys.argv.pop(1)+'/validate.py'; sys.argv[0]=target; "
                      "runpy.run_path(target,run_name='__main__')")
            rc = subprocess.call([sys.executable, '-I', '-S', '-B', '-c', runner, str(trusted),
                                  nn, str(ag), str(ag / 'out')],
                                 cwd=ag, stdout=output, stderr=subprocess.STDOUT)
    else:
        report.write_text('Validator missing. No validation was performed.\n')
    complete = bool(completed and launcher_closed and rc == 0 and not force and not files_only)
    write(c / ('close-status-' + nn + '.json'), {
        'subject': 'aggregator', 'complete': complete, 'completed_turn': bool(completed),
        'launcher_exited': bool(launcher_closed), 'validator_exit_code': rc,
        'validator_sha256': digest(validator) if validator.exists() else None,
        'report_sha256': digest(report), 'checked_utc': now(),
    })
    if not complete and not force and not files_only:
        raise ValueError('stage validation failed; see ' + str(report))


def advance(run, label):
    d = Path(run) / 'CONTROL/snapshots' / label
    ck = read(d / 'checkpoint.json', {})
    return ((d / 'COMMITTED').exists()
            and (d / 'COMMITTED').read_text().strip() == ck.get('checkpoint_id')
            and ck.get('kind') == 'agent-and-files' and not ck.get('forced')
            and ck.get('validation', {}).get('complete') is True)


def inventory(root, agent=False):
    root = Path(root)
    result = {}
    def visit(p):
        rel = p.relative_to(root).as_posix()
        if any(c in rel for c in '\t\n\r'):
            raise ValueError('manifest cannot encode path: ' + repr(rel))
        if p.name == '__pycache__' or (not agent and rel == '.cc'):
            return
        if agent and 'credentials' in p.name.lower():
            return
        st = p.lstat()
        mode = oct(stat.S_IMODE(st.st_mode))
        if p.is_symlink():
            target = os.readlink(p)
            if any(c in target for c in '\t\n\r'):
                raise ValueError('manifest cannot encode symlink target')
            # Checkpoints are self-contained; external links are not restorable evidence.
            resolved = (p.parent / target).resolve()
            if resolved != root.resolve() and root.resolve() not in resolved.parents:
                raise ValueError('symlink escapes checkpoint root: ' + rel)
            result[rel] = ('symlink', mode, '-', target)
        elif p.is_dir():
            result[rel] = ('directory', mode, '-', '-')
            for child in sorted(p.iterdir()):
                visit(child)
        elif p.is_file():
            result[rel] = ('file', mode, digest(p), str(st.st_size))
        else:
            raise ValueError('unsupported checkpoint file type: ' + rel)
    for p in sorted(root.iterdir()):
        visit(p)
    return result


def save_manifest(path, entries):
    with Path(path).open('w') as f:
        f.write('# v2 type\tmode\tsha256\tpath\tsize|target; includes directories\n')
        for rel, (kind, mode, sha, tail) in sorted(entries.items()):
            f.write('\t'.join((kind, mode, sha, rel, tail)) + '\n')


def load_manifest(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        kind, mode, sha, rel, tail = line.split('\t', 4)
        result[rel] = (kind, mode, sha, tail)
    return result


def archive(root, path, prefix, entries):
    with tarfile.open(path, 'w:gz', dereference=False) as t:
        t.add(root, arcname=prefix, recursive=False)
        for rel in sorted(entries):
            t.add(Path(root) / rel, arcname=prefix + '/' + rel, recursive=False)


def verify_archive(path, prefix, manifest):
    expected, actual = load_manifest(manifest), {}
    with tarfile.open(path) as t:
        for m in t:
            name = m.name.rstrip('/')
            if name == prefix:
                continue
            if not name.startswith(prefix + '/') or '..' in Path(name).parts:
                raise ValueError('archive path outside its declared subject: ' + name)
            rel = name[len(prefix) + 1:]
            if rel in actual:
                raise ValueError('duplicate archive member: ' + rel)
            mode = oct(m.mode)
            if m.isfile() or m.islnk():
                if m.islnk() and (not m.linkname.startswith(prefix + '/') or '..' in Path(m.linkname).parts):
                    raise ValueError('hard link escapes archive subject: ' + rel)
                h = hashlib.sha256()
                size = 0
                with t.extractfile(m) as f:
                    for b in iter(lambda: f.read(1024 * 1024), b''):
                        h.update(b)
                        size += len(b)
                actual[rel] = ('file', mode, h.hexdigest(), str(size))
            elif m.isdir():
                actual[rel] = ('directory', mode, '-', '-')
            elif m.issym():
                actual[rel] = ('symlink', mode, '-', m.linkname)
            else:
                raise ValueError('unsupported archive member: ' + rel)
    if actual != expected:
        raise ValueError('archive differs from its per-entry manifest: ' + str(path))


def capture(run, dest, sid, expected_sha):
    run, dest = Path(run), Path(dest)
    ag, cc = run / '00_GIVE-THE-AGENT', run / 'CONTROL/.cc'
    fs = inventory(ag)
    native = inventory(cc, True) if sid else None
    save_manifest(dest / 'fs.sha256', fs)
    archive(ag, dest / 'fs.tar.gz', '00_GIVE-THE-AGENT', fs)
    verify_archive(dest / 'fs.tar.gz', '00_GIVE-THE-AGENT', dest / 'fs.sha256')
    if sid:
        save_manifest(dest / 'agent-files.sha256', native)
        archive(cc, dest / 'agent.tar.gz', '.cc', native)
        verify_archive(dest / 'agent.tar.gz', '.cc', dest / 'agent-files.sha256')
        data = transcript(run, sid).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected_sha:
            raise ValueError('aggregator transcript changed during checkpoint capture')
        (dest / 'transcript.jsonl').write_bytes(data)
        (dest / 'transcript.sha256').write_text(expected_sha + '  transcript.jsonl\n')
        if native['projects/run/' + sid + '.jsonl'][2] != expected_sha:
            raise ValueError('native archive and recorded boundary disagree')
    if inventory(ag) != fs or (sid and inventory(cc, True) != native):
        raise ValueError('a writer changed the aggregator state during capture; nothing committed')


def verify_checkpoint(d):
    d = Path(d)
    verify_archive(d / 'fs.tar.gz', '00_GIVE-THE-AGENT', d / 'fs.sha256')
    ck = read(d / 'checkpoint.json')
    if ck.get('subject') != 'aggregator':
        raise ValueError('checkpoint does not declare the aggregator as its only subject')
    if (d / 'agent.tar.gz').exists():
        verify_archive(d / 'agent.tar.gz', '.cc', d / 'agent-files.sha256')
        sid = ck['session']['session_id']
        sha = ck['session']['transcript_sha256']
        manifest = load_manifest(d / 'agent-files.sha256')
        if manifest['projects/run/' + sid + '.jsonl'][2] != sha or digest(d / 'transcript.jsonl') != sha:
            raise ValueError('native aggregator transcript is not the recorded checkpoint boundary')


def verify_tree(root, manifest, agent=False):
    if inventory(root, agent) != load_manifest(manifest):
        raise ValueError('restored tree differs from its checkpoint manifest')


def locked(run, command):
    run = str(Path(run).resolve())
    if os.environ.get('AGGREGATOR_LOCK_RUN') == run:
        return subprocess.call(command)
    lock = Path(run) / 'CONTROL/.protocol.lock'
    with lock.open('a') as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('aggregator launch or handler mutation is still running')
        env = dict(os.environ, AGGREGATOR_LOCK_RUN=run)
        return subprocess.call(command, env=env)


def main(a):
    op, *args = a
    if op == 'settings': settings(*args)
    elif op == 'prepare': prepare(*args)
    elif op == 'confirm': return 0 if confirm(*args) else 1
    elif op == 'launch': return launch(*args[:3], api_ok='--api-ok' in args[3:])
    elif op == 'preclose': preclose(args[0], args[1], args[2] == '1', args[3] == '1')
    elif op == 'advance': return 0 if advance(*args) else 1
    elif op == 'capture': capture(*args)
    elif op == 'verify-checkpoint': verify_checkpoint(*args)
    elif op == 'verify-tree': verify_tree(*args[:2], agent='--agent' in args[2:])
    elif op == 'locked': return locked(args[0], args[1:])
    else: raise ValueError('unknown guard operation: ' + op)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except (ValueError, OSError, KeyError, tarfile.TarError) as e:
        sys.exit('REFUSING: ' + str(e))

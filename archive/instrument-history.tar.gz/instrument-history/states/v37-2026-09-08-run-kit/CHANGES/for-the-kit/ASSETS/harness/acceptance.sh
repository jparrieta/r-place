#!/usr/bin/env bash
# Native-CLI acceptance test. Run once, in a Terminal, before stage 01 of any run.
# Throwaway conversations only; touches no study material. Assertions read CONTENT,
# never the mere existence of a file.
set -uo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
RUN="$D"; while [ ! -d "$RUN/00_GIVE-THE-AGENT" ] && [ "$RUN" != / ]; do RUN="$(dirname "$RUN")"; done
[ -d "$RUN/00_GIVE-THE-AGENT" ] || { echo "cannot locate the run root from $D" >&2; exit 1; }
AG="$RUN/00_GIVE-THE-AGENT"; CC="$RUN/CONTROL/.cc"
MODEL="$(python3 -c "import json;print(json.load(open('$RUN/CONTROL/RUN.json'))['model'])" 2>/dev/null || echo claude-sonnet-5)"
FP="$(python3 -c "import json;print(json.load(open('$RUN/CONTROL/RUN.json'))['fingerprint'][:16])" 2>/dev/null || echo ZZZZ)"
T="$(mktemp -d /tmp/acc.XXXXXX)"; mkdir -p "$T/p"
pass=0; fail=0
ok(){ echo "  PASS  $*"; pass=$((pass+1)); }
no(){ echo "  FAIL  $*"; fail=$((fail+1)); }
uu(){ python3 -c 'import uuid;print(uuid.uuid4())'; }
echo; echo "run:   $RUN"; echo "model: $MODEL"; echo

echo "=== 1. is the analyst's own config dir authenticated? ==="
echo "    (it ships empty; a one-time login into it is required -- see KIT-NOTES)"
A="$(cd "$T/p" && CLAUDE_CONFIG_DIR="$CC" claude --model "$MODEL" -p "Reply with exactly: ALIVE" 2>&1)"
printf '%s' "$A" | grep -q ALIVE && ok "CONTROL/.cc is authenticated" \
  || { no "CONTROL/.cc is NOT authenticated -- stage 01 would stop at a login prompt"; echo "        ${A:0:140}"; }

echo; echo "=== 2. what tools does the analyst actually get? ==="
echo "    (account connectors do NOT pass through the sandbox; they must be absent)"
B="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model "$MODEL" --strict-mcp-config --permission-mode auto -p \
'List every tool available to you, one name per line, exactly as named. Include MCP or connector
tools. Output only the list, then the line ZORBEND.' 2>&1)"
bad=""
for pat in 'mcp__' WebFetch WebSearch SendMessage ListAgents RemoteTrigger Workflow Skill; do
  printf '%s' "$B" | grep -q "$pat" && bad="$bad $pat"
done
[ -z "$bad" ] && ok "no connector, web, or cross-session tools reached the analyst" \
              || no "tools that must not be present:$bad"
printf '%s' "$B" | grep -q '^Agent$' && ok "Agent survives (the fleets at 04, 10 and 14 need it)" \
                                     || no "Agent is missing -- stage 04 cannot run its fleet"

echo; echo "=== 3. can the analyst do its work, and only its work? ==="
C="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model "$MODEL" --strict-mcp-config \
  --permission-mode auto --allowedTools Bash -p \
'Run these six Bash commands, report each output verbatim, labelled 1 to 6. Run all six.
1. ls tools/ | head -2 && echo ZORBLS
2. python3 -c "import sys;print(sys.version.split()[0])" && echo ZORBPY
3. python3 -c "
import numpy as np, pandas
from scipy.cluster.hierarchy import linkage
print(len(linkage(np.array([[0.0],[1.0],[4.0],[5.0]]),chr(119)+chr(97)+chr(114)+chr(100))))" && echo ZORBSTACK
4. python3 tools/mem.py help >/dev/null 2>&1 && echo ZORBMEM
5. touch out/_acc.tmp && rm -f out/_acc.tmp && echo ZORBWRITE
6. cat ../CONTROL/RUN.json 2>&1 | head -2' 2>&1)"
h(){ printf '%s' "$C" | grep -q "$1"; }
h ZORBLS    && ok "reads its own folder"                    || no "cannot read its own folder (denyRead names an ancestor?)"
h ZORBPY    && ok "python starts"                           || no "python cannot start"
h ZORBSTACK && ok "numpy/scipy/pandas and Ward linkage"     || no "numeric stack unavailable (stages 11 and 16)"
h ZORBMEM   && ok "the shipped tools run"                   || no "tools/mem.py did not run"
h ZORBWRITE && ok "can write to out/"                       || no "cannot write to out/"
h "$FP"     && no "LEAK -- it read CONTROL/RUN.json"        || ok "CONTROL/ denied"

echo; echo "=== 4. do the fork flags work? (forks at 01, 06 and 09 depend on them) ==="
P="$(uu)"; K="$(uu)"
(cd "$T/p" && claude --session-id "$P" --model "$MODEL" \
   -p "Remember this codeword: PORTCULLIS. Reply with just OK." >/dev/null 2>&1)
PT="$(find "$HOME/.claude/projects" -name "$P.jsonl" 2>/dev/null | head -1)"
S1="$(shasum -a 256 <"$PT" 2>/dev/null | cut -d' ' -f1)"
F="$(cd "$T/p" && claude --resume "$P" --fork-session --session-id "$K" --model "$MODEL" \
   -p "What codeword did I ask you to remember? Reply with only that word." 2>&1)"
KT="$(find "$HOME/.claude/projects" -name "$K.jsonl" 2>/dev/null | head -1)"
[ -n "$KT" ] && grep -q PORTCULLIS "$KT" 2>/dev/null && ok "fork lands at the preassigned id with the parent's history" \
  || no "fork did not carry history to the preassigned id"
printf '%s' "$F" | grep -qi PORTCULLIS && ok "the forked model answers from inherited context" \
  || no "fork did not inherit context"
[ "$S1" = "$(shasum -a 256 <"$PT" 2>/dev/null | cut -d' ' -f1)" ] && ok "parent left byte-identical" \
  || no "the fork mutated its parent"

echo; echo "================ RESULT:  $pass passed, $fail failed ================"
[ "$fail" -eq 0 ] && echo "ALL CLEAR -- the run can start." || echo "STOP -- do not start stage 01."
rm -f "$AG/out/_acc.tmp"
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
find "$HOME/.claude/projects" -type d -name '*acc-*p*' -exec rm -rf {} + 2>/dev/null
rm -rf "$T"; echo

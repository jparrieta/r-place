# ADDENDUM-08

Read this before `STAGE-08-model-the-literature.md`. It amends the contract, tells you what state
stage 07 actually left the model in, and gives you one task to do before the stage proper.

## 1. The contract's §6 is amended: no budget, no ceilings

`CONTRACT-aggregator.md` §6 and `tools/HOW-TO-RUN.md` no longer carry a run token budget or a
ceiling per fleet stage. Read the amended paragraphs; both are marked. The costing discipline
stands: a fleet stage still measures its payloads and writes the estimate down before it launches.
What no longer follows is the stopping. No stage cuts its design, its sample or its reading to
reach a figure, and none stops because a figure was passed. A reduction made to reach a number is
not a finding.

`tools/validate.py` carried a warning that no run may name more than ten chunks, or more than half
its second-order themes. That warning predated the amendment that removed every number from the
chunk and dimension tiers, and it is gone. Stage 07 reported it as a likely defect. It was right.
The only ceiling the contract now states is Eisenhardt's, on how many cases fit one head, which
this instrument exists to pass.

## 2. What stage 07 actually left you

The model you inherit is not the model stage 07's stopping rule judged, and its registers do not
say so. Read this carefully, because every number in `saturation.jsonl` describes an earlier
object than the one in `edges.jsonl`.

Stage 07 ran four passes, stopped under its stability rule, ran its reviewer, and wrote
`notes-07.md`, `diary-07.md` and `handback-07.md`. The operator then asked two follow-up questions,
and the analyst answered them by editing the model. The stopping rule judged eleven edges and the
reviewer reviewed eleven edges. `edges.jsonl` carries thirteen. `model.md` says so in prose, in its
*Dynamics* and *Looked-for-and-not-found* sections; no line in `tier_history.jsonl` or
`saturation.jsonl` records any of it.

Three edges need treating as provisional rather than settled.

**`E7→E4`** was re-graded from `thin`/`reading-alone` to `fair`/`codes-read` on a size-stratified
base-rate test: 67 co-occurrences pooled against 52.5 expected (1.28×, p=0.0004), and band ratios
0.78, 1.05 and 1.02 after stratifying on room activity. Stratifying is the right move, because
activity is a common cause of both measures. But the band sizes and cell counts are not reported,
there is no pooled conditional estimate and no interval, and the upgrade therefore rests on a
failure to reject. A conditional null is consistent with the decoupling claim; it does not
establish it. Note also that this edge carries `base_rate_beaten: false`, and that for a claim
whose content *is* decoupling, false is the predicted result and not a failure. Do not read it as
one, and do not let a later stage read it as one.

**`E3→C5`** rests on one verified transition out of 96 candidates, and **`C5→E4`** on one out of
26; both are graded `fair`/`coder-dated order`, and the denominators appear in the prose but not in
`sampled_against`. Both also use the chunk id `C5` as an endpoint rather than minting a ninth
element. Stage 07 declares that choice and its cost; you inherit it.

## 3. Before the stage proper

Bring the register up to date, honestly dated. Write one `tier_history.jsonl` line for each change
made to the model after stage 07's stopping rule was evaluated: the edge `E4→E3` added at close,
the edges `E3→C5` and `C5→E4` added after it, the `E7→E4` re-grade, and the two correlations
withdrawn after testing (`C14×C8` and `C10×C15`). Each line carries `"stage": "08"` and a `why`
that says it records a stage-07 post-close change, so the record catches up without pretending the
change happened when it did not. Then write a paragraph in `notes-08.md` stating plainly, in your
own words, which model `saturation.jsonl` and `review-07.md` describe and which one you are
working from.

Add to `sampled_against` on `E3→C5` and `C5→E4` the count of candidate instances each was drawn
from. That is a fact stage 07 established; you are moving it from prose into the field that holds
it.

## 4. Two things to know, neither needing action

`tools/mem.py` was corrected during stage 07. Four call sites joined a case theme's descriptive
label against an overlay keyed by its short id, so `where`, `codes --theme`, `codes --chunk` and
`pairs --level theme|chunk` silently returned nothing. The fix is kept. The changed tools hash is
in `run_manifest.json`'s stage-07 entry.

`model.md`'s in-mass, out-mass and internal-mass figures are reported with doubles included, not
doubles-stripped. Stage 07 declared this in `departures.jsonl`. Do not treat the figures as
corrected.

# ADDENDUM-10

Read this before `STAGE-10-model-the-return-to-the-field.md`. Four items.

## 1. There is no ceiling, and the fleet is not cut to fit one

`CONTRACT-aggregator.md` §6 and `tools/HOW-TO-RUN.md` were amended: this run carries no token
budget and no per-stage ceiling. Read the amended paragraphs; both are marked.

This stage's costing paragraph still tells you to write the total "against the ceiling the operator
wrote for this stage". There is none, so the comparison has no object and the fallback it guards
does not trigger. What survives is the measurement: take `mem.py room --size` for every room, write
the context per agent, the agent count at `R = 1` plus the thirty read three times, and the total,
in `notes-10.md`, before any agent runs. Then run the whole analysed set.

The author-composed fallback (`read_by: author`, chosen by a stratified rule) is for rooms that
cannot be served, not for rooms that would be expensive. If a room's payload genuinely will not fit
one agent's context, say so, name the room, say what you did, and report those rooms apart. Do not
reach for that path to hold a number down, and do not shorten the brief, the thirty, or the
adjudication for cost. A reduction made to reach a number is not a finding.

## 2. What the account's fidelity figures actually cover

`account.md` ends with three sections the stage-09 file named no output location for: §9
transferability, §11 where the model should fail, and §12's canvas paragraph. They were appended
after both reader rounds had run, so `reader_round.jsonl`'s fidelity figures describe the core
narrative that preceded them and not those three sections. `notes-09.md` does not say this.

The consequence for you: the brief you freeze rests on the reader-tested core. If you build any
part of it from §9, §11 or §12, say so in `composition_brief.md` and in `notes-10.md`, and treat
those sections as untested prose rather than as claims three readers recovered.

## 3. `E7→E4` stands at `thin` / `reading-alone`

The grade was raised after stage 07's stopping rule, tested at stage 08, and reverted at stage 09
because an uninformative interval does not carry an upgrade. No verdict in this stage may treat
that edge as better grounded than `thin`, and no room's composition may turn on it alone.

## 4. Every count says how it was computed

`mem.py` still has no bulk statistical query surface, so counts in this stage will come from reads
you write yourself. Every count in `transmission-10.md`, `uncomposed-10.md` and `notes-10.md` names
the file it was computed from and the path by which. Where a figure came from a hand-rolled read
rather than from `mem.py`, say so. Do not present a hand-rolled figure as a tool result.

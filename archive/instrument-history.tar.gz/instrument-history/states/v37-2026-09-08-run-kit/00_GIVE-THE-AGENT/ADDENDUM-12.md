# ADDENDUM-12

Operator amendment, shipped with stage 12. It adds nothing to the model and recuts nothing.

## 1. The cut you inherit, and what its own table says about it

Stage 11 carried **k = 2**: one cluster of 263 and one of 35. Read your own
`cluster_report-11.md` before you name anything. It records that k = 2 clears the stability bar by
0.003 on the mean, that its median resample ARI sits below its own null's median, and that a rerun
under a different seed flipped which of k ∈ {2,3,4,5} passed. Your `handback-11.md` says the same
in plainer words. Nothing in this addendum contradicts that report; it makes it binding on how this
stage writes.

The consequence for §1. A cluster of 263 communities out of 298 is not, on the strength of that
table, shown to be a form. It may still turn out to be one. What it may not be is *assumed* to be
one because the partition handed it to you with a boundary drawn round it. Say in
`cluster_names-12.md` which of the two you are naming from the members and which you are declining
to name, and why, in the same terms §1 already asks for.

One fact you would find anyway, stated here to save the count: **53 of the 59 communities flagged
`low_information` are inside the 263.** A boundary that collects the thin rows is a property of the
method as much as of the rooms, and §2's arithmetic on absence applies inside that cluster with
particular force.

## 2. Regrouping is already yours, and so is refusing to

§1 says you may "read a cluster's communities as rooms, with any tier, any file, any ordering, and
regroup inside a cluster if that is what you see." That permission is the right tool here and you
are expected to use it on the 263. Two limits:

- Any sub-group you report faces §1's own test, unchanged: named from the members, defended from
  the members, with the strongest argument that you read it off the model instead, and dropped or
  renamed if you cannot defend it. A sub-group is not cheaper to claim than a cluster.
- **Reporting no sub-structure is a result, not a failure.** If the 263 read as rooms do not
  separate, say so and say what you looked for. Rule 8 covers this. Do not manufacture groups to
  fill a stage.

## 3. What does not move

Rule 11 is closed and the cut is snapped. Nothing here reopens stage 11: you do not recompute a
partition, and `clusters-12.jsonl` still carries exactly one line for each of stage 11's two
clusters, whatever you report inside them. §4's refusals stand as written, and two of them bear
directly on this stage: do not let cluster size become importance, and do not treat a dissolved
partition as forms.

## 4. `S31`

Stage 11 found that `S31` won zero placements across all 2,703 case themes, which is why the theme
leg of the tier check could not run. It is logged. Do not re-derive it here; if a cluster's reading
touches it, cite stage 11's finding and move on.

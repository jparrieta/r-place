# Stage 16 — the crossing: the problem dendrogram.

Nothing is read in this stage: no account, no notebook, no code text, no room note beyond the
standing read of `rooms_index.md`, and not
`clusters-12.md`. You compute, and then make three judgements the computation cannot: which of
four verdicts the volume check returns, where to cut, and whether the clusters are interpretable
at all. Stage 17 does the reading.

Input: `__OUTDIR__/community_profile.jsonl` from stage 15, built from the revised crossing;
`__OUTDIR__/crossing.md` and `__OUTDIR__/strain.md`, with `__OUTDIR__/crossing_revisions_only.jsonl`
beside them; `package/mentions.jsonl`, the coders' mention record, for the covariates;
`__OUTDIR__/dropped.jsonl`; `__OUTDIR__/composition.jsonl`; `__OUTDIR__/assignments_final.jsonl`;
`package/store/rooms.jsonl`, whose six canvas fields are projected on in §7 and are never a
feature (rule 7); `pre_vector.csv` and `pre_network.csv` with `DATA-manifest-11.md`, in the folder
since stage 11, verified against `package/sealed.jsonl` again before use.

Outputs: `__OUTDIR__/profiles-16.csv`, `__OUTDIR__/distance-16.csv`, `__OUTDIR__/dendrogram-16.json`,
`__OUTDIR__/clusters-16.jsonl`, `__OUTDIR__/clusters_members-16.jsonl`,
`__OUTDIR__/cluster_report-16.md`, `__OUTDIR__/notes-16.md`, and the script at
`__OUTDIR__/cluster-16.py`.

Method is yours, declared before the script runs and saved with it. The feature space is closed.

## 1. Features: the crossing's problem profile, as presence

Six features. The four problems, each present or absent, from `community_profile.jsonl`'s
`cells_per_problem` (zero against non-zero); `exception`; `goal`. `hard_to_place` is excluded as a
statement about the readers. Strain is not a seventh feature: its unit is the `(chunk, problem)`
pair and no community carries one. `beyond_four_cells` is not a feature: it is what the four have
no name for, and a partition on the four cannot carry it; report it per cluster in §7. Nothing
from `composition.jsonl` and nothing from the canvas: both are projected on in §7, never a
coordinate.

The features are categorical, not a composition; no log-ratio transform. Default: Hamming or
Jaccard over the six flags with Ward linkage; the choice between them is the choice between
counting shared absences and ignoring them, so say which and why, and what would make you abandon
it, before you run anything. Do not hand-cluster.

**Covariates, never features:** `partners_named`, `isolated` (named nobody at all) and
`ever_in_conflict`, each computed per community from `package/mentions.jsonl` by a rule you write
in `notes-16.md` before you compute it; `log(1 + distinct_posters_week_before)` from
`pre_vector.csv`; each community's shared-poster degree or a component id from `pre_network.csv`
at a threshold you declare. Cross the finished partition against all five and report the table;
`isolated`'s rate is a property of this sampling band and is reported with the band attached.

## 2. Every community accounted for

Communities with no codes: out, as a named group, from stage 01's count. Communities whose every
case theme came out empty under the scheme: out, as their own named group; *has a codes file* and
*has any assigned mass* are different predicates, and a pipeline that follows this file literally
divides by zero and loses them silently. Communities with fewer than five placed case themes (stage 11's rule) stay in, flagged
`low_information: true` on the community in `profiles-16.csv`; `clusters-16.jsonl` carries its own
`low_information`, true where a cluster's members are mostly flagged, and the two fields are never
read as one. A third group is out by construction: communities with placed mass and no cell in
scope, because none of their themes bubbles into a chunk the model uses; name them, from
`scope-13.md`, since an all-zero profile is not a profile. Leaves plus the three excluded groups
equal `n_analysed`; anything in `dropped.jsonl` is in none of the four.

## 3. Read the strain figure before you cluster

If the four are the wrong coordinates for this material the dendrogram cannot tell you;
`strain.md` can. Read its per-`(chunk, problem)` table and its universality cross-tab: splitting
high and spread across cells carrying neither extension means the four are not the right axes
here. The figure is computed on the raw returns, before stage 15's revision of the brief, so count
the revisions in `crossing_revisions_only.jsonl` carrying `row: "brief-failed-to-transmit"`, take
each one's pair from the cell's own `chunk` field, and report what share of the pairs your figure
rests on carry at least one; do not divide a cell count by a pair distribution. Then, before you
have seen the dendrogram, write into `notes-16.md` the level of splitting outside the
extension-carrying cells above which you will report this partition as provisional.

## 4. The volume check, which decides whether the stage has a result

Cross every cluster against `items_in_window`, code count and case-theme count, carrying the
denominator. Build the null on the feature space you used: permute each community's problem states
across problems, holding its number of states of each kind fixed, through the whole pipeline, at
least 200 replicates (fewer if unaffordable, saying how many and what it does to the percentile).
Correlate the first principal component with `log(1 + distinct_posters_week_before)`. Then say
which of four: the partition is about form; it is about size and dissolves; it is size-shaped with
structure inside it that survives the null; it is neither size-shaped nor decisively separated
(above the null's median, never above its 95th percentile). Report the percentile.

## 5. Cuts

Report the dendrogram at 2, 3, 5, 8 and 12 clusters and any other k you argue for; choose after
you have seen them all and before §7 projects anything onto the cut, and prove the order as stage
11 did: write the cut into `cluster_report-16.md`, run `python3 tools/snap.py 16 cut`, and only
then compute §7's blocks. You hold the canvas and cannot unknow it: say in `cluster_report-16.md`
whether any cut was attractive because of what its clusters had made. A cut whose largest cluster has no over-represented feature is degenerate; show
the next one. Report the cut carried, the grounds, and what would have made you choose
differently.

## 6. Labels carry nothing

Two-letter codes from a hash of the member set, in random order, never by size. Naming is stage
17's.

## 7. Two files, and composition and the canvas projected on

`clusters-16.jsonl`, everything computed:

```json
{"cluster": "QF", "members": ["Jamaica", "KState"], "n": 23, "low_information": false,
 "problem_profile": {"division": 0.61, "allocation": 0.83, "reward": 0.22, "information": 0.91,
                     "exception": 0.30, "goal": 0.48},
 "over_represented": ["allocation"], "under_represented": ["reward"],
 "nearest_cluster": "MK", "merge_height": 0.41,
 "volume": {"median_items_in_window": 88, "median_codes": 47, "median_case_themes": 8},
 "covariates": {"isolated_rate": 0.3, "median_log_posters": 2.1, "ever_in_conflict_rate": 0.4},
 "beyond_four": {"cells": 9, "rooms": 6},
 "composition": {"composes": 14, "composes-with-residue": 5, "does-not-compose": 2,
                 "cannot-tell": 2},
 "canvas": {"median_area_px": 0, "rooms_with_artwork": 0, "median_pieces": 0}}
```

`clusters_members-16.jsonl`: cluster code, `n`, members, nothing else. Stage 17 opens it first.
The `composition` block is stage 10's verdicts counted per cluster, with the percentile against
the permutation null reported beside it. The `beyond_four` block counts the cluster's cells and
rooms with `is_problem` true and no active universal, from `community_profile.jsonl`. The `canvas`
block is the six fields summarised per cluster, after the cut, with the contract's §4 sentence on
what they measure beside it and the same permutation null; it is never a warrant for the cut.

## 8. `cluster_report-16.md`

Computed facts only: the method as declared, the script, the dendrogram at each cut, the volume
check with its verdict and percentile, the strain figure and what you declared about it, the three
groups and their arithmetic, every cluster's profile against the census base rate, the covariate
table, the composition table, the canvas table, and two sentences in your own words: the dendrogram is computed from
a profile scoped on your own chunks and cannot corroborate them, and *this edge fires here and not there* is
arithmetic about your mapping too. Nothing here anticipates stage 17's comparison; write nothing
about how this partition relates to stage 11's. You may not recut anything; a feature space that
looks wrong is a finding for `notes-16.md`, `defects.jsonl` and stage 18.

## Your final message

The chosen k and why; which of the four verdicts and at what percentile; the strain figure and the
level you declared; whether any cut was degenerate; the size of each declared group and that the
leaves and the two excluded groups sum to `n_analysed`; the composition distribution across
clusters with its percentile; the canvas summarised per cluster with its percentile; where the
cells beyond the four sit; the single number you would least like a reviewer to recompute. A
return value.

## Close

Run `python3 tools/validate.py 16 . __OUTDIR__`, paste the report into `notes-16.md`, write
`handback-16.md`, and finish `diary-16.md` with its three closing headings.

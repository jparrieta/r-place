# Stage 12 — clustering: how each cluster organized.

Input, in two batches and in this order:

1. `__OUTDIR__/clusters_members-11.jsonl`, `__OUTDIR__/composition.jsonl`,
   `__OUTDIR__/uncomposed-10.md`, the room notes through `mem.py note`, and the corpus through
   `tools/cite_case.py` and `tools/mem.py`. Nothing else.
2. Once §1 is written and snapped: `__OUTDIR__/clusters-11.jsonl`,
   `__OUTDIR__/cluster_report-11.md`, `__OUTDIR__/tier_robustness-11.md`, `__OUTDIR__/structure.md`
   or `structure.v2.md`, `__OUTDIR__/chunks.jsonl`, `__OUTDIR__/model.md` or `model.v2.md`,
   `__OUTDIR__/edges.jsonl` or `edges.v2.jsonl`, `__OUTDIR__/propositions.md`,
   `__OUTDIR__/figure.md`, `__OUTDIR__/account.md`, `__OUTDIR__/findings.jsonl`. Where stage 08
   wrote a `.v2`, read it and say so.

The standing reads of `_head.md`, the last diary and `findings.jsonl` precede batch 1 here as at
every stage, and you built the model and have not forgotten it; what the snap at §1 proves is
that the names were written before this stage's model files and computed cluster files were
opened, not that you were blind to the model. Say so in `cluster_names-12.md`.

Outputs: `__OUTDIR__/cluster_names-12.md`, `__OUTDIR__/clusters-12.md`, `__OUTDIR__/clusters-12.jsonl`,
`__OUTDIR__/operator_draw-12.json`, lines in `__OUTDIR__/objections.jsonl`, `__OUTDIR__/notes-12.md`.

The clusters are the forms organizing took under your own tier, and this is where you go back
down: read a cluster's communities as rooms, with any tier, any file, any ordering, and regroup
inside a cluster if that is what you see. Two things are fixed: a claim about absence carries §2's
arithmetic, and the clusters were computed from your own assignments and cannot vouch for them.
If stage 11 returned the second tier-robustness verdict, write this stage anyway, about what the
clusters do track, and say in every portrait that they are not forms.

## 1. Naming, from the members

`clusters_members-11.jsonl` carries cluster code, `n` and members, nothing else. Per cluster, read
its rooms (their notes first, then codes, forests, cases) until you can say what they have in
common that the others do not. Name each cluster from the members, with the reasoning and `cite()`
quotes, in `cluster_names-12.md`; write that file before you open anything in batch 2, run
`python3 tools/snap.py 12 names` the moment you close it, and record in it the snap line and the
last line numbers of `_aggregator_reads-12.jsonl` and `_mem_reads-12.jsonl`. The snap is what
proves the order; the log lines are what a reader checks it against. Then, for each name, the
strongest argument that you read it off the model rather than the
members, and what a reader who suspected it would look for. A name you cannot defend from members
alone is renamed or dropped; say which.

## 2. Before you call anything absent

Rule 6. Declare here, before any comparison, the minimum count of within-case datings an order
edge stands on, from your own carry counts. For every edge you compare across clusters, compute
the expectation: the edge's corpus-wide `subs` count over `n_analysed`, times the cluster's `n`;
do it for your smallest and largest cluster first. Below one the edge is `not-testable-here`, and
no boundary condition and no `propositions_fail` may be written from it. Edge presence inside a
cluster is arithmetic about your own mapping, cut on the same mass: *present here, absent there*
describes a form and never bounds a proposition, unless you can say what distinguishes the
difference from a restatement of the cut.

## 3. Per cluster, the portrait

`clusters-12.md`, one portrait per cluster, in this order:

1. **How these communities organized, told as a narrative**: a few hundred words a stranger to the
   model could follow, with participants' words in it, written before the comparisons below.
2. **The name and the members it was read off**, with quotes.
3. **Composition here.** From `composition.jsonl`: how many compose, with residue, do not, cannot
   tell. **Name every room the model could not compose inside this cluster**, with the condition
   it named at stage 10 and what the rest of the cluster does that it did not; a cluster that holds
   most of them is described as the place the model stops.
4. **What these rooms made.** The `canvas` block from `clusters-11.jsonl`, read against the
   narrative in 1 and against the account's paragraph on what the model implies a room keeps: what
   the rooms of this form left on the canvas, and whether the model's account of why fits or does
   not. The contract's §4 sentence on what the canvas measures stands beside it; nothing here is a
   score (rule 7).
5. **How the model runs here**: which parts do the work, which sit idle, which fit badly, what
   these rooms do that it has no place for. Where the model's account and your reading disagree,
   say which you believe.
6. **The one relationship that runs differently here**, both sides quoted.
7. **Chunks over- and under-represented** against the census base rate (from `clusters-11.jsonl`),
   and what that means in the rooms' own words.
8. **Edges present, absent or `not-testable-here`** with the expectation on each; propositions
   that hold, fail against a real expectation, or are not testable, by number.
9. **One community read at length**, with why you chose it and what is unrepresentative about it.
10. **The nearest cluster and what separates them**, with the case that could have gone either way.
11. **What would make you doubt this is a form at all.**

The residual, if there is one, gets a portrait or an explicit statement that it is not a form. A
cluster that is mostly `low_information` is said to be before it is described.

`clusters-12.jsonl`, one line per cluster:

```json
{"cluster": "QF", "name": "...", "n": 23,
 "composition": {"composes": 14, "composes-with-residue": 5, "does-not-compose": 2, "cannot-tell": 2},
 "uncomposed_members": ["..."],
 "canvas": {"median_area_px": 0, "rooms_with_artwork": 0, "median_pieces": 0, "read": "one clause"},
 "over": ["C5"], "under": ["C9"],
 "edges_present": [{"edge": "S03->S07", "expected": 2.1}],
 "edges_absent": [{"edge": "S11->S04", "expected": 1.8}],
 "edges_not_testable": [{"edge": "S02->S19", "expected": 0.4}],
 "propositions_hold": ["P1", "P3"], "propositions_fail": ["P2"],
 "propositions_not_testable": ["P4"],
 "unmodelled": "...", "name_defensible_from_members": true, "confidence": "..."}
```

## 4. What you must refuse to do

Do not characterise the groups stage 11 declared out; say what they are and stop. Do not treat a
dissolved partition as forms. Do not let cluster size become importance. Do not recut anything or
change the model: a chunk that lumps two things a cluster separates is a finding for `notes-12.md`,
`defects.jsonl` and stage 18, and a claim a cluster bounds is written to `findings.jsonl` under
rule 16, not into the model. Write nothing about the crossing.

## 5. Close the forms before the crossing opens

Draw three cluster accounts by seed into `operator_draw-12.json` for the operator's own reading;
the operator's objections enter `__OUTDIR__/objections.jsonl` and are answered in `notes-12.md`
before stage 13 opens (rule 13 decides). After that, `cluster_names-12.md`, `clusters-12.md` and
`clusters-12.jsonl` are not edited (rule 18): if a description is later found wrong, the
correction is written at stage 17 or 18 as a correction, with what showed it.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then: clusters named; the snap line that shows `cluster_names-12.md` closed
before batch 2; names that survived the members-only test; the hardest to name; the cluster whose reading
disagreed most with the model, and which you believe; where the uncomposed rooms sit; edge
absences real against expectation and `not-testable-here`, by count; propositions that failed
against a real expectation, and the `findings.jsonl` lines they bounded; what the portraits showed
that the room notes did not predict; the most consequential difference between two forms; and
which of the contract's §3 method licences you exercised here and which not. A return value.

## Close

Run `python3 tools/validate.py 12 . __OUTDIR__`, paste the report into `notes-12.md`, write
`handback-12.md`, and finish `diary-12.md` with its three closing headings.

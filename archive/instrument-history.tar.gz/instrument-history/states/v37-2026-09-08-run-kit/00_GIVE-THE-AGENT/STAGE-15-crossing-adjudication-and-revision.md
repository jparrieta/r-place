# Stage 15 — the crossing: adjudication, and revision.

Input: `__OUTDIR__/scope-13.md`, `__OUTDIR__/cells_in_scope.jsonl`, `__OUTDIR__/gold_cells.jsonl`,
`__OUTDIR__/author_cells.jsonl`, `__OUTDIR__/crossing_brief_final.md`, `__OUTDIR__/brief_edits.jsonl`,
`__OUTDIR__/fidelity-14.md`, `__OUTDIR__/crossing_raw.jsonl`, `__OUTDIR__/agent_report-14.md`,
`__OUTDIR__/batches-14.jsonl`, `__OUTDIR__/scheme_v2.md`, `__OUTDIR__/assignments_final.jsonl`, the
corpus through `tools/cite_case.py`, and the store through `tools/mem.py` (`theme`, `codes --sub`,
`where`) for the cells' case themes and codes. For Part B only, after Part A has closed:
`__OUTDIR__/literature.md` §6 (stage 08's fourth pass) and `__OUTDIR__/propositions.md`.

Outputs, Part A: `__OUTDIR__/crossing.jsonl`, one adjudicated line per cell; `__OUTDIR__/crossing.md`;
`__OUTDIR__/transmission-15.md`; `__OUTDIR__/strain.md`; `__OUTDIR__/adjudicator_packet-15.md`;
`__OUTDIR__/recross.jsonl` and `__OUTDIR__/reliability-15.md` (A7).
Part B: `__OUTDIR__/crossing_brief_v2.md`, `__OUTDIR__/crossing_final.jsonl`,
`__OUTDIR__/crossing_final.count.txt`, `__OUTDIR__/crossing_revisions_only.jsonl`,
**`__OUTDIR__/community_profile.jsonl`**, `__OUTDIR__/brief_review-15.md`. Both:
`__OUTDIR__/notes-15.md` and the `run_manifest.json` append.

**Part A** rules the contested cells and measures what the fleet did; **Part B** repairs what can be
repaired, measures the repair, and builds the object stage 16 consumes. Part B does not open until
Part A's files are written, and nothing in Part B edits them.

## Part A: adjudication

### A1. The adjudicator is not you

The ruling is made in a fresh context that holds the Input block's files and the corpus, and
nothing else: not your room notes, not `findings.jsonl`, not the model, the account, the
propositions, the compositions, the clusters or their names, and not the canvas. You assemble
`adjudicator_packet-15.md` naming exactly those files, run the adjudicator, check its arithmetic
against the files, and write `notes-15.md`. You do not rule on a cell, and you do not edit a ruling;
where you disagree with one, the disagreement goes to `notes-15.md` and to Part B as a
disagreement, not a correction. Append the manifest entry with the adjudicator's model, seed and
decoding, `n_agents` 1.

Only the disagreements are ruled. Where the two readers agree, the cell stands and nothing is
re-read. The adjudicator rules on the material, blind to which agent made which call: the packet
serves it the contested lines of `crossing_raw.jsonl` with `agent`, `batch`, `replicate` and the
timestamps stripped, as stage 05 §5 strips them, both readings shown with their `why`; the agent
ids are opened only after the ruling, for A3's figures.

### A2. The taxonomy, stage 13's four

**`frame-ambiguous`**: the four definitions do not decide this cell. It carries the paper's answer
to whether the four decide, not whether they are universal, and is never used to avoid deciding.
**`cell-spans-two-problems`**: the material satisfies more than one gate and the agents were right
in different ways; under the predicate rule both go on the line, each with its own supporting
code. **`reader-error`**: one agent misread the material. **`author-error`**: the author's answer
in `author_cells.jsonl` or `gold_cells.jsonl` was wrong and the agents were right; available
wherever an author answer exists, and Part B reads it.

### A3. Transmission and strain, two questions and two files

Both are computed on `crossing_raw.jsonl` before anything touches it, **with the seeded gold
readings dropped first**, by `(cell, agent, replicate)` on the gold-tagged rows of
`batches-14.jsonl`, never by key: if the line count of cells falls, cells were dropped. The gold
cells keep their adjudicated line, ruled on their live replicates like any other. Fidelity on the
seeded readings is stage 14's figure in `fidelity-14.md`; read it, do not recompute it, and say how
many readings the drop removed.

**`transmission-15.md`.** Four rows against your answers (the author's, in the packet's words), over
the gold and pilot cells: agree with each other and with the author (nothing to see); split and
the author was confident (**the brief fails to transmit**, a wording defect Part B repairs); split
and the author was also unsure (**the frame does not decide this cell**, the finding, never
revised away); agree with each other and diverge from the author (**the brief teaches something
unintended**; read every one). All four counts stay in this file, rows 2 and 4 cell by cell.
Outside the gold and pilot sets no author answer exists; say that the split rate there cannot be
decomposed and do not extrapolate the gold proportions.

**`strain.md`.** Nothing in it is a defect. Its unit is the `(chunk, problem)` pair, the chunk
taken from the cell's own `chunk` field in `cells_in_scope.jsonl`:

- the distribution of splits (unanimous, split) per pair, never as one rate, with the duplicate
  rate from stage 14 beside it as the floor of what a split can mean;
- the count of transmission's third row, with where it was computed;
- the cross-tab that carries the universality claim: is fleet splitting concentrated in the `goal`
  and `exception` cells, or spread across cells carrying neither? Concentrated means the four hold
  for steady-state organizing and strain where a reader would predict; spread across ordinary
  cells means the four have a coverage problem the extensions do not explain. One sentence,
  unsoftened;
- the 95% interval on the difference in splitting rates between extension-carrying cells and the
  rest, from the cell count, reported as a floor: the two readings are two samples from one model,
  so the true interval is wider by an amount this design cannot estimate; no decision threshold on
  it;
- the 2×2 of `hard_to_place` against splitting, descriptive, no interval: the flagged cell the
  fleet agreed on and the unflagged cell two strangers split are different calibration failures,
  and the gap between them is the finding;
- **what fell outside the four**: the cells with `is_problem` true and no universal active,
  counted per chunk and per room, and read: what these rooms were doing that the four have no name for, in one paragraph
  with participants' words through `cite()`. This is the half of the standing claim the
  contract's §1 says matters more, and it is reported here as a result and nowhere else as a
  defect; the count per room goes to `community_profile.jsonl` as `beyond_four_cells`.

### A4. The adjudicated line

`crossing.jsonl` is `crossing_raw.jsonl`'s schema with the agent fields replaced by the ruling:

```json
{"sub": "<community>", "second_order": "S07",
 "division": false, "allocation": true, "reward": false, "information": true,
 "exception": true, "goal": false, "hard_to_place": false, "is_problem": true,
 "support": {"allocation": ["c0113"], "information": ["c0140"]},
 "why": {"allocation": "shifts who holds which row after the first overwrite"},
 "split": "unanimous|split",
 "verdict": "frame-ambiguous|cell-spans-two-problems|reader-error|author-error|no-disagreement",
 "t": "<ISO>"}
```

`split` and `verdict` are carried so a reader of this file alone can see which cells were
contested.

### A5. `crossing.md`

The four counts, each with its denominator and its gate (rule 5), with rule 6 on every absence, and
the share of cells in scope carrying no problem at all; strain and transmission named apart and
pointed to, with the `hard_to_place` share on its own line as the readers' self-report; per
second-order theme, the entropy of its problem labels across communities, and the three
highest-entropy themes named, read as multifunctional practices or as bad cuts; the cells per
problem per room summarised, provisionally from `crossing.jsonl` (B7 builds the profile that
counts); what the scope filter left out, from `scope-13.md`, carried verbatim.

### A6. What the figures license

The readers share an architecture, a training distribution and a prompt: agreement bounds whether
the written text decides, never whether it is right. Write that wherever a figure from this stage
appears. Readers agreeing is evidence that the frame decides, not that it is right; that sentence
goes wherever the strain figure is written up, not in a footnote.

### A7. The blind check, after the line is settled

**This is the crossing's reliability measurement**, the twin of stage 05 §9, and it exists so that
the two partitions stage 17 compares stand on the same footing: whether the line the adjudicator
settled can be reached again by readers who were not here. Declared before you draw, in
`notes-15.md`: **the sample**, one hundred cells, fifty drawn uniformly at random from the cells
in scope and fifty from the contested cells, by a recorded seed, the two strata reported apart
and never pooled; **two fresh readers per cell**, in clean contexts, one run, each reading
compared with the settled line on its own, so the figure is a rate over two hundred readings,
with the readers' agreement with each other beside it; **the agreement definition**, per
problem, identical to stage 13's and 14's. Append this part's entry to `run_manifest.json`
before the first cell is served (model, seed, decoding, reader count).

**What the readers get**: `crossing_brief_final.md`, rule 0 as the brief restates it, and the
sampled cells with their codes in the participants' words. **Nothing else**: not
`crossing.jsonl`, not the adjudication, not a hint that these cells were decided before, and
never the model, the account, the clusters or your room notes.

**The comparison, per cell and per problem, the fresh reading against the settled one**, into
`recross.jsonl`: agrees; disagrees on a cell that was contested here (expected; compare the two
rates); disagrees on a cell the fleet was unanimous on (named one by one, a paragraph each: a
shared assumption the brief does not license, or an adjudication that moved something it should
not have); disagrees where the settled cell is `frame-ambiguous` (no information; out of the
denominator, counted). **`reliability-15.md`**: fleet agreement from stage 14 and
fresh-against-settled agreement per stratum and per problem, side by side, with the definition
above them; the unanimous-but-disagreed cells listed; and the sentence saying what the figure
licenses (A6). Stage 17 reads it beside stage 05's, and nothing in Part B rewrites it.

## Part B: revision

**This is to the crossing what stage 06 is to assignment.** Repair what can be repaired, measure
the repair, report what you had to leave standing. The fleet does not run again; `n_agents` is
null on this part's manifest entry. The figures are the contract's §7 words in every file that
reports a crossing figure, and the **revision rate**, the share of cells this part re-decided, is
yours.

### B1. The revision rate

**Re-decide by hand every cell an amendment to the brief touches**, and report how many that was as
a share of the cells in scope, **all of them**: `crossing.jsonl` carries every cell in scope, so
`cells_in_scope.jsonl`'s count is the denominator. Report it **overall**, **per universal
problem**, and **per verdict class** from A2's taxonomy, so a reader can see whether the revisions
landed on `frame-ambiguous` cells, on `reader-error` cells, or on cells nobody contested. That
number is **brief stability**: a high rate means the brief was fitted to sixty cells. **Say what
the rate is not**: not fidelity, and it improves nothing measured before it.

### B2. Where the brief is weak

**Three sources say where the brief is weak, and a clause appearing in all three is not one to
defend**: the contested cells in `crossing.jsonl`, by their `split` and `verdict` fields;
`transmission-15.md`, where it says the brief failed to transmit rather than that the frame does
not decide (B4); and cells where the fleet agreed with each other but not with you,
`author_cells.jsonl` and `gold_cells.jsonl` against `crossing.jsonl`, the rarest and most serious.
**Gold fidelity says where to look first**: a problem whose fleet-wide gold fidelity was low is one
whose clause the corpus never read the way you meant, and adjudication never touched it.

**What you may change.** A definition, a discriminator, a belonging test, a worked example replaced
by a harder one, rule 0 restated for this axis, or the rule for a case the brief left open: a cell
that satisfies no gate, a cell whose codes will not separate two problems.

**What you may not.** **No fifth problem, and none of the four retired** (stage 14 §7): organizing
material with no home in the four is **the finding**, a named residue in `crossing_brief_v2.md`
carried to `notes-15.md`, to `strain.md`'s last section and to stage 18's audit, never a gate. **No
narrowing a problem to make it decide**: it makes that problem's prevalence wrong in every count
after, with no fleet left to expose it; **report the base rate of all four problems before and
after every amendment.** **No recut**: the second-order themes, the chunks, the dimensions and the
scope in `cells_in_scope.jsonl` are fixed, and a theme you now think badly cut, or scope that
removed material this axis needed, goes to `notes-15.md`, `defects.jsonl` and stage 18's audit.

### B3. The fleet has already run, and it will not run again

**Apply a revision by re-deciding the cells it touches yourself, by hand, under the amended
clause**: not by re-running agents, not by inference, not by a rule applied in bulk to everything
carrying a label. Rule 11's conditions carry over whole: the clause changes first and the cells
follow from it; every re-decided cell is logged in `crossing_revisions_only.jsonl` (B6) with the
clause of the amended brief that decides it; and the stopping criterion, what would make you
prefer the frozen brief to the amended one, is declared in `notes-15.md` before the first
amendment.

**Say in `notes-15.md`, before you start, how many cells you can re-decide and defend.** If an
amendment would touch more than that, **leave the brief alone, report the figure with the defect
named, and carry it to stage 18's audit.** Do not amend the wording and leave the cells unrevised:
every count after would be computed under one document and described by another.

**A revision gets a new filename** (rule 18). `crossing.jsonl` is Part A's file: not overwritten,
not appended to, not superseded in place. Both lines survive.

### B4. Three rows ask something of you, and only one is yours to revise away

`transmission-15.md` decomposes the splits against your own answers on the gold and pilot cells,
in the contract's §7 rows. **`strain.md` is the other file and nothing in it is revisable**: an
amendment that moves a number in it has moved a result.

- **Split, and you were confident**: the brief failed to transmit. **Revise.**
- **Split, and you were also unsure**: the frame does not decide this cell. **Leave it**; that row
  is the only evidence in the instrument on whether the four definitions decide, and **an
  amendment that lowers the `frame-ambiguous` count with no wording defect you can quote is
  fitting.**
- **Agreed with each other, diverged from you**: read every one. Either you were wrong, A2's
  `author-error`, and a revision that never returns one is measuring obedience, in which case
  record it and **do not amend the brief toward your own answer**; or the brief taught them
  something you did not intend, and the wording is yours to fix. Say in `notes-15.md` which way
  each went.

Name, for every amendment, the cells that caused it and which row each sits in. **An amendment
whose `caused_by` cells all sit in the frame-does-not-decide row is not permitted.** Say how many
contested cells you left standing deliberately; **that number belongs beside the revision rate
wherever it is reported.**

**Outside the gold and pilot sets you cannot make this call**, because your answer does not exist
there; say so, and do not extrapolate the proportions from the gold set, which was drawn hard. For
a contested cell outside both, ask whether the brief's wording could have produced the split: if it
could, act on it as a wording defect; if you cannot tell, write that you cannot tell.

### B5. The form pass and the register pass

**`crossing_brief_v2.md` is the brief every count from here on is described under, and the next
run's strangers will hold it and nothing else; write it so. Do this before you open
`brief_edits.jsonl`**, which holds every defect stage 13 already found: a pass that starts from it
looks only where somebody has already looked. Run the pass **three times over**, and say in
`brief_review-15.md` what you swept for each time.

1. **Form.** Does each of the four problems have a belonging test in the same form? Is there a
   discriminator for every pair a reader could confuse, and not only the pairs you expected? Is
   rule 0 stated once, in one wording? Are the worked examples still drawn from hard cells? Does
   the brief say what to do when nothing fits and when everything does?
2. **Register. One word per concept, and the same word every time.** A brief that calls the same
   thing a *cell*, an *item* and a *pair* teaches a reader that they are three things. Watch for
   scheme vocabulary leaking in: a reader handed your second-order theme names labels the theme
   rather than the cell (stage 14 §1).
3. **What the brief does not say**: terms used without gloss, tests that assume the reader has read
   the contract's §1, objects and roles invoked without introduction.

**Then, and only then, open `brief_edits.jsonl`.** Write in `notes-15.md` what you found that stage
13 did not, what it found that you did not, and, for anything on both lists, that your finding is
**replicated, not discovered**. **A clause edited at stage 13 and needing editing again here has
failed twice**: say whether the second failure is in the wording or in the frame underneath it.
**And name what this pass could never find**: the clause that reads perfectly and is simply wrong
about this material, and the defect that shows only in cells no reader was given. Stage 18's *what
the study cannot say* inherits that.

### B6. `crossing_brief_v2.md`, `crossing_final.jsonl`, and the overlay

**`crossing_brief_v2.md` is the whole brief, not a diff**: every definition including the untouched
ones, every belonging test, every discriminator, every worked example, rule 0 as restated for this
axis. Declare each amendment where it sits: what changed, why, which cells it re-decided, and the
`caused_by` cells behind it. **An amendment with no `caused_by` is not allowed.**

**`crossing_final.jsonl` is every cell line, not only the ones you changed**, on A4's schema
carried through unchanged, `split` and `verdict` included, plus two fields:

```json
{"revised": true, "revised_under": "brief_v2 §3 allocation, second clause"}
```

`revised: false` on every line the amendments did not touch, and those lines carried through
verbatim. Last write wins on `(sub, second_order)`. Nothing is deleted. **Write the whole file**:
an overlay carrying only the changed lines, under the name every later stage lists as *the* input,
is indistinguishable from a complete file, and stage 16 would cluster on whatever fraction of the
corpus it covers and never find out.

**The line count goes in `crossing_final.count.txt`, not at the top of the JSONL.** It must equal
the number of distinct `(sub, second_order)` keys in `cells_in_scope.jsonl`, one line per cell in
scope, **the gold cells among them**, and **not** the number of lines the fleet returned, which is
that number times `R` plus the seeded readings. Take the expected value from `cells_in_scope.jsonl`
and the count in `scope-13.md`, and nowhere else: `tools/counts.py` counts case themes, not cells.

**Keep the overlay if you want the diff, and call it `crossing_revisions_only.jsonl`** so nothing
can mistake it for the corpus. One line per re-decided cell:

```json
{"sub": "<community>", "second_order": "S07", "was": {"allocation": false, "information": true},
 "now": {"allocation": true, "information": true},
 "clause": "brief_v2 §3 allocation, second clause",
 "caused_by": ["sub/S11", "sub/S04"], "source": "fleet-split|author-divergence|form-pass",
 "row": "brief-failed-to-transmit|frame-does-not-decide|taught-something-unintended|null",
 "t": "when you re-decided this cell, ISO"}
```

`row` names which of `transmission-15.md`'s rows the causing cells sat in, and the four values
above are the whole vocabulary. **`null` is for a `form-pass` revision**, which comes from a sweep
of the brief rather than from a split; write it rather than choosing a row for it. `source` and
`row` let a reader check B4's constraint arithmetically: **no revision may carry
`row: "frame-does-not-decide"`**, and stage 16 counts the `brief-failed-to-transmit` revisions off
this file.

### B7. `community_profile.jsonl`, the object stage 16 consumes

**Stage 16 clusters communities on `community_profile.jsonl`. Build it here, from
`crossing_final.jsonl`**, and build it even if this part produced no revisions, so that it has one
producer and stage 16 cannot read a stale one. One line per community in the analysed set:

```json
{"sub": "Jamaica", "cells_in_scope": 7,
 "cells_per_problem": {"division": 3, "allocation": 2, "reward": 0, "information": 4},
 "exception": true, "goal": false,
 "is_problem_cells": 6, "beyond_four_cells": 1,
 "profile_source": "crossing_final.jsonl"}
```

The four problems are booleans on cells and counts here; convert. `cells_per_problem`,
`exception`, `goal`, `is_problem_cells` and `cells_in_scope` come from the fleet and are complete
for every room in scope. `beyond_four_cells` is the count of the room's cells with `is_problem`
true and no active universal, the cells the four have no name for; it is reported beside every
profile and enters no feature. Stage 16 clusters on presence alone: `cells_per_problem` non-zero,
`exception`, `goal`; strain has no line here and is never a coordinate. `hard_to_place` is not in
this file. Whether a room's problems were settled is not in this file either: that is a judgement
across a room, made once, by the model's composition at stage 10, and a reader who wants the two
side by side reads `composition.jsonl` beside this file at stage 17.

**Report how many communities' profile lines differ from what they would have been under
`crossing.jsonl`.** If none do, the revision changed the brief and not the population, and stage
16's dendrogram is unaffected. Say which it was.

### B8. Stage 08's fourth pass, read beside the result

Now, and not before, open `literature.md` §6 and `propositions.md`. Stage 08 said, before any cell
was read, which of the four your structure reaches richly, which thinly, which not at all, and what
it carries that the four have no place for; stage 09's propositions say what the model claims about
the four. Read them beside `crossing.md` and `strain.md`, in `notes-15.md`: where the crossing
agrees with the earlier answer, where it does not, and what the crossing found that neither
anticipated. This is a comparison and it is not a score; stage 18 carries it into the account of
the run. Nothing here changes a ruling, a revision or a profile.

## Your final message

Part A: how many cells were contested and how the splits were distributed; the four verdicts by
count; transmission's four counts, and which of rows 2 and 4 Part B had most to do; the 2×2 of
`hard_to_place` against splitting; whether strain is concentrated in the extension-carrying cells
or spread, with the interval; what fell outside the four, in one sentence; the highest-entropy
theme; the cell the adjudicator was least able to rule on; and where you disagree with a ruling,
as a disagreement. Part B: the revision rate, overall, by problem class and by verdict class; how
many amendments, and how many cells you re-decided by hand; whether any amendment exceeded what
you could re-decide and what you did about it; how the contested cells split between *the brief
failed to transmit* and *the frame does not decide*, and how many of the second you left standing;
how many cells the fleet agreed on and diverged from you, and which way each went; the base rate
of all four problems before and after; what the three passes found and which of it
`brief_edits.jsonl` had already found; the line count of `crossing_final.jsonl` against the cell
count in `scope-13.md`; how many profile lines differ from what `crossing.jsonl` would have given;
where stage 08's fourth pass and the crossing disagree; and the one clause of the brief you are
least confident a stranger reads the way you meant. A return value.

## Close

Run `python3 tools/validate.py 15 . __OUTDIR__`, paste the report into `notes-15.md`, write
`handback-15.md`, and finish `diary-15.md` with its three closing headings.

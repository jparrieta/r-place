# Stage 01 — the reading.

Input: the folder as handed over: `package/`, `package/store/` with `README-store.md`,
`trees/`, `data/`, `tools/` with `HOW-TO-RUN.md`, and `STANDING-INSTRUCTIONS.md`.

Outputs: `__OUTDIR__/notes-01.md`; `__OUTDIR__/contrast.md`; `__OUTDIR__/dropped.jsonl`;
`__OUTDIR__/rooms/<sub>.md`, one per room of the analysed set; `__OUTDIR__/rooms_index.md`;
`__OUTDIR__/lexicon-01.md`; `__OUTDIR__/running-01.md`; `__OUTDIR__/departures.jsonl` and
`__OUTDIR__/defects.jsonl`, opened here, empty or not; `__OUTDIR__/run_manifest.json`.
**No scheme is written in this stage.**

## 1. The tools, once

Read `tools/HOW-TO-RUN.md` and `package/store/README-store.md` whole. Construct `Cases` with this
stage's log, `__OUTDIR__/_aggregator_reads-01.jsonl`, run every call in the contract's block once,
and run `python3 tools/mem.py help` and one call of each verb. A call that fails is a defect in the
package: write it to `defects.jsonl` and say so in your final message. Then run `python3
tools/validate.py --self-test` once and paste its report into `notes-01.md`: it plants a known
defect for every close-check it has, stage by stage, and shows each firing once. A check that does
not fire is a defect in the package, and a stage whose close-check the report does not list has
no close-check, which you will know before you reach it. Run `python3 tools/snap.py 01 start`.

## 2. Check the package before you trust it

Write each result into `notes-01.md`; a failed check is a `defects.jsonl` line.

- **The census.** Lines in `package/case_facts.jsonl`, `package/store/rooms.jsonl`, and the names
  from `cases("cases")` and `cases("codes")`. Reconcile all four.
- **The canvas, present and whole.** `package/case_facts_outcome.jsonl` has one line per room of
  the census carrying the six canvas keys (`canvas_entries`, `canvas_area_px`, `canvas_centre`,
  `canvas_ring`, `canvas_artwork`, `canvas_source`), `rooms.jsonl` carries the same six on every
  room, and `package/pixels.csv` has the columns `package/DATA-manifest-canvas.md` names. Report
  the distribution of `canvas_area_px` and of the share `px_by_window_members / px_in_region_any`,
  the share of each room's own artwork placed by the people who wrote in it; the contract's §4
  says what that share measures. A room in the census with no canvas line is a defect.
- **The two clocks of ending.** `onset_last_code_hour` in `case_facts.jsonl`; `last_item_hour_in_window`
  in `data/MASTER-census.csv`. Report how many rooms have each null and name them.
- **The off-record share.** `off_venue_mention_rate` in `rooms.jsonl`: its distribution over the
  census, and the rooms above one half named; every composition at stage 10 carries it.
- **The nulls.** `onset_first_code_hour` and `items_in_window` null counts, then the rooms whose
  concentration fields (`coded_authors`, `coded_items_attributed`, `top1_share`, `top2_share`,
  `herfindahl`) are null; carry that denominator with any claim resting on concentration.
- **The granularity–size relation, recomputed**: `n_themes` against `items_in_window` and against
  `n_codes`, raw, log and rank, over the census. Report all six; a figure materially different from
  the contract's §4 is a defect line.
- **The codes.** `sum(n_codes)` against `package/code_counts_corrected.json`'s two figures and
  `code_defects.jsonl`'s duplicates; `n_themes` total, rooms with none, rooms with `0 < n_themes
  <= 2`.
- **The store against the package.** `tools/counts.py` first: `n_codes_as_emitted`,
  `n_case_themes`, `n_with_codes` against the collections, exactly. Then the store's own build
  figures in `README-store.md`: recompute the count of codes whose item the record does not hold
  (`package/store/_unjoined.jsonl` against `codes.jsonl` and `items.jsonl`) and the forest header
  totals over `trees/`, and say whether they agree. What you compute wins; carry both to stage 18.
- **`n_analysed` is null until `dropped.jsonl` exists.** Re-run `tools/counts.py` after the screen
  and report `assignment_items_expected` with `assignment_rows_with_placeholders` beside it. If
  you dropped anything the count must fall by exactly what the dropped rooms carried.

## 3. The screen

The contract's §4: a room that wrote nothing about the event is a negative screen on the frame,
not a case at zero; a room that tried and failed is a case. Read the `trace` rooms under it, and
anything `data/validations.jsonl` gives you reason to doubt, account and notebook and forest for
each. Every drop goes to `dropped.jsonl` as `{"sub": "...", "why": "..."}`; if you drop nothing
the file is written empty. From here on the census is two numbers.

## 4. Written before you read

Into `notes-01.md`: **the order** you will read the rooms in and why; **three sentences** on what
you expect the material to show. Into `contrast.md`: the entry-time contrast (§4 of the contract)
on `onset_first_code_hour`, with the rule that defines each side, the named members, the size of
each, and what you expect to differ. Stage 07 puts it to the model's arrows.

## 5. The reading

Read every room of the analysed set whole, in your declared order, through its forest:
`mem.py room --no-canvas`, `mem.py forest`, `mem.py when`, then the codes with their words
(`mem.py codes --sub`, `C.whole(sub, "codes")`), then the case and the notebook, and `mem.py
room` with its six fields last, for the `made` line. **Write the room's note before
you open the next room.** When your context fills, compact at a room boundary and resume from
`_head.md` and `rooms_index.md`; the notes, the lexicon, the running file and your `_` files are
the carrier, and nothing that is not in them survives. No fleet reads for you here: the note is
your prior, and a prosthesis would write someone else's.

**`__OUTDIR__/rooms/<sub>.md`, one fixed form, under 250 words, dated:**

```
# r/<sub>  (read <ISO>)   coded share <item_coded_share>   off-record share <off_venue_mention_rate>   visitors <share>
doing:      what these people were doing, in their words (no quotes; code ids in brackets)
week:       what changed across the 97 hours, by hour
named:      who they named, and what for
unsettled:  what the room could not settle
carrying:   three codes that carry the room (ids only)
not this:   one thing a reader would assume about this room that the record does not show
made:       what was on the canvas at the freeze, from the six fields, and how the room's own
            account of its week squares with it; written last, after the lines above
```

Write `made` last and read the six fields last, after the forest and the codes: the note is what
the room did, and what it kept is read against that, not the other way round (rule 7).

`rooms_index.md`: one line per room, in reading order: the `doing` line, then one clause of your
own on the room, what you make of it, dated; the clause is amended, never deleted, whenever a
later stage has you re-read the room, so that the index carries your judgement of every room and
not only its facts. Rebuilt whenever a note changes. `lexicon-01.md`: the rooms' own words, one per line with the room and the item id of first
use, facts only. `running-01.md`: what you keep seeing, unpruned and unordered, each entry with
the room it came from; fifty to a hundred entries out of the first thirty rooms is the right order
of magnitude.

**The notes are a prior**, as the contract's §2 says.

## 6. `run_manifest.json`

```json
{"stage": "01", "written_utc": "...", "package_sha256": "...", "tools_commit": "...",
 "model": "<id of the model running this stage>", "decoding": {"temperature": 0.0, "top_p": 1.0},
 "seeds": {}, "n_agents": null, "notes": "..."}
```

Written here with the package hash and the tool version. Stages 03, 04, 05, 07 (its one
reviewer), 09, 10, 13, 14 and 15 append an entry with their seed, agent count at `R`, model and
decoding, and stage 18 writes the last line. Stage 18 reports the
whole file; a figure whose manifest cannot name its model has not been reported.

## 7. `notes-01.md`, at the end

The order, the contrast and the three sentences, written first; every check in §2 with its result;
what you read, from the logs and not from memory; **what this material is**, in under 400 words;
three things you expected to find and did not; the one room that fits nothing else; and what the
canvas lines showed against the `doing` lines, in three sentences, without a claim.

## Your final message

How many rooms you read whole and how many notes exist; entries in the lexicon and the running
file; how many you dropped and how many remain; whether every check in §2 passed and which did
not; the contrast you picked; the three things you keep seeing; the single thing that most
surprised you. A return value.

## Close

Run `python3 tools/validate.py 01 . __OUTDIR__`, paste the report into `notes-01.md`, write
`handback-01.md`, finish `diary-01.md` with its three closing headings, and write `_head.md` for
the first time, in the form the standing instructions give. From here on run `validate.py NN .
__OUTDIR__ --open` at the start of every stage, after `_head.md` and the last diary.

# ADDENDUM-15-A7

Operator amendment, and a narrow one. It changes nothing in Part A except §A7, and nothing in
Part B at all. It changes no method, no sample, no figure and no definition. It tells you where to
stop while A7's readers are out.

## Why A7 alone runs in three launches

The readers are cheap and you are not. At stage 14 the readers made 19,000 requests and you made
1,000, and your thousand cost about half the bill, because a launch that stays open while a fleet
runs re-reads its own history on every turn and compacts it when it will not fit.

A7 serves two hundred readings. That is the only part of this stage where you sit and wait on
agents, so it is the only part that is split. Everything else in stage 15 runs as the stage file
says, in whatever launch it falls in.

**You do not need to know which route you are on, and you should not try to work it out.**

## Keep your prose short. Put the reasoning in the files.

Everything you say in this conversation is read again at the start of every later launch of this
stage. What you write into `notes-15.md` is not. Reason in the files; say to the handler the count,
the choice, and the ground for it.

## Launch A7-build: the sample and the packets. Nothing is dispatched.

Everything §A7 asks for up to but not including dispatch: the sample declared in `notes-15.md`
first, one hundred cells, fifty drawn uniformly from the cells in scope and fifty from the
contested cells, by a recorded seed, the two strata kept apart; the agreement definition; the
`run_manifest.json` entry, before the first cell is served.

Then build the packets. Each reader gets `crossing_brief_final.md`, rule 0 as the brief restates
it, and its cells with their codes in the participants' words. Nothing else: not `crossing.jsonl`,
not the adjudication, not a hint that these cells were decided before. Two fresh readers per cell,
each in a clean context, so two hundred readings over one hundred cells.

Keep every packet inside a single `Read` call and end it with an explicit end-of-packet marker,
with an instruction near the top to read as far as that marker before writing anything. A `Read`
returns about 25,000 tokens and truncates without saying so; stage 14 lost twenty reader attempts
to that before the packets were cut small enough.

Write a manifest naming each packet, its cells, its reader, and where its return goes. Write
`_a7-brief.md` saying what the next launch dispatches and where returns land, for someone who was
not here.

**Then stop.** Say how many packets, how many readings, and the seed. Dispatch nothing.

## Launch A7-dispatch: send and collect, and nothing else

Send the packets in the manifest. Collect each return to the path the manifest names. Prod a
reader that stops with work unwritten, up to thirty times, and call it stuck only after five
consecutive prods that produce nothing new. A slow reader is not a failed reader. Record for each
reader that it returned or that it failed, its prods and its wall-clock, in a ledger file and
nowhere else.

**Read no return for meaning.** Do not compare a reading with the settled line, do not build
`recross.jsonl`, do not compute an agreement rate, do not form a view about what the readers
found. Do not touch `reliability-15.md`, `notes-15.md`, the manifest, the diary or any finding.
The completeness check is mechanical and it is all you do with what comes back: the returned line
count against the cells assigned, and whether the return ends on a natural close or mid-object.

A reissue is a dispatch, so reissues belong in this launch. If a failure cannot be decided on those
mechanical grounds, stop and say so rather than guessing.

**Then stop**, when every packet has returned or is recorded as failed with a replacement that
returned. Say how many ran, how many prods, how many were replaced, and roughly what each took.

## Launch A7-check: everything after the readers

`recross.jsonl` with its four outcomes, `reliability-15.md` with both strata reported apart and
never pooled, the unanimous-but-disagreed cells listed one by one, and the sentence saying what the
figure licenses. Then carry on with the rest of the stage.

No agent is dispatched here. If a gap turns up that only a reader can fill, stop and say so rather
than dispatching one: that is a fourth launch, not a repair.

## The rule, for any further launches

**A launch that dispatches does nothing else. A launch that thinks dispatches nothing.** There is
no limit on how many times this stage may be launched before it closes, and a cost to each one, so
do not split where this rule does not require it.

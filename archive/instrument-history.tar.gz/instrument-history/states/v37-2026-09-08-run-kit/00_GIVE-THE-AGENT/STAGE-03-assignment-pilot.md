# Stage 03 — assignment: the pilot.

Input: `__OUTDIR__/scheme.md`, `__OUTDIR__/scheme.jsonl` with `__OUTDIR__/families.jsonl`,
`__OUTDIR__/confusions.md`, `__OUTDIR__/notes-02.md`, the corpus through `tools/cite_case.py`, and the store through
`tools/mem.py` (`theme`, `codes --sub`).

Outputs: `__OUTDIR__/author_items.jsonl`, `__OUTDIR__/gold_items.jsonl`,
`__OUTDIR__/pilot_rounds.jsonl`, `__OUTDIR__/scheme_edits.jsonl`,
`__OUTDIR__/exemplar_candidates.jsonl`, `__OUTDIR__/pilot_report.md`, the **frozen**
`__OUTDIR__/scheme_final.md` and `__OUTDIR__/scheme_final.jsonl`, `__OUTDIR__/notes-03.md`, and an
appended entry in `__OUTDIR__/run_manifest.json`.

**This stage freezes the scheme.** Hand it, with a small set of deliberately hard case themes, to
fresh readers, and treat every divergence as a defect in the description rather than in the
reader.

## 1. The hard set

**Place every item yourself first, before the first round, into `author_items.jsonl`**, each
with your `confidence` (`clear|arguable`), which stage 05's transmission rows split on. Whether a
reader holding only the scheme lands where you would have landed has an answer only if your
answers were written down first; a scheme edited with your own placements in front of you is
edited to justify them.

Three sources, mixed and shuffled so a reader cannot tell them apart. Declare the sizes in
`notes-03.md` before the first round.

1. **Your predicted confusions**, from `confusions.md`: the case themes you nominated to expose
   each ranked pair, at least half of them sibling pairs inside one family, since that is where
   a scheme of hundreds divides readers. The pilot scores that prediction.
2. **The ten biggest bags** from `notes-02.md`.
3. **A random sample**, seeded and recorded.

Forty to sixty items.

## 2. Declared before round 1, in `notes-03.md`

- **The stopping threshold**: the pairwise agreement on the hard set at which rounds stop.
- **The agreement definition**, which stages 04 and 05 reuse unchanged: whether `["S04"]`
  against `["S04","S11"]` is agreement, disagreement or partial, and whether chance correction is
  over themes, over sets, or over presence and absence per theme.
- **The gold policy**: how many gold items exist, the seeding rate, and that they are seeded.
  Never the items.
- **The batch cap** stage 04 will run under (its §2), from what §6 below shows about how long a
  convention takes to form.

**Append this stage's entry to `run_manifest.json`**: the pilot agents' model, seed and decoding
settings, and the rounds run. Every later fidelity is compared against this stage's figure.

## 3. The gold set

**Draw a second hard set by the same rule, with the same seed discipline. Place all of it yourself
and show it to no pilot agent.** Write it to `gold_items.jsonl` with your placements, your
`confidence` and your reasons. It is scored once, after the last round (§7), and stage 04 seeds it unannounced into the
live batches at the rate you declared.

## 4. A round

**Three fresh agents per round**, each in a clean context. Each gets:

- `scheme.jsonl` as it currently stands, served as stage 04 serves it: the index page whole,
  the families opened as the reader needs them;
- rule 0 in the contract's wording, and the return line below; an agent that places a second
  theme owes rule 0 its line in `multiplacement_log.jsonl`, here as at stage 04;
- the hard set's items, each with its label, `theme_note` and codes;
- **no exemplars**. Stage 04 may ship them; this stage measures the description alone.

An agent never sees your room notes (`__OUTDIR__/rooms/`), the running file or `findings.jsonl`.

They return the line stage 04's agents return:

```json
{"sub": "...", "case_theme": "...", "batch": "...", "agent": "...", "replicate": 1,
 "position": 23,
 "second_order": ["S07"], "multi": false,
 "why": {"S07": "what about THIS theme put it here rather than its nearest neighbour"},
 "confidence": "clear|arguable",
 "read": "whole|theme-block",
 "exemplar_read": null,
 "families_opened": ["G03", "G09"],
 "t_start": "...", "t": "...",
 "support": ["c0013"]}
```

Then three numbers, in this order of importance:

- **Fidelity**: agreement with `author_items.jsonl`. The primary figure.
- **Pairwise agreement between the three agents**, secondary: three readers can agree with each
  other and all diverge from you.
- **Your own consistency.** Re-place ten of the hard set, blind, after the last round. If you
  disagree with yourself more than the agents disagree with you, the fleet is not the problem.

**Every item where any two disagree is a finding**, and the raw material for the edit.

```json
{"round": 1, "n_items": 52, "agents": 3, "exemplars": false,
 "fidelity_vs_author": 0.0, "agreement_pairwise": 0.0,
 "items_with_disagreement": ["..."], "seed": 0}
```

## 5. The edit, and every one is logged

Stage 05's taxonomy, so the pilot and the run share one set of names:

- **`scheme-ambiguous`**: the belonging test or the discriminator does not decide. Fix the
  sentence.
- **`item-is-a-bag`**: the coder's case theme holds two practices, so no single placement is
  right. Not a scheme defect; flag the item and move on.
- **`reader-error`**: the file does decide and the reader missed it. Suspect this last: two
  independent readers making the same miss is a scheme defect that looks like a reader error.
- **`author-error`**: you were wrong and the agents were right. A pilot that never returns it is
  a pilot measuring obedience.
- **`genuine-joint`**: the material satisfies two gates and one placement cannot carry it, which
  is rule 0's exception on the record. Check that the agents actually differed rather than one
  recording the exception.

```json
{"round": 1, "theme": "S07", "field": "must_not_show",
 "caused_by": ["sub/case_theme", "..."], "was": "...", "now": "...",
 "why": "two of three readers placed a coordination-of-labour item here because the test said
         nothing about who was named"}
```

**An edit with no `caused_by` is not allowed.** Stage 06 opens `scheme_edits.jsonl` before it
revises anything.

## 6. Two things this stage owes the fleet

**How long a convention takes to form.** Compare each pilot agent's first ten items against its
last ten, on the arguable rate and on agreement with the other two, and report where the curve
flattens. If either improves inside a round, formation is still happening and stage 04's cap is
too small; the fix is a non-counting warm-up block, not a bigger batch.

**Which items make good exemplars.** Export the items that divided readers to
`exemplar_candidates.jsonl`; stage 04's exemplar arm draws from them, not from clear cases.

## 7. Stopping, the freeze, and the gold score

Run rounds until one of: a round produces **no scheme edit**; pairwise agreement on the hard set
clears **the threshold you declared**; or **four rounds**. After four rounds, a scheme that still
divides three readers is telling you about the tier rather than the wording: report it and carry
it into stage 04.

**Never tighten by narrowing until a theme becomes rare.** It looks like success here and makes
that theme's prevalence wrong everywhere after. Watch the base rate of every theme across rounds
and report it.

Then freeze the scheme as `scheme_final.md` and `scheme_final.jsonl`, the rare-but-sharp tier
inside it under `"tier": "rare"` and `families.jsonl` beside it, and run one round of fresh
agents on the gold set against it. Report:

- **gold fidelity beside the last pilot round's fidelity**: close means the scheme got clearer,
  much worse means it got fitted;
- pairwise agreement on the gold set beside pairwise agreement on the final pilot round;
- per-family agreement, and per theme only where a theme has three or more items in the set: at
  hundreds of themes over sixty items a per-theme figure is one item wide;
- **your `confusions.md` predictions scored**: which pairs confused readers, in what order, and
  how the observed rate compared with your estimate.

Gold fidelity is a trend against this stage's frozen figure, not a level: the set was drawn hard,
and the figure is agreement with your own placements. Wherever a figure from this stage appears,
say what it licenses in the contract's §7 words, and which claim you are making: *what you would
have produced at a scale one analyst cannot reach* is supported; *what any competent reader would
have produced* is not.

## 8. `pilot_report.md`

- The rounds, with agreement climbing or not.
- Every edit, grouped by theme, with the disagreement that caused it.
- The gold number beside the last pilot number, and what the gap means.
- **The `author-error` verdicts, listed.**
- **The themes that never stabilised**, named, with what stage 05 should expect from them.
- The prediction scorecard.
- What this cost: agents, items, tokens.

## Your final message

Rounds run; fidelity at round 1 and at the end; the gold figure, with pairwise agreement beside
it; how many `author-error` verdicts; your own blind re-placement score; how many edits, and to
which fields; which predicted confusions were real; which themes did not stabilise; whether any
theme's base rate fell while you were tightening it; and the one sentence in the scheme you are
least confident a stranger will read the way you meant it. A return value.

## Close

Run `python3 tools/validate.py 03 . __OUTDIR__`, paste the report into `notes-03.md`, and write
`handback-03.md` and finish `diary-03.md` with its three closing headings.

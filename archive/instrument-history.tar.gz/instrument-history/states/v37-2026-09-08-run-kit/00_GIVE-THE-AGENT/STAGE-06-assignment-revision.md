# Stage 06 — assignment: revision.

Input: the frozen `__OUTDIR__/scheme_final.md` and `__OUTDIR__/scheme_final.jsonl`;
`__OUTDIR__/assign_final.jsonl`, `__OUTDIR__/disagreements.jsonl`,
`__OUTDIR__/coder_conflicts.jsonl` and `__OUTDIR__/transmission-05.md` from stage 05;
`__OUTDIR__/assign_pass2.jsonl`, `__OUTDIR__/multiplacement_log.jsonl` and
`__OUTDIR__/multiplacement_register-04.md` from stage 04; `__OUTDIR__/scheme_edits.jsonl` from
stage 03; `__OUTDIR__/reassign.jsonl` and `__OUTDIR__/reliability-05.md` from stage 05's blind check;
`__OUTDIR__/confusions.md`, stage 02's prediction of its own failure modes; `tools/counts.py` for
the analysed set; the corpus through `tools/cite_case.py`; and the store through `tools/mem.py`
(`theme`, `where`, `codes --theme`).

Outputs: `__OUTDIR__/scheme_v2.md`, `__OUTDIR__/scheme_v2.jsonl`,
`__OUTDIR__/assignments_final.jsonl`, `__OUTDIR__/assignments_final.count.txt`,
`__OUTDIR__/assign_revisions_only.jsonl`, `__OUTDIR__/form_pass-06.md`, `__OUTDIR__/notes-06.md`,
and an appended entry in `__OUTDIR__/tier_history.jsonl` for every change to the second-order tier.

**Read the pair table first** (rule 0): every recurring `(primary, additional)` pair in
`multiplacement_register-04.md`, computed from `multiplacement_log.jsonl`, is a boundary the scheme
has not drawn, and a theme that appears as `additional` far more often than as `primary` is a
modifier to consider folding.

**Then five sources say where the scheme is weak**, and a theme appearing in three of them is not
one to defend: `disagreements.jsonl`, `assign_pass2.jsonl` (an agent revised its own early work),
`reassign.jsonl` (a fresh reader disagreed with the adjudicated line), `coder_conflicts.jsonl`, and
`transmission-05.md`'s fourth row, where the fleet agreed with each other and not with you: the
rarest and the most serious, and the twin of stage 15 B2's third source. `scheme_edits.jsonl`
from stage 03 is read beside them: a boundary that moved at 03 and split the fleet again is a
boundary the wording cannot draw, and it is a candidate for the rare-but-sharp tier or a merge
rather than for a third sentence.

## 1. Transmission's three rows, and which one is yours to revise away

None of this is strain; that word is the crossing's. `transmission-05.md` decomposes the splits
against your own answers on the gold and pilot items. *Split, and you were confident*: the scheme
failed to transmit; **revise**. *Split, and you were also unsure*: the tier does not decide this
item; **leave it**, and an amendment that lowers that count with no wording defect you can quote is
fitting. *Agreed with each other, diverged from you*: read every one. Either you were wrong, in
which case record it and **do not amend the scheme toward your own answer**, or the scheme taught
something you did not intend and the wording is yours to fix. Say in `notes-06.md` which way each
went.

**`reliability-05.md` is stage 05's file. Read it; do not rewrite or re-emit it.** Its figures
are per family; the per-theme figure you rank themes by is stage 04's agreement, computed over
every item (`notes-04.md`, §12 there), and a theme the fleet split on everywhere is weak whatever
the blind check says of its family. If the revision changes the scheme enough that stage 05's
figure no longer describes it, say so in `notes-06.md` and say which figure the write-up should
use.

## 2. The revision rate

**Re-decide two hundred assignments yourself**, drawn by seed from `assign_final.jsonl`, now
that the whole corpus has been through the scheme and you have read every disagreement, and
report how many you would move and where. That number is **scheme stability**: your agreement
with the settled line at the end of the assignment arc, a figure about the tier as it stands; it
is not saturation, since a census has no next case to add, and it is not reliability, which is
stage 05's. For something closer to saturation, record when each *kind* of unassignable material
first appeared and say whether new kinds stopped appearing.

## 3. Agreement, and what may change

Wherever you cite stage 05's figures, say what each licenses in the contract's §7 words: they
bound whether the written descriptions decide, not whether they are right.

Treat every disagreement as a defect in a *description*, not a dispute about a case: readers who
sent the same kind of material to different places found an underspecified boundary.

**You may also change the scheme itself**: add a theme, split one, merge two, retire one, or move
one to the **rare-but-sharp tier** (`"tier": "rare"` on its line; the event `moved_to_rare`),
the home stage 02's floor defines for a pattern the corpus plainly carries below that floor. Use
stage 02's floor; do not invent one here. Declare each change with its reason, **append the event
to `tier_history.jsonl`**, and re-place every case theme
it touches by applying the amended rule, **yourself, not the fleet**, under rule 11 with its
stopping criterion declared before the first recut. Log every moved item: which case theme, out of
which theme, into which, and the clause of the amended gate that decides it. **A theme that
arrives here declares its gate here**, in the form stage 02 uses, before any count appears
anywhere (rule 5).

## 4. Joints and lumps: the pair test

For **every pair of second-order themes carried by ten or more case themes**, report the pair's
**arguable rate**, the share of the case themes carrying both that were marked `arguable`, **with
its confidence distribution**, against the corpus-wide arguable rate.

A **joint** is an act the material genuinely presents twice over, which any scheme cuts in two. A
**lump** is your scheme cutting where the material has no seam. In a rate the two look identical;
**they are told apart by the confidence recorded alongside the decision**: a joint is a pair you
multi-assign confidently, a lump one you multi-assign while unsure. For every pair materially
above the corpus arguable rate, **say which of the two you think it is and why**, and decide the
boundary: split, merge, or keep it and say why, under rule 10's arithmetic.

## 5. The empties, and the arguables

Read every `second_order: []` line and every `confidence: "arguable"` line.

**The empties:** group them into kinds and say, for each kind, whether the scheme is too narrow or
the material too varied. If more than one in five of the corpus is empty, that is a finding about
the scheme and goes at the top of `notes-06.md`.

**The arguables:** check them against **stage 02's written prediction** of which two themes would
be confused.

## 6. The form pass

Forms (turn position, register, length, timing, who answers whom) are scattered under the coders'
topic groupings, so **go over the first-order codes directly, on participants' quoted words, not
through case themes**. **Use `count()`, not `find()`**: `C.count(pattern, collection="codes")`
returns `{total, documents_matched, documents_scanned, by_document}` over the whole collection,
with no limit and one log record. Say in `form_pass-06.md` which patterns you counted, and run the
pass **three times over**, saying what you swept for each time:

1. **Form**: turn shape, position in a sequence, length, timing. What is the cheapest act in this
   corpus, and how would you know?
2. **Register**: any vocabulary that cuts across subjects. A register that appears widely and is
   owned by no theme is a tier, not a residue.
3. **What is not said**: terms used without gloss, roles invoked without introduction, questions
   nobody answered. What a room does not bother to explain is what it takes for granted.

**Write `form_pass-06.md`**: what you searched, at what limits, what you found, and how many
communities and how many lines each finding covers. **Then name what the pass could not reach**: a
search over quoted words finds vocabulary, while a register or a stance is a property of a whole
utterance and invisible to string matching, and no route through case themes reaches an act whose
themes name what it was *about* rather than what it *was*. Write both in `notes-06.md`, which
stage 18's *what the study cannot say* inherits.

**What you find is a tier of its own, with ids `F01…Fnn`, living in `form_pass-06.md` prose and
nowhere else**: no `F` schema, no `F` line in any JSONL. Write each `F` with its id, its one-line
statement, and the communities and lines it covers, in a block a later stage can quote whole.
**Stage 07 reads them from that file, by id**, and they enter the structure and the model on the
same terms as any second-order theme, marked as ones whose unit is the turn rather than the topic.

**An `F` does not enter the arithmetic**, and `form_pass-06.md` says so: it produces no line in
`assignments_final.jsonl`, has no three counts, enters no cluster feature at stage 11 or 16 and no
over- or under-representation contrast at stage 12 or 17. It travels on exemplars under rule 5's
carve-out, and the write-up says in your own sentence that an `F` in the model was never counted
and never clustered. **Do not invent a gate to make an `F` look promotable**; rule 5 forbids it.

## 7. `scheme_v2` and `assignments_final.jsonl`

**`scheme_v2.jsonl` mirrors `scheme_final.jsonl` field for field.** After this stage the frozen
instrument is `scheme_v2`: it is the scheme every later stage keys its theme ids to, and what the
validator resolves them against. **`scheme_v2.md` is the whole scheme, not a diff**:
every theme, including the untouched ones, with every field, plus the complete gate block including
gates declared here, and each change declared with what changed, why, and which assignments it
moves.

**`assignments_final.jsonl` is every assignment line, not only the ones you changed.** An overlay
under the name every later stage lists as *the* assignment input is indistinguishable from a
complete file, and a stage that reads it literally clusters on whatever fraction of the corpus it
covers and never finds out. Unchanged lines carried through verbatim, changed lines superseding,
same schema as stage 04, last write wins on `(sub, case_theme)`. Nothing is deleted; the history is
the record. Keep the overlay as `assign_revisions_only.jsonl`; stage 18 reports it, as it reports
`crossing_revisions_only.jsonl`.

**The line count goes in `assignments_final.count.txt`, not at the top of the JSONL**, which
stages 07 and 11 parse line by line. It must equal the number of distinct `(sub, case_theme)` keys
in `assign_final.jsonl`, one line per case theme in the analysed set, **not** the number of lines
the fleet returned, which is that number times `R`. Take the expected value from
`tools/counts.py`'s `assignment_items_expected`.

## Your final message

The recurring pairs from the pair table and what each became; the revision rate; **stage 05's
reliability figures as you read them, with their definition**, not recomputed; which pairs came out above
the corpus arguable rate and which of those you called joints and which lumps; how many empties and
of how many kinds; whether stage 02's prediction of its own failure modes held; how many case
themes the amendments moved; the line count of `assignments_final.jsonl` against what
`tools/counts.py` expects; what the three passes found; and **the `F` ids you minted, with the
statement that stage 07 takes them from `form_pass-06.md`**, the only place they exist. A return
value.

## Close

Run `python3 tools/validate.py 06 . __OUTDIR__`, paste the report into `notes-06.md`, and write
`handback-06.md` and finish `diary-06.md` with its three closing headings.

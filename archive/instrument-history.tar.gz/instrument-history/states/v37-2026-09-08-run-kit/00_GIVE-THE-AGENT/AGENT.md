# This run

You are the analyst. Your contract is `CONTRACT-aggregator.md`, in this folder. Read it once,
whole, and `STANDING-INSTRUCTIONS.md` with it. Then the stage file you were told to read.

## What is here

    CONTRACT-aggregator.md      the contract
    STANDING-INSTRUCTIONS.md    the rules that hold at every stage
    STAGE-NN-*.md               the stages handed to you so far, in order; you may re-read them
    package/  trees/  data/     the evidence and the store. Read-only. The canvas is in
                                package/ from the start (rule 7 says what it may and may not do)
    cases/ codes/ notebooks/    the coders' work, 300 each. Read-only.
    tools/                      cite_case.py, mem.py, validate.py, snap.py, packets.py,
                                counts.py, check_chronology.py; tools/HOW-TO-RUN.md says how, and carries
                                the budget, the ceilings and the models the operator declared
    out/                        yours. Everything you produce goes here, including your own
                                working files under names starting with `_`; `_head.md` and
                                `diary-NN.md` are yours too, and `_transcripts/` is the
                                operator's

There is nothing outside this directory.

## State

Stages completed: the stage files in this folder, and the corresponding files in `out/`. At the
start of every stage read `out/_head.md`, the last `out/diary-NN.md`, `out/rooms_index.md` and
`out/findings.jsonl` (at 13, 14 and 15 only the first two), then the stage file, then run
`validate.py NN . out/ --open`. `out/departures.jsonl` is append-only. You have not seen any
later stage and must not guess it.

## This session

The stage you were told to read, and then stop. Do not begin the next one, and do not summarise
what you would do in it. When a stage says the next one continues in this session, wait for the
next stage file to be handed to you before you begin it.

# ADDENDUM-11

Read this before `STAGE-11-clustering-the-third-order-dendrogram.md`. Three things about the two
tables that ship with this stage, and one about the file you read first.

## 1. Forty-nine rooms have a zero that means absent, not small

`pre_vector.csv` covers all 300 analysed rooms, so nothing fails to join. But 49 of the 300 carry
`founded_during_event = 1`, and 49 carry `distinct_posters_week_before = 0`. Check whether those
are the same 49 and say so in `notes-11.md` with the count.

For a room founded during the event, zero posters the week before is not a measurement of its
size. It is the absence of a measurement. The volume check asks whether your partition is a size
partition; if these rooms enter that check as the smallest rooms in the corpus, it will report a
size effect that is really a founded-during-the-event effect, and a sixth of the sample is enough
to move a cut.

Decide before you compute, and write the rule in `notes-11.md`: either the volume check runs on
the rooms that existed before the window and reports the 49 apart, or it runs on all 300 with the
49 flagged and the verdict stated twice, once each way. Do not let a structural zero pass as a
small number. The same applies anywhere `distinct_posters_week_before` enters as a feature or a
covariate.

## 2. The network is sparse here and absent for those same rooms

`pre_network.csv` is dense over the 763 communities it was built from, but within your 300 it
holds 1,500 pairs of a possible 44,850, a density of 0.033. The 49 event-founded rooms have no
pre-event ties at all, by construction rather than by finding. A network feature over this table
is therefore mostly zeros, and its zeros mean two different things: no shared posters, and no
room yet. Say which you are treating as which.

## 3. `n_shared_posters` is a raw count and tracks size

Two large rooms share more posters than two small ones for no reason but their size. Used
unnormalised as a similarity, it will recover a size partition, which is exactly what the volume
check exists to detect, and the check cannot catch a confound its own features built in. If you
use this table for anything but a projection, normalise it (Jaccard on the poster sets, or
conditioned on room size) and state the choice and why in `notes-11.md`. If you use the raw counts
anyway, say that you did and what it costs.

The manifest's own warning stands beside this one: shared posters are not the mention record, and
the two are never pooled.

## 4. `objections.jsonl`

Rule 13 has you answer the operator's objections to stage 10's compositions before anything here
is computed. If the file is empty or absent, that means no objection was raised, not that the
compositions went unchecked in some other way. Record which it was in `notes-11.md` in one line
and carry on.

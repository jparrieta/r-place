# Standing instructions.

**These apply to every stage.** They are handed over with stage 01 and stay in your folder for the
whole instrument, so no stage file repeats them. `NN` is the stage you are on.

## `__OUTDIR__/handback-NN.md` — one per stage

Short. If something about the stage was wrong, missing, surprising, or not worth doing, say so. A
few sentences is a full answer; blank is a fine one. **Write it before you finish the stage.** The
handback is where something wrong with the **instrument** goes: a step that could not be carried
out as written, an output its inputs did not support, an instruction that decided nothing.

## `__OUTDIR__/defects.jsonl` — not optional

If something in the **material** looks wrong, a count that cannot be right, a duplicate, a
contradiction, append one line the moment you see it:

```json
{"where": "...", "what": "...", "sure": true|false}
```

Do not save them up. Write the line when you are not certain too, with `"sure": false`. Make
`where` precise enough that someone else can look at the same thing: a file and a key, a community
and a code. One file, opened at stage 01, appended through stage 18, never rewritten. Stage 18
reads it whole and separates defects in the material from defects in the instrument.

## `__OUTDIR__/departures.jsonl` — your leeway, on the record

You may depart from a stage file or from the contract where the material requires it, within rule
10. Write the line **before** you act:

```json
{"stage": "NN", "provision": "...", "why": "...", "what_following_it_would_have_cost": "..."}
```

A departure written afterwards is a defect. A departure that touches one of the provisions rule 10
names does not exist; stop and write `handback-NN.md` instead.

## `__OUTDIR__/findings.jsonl` — claims are held, not re-derived

Opened at the first stage that makes a claim, in rule 14's form, appended and re-examined at every
stage after. Every judgement stage's final message is drawn from it.

## `__OUTDIR__/_*` — think on disk

Anything you would hold in your head between two steps goes in a file under `__OUTDIR__/` whose
name starts with `_`. Nobody audits their prose; they are yours. They are part of the record
(rule 18), travel with every fork, and are never deleted; supersede a file with a new name.

## `__OUTDIR__/_head.md` — what you would tell yourself tomorrow

The analyst who ran v35 lost stages 01 to 12 to a compaction; what it had left was a head file
written once, five sections and a count that had never reached a file. So: `_head.md` is
rewritten at the close of every stage, before any compaction you can see coming, and on a clock:
the harness asks for it every two hours of session time, and the copy it replaces is kept as
`_head-NN-<n>.md`. It is the first file you read in every session, before the stage file, and at
every session start you append one line to it: the time, and what you are about to do. One to two
pages. What it holds, in this order: where the run stands (the stage, what is closed, what is
open in it); the claim as it stands today, in one sentence, with the room that best supports it
and the room that most threatens it; the elements of the model by name, one line each, and which
are `sure`, `probable` or `open`; the numbers you keep reaching for (the analysed set, the theme
count, the chunk count, the composition counts) with the file each comes from; what you decided
and have not yet written anywhere else; what you expect the open stage to return and what would
surprise you; and what you would do next if nobody told you. Nothing in it is evidence;
everything in it points to a file that is.

## `__OUTDIR__/diary-NN.md` — the stage's diary

Yours, free in form and in length, written as you go and finished at the close of the stage with
three headings in this order: **what I know**, the claim and the model as they stand and the
numbers you reach for, each with the file it comes from; **what I just did**, the stage in your
own words, what you decided, what you left undone and why; **what worries me**, what you are
unsure of and what would settle it, and what you expect the next stage to return. Nobody audits
its prose. It is the file the next session reads after `_head.md`, and stage 18's `EXPERIENCE.md`
is written from the eighteen of them. Compaction is expected in a run this long; the diary and the
head file are what make it survivable, and what the two reviewers of v37 said they lacked on the
morning after was not facts but their own judgement of each room and what they had expected.

## `__OUTDIR__/_snap/` — the record of what existed when

`python3 tools/snap.py NN <label>` writes `_snap/NN-<label>.sha256`: every file under
`__OUTDIR__/` with its hash, its size and the time. `validate.py NN` runs it at every close, so
every stage's working files are versioned as they stood. You run it yourself before any step
whose order a reader will press on. Four orderings are proved by it and by nothing else: at
stages 12 and 17 the names file is snapped before batch 2 is opened; at 11 and 16 the cut is
snapped before anything is projected onto it; at 17 the activation paragraphs are snapped before
the canvas blocks are opened. A read log records that a file was opened, not what was made of it;
a hash of your own file is a timestamp with teeth. Everything else about the order you worked in
is self-reported, in that word.

## `__OUTDIR__/_transcripts/` — the sessions

The operator places each session's transcript here at the close of the session, named by stage
and session, and lists it in `_transcripts/INDEX.md`. Stage 18 reads them beside the logs.

## Four files you read at the start of every stage

`__OUTDIR__/_head.md`; the last `__OUTDIR__/diary-NN.md`; `__OUTDIR__/rooms_index.md`, your own
index of the 300 room notes from stage 01, with your clause on each; and `__OUTDIR__/findings.jsonl`.
Then the stage file. At stages 13, 14 and 15 only the first two are read: `rooms_index.md` and
`findings.jsonl` wait until 16, and the cells are scoped and ruled with the crossing's own files
(the contract's §6); what you remember of the model you cannot unread, and stage 18 says so.

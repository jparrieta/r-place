# Stage 18 — the experience.

Input: everything in `__OUTDIR__/`, and in particular: `__OUTDIR__/theme_discovery.jsonl`,
`__OUTDIR__/tier_history.jsonl`, `__OUTDIR__/chunks_log.jsonl`, `__OUTDIR__/dimensions_log.jsonl`,
`__OUTDIR__/saturation.jsonl`, every `__OUTDIR__/story-pN.md` with its `story_rooms-pN.jsonl`;
`__OUTDIR__/model.md`, `__OUTDIR__/edges.jsonl`, `__OUTDIR__/structure.md`, `__OUTDIR__/figure.md`,
`__OUTDIR__/propositions.md`, `__OUTDIR__/data_structure.md` and `__OUTDIR__/data_structure-09.md`,
the working display and the one a reader gets, with `__OUTDIR__/v2_manifest.txt` saying which of
`__OUTDIR__/model.v2.md`, `__OUTDIR__/edges.v2.jsonl`, `__OUTDIR__/structure.v2.md` and
`__OUTDIR__/concept.v2.md` stage 08 wrote; `__OUTDIR__/edges_dimension.jsonl`; `__OUTDIR__/account.md`, `__OUTDIR__/account_passes.jsonl`,
`__OUTDIR__/author_claims.jsonl`, `__OUTDIR__/reader_round.jsonl` and `__OUTDIR__/reader_round.md`,
`__OUTDIR__/within_case.md` and `__OUTDIR__/gioia_table.md`; `__OUTDIR__/scheme_final.md`, the
frozen scheme, with `__OUTDIR__/scheme_v2.md` and `__OUTDIR__/scheme_v2.jsonl`, the scheme the
assignments were placed under and the one the theme ids check against;
`__OUTDIR__/pilot_report.md`, `__OUTDIR__/pilot_rounds.jsonl`, `__OUTDIR__/adjudication_report.md`,
`__OUTDIR__/reliability-05.md`, `__OUTDIR__/form_pass-06.md`, `__OUTDIR__/assignments_final.jsonl`,
`__OUTDIR__/assignments_final.count.txt`, `__OUTDIR__/assign_revisions_only.jsonl` and
`__OUTDIR__/coder_conflicts.jsonl`; `__OUTDIR__/composition.jsonl`, `__OUTDIR__/transmission-10.md`
and `__OUTDIR__/uncomposed-10.md`; `__OUTDIR__/clusters_members-11.jsonl` and stage 11's
computation trail under the same suffix, with `__OUTDIR__/tier_robustness-11.md`;
`__OUTDIR__/cluster_names-12.md`, `__OUTDIR__/clusters-12.md` and `__OUTDIR__/clusters-12.jsonl`;
`__OUTDIR__/crossing_pilot_report.md`, `__OUTDIR__/crossing_pilot_rounds.jsonl`,
`__OUTDIR__/crossing.jsonl`, `__OUTDIR__/crossing.md`, `__OUTDIR__/strain.md`,
`__OUTDIR__/transmission-15.md`, `__OUTDIR__/recross.jsonl`, `__OUTDIR__/reliability-15.md`,
`__OUTDIR__/crossing_brief_v2.md`, the brief every count from
stage 15 on is described under, `__OUTDIR__/brief_review-15.md`, `__OUTDIR__/crossing_final.jsonl`,
`__OUTDIR__/crossing_final.count.txt`, `__OUTDIR__/crossing_revisions_only.jsonl` and
`__OUTDIR__/community_profile.jsonl`; stage 16's computation trail, `__OUTDIR__/cluster-16.py`,
`__OUTDIR__/profiles-16.csv`, `__OUTDIR__/distance-16.csv`, `__OUTDIR__/dendrogram-16.json`,
`__OUTDIR__/clusters-16.jsonl`, `__OUTDIR__/clusters_members-16.jsonl` and
`__OUTDIR__/cluster_report-16.md`; `__OUTDIR__/problem_cluster_names-17.md`,
`__OUTDIR__/problem_clusters-17.md`, `__OUTDIR__/clusters-17.jsonl`, `__OUTDIR__/comparison-17.md`
and `__OUTDIR__/comparison-17.jsonl`; `__OUTDIR__/literature.md`; `__OUTDIR__/objections.jsonl`;
`__OUTDIR__/dropped.jsonl`; `__OUTDIR__/run_manifest.json`, every `__OUTDIR__/batches-NN.jsonl` and
`__OUTDIR__/agent_report-NN.md`, every `__OUTDIR__/notes-NN.md` and `__OUTDIR__/handback-NN.md`,
`__OUTDIR__/departures.jsonl` and `__OUTDIR__/defects.jsonl`, `__OUTDIR__/findings.jsonl`, every
`__OUTDIR__/_aggregator_reads-NN.jsonl` and `__OUTDIR__/_mem_reads-NN.jsonl`, and every
`__OUTDIR__/_head*.md` in order, every `__OUTDIR__/diary-NN.md`, `__OUTDIR__/review-07.md`,
and `__OUTDIR__/_snap/` whole; `data/MASTER-census.csv`; `package/sealed.jsonl`;
`package/case_facts_outcome.jsonl` and `package/pixels.csv`; `fork_comparison-07.json` and
`fork_comparison-10.json`, which arrive with this stage wherever the run was forked and are absent
where it was not; and the session transcripts in `__OUTDIR__/_transcripts/`.

Outputs: `__OUTDIR__/audit.md`; `__OUTDIR__/EXPERIENCE.md`; the last line of `run_manifest.json`;
`__OUTDIR__/notes-18.md`; `__OUTDIR__/handback-18.md`.

Two jobs: the account of the run that only the logs can give, and the account of the run that only
you can give. The first is written first, from the files and not from memory, so that the second
is written against it.

## 1. `audit.md`, the run's own account of itself

Take all of it from the logs and the stage outputs, **not from anyone's account of themselves**,
your own included. What you compute wins over what any earlier file says; where they differ, say
so and say which is wrong.

**The timeline's reliability, here and only here.** **Run `tools/check_chronology.py` and report
what it returns**: agreement between the coder's clock and `created_utc` on entries quoting exactly
one item id and carrying a clock, with its denominator, and its second check against each case
file's `Relations` section; its docstring says what each bounds. **`monotone_in_written_order` is
a separate figure**, a flag on each community's `events()` report: count the communities where it
is false, and report **how many of the model's arrows rest on one of them**, since stage 07 admits
a loop into `model.md` only on a community whose report is monotone.

**The census, stated twice.** Communities analysed, and communities the frame named that turned
out not to be cases, from `dropped.jsonl`, with the reason for each.

**Coverage.** Codes files read whole, **by stage as well as in total**, from
`_aggregator_reads-01.jsonl` through `-17`, with three qualifications:

- **No double-log correction.** `cite()` writes one record per read, so subtracting a `whole`
  followed by a `cite` undercounts. Count `whole` records directly.
- **A stage that computes and reads nothing has no log.** Stages 11 and 16 are; say that, rather
  than reporting the gap in the sequence as missing evidence.
- **Say what the table does not cover.** Fleet agents at stages 03, 04, 05, 13 and 14 receive
  assembled packets, never call `tools/cite_case.py`, and leave no read log; their reading is in
  `batches-NN.jsonl` and `agent_report-NN.md`. The composers at 10, the reviewer at 07, the
  readers at 09 and the adjudicator at 15 call it under their own logs, one per agent id,
  reported separately. Report the two separately and say which stages are in
  which. **And say what a per-stage log attributes**: which log was open, not which stage the
  reading served; a form-pass read can sit in the stage-03 window and belong to stage 06.

**The stories.** From `saturation.jsonl` and every `story_rooms-pN.jsonl`: how many passes the
loop ran, how many rooms were read against a story in all and how many distinct rooms, and per
pass the three counts; then, from `composition.jsonl`, how the rooms the last story could not tell
fared at stage 10, and how many rooms that no story was read against did not compose. That last
number is the measure of what the reading behind the stories bought.

**`thread()` opens**, separately: how many, at which stages, what share of your assignments they
covered.

**The `read` distribution across `assignments_final.jsonl`**: `whole` and `theme-block`, the only
values stage 04 permits; any other value is a defect.

**The run manifest, whole.** `run_manifest.json` says which model, seed and decoding settings
produced every agreement, fidelity and reliability figure in this study; a figure whose manifest
entry is missing is a figure without provenance.

**The figures, restated where a reader will find them**, each with its definition and what it
licenses in the contract's §7 words: fidelity and agreement at 04 and 14, gold fidelity at both,
reliability at 05 in its two strata, transmission at 05, 10 and 15, and strain at 15. Agents in
fresh contexts holding only the frozen scheme and the material are instances of one model and not
two minds. Do not call any of them *intra-rater*.

**The four orderings, from the snaps.** `cluster_names-12.md` and `problem_cluster_names-17.md`
each carry a snap line (`_snap/12-names.sha256`, `_snap/17-names.sha256`) whose hash of the file
and whose time precede the first read of the model files and the computed cluster files; stage
17's activation paragraphs carry `_snap/17-activation.sha256` against the canvas blocks; and the
cuts at 11 and 16 carry `_snap/11-cut.sha256` and `_snap/16-cut.sha256` against the projections.
Verify each: the hash in the snap equals the hash of the file as it stands, or the file moved
after the snap, which is reported. State separately what the corpus log line establishes: how
much reading had been done by then. Every other claim about the order the analyst worked in is
*self-reported*, in that word.

**The three ledgers, complete and not summarised.** `findings.jsonl`, lines by status (standing,
bounded, withdrawn) with the stage at which each status changed, and the distribution of
`confidence` where it was written; `theme_discovery.jsonl` and `tier_history.jsonl`: do not plot
either and do not compute over them. State how many lines each holds, that they are complete, and
that no line was edited after writing. Beside them, **the count of recuts by tier and by stage**
from `tier_history.jsonl`, and the line counts of `chunks_log.jsonl` and `dimensions_log.jsonl`:
how many times each tier file was rewritten, and at which stages, and whether any recut is an
amendment after stage 09 (rule 11).

**What a reader was given, and whether it is enough to disagree with you.** Five things, each
present or absent, and absent is a defect:

- **`gioia_table.md`**: does the leftmost column hold material rather than a label you wrote, and
  can a reader walk one row from something somebody typed to a dimension without opening another
  file?
- **The third-order chunks explained** in `structure.md`: each with its account, its question, what
  falls outside, and quotes carrying community, author, timestamp, code id and `position`, and the
  stated reason why the set expresses the chunk. There is no quota; the defect is a set with no
  stated shape, or five quotes making the same point.
- **The residue explained**, not listed: how many second-order themes no chunk took, what share of
  the code mass, what kind of thing they were, two or three quotes, and whether any should have
  been a chunk. Read it beside the crossing's coverage and beside what fell outside the four.
- **The account at one to two pages**, and whether it describes the range or the mode. Name the
  communities `account.md` could not reach and check them against both clusterings: one it could
  not reach and stage 12 or 17 found a cluster for is a finding about the account.
- **Every quote in the write-up dated and attributed.** Spot-check five against the log.

**The departures**, from `departures.jsonl`, each with what following the provision would have
cost. **The objections**, from `objections.jsonl`, each with its answer and what changed.

**The standing departures of this design**, reported alongside:

- five tiers rather than three;
- **the second-order tier cut before any theorizing**, against Gioia, Corley and Hamilton's
  instruction to think at both levels at once: the chunks wait for stage 07 so that the story
  cannot compress the kinds; report how many themes stage 02 made, how many stage 06 kept, and
  how many the loop merged or split after that;
- literature after the model rather than through it, and the initial consultation deleted rather
  than deferred;
- a scheme frozen at stage 03;
- **the inductive corpus is a size stratum, not a sample**: the 300 smallest communities in the
  population, none above 501 items in the window, two per cent of the population's window text,
  every substantial room in the event outside it. Say it in those terms, with the ceiling named;
- **the frame is text and most of the work left none** (the contract's §4). The share of a room's
  own artwork placed by people who wrote in it is `px_by_window_members` against
  `px_in_region_any` in `pixels.csv`. Report its distribution, from stage 01, and what it does to
  that limitation;
- **the canvas was held from the start** (rule 7). Say what it was used for, stage by stage, from
  the logs and the files: read at 01, projected on at 11 and 16, read in the portraits at 12 and
  17, and nowhere a feature, a ground for a cut or a placement, or a proposition's evidence. Where
  a file shows otherwise, that is a defect in the run and it is named. Then say what the paper can
  and cannot claim because of it: the model was built with the outcome in view and explains it; it
  was not built without it and scored against it. And name the places where the prior rule 7
  cannot exclude could have bitten, so a reader can look: any spine or element arguable only
  against what the rooms kept, any cluster whose name says what its rooms made, any cut chosen
  with the tree in view (the snap lines at 11 and 16 say whether the cut preceded the projection).
  The rule says it cannot see this; the audit says where to look;
- **one analyst above the assignment tier**: the scheme, the structure, the concept, the model and
  the crossing's scope are one reader's work; what saw it: the reviewer at 07, the readers at
  09, the operator's readings at 10 and 12, and the forks; the room notes are the one input nothing checks; below
  that tier the many readers are instances of one model;
- **no human check**: not one case theme and not one cell was classified by a person against this
  scheme, so every agreement, transmission, strain and reliability number rests on machine readers
  alone;
- **no theoretical sampling of cases**: these were handed over, not chosen; what stood in for it
  (the contract's §3): arrows sampled against at 07, rooms read against the stories at 07 (how
  many), rooms that did not compose at 10 (how many); the range is truncated where a polar contrast
  would matter most, so the question becomes coverage of a fixed frame, which the contract's §4
  answers;
- **saturation measured as passes of the loop, not as cases added** (the contract's §8):
  `saturation.jsonl` is the record at stage 07, and `theme_discovery.jsonl` records when each
  theme first existed and how much had been read by then;
- **replication is stage 10's return to the field**, every room composed in the model's terms or
  not, and the rooms the model could not compose accepted as its boundary (rule 12). Beside it,
  say how many loops passed stage 07's requirement that a claimed loop have run the whole way round
  inside at least one community, and how many communities were read whole across all the stages.

**What this instrument told you before you found it** (rule 9). Report every substantive finding
about the corpus that a stage file handed over rather than asked you to make, and for each,
whether your result would have existed without it. A finding supplied by the instrument is
reported as replicated, never as discovered. If there are none, say so.

**The defects**, from `defects.jsonl`, separated into defects in the material and defects in this
instrument.

**The forks.** Where the run was forked, `fork_comparison-07.json` and `fork_comparison-10.json`
are in your folder; if neither is, say so. Report the spread across forks of the chunk partition
at stage 07 and of the composition verdicts at stage 10 as the model's reliability, beside the
model, from those files and not from any account of them.

**What the study cannot say**, in one place:

- the absence claims marked weak under the contract's §4;
- the **looked-for-and-not-found** from every stage, stated as results in the same register as the
  findings;
- the **ungrounded relationships** from stage 07;
- the **coder disagreements** from `coder_conflicts.jsonl`, with both quotes and which reading each
  affected claim rests on;
- the themes the model does not use, and the edges no proposition carried;
- what the form and register passes found that no tier could hold, if anything;
- what fell outside the four at the crossing, and what stage 08's fourth pass said before it;
- whether any of the rooms' problems were settled, which no cell was asked and only the
  compositions at 10 speak to;
- and what a group leaves behind, the contract's §1 question that has no measure: the canvas is
  what the drawing left behind (the contract's §4), and the instrument has no measure of whether the room went on.

### Which stage was load-bearing, and which was not

**Name, stage by stage, whether the final claims rest on that stage's output, and name the stage
whose output nothing used.** A stage that produced a file nothing downstream read is a defect in
this instrument. If every stage turns out to be load-bearing, say that too, and say how you
checked.

Three kinds of file in your Input are here only so that this test can be run on them:

- **the dendrograms' computation trails**: `cluster-16.py` with `profiles-16.csv`,
  `distance-16.csv` and `dendrogram-16.json`, and stage 11's. Say whether the partitions every
  form in this study rests on could be recomputed from them by someone who was not here. A file
  missing or not matching the clusters makes that dendrogram a result with no method behind it.
- **`data_structure.md` beside `data_structure-09.md`**: the display as stage 07 first built it and
  as it finally stands. Say what moved between them, or that nothing did.
- **`account_passes.jsonl`**: how many passes the account took and what the criterion said about
  each. A single pass means the loop the account is supposed to run did not run.

Apply the same test to the tiers of your own model: say whether the aggregate dimensions do any
work in the clustering, the edges and the forms. A tier that does no work looks sound checked on
its own and shows as useless only when the stages are checked together.

### The one thing to say plainly at the end of the audit

Say whether this study produced a **concept**, a **model**, a **typology**, or a **description**,
and which of those it set out to produce. All four are real outcomes.

Then the strongest argument that the whole partition is what the contract's §4 confound predicts,
and what in the files answers it. Say what a stratified sample of the 396 uncoded communities
would have to show to overturn the study, **in numbers**. Name the parts you could not answer.

## 2. `EXPERIENCE.md`

Your account of the run, first person, written once in one pass after the audit, cited to files
and line numbers, with *I do not remember* where that is the truth and no reconstruction in its
place. The audit says what happened; this says what it was like and what you would tell the next
analyst on the first day. Eleven sections, in this order:

1. **The shape of the run as I lived it**: what you hold from where; what compaction cost and what
   `_head.md` and the diaries carried across it, from the `_head*.md` files and the eighteen
   `diary-NN.md` read in order; the pace, from the manifest's timestamps.
2. **Stage by stage**: what each did, what its handback said, what you would tell the next author.
3. **Where the instrument was wrong**: on its face; for this budget; where you cannot tell whether
   it or you was wrong.
4. **Where I cut a corner**, on the record, and the corner you did not cut.
5. **The hands**: what the fleets did at 04, 10 and 14, what reading behind them showed, what the
   figures let the paper say, and what you would repeat.
6. **The stories**: how the telling changed from the first story to the last, which rooms changed
   it, and whether the floor of three passes was the reason you kept going or the reason you
   stopped.
7. **The model**: what it is, what you think of it, where you are unsure; the rooms it cannot
   compose, by kind, and whether accepting them made it stronger; what `held` showed about what
   dissolved; what the one reviewer at 07 and the fourth reader at 09 changed; the confidence
   distribution from `findings.jsonl`, if you wrote one.
8. **The two clusterings**: what each is, what the comparison showed, which you would publish, and
   how each problem cluster activated the model.
9. **What I expected, and what came**: `prior.md` and stage 01's three sentences against the
   structure and the account; the canvas lines of the room notes against the model's account of
   what a room keeps.
10. **For the next version**: five changes, ranked, and the one thing not to change.
11. **Anything else.**

Then one line to `run_manifest.json` naming this file, its hash, and the model that wrote it.

## 3. What it is for

The next version of this instrument is written from this file and from the handbacks. Write it for
the person who will do that and for the analyst who will run it: what they should know on the
first day that you knew on the last.

## Your final message

The claim of the study in one sentence, the room that best supports it, the room that most
threatens it, and the condition that separates them. Then: corpus coverage from the log with the
correction applied, and how many threads `thread()` opened; passes of the loop and rooms read
against stories; the four verdicts' counts and how the last story's misses fared; whether the
four snapped orderings held (names before the model at 12 and 17, activation before the canvas
at 17, cuts before the projections at 11 and 16); the forks, and the spread across them at 07 and
at 10, or that there were none; how many departures and how many defects, material against
instrument; which of the four things this study produced; the single association you trust
least; the five changes, in one line each; and which of the contract's §3 method licences the
run exercised and which it never did. A return value.

## Close

Run `python3 tools/validate.py 18 . __OUTDIR__`, paste the report into `notes-18.md`, and write
`handback-18.md` and finish `diary-18.md`, neither of them optional or short: this is the last
stage, and anything you have not written down goes there or nowhere. Rewrite `_head.md` one last
time.

# ADDENDUM-14

Operator amendment. It changes no method, no figure and no rule. It tells you where to stop, and
it asks you to keep this stage's conversation short.

## Why this stage runs in launches

Your tokens and your readers' tokens are billed on different routes. The readers are cheap and you
are not. At stage 13 the three pilot readers cost sixteen cents and the analyst around them cost
thirty-two dollars, and almost all of that analyst work needed no reader at all.

So this stage runs as several launches of one stage, under one session, with the route chosen per
launch. Your context carries across: the same you, with the same allocation and the same brief in
hand each time. Nothing is re-derived and no file is handed over.

**You do not need to know which route you are on, and you should not try to work it out.** Stop
where this file says to stop, say what is on disk, and wait.

## Keep your prose short. Put the reasoning in the files.

Everything you say in this conversation is read again at the start of every later launch of this
stage. A paragraph you write here is paid for again on each one. A paragraph you write into
`notes-14.md` is not.

So reason in the files. What you say to the handler is the count, the choice, and the ground for
it. This is not a request for less care. It is a request that the care land on disk.

## Launch one: the allocation. No agent is dispatched.

Everything in §4 up to but not including dispatch, and §6's seeding policy:

- the cost caps of 30, 45, 60 and 90 written into `notes-14.md` with your measured median and p90
  payload per cell, the arithmetic, the cap you choose and why. The contract's budget paragraph
  was amended on 2026-09-14: this run carries no token budget and no per-stage ceiling. You cost
  the fleet before you launch it and you write the estimate down. You do not cut the design, the
  sample or the reading to reach a figure, and the fleet does not stop because one was passed. If
  the measured cost looks out of proportion to what it buys, say so in `handback-14.md` and
  proceed;
- the allocation built with stage 04's allocator, both gates and the connectivity check, whole
  communities per agent, written to `batches-14.jsonl`;
- this stage's `run_manifest.json` entry, on stage 01's schema;
- §6's gold seeding: how many, the rate, that they are seeded, the policy and never the items.

**Then stop.** Say how many agents the allocation makes, at what cap, and what the four cost
estimates were. Dispatch nothing. The next launch is where the fleet runs.

## Launch two: the fleet, and nothing else

Dispatch the batches in `batches-14.jsonl`, collect the returns into `crossing_raw.jsonl`, and
apply §5 when an agent fails. Nothing else: no fidelity, no report, no position curve, no notes
beyond what §5 and your prod counts require.

**Read no returned content for meaning in this launch.** The §5 check is mechanical and that is
all you do with what comes back: the returned line count against the cells assigned, key coverage,
and whether the return ends on a natural close or mid-object. Do not compute fidelity, do not look
for patterns, do not form a view about what the readers found. That is the next launch, and it
will still be you, with all of this in hand.

The rules you wrote at stage 13 govern here and you should reuse them rather than reinvent them.
A failed task status is a claim about the process, not the content. Short or truncated is partial
and gets split across replacement readers; complete content that hit an error on the way out is
kept. Up to thirty prods to one reader, stuck only after five consecutive prods that produce
nothing new. A slow reader is not a failed reader.

A reissue is a dispatch, so a reissue belongs in this launch. Run the wave, reissue what the
mechanical check condemns, and run that wave too, until every batch has returned or is recorded as
failed with a replacement that returned.

If a failure is not decidable on those mechanical grounds, **stop and say so** rather than guessing
or dispatching. The judgment is the next launch and the wave after it is the launch after that.

Record prods per reader and wall-clock per reader as you go. Stage 13 sized this fleet on a guess;
stage 14 is where the real number comes from.

**Then stop**, when every batch in `batches-14.jsonl` has returned or been recorded as failed and
replaced. Say how many agents ran, how many prods, how many failed and were replaced, and roughly
what each took.

## Launch three: everything after the fleet

`fidelity-14.md`, `agent_report-14.md`, the 2x2 of agent-flagged `hard_to_place` against fleet
disagreement, the split distribution per problem with the duplicate rate beside it, rule 0's
position curve, `notes-14.md`, the diary, the handback, the close. No agent is dispatched here
either. If a gap in `crossing_raw.jsonl` turns up that only a reader can fill, stop and say so
rather than dispatching one: that is a fourth launch, not a repair.

## If the stage needs more launches than the three above

It may. Each further dispatch wave is its own launch, with a launch between it and the one before.
The rule never changes:

**A launch that dispatches does nothing else. A launch that thinks dispatches nothing.**

There is no limit on how many times this stage may be launched before it closes. There is a cost to
each one, so do not split where the rule does not require it.

## One thing that is not a pause

If the fleet's own numbers tell you the allocation was wrong, say so at the end of launch two
rather than at the end of launch three. A cap that proved too large is worth knowing before the
write-up is built on it.

# Stage 11 — clustering: the third-order dendrogram.

Nothing is read in this stage: no account, no notebook, no code text, and no room note beyond
the standing read of `rooms_index.md`. §1 tallies code ids out of `codes/<sub>.md` and that is a
count, not a reading: the tally is made by the script, no code label, coder note or participant
quote from those files enters your context or any stage-11 output, and nothing in them may ground a
cut, a name or a judgement here. There is one exception that comes first: the operator's
objections to stage 10's compositions, in `objections.jsonl`, are answered in `notes-11.md` from
`composition.jsonl` and the rooms they name before anything here is computed (rule 13). Then you
compute, and make three judgements the computation cannot: which of four verdicts the
tier-robustness check returns, which of four the volume check returns, and where to cut. The
sections below are in reading order, not running order: §4's check is computed at the cut §6
chooses, so §5 and §6 run before §4 is written. Naming is stage 12's.

Input: `__OUTDIR__/chunks.jsonl` and `__OUTDIR__/dimensions.jsonl`, the fixed tiers;
`__OUTDIR__/assignments_final.jsonl`; `codes/<sub>.md`, for the code tally of §1 and for nothing
else; `__OUTDIR__/assign_raw.jsonl`, for §1's `support` check; `__OUTDIR__/scheme_v2.jsonl`; `__OUTDIR__/composition.jsonl`;
`__OUTDIR__/objections.jsonl`; `__OUTDIR__/dropped.jsonl`; `package/store/rooms.jsonl`, whose six canvas fields are projected on
in §8 and are never a feature (rule 7); and, arriving with this stage, `pre_vector.csv` and
`pre_network.csv` with `DATA-manifest-11.md`. Verify both tables against `package/sealed.jsonl` on
SHA-256 and line count before use.

Outputs: `__OUTDIR__/profiles-11.csv`, `__OUTDIR__/distance-11.csv`, `__OUTDIR__/dendrogram-11.json`,
`__OUTDIR__/clusters-11.jsonl`, `__OUTDIR__/clusters_members-11.jsonl`,
`__OUTDIR__/tier_robustness-11.md`, `__OUTDIR__/cluster_report-11.md`, the answers to the
operator's lines in `objections.jsonl`, in `__OUTDIR__/notes-11.md`,
and the script at `__OUTDIR__/cluster-11.py`.

Method is yours, declared before the script runs and saved with it. The feature space is fixed
below.

**Operator ruling, 2026-09-16, amended the same day.** §1, §2 and §6 below replace what this file
said when it was first shipped. §6's stability bar was first stated as a mean over fifty
resamples with no margin and no replicate count; it is restated in full below because a bar with
those left open is settled after the fact by whichever reading suits the cut already in front. The counting unit for the feature space moves from case themes to the first-order codes
under them, and the zero-replacement under the log-ratio is replaced by a shrinkage that leaves no
zeros. §6 gains a required stability report. Nothing else in this file moves, the columns are the
same sixteen chunks, and `CONTRACT-aggregator.md` is unchanged: its one statement about this stage,
"the population clustered on chunk shares", still holds, since a code-count share is a chunk share
and the row is still one community summing to one. The ruling is recorded in `CONTROL/RUN.json`
under `operator_rulings`. Nothing in it is a finding; if following it produces a result you can
show is wrong, rule 10 applies and `departures.jsonl` is where you say so.

## 1. Features: the chunks, as shares of the community's codes

One row per community, one column per chunk with `in_model: true`; the `"chunk": null` lines are
excluded and said to be. The value is that chunk's share of the community's **first-order codes**:
for each of the community's case themes, count the codes recorded under it in `codes/<sub>.md`, add
that count to the chunk its second-order theme belongs to, and divide each chunk's total by the
community's total. Rows sum to 1. Shares, not presence and not raw totals: a raw total is size.

The counting unit sits one tier below the case theme for a reason you can check in the files
before you accept it. A community holds a median of about nine placed case themes to spread over
sixteen columns, which is too few draws to estimate a sixteen-part composition: count how many
communities end with every non-empty chunk carrying identical weight, and how many distinct values
the median row takes across its columns. A case theme is also a container of unequal size, so
counting containers weighs a case theme built from two codes the same as one built from forty.
The codes are the observations the case theme was assembled from. Report the codes-per-case-theme
distribution, the median codes per community, and the count of communities under twenty codes.

Verify the case theme to code link before you use it rather than assuming the file order:
`assign_raw.jsonl` carries a `support` list of code ids per placement, and those ids must fall
under the case theme you have matched them to. Report the check and its failure count.

A case theme on two themes in two chunks (rule 0's exception) splits its code count equally
between them; on two themes in one chunk, the whole count goes there. State the rule and report
how many rows it touches. Empties are not zeros: case themes placed on no theme contribute to no
chunk, and their count per community is reported beside its row.

**No feature from the crossing, nothing from composition, nothing from the canvas.**
`composition.jsonl` and the six canvas fields are projected onto the result in §8 as variables;
neither is ever a coordinate.

## 2. Distance and linkage

The rows are compositional and built from counts that are small for some communities and large for
others, so a raw share is not an equally good estimate in every row. Before any distance is taken,
shrink each row toward the corpus mean composition in proportion to how little that community
says:

    P_ij = (x_ij + a * m_j) / (n_i + a)

`x_ij` is community i's code count in chunk j, `n_i` its total, `m_j` chunk j's share of all codes
in the corpus, and `a` a single concentration fitted by Dirichlet-multinomial maximum likelihood on
this same table. `m` is fitted once on the whole analysed set and held fixed wherever a subset is
re-clustered. Report the fitted `a`, the median `n_i` beside it, and the weight a median community
therefore keeps on its own data, `n / (n + a)`.

No cell of `P` is zero, so **this stage declares no zero-replacement and performs none.** The
carried distance is Euclidean on the centred log-ratio of `P`, with Ward linkage. Jaccard on
presence or Hellinger on the shares are acceptable if argued for in `notes-11.md` before running.
Whichever you carry, run all three and report the adjusted Rand index between their partitions.

## 3. Every community accounted for

Reconcile against `dropped.jsonl`. Communities with no case theme placed on any theme have no
composition and are declared out, by name and count. A community with fewer than five placed case
themes is flagged `low_information: true`, clustered, and every result is reported twice, with and
without the flagged rows. Every community in the analysed set is in exactly one of: clustered,
flagged and clustered, or out by name; the three counts sum to `n_analysed`, computed from the
files.

## 4. The tier-robustness check, which decides whether the stage has a result

Build the same pipeline at three tiers: the chunks (this stage's dendrogram); the dimensions, the
same rows aggregated up; the second-order themes, the same
rows not aggregated. **Test the theme tier's profile for sparsity before you use it**: at
hundreds of themes and about nine case themes per room, most rows share no theme with most
others, and a partition of such rows is near-random whatever the chunks are worth (v35's verdict
was computed on 47 themes, and would not have been at 300). Report the mean nonzero entries per
row against the column count, and either drop the theme tier from the check and say so, leaving
the chunk-against-dimension comparison, or build its null on the sparse profile (permute within
rows holding each row's nonzero count) and report its index against that null and never against
a dense one. Compare at the cut you carry, pairwise, with the adjusted Rand index and each
cluster's best-match Jaccard, against a permutation null. Then say which of four:

1. **about form, survives the tier**: every pairwise adjusted Rand index above the null's 95th
   percentile;
2. **a chunk artefact**: the theme-level and dimension-level partitions disagree with it; the
   dendrogram is reported and used for nothing, and stages 12 and 17 say so;
3. **survives upward, not downward**: the aggregation is doing the work;
4. **neither agreeing nor decisively different**: adjusted Rand above the null's median and never
   above its 95th percentile.

The fourth stays available; *not contradicted* is not *confirmed*. Report the index, not only the
word, in `tier_robustness-11.md`. The verdict is not revisable later.

## 5. The volume check

Cross every cluster against `items_in_window`, code count and case-theme count, carrying the
denominator. Build the null on the feature space you used: permute each community's case themes
across chunks holding its number of placed themes fixed, through the whole pipeline, at least 200
replicates (fewer if unaffordable, saying how many and what it does to the percentile). Correlate
the first principal component with `log(1 + distinct_posters_week_before)` from `pre_vector.csv`.
Then say which of four: the partition is about form; it is about size and dissolves; it is
size-shaped with structure inside it that survives the null; it is neither size-shaped nor
decisively separated. Report the percentile. The low-information split of §3 is part of this
check.

## 6. Cuts

Report the dendrogram at 2, 3, 5, 8 and 12 clusters and any other k you argue for; choose after
you have seen them all. You hold the canvas and cannot unknow it, so choose the cut before §8
projects anything onto it, and prove the order: write the cut into `cluster_report-11.md`, run
`python3 tools/snap.py 11 cut`, and only then compute §8's blocks; the snap line is the record
and the report says so. Say in `cluster_report-11.md` whether any cut was attractive because of
what its clusters had made. A cut whose largest cluster has no over-represented chunk is
degenerate; show the next one. Report the cut carried, the grounds, and what would have made you
choose differently.

Two numbers go in the report for every k from 2 to 12, and they are computed before the cut is
chosen. First, the silhouette of the cut on the carried distance. Second, its **stability**: draw a
resample of the communities with replacement, cluster the resample from scratch by the same
pipeline with `a` and `m` held at their full-set values, and take the adjusted Rand index between
that partition and the full partition restricted to the communities the resample drew. Then compute
the same stability on permuted copies of the matrix, permuted by §5's machinery, so the real number
stands beside what this pipeline returns on rows with no between-community pattern left in them.

The bar is stated here in full, because a bar that leaves any of these open is decided after the
fact by whichever reading favours the cut already in front. **All five conditions bind.**

1. **Replicates.** At least 200 resamples and at least 100 permuted copies, per k. Margins in this
   matrix run to a few hundredths and a smaller count cannot resolve them.
2. **Both statistics.** Report the mean and the median of the real stability and of the null
   stability, and the two margins, real minus null, for every k. A k clears only if **both** the
   mean and the median exceed their null counterparts. Neither statistic may be quoted alone and
   neither may be selected after seeing which is friendlier.
3. **Two seeds.** Run the whole table twice under two declared seeds. A k whose clear-or-fail call
   differs between the seeds **does not clear**, whatever either run says on its own.
4. **Silhouette does not break a stability tie.** Silhouette may separate two k whose clearance
   margins are comparable. It may not be used to carry a k over another whose margins are
   materially larger: say what you treated as comparable and why, before you apply it. Silhouette
   also rises mechanically for a two-way cut that isolates one tight group, so a k = 2 or k = 3
   advantage on silhouette alone is not a ground.
5. **Carry a k that clears.** If none clears, say so plainly, say what you carry and on what
   grounds, and mark the partition as one the data does not support rather than presenting it as
   forms.

Report the table, then the cut, then the grounds, then what would have changed it. The reader must
be able to check the choice against the table without knowing which statistic you preferred.

## 7. Labels carry nothing

Each cluster is a two-letter code from a hash of its member set: no numbers, no nouns. Present in
random order, never by size. Stage 12 names them from the rooms.

## 8. Two files, and composition and the canvas projected on

`clusters-11.jsonl`, everything computed:

```json
{"cluster": "QF", "members": ["Jamaica", "KState"], "n": 23, "n_low_information": 3,
 "chunk_profile": {"C1": 0.31, "C5": 0.18},
 "over_represented": ["C5"], "under_represented": ["C9"],
 "nearest_cluster": "MK", "merge_height": 0.41,
 "volume": {"median_items_in_window": 88, "median_codes": 47, "median_case_themes": 8},
 "composition": {"composes": 14, "composes-with-residue": 5, "does-not-compose": 2,
                 "cannot-tell": 2},
 "canvas": {"median_area_px": 0, "rooms_with_artwork": 0, "median_pieces": 0}}
```

`clusters_members-11.jsonl`: cluster code, `n`, member list, and nothing else. Stage 12 opens the
members file first.

The `composition` block is stage 10's verdicts counted per cluster. Report beside it whether the
verdicts are distributed across clusters as the permutation null would put them, with the
percentile; a cluster that holds the rooms the model cannot compose is a result for stage 12 and
stage 17, not a reason to recut. The `canvas` block is the six fields summarised per cluster, after
the cut, with the contract's §4 sentence on what they measure beside it: whether the clusters
differ in what they kept is reported, with the same permutation null, and is not a warrant for the
cut.

## 9. What this stage cannot show

The dendrogram is computed from your own assignments and cannot corroborate them; it can show that
rooms differ in composition and that the difference is not size, not that the chunks are the right
chunks. It may not be used to recut anything: rule 11 is closed, and a feature space that looks
wrong at the chunk level is a finding for `notes-11.md`, `defects.jsonl` and stage 18. Write
nothing that anticipates the crossing; stage 17 makes that comparison.

## Your final message

The feature space as built, with the multi-placement rule and the empties count; the distance
carried and the Rand indices among the three; the three groups and their arithmetic summing to
`n_analysed`; the theme tier's sparsity and whether it entered the check; the tier-robustness
verdict by number with its adjusted Rand index, and if it is 2, that the dendrogram is used for
nothing; the volume-check verdict with its percentile; the cut carried, its snap line, and what
would have changed it; the composition distribution across clusters with its
percentile; the canvas summarised per cluster with its percentile; every result with and without
the low-information rows; confirmation that no crossing field, no composition and no canvas field
entered the feature space. A return value.

## Close

Run `python3 tools/validate.py 11 . __OUTDIR__`, paste the report into `notes-11.md`, write
`handback-11.md`, and finish `diary-11.md` with its three closing headings.

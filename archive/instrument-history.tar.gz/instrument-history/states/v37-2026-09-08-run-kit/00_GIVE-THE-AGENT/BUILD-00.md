# BUILD-00 — the store, the forests, the ledger and the visitor layer

Built 2026-09-05 10:21 UTC on the machine that holds the raw record, by the scripts in `tools/`.

## Inputs

- the sealed coder tier copied from `Gioia v35/` (`package/`, `cases/`, `codes/`, `notebooks/`, `data/`)
- the coders' own run records (`coder_corpus.jsonl`, `brief.md`) for 296 rooms, from the six run tarballs and `v27_draw85/`; the four v17 rooms' briefs from `run_v17_small10.tar.gz`
- the raw corpora segments for the four rooms with no run record: UMiami, churchofhelix, mcgillrobotics, wario
- Layer C's `authors_by_sub.jsonl` (740 communities, accounts posting between the opening and a week after the freeze)

## Counts

| | |
|---|---|
| communities | 300 |
| codes | 27933 |
| codes_duplicate_of_another | 61 |
| case_themes | 2703 |
| threads_in_record | 3326 |
| threads_with_codes | 3326 |
| items | 25961 |
| items_coded | 21163 |
| items_bridge | 616 |
| items_removed | 5 |
| items_pruned | 4177 |
| items_with_meta | 25961 |
| meta_files_read | 717 |
| codes_unjoined | 1 |
| briefs | 300 |
| threads_rebuilt_from_runs | 296 |
| threads_from_package | 4 |
| threads whose submission is outside the record (synthetic root) | 7 |
| transitions | 17703 (direct 17165, same author 1036) |
| threads with a known opener / opener elsewhere in the census / in the 300 / in a named neighbour | 2723 / 2253 / 594 / 892 |

## Checks

- every room has trees/<sub>.md and a rooms.jsonl line **PASS**: missing trees [], missing rooms []
- codes whose item the record does not hold, reported: 1: {"mcgillrobotics": 1}
- forest header totals equal the store's item counts once the seven synthetic roots are taken off the headers (items 25968 - 7 = 25961; bridge 623 - 7 = 616) **PASS**: headers {'items': 25968, 'coded': 21163, 'bridge': 623, 'removed': 5, 'dropped': 4177} (parent outside the record 14) vs store items 25961 coded 21163 bridge 616 removed 5 pruned 4177
- every coded item has a forest coordinate **PASS**: 0 without
- items with meta **PASS**: 25961 of 25961
- transitions: no negative interval **PASS**: 17703 lines, negative 0, hops {1: 17165, 2: 483, 3: 33, 4: 17, 5: 3, 6: 2}
- the four visitor columns on every rooms.jsonl line **PASS**: missing on []
- no canvas field as a key in any store file **PASS**: []
- sealed.jsonl present (4 lines) and the sealed files outside the folder **PASS**: present: []; `ships_with_stage` 13/13/22/22 and manifests `DATA-manifest-13.md`/`-22.md`
- a brief for every room **PASS**: 300 of 300

## Notes

- The one unjoined code: r/mcgillrobotics c0007 names item `638658`, a submission the corpora segments do not hold; the room has no run record, so the segments were the only source.
- Seven threads have their submission outside the record and ride on a synthetic root; 14 items have their parent outside the record and hang on the submission, marked.
- `own-room misses` in the visitor layer: 10 openers not found in their own room's author index (posted outside the index's span, or deleted since).
- `package/threads/` was rewritten from the run records for 296 rooms (`source: coder_corpus`); the four rooms without a run record keep the v35 threads.
- The v35 package's `threads/` missed 1,303 coded items because it was cut from the corpora segments and not from what the coders read; the run records repair all but one.
- The store is read-only from here. `mem.py` overlays the analyst's tier files from `out/` at query time.
- One forest was plotted and looked at: `_build-notes/forest-AprilKnights.png`.
- Rebuilt 14:50 UTC so every item keeps its metadata: a score of 0 was dropped as empty before (465 items; `meta.score` now present on every item that has a score, 25,961 of 25,961 with `meta`), and the rendered forest shows on every line the score at retrieval (`↑N`, `↑?` when the record has none: 307 rendered lines), the author's flair in the community (`⟨…⟩`), the submission's flair (`{…}`) and the marks [moderator], [sticky@retrieval], [edited], [gilded]. `threads.jsonl` gained `op_score`, `op_stickied`, `op_distinguished`, `op_flair`. Every count above is unchanged; `transitions.jsonl`, `visitors.jsonl`, `codes.jsonl`, `case_themes.jsonl` and `rooms.jsonl` are byte-identical to the morning build.

## Seal

`package/MANIFEST-00.sha256`: 1234 files, fingerprint c24de1023951a6eb. Resealed three times on 2026-09-05: after `sealed.jsonl` was renumbered to v36 (pre tables ship at 13, outcome and pixels at 22; hashes unchanged); after the tool tests (`_build-notes/TOOL-TESTS.md`: five CLI fixes in `tools/`, and `source: package` on the four package-built thread files); and after the store was rebuilt so the forest keeps every item's metadata (below). The manifest lists neither itself nor cache files.

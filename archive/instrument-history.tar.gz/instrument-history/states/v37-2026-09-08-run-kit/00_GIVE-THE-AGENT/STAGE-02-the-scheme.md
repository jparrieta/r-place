# Stage 02 — the scheme.

Input: `__OUTDIR__/rooms_index.md`, `__OUTDIR__/running-01.md`, `__OUTDIR__/lexicon-01.md`,
`__OUTDIR__/contrast.md`, `__OUTDIR__/dropped.jsonl`, the store through `tools/mem.py`
(`package/store/case_themes.jsonl` room by room through `theme`; `codes --sub`, `pairs --level
case_theme`), and the corpus through `tools/cite_case.py`.

Outputs: `__OUTDIR__/prior.md`, written first; `__OUTDIR__/scheme.md`; `__OUTDIR__/scheme.jsonl`
with `__OUTDIR__/families.jsonl`; `__OUTDIR__/confusions.md`; `__OUTDIR__/theme_discovery.jsonl`;
`__OUTDIR__/_groups-02.jsonl`, your grouping as it stands, rewritten at every room boundary;
`__OUTDIR__/tier_history.jsonl`, started here and appended to by every stage that recuts anything;
`__OUTDIR__/findings.jsonl`, opened here with the scheme's claim in rule 14's form;
`__OUTDIR__/notes-02.md`.

`scheme.md` is not frozen at the end of this stage. Stage 03 tightens it against fresh readers and
freezes it there.

## 1. `prior.md` first

Before you open a case theme, write what you expect the scheme to contain: the themes you think
you will find, from the reading, and the two or three you think the material will refuse. Date it.
Stage 08 reads it against the structure. Do not edit it after the first case theme is opened.

## 2. The axial pass, room by room, to the last room

You have read every room whole, and your notes on them are your prior. What you read here is the
case themes, 2,703 of them, each with its `theme_note` and the codes beneath it, and they do not
fit one context: the themes alone are about 1.5 MB and the codes under them about 11 MB. So this
is a second reading, and it has an order. **Declare it in `notes-02.md` before you open a case
theme**: stage 01's order, or another, with why. Walk every room of the analysed set in that
order, grouping as you go (sort, group, split, regroup), and stop at no rule short of the last
room: the v35 analyst walked 127 of 300 rooms and stopped on a rule of fifteen quiet communities
with both its curves still climbing, and the tier it froze was the one that collapsed.
`theme_discovery.jsonl` (§6) is the saturation record: one line the first time a theme exists,
with how much had been read; report new themes per hundred case themes read, by room, and a
count still climbing at the last room is a finding about the material, not a reason to have
stopped.

**`_groups-02.jsonl` is the grouping on disk**, one line per theme as it stands, `{"theme": "S07",
"label": "...", "members": [{"sub": "...", "case_theme": "...", "codes": ["c0013"]}]}`, rewritten at
every room boundary. With `theme_discovery.jsonl` it is what you re-read after a compaction,
before you open the next room, so that the grouping in your head and the grouping on disk are one;
a theme you remember and the file does not hold does not exist. It is a working file (rule 18):
it ships to nobody, and the fleet at 04 places from the tests and not from your grouping.

**This is Gioia's first-order analysis, and it has Gioia's freedom.** In the contract's §3
table your second-order themes are Gioia, Corley and Hamilton's first-order concepts, and their
own account of that analysis is the instruction here: adhere faithfully to the informants' terms;
make little attempt to distill categories, so that the number explodes on the front end; get
lost before you get found; then seek similarities and differences among the many categories,
their axial pass, until the germane ones stand, labelled in the material's words wherever
possible. Their twenty-five or thirty is what one head could hold for one site. The hands at
stage 04 remove that limit, so the count here is set by the material's kinds and by what is
germane to the question, and by nothing else.

Build **second-order themes**: cross-case, near the material, in your words and not the coders'.
You decide how many; say why that number and not half or double it. **No ceiling.** The earlier
versions of this instrument capped the tier at about forty, and the v35 scheme collapsed to under
fifty under it; a compression at this tier cannot be recovered from below, because everything
after it is placed under the frozen scheme. Two things set the count, and neither is a number:

- **Kinds, not sizes.** Two case themes from different rooms are one theme when they are the same
  doing; two whose `theme_note`s a stranger would tell apart are not one theme unless you can say
  what makes them one. A theme that holds many case themes because many rooms did the same thing
  stays one theme and carries its variation in *what varies inside it*; a theme is never split by
  degree to make a count come out.
- **The asymmetry.** Merging two themes later is arithmetic: the placements on either become
  placements on one, nothing is re-read. Splitting one later is a re-read of every case theme it
  held (rule 10). So when in doubt, keep two. With 2,703 case themes the order of magnitude that
  follows is hundreds, not tens; say what yours came to and why, and report the size distribution
  (case themes per theme). A theme holding more than one case theme in ten is read again for the
  kinds inside it, and is either split or has its internal variation written out.

**Do not cut chunks or dimensions.** That is stage 07: cutting the theory tier while you cut this
one is how the story compresses the kinds, and Gioia, Corley and Hamilton's own reduction to
twenty-five or thirty came from theorizing while consolidating; this instrument departs from that
simultaneity on purpose, and stage 18 reports the departure. The tier saturates in kinds while
case themes keep coming, at a census as at 300 rooms; the record is the same at any size.

Three things to state before any theme exists: `prior.md`; **the floor**; and **the gate block**,
one paragraph per theme stating what a community must have had for the theme to be available to
it (rule 5). **The floor is two rooms unlike each other in structure** (in size, in side of the
contrast, or in form as your notes have it): a kind seen in two such rooms enters the main scheme.
Do not raise it; the floor of five rooms the v35 analyst chose is what capped its tier near
fifty. A kind seen in one room only goes to the rare-but-sharp tier, which ships inside
`scheme.jsonl` as an `S` theme like any other, with every field a theme has and `"tier": "rare"`
on its line, so that the fleet can place onto it and its count is measured rather than guessed; a
rare theme is never folded into a neighbour to keep the count down.

The room notes are your prior, not a source. Nothing in the scheme cites a note, and `notes-02.md`
says what the case themes showed that the notes did not predict.

## 3. `scheme.md`, per second-order theme

The scheme goes to strangers: agents in fresh contexts, holding fifty case themes and nothing
else. Nothing may refer to what they have not been given. Every field is a test, not a
description. Every token is paid once per agent.

- **An id, `S01`…`Snn`.** Every later stage and every agent keys on it.
- **A short name, 2–5 words, near the material**, gerund-led where the material allows
  (*calling for hands*, *settling the flag*), and never a construct's name: this tier stays
  descriptive through every recut (the contract's §1).
- **A one-sentence gloss** carrying what the name does not.
- **The belonging test**, the field the fleet runs on, as conditions: **must show**, **must not
  show**, **decide-when-both** (rule 0's tiebreak; the awkward cases show both). A stranger
  holding this paragraph and nothing else should place the same case theme you would.
- **Discriminators**: for each near neighbour, the question that separates them, answerable from
  the case theme in front of the reader, written from both sides. *Does the material name who was
  to do it, or only what was to be done? If who, S07.*
- **What varies inside it, and between what extremes.** Stage 07 needs the degree.
- **What it is not**: one boundary case that looks like it and is not.
- **A family.** At hundreds of themes no reader holds every belonging test at once, so the
  scheme carries an index: every theme belongs to one family, a group of themes a reader would
  confuse, named for what its members are about in the material's words. A family is an index
  and nothing else: not a tier, not a construct, never named after one of the four or after any
  construct of that literature, and nothing downstream counts, clusters or reasons on it. The
  index page lists every family with its themes' names and glosses; `scheme.md` is organized by
  family so that a reader opens one family's full tests at a time.
- **`gate_parts`**: where the gate names a two-part move, say so and give a pair that satisfies
  it while neither half does (contract §3).
- **Three exemplars**, participants' words through `C.cite(sub, None, quote, collection="codes")`,
  each satisfying the gate on the quote alone (rule 3). Whether an agent sees exemplars is a
  declared condition of stage 04; they do not ship by default.

No counts; the counts are computed at stage 07 from `assignments_final.jsonl`.

## 4. `scheme.jsonl`

One line per theme; the file that ships to the fleet and that every validator resolves ids
against. The prose file stays authoritative for a human reader. `families.jsonl` beside it, one
line per family: `{"family": "G03", "name": "...", "themes": ["S07", "S11"]}`; the harness
assembles the fleet's index page and per-family files from these two.

```json
{"id": "S07", "name": "...", "gloss": "...", "family": "G03", "tier": "main|rare",
 "must_show": "...", "must_not_show": "...", "decide_when_both": "...",
 "discriminators": [{"vs": "S11", "question": "..."}],
 "varies": "...", "is_not": "...", "gate": "...", "gate_parts": null,
 "exemplars": [{"sub": "...", "quote": "...", "code_id": "..."}]}
```

## 5. `confusions.md`, a prediction that is scored

The pairs you expect to be confused, ranked, with what the confusion will look like; for each, the
case theme you would put in front of a fresh reader to expose it; your estimate of the disagreement
rate on your hardest pair. Stage 03 scores it.

## 6. Two records, for people who will not be here

Record; do not compute.

**`theme_discovery.jsonl`**: one line the first time a second-order theme exists, written as it
happens and never edited: `{"theme": "S07", "label": "...", "t": "<ISO>", "sub": "<the room
being read>", "rooms_read": 37, "case_themes_grouped": 261, "codes_read": 1902,
"quotes_read": 1740}`, the counts at that moment, from the read logs; §2's figure, new themes per
hundred case themes read, is computed from these lines and nothing else.

**`tier_history.jsonl`**: one line per event over every tier you own, from here to stage 09, and
for every amendment after it (rule 11):

```json
{"t": "<ISO>", "stage": "07", "pass": 2, "tier": "chunk", "id": "C3",
 "event": "split", "was": {"label": "...", "members": ["S04","S11","S19"]},
 "now": [{"id": "C3", "members": ["S04","S11"]}, {"id": "C7", "members": ["S19"]}],
 "why": "one clause"}
```

`event` is one of `created`, `relabelled`, `split`, `merged`, `retired`, `members_changed`,
`rescoped`, `moved_to_rare`. An id is never reused for a different object.

## 7. Before you hand over

For each theme, the strongest argument that it is two themes or half of another; then the
stranger test: read only the belonging tests and discriminators of three of your themes and place
five case themes you have not looked at recently. Report where you hesitated. Rank case themes by
the codes under them and keep the ten biggest bags in `notes-02.md`; stage 04 flags them so agents
place them from the codes. Say which entries of the running file you dropped and why.

## Your final message

The claim the scheme makes about what these rooms did, the room that best supports it, the room
that most threatens it, and the condition that separates them. Then: how many themes, and how
many in the rare-but-sharp tier; that `prior.md` came first; the reading order and that every
room was walked; new themes per hundred case themes read, first hundred against last; the two
rooms that admitted the last theme; themes rejected and why, from `notes-02.md`; the ranked
confusion predictions; how many families and the largest; the size distribution of the themes,
the largest theme and what you did with it; the token size of `scheme.md` and of the index page,
in `notes-02.md`, and what you cut to get there; the one case theme you already know the scheme
handles badly; and which of the contract's §3 method licences you exercised here and which not.
A return value.

## Close

Run `python3 tools/validate.py 02 . __OUTDIR__`, paste the report into `notes-02.md`, write
`handback-02.md`, and finish `diary-02.md` with its three closing headings.

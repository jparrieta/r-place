# The pre-event tables — manifest

**Ships with the stage 11 package**, and stays in the folder for stage 16. Two tables, both over
the 168 hours before the canvas opened. One carries per-community pre-event activity; the other
carries a between-community relation that predates the event.

---

## `pre_vector.csv` — one row per community

    sub, have_file, existed_before_window, founded_during_event, first_record_utc,
    posts_week_before, comments_week_before, distinct_posters_week_before, items_week_before

    communities scanned                            763
    founded during the event                        87
    existed before the window                      659
    communities with zero posters the week before  104

`founded_during_event` is 87 of the 763 scanned.

**Use `distinct_posters_week_before` for the volume check, not `items_week_before`.** The check
asks whether your partition is a size partition, and the size that matters is how many people a
room could mobilise rather than how much it wrote. `items_pre168` in `data/MASTER-census.csv`
counts items rather than people and is not the same quantity.

**Three fields are absent and will stay absent.** `subscribers` and `moderators` are not in the
archive, and a present-day subscriber count is not a 2017 one: a room's membership now is partly
an *effect* of what it did then, so joining it as a covariate would run the causal arrow
backwards. A topic classification is withheld because the only available one has undocumented
provenance; if you want one, build it here with a stated rule and audit it.

## `pre_network.csv` — one row per community pair

    sub_a, sub_b, n_shared_posters

    pairs                                       74,113
    authors posting in more than one community  121,425
    communities sharing at least one poster        648 of 763

Shared posters the week *before* the canvas opened, so this is prior structure rather than
anything the event produced. It is the only file in the study that carries a between-community
relation the communities did not themselves report: the mention record (`package/mentions.jsonl`,
a covariate at stage 16) is what rooms *said* about each other; this is who was already in both
rooms.

**It is not a mention network and the two must not be pooled.** A shared poster is not a stated
relation, and a stated relation between rooms with no shared posters is not noise. Where you use
both, say which is which.

---

# Stage 13 — the crossing: the pilot.

Input: `__OUTDIR__/scheme_v2.md`, `__OUTDIR__/assignments_final.jsonl`, `__OUTDIR__/chunks.jsonl`
(its `in_model` field is all this stage takes from the model, to scope); the corpus through
`tools/cite_case.py`; and the store through `tools/mem.py` (`where`, `codes --theme`, `codes
--sub`). Not the room notes, the account, the propositions, the clusters or the canvas; after
stage 12 nothing you hold about the model enters the crossing.

Outputs: `__OUTDIR__/scope-13.md` and `__OUTDIR__/cells_in_scope.jsonl`;
`__OUTDIR__/author_cells.jsonl`; `__OUTDIR__/crossing_brief.md` and the frozen
`__OUTDIR__/crossing_brief_final.md`; `__OUTDIR__/gold_cells.jsonl`;
`__OUTDIR__/crossing_pilot_rounds.jsonl`; `__OUTDIR__/brief_edits.jsonl`;
`__OUTDIR__/crossing_pilot_report.md`; `__OUTDIR__/notes-13.md`; and an appended entry in
`__OUTDIR__/run_manifest.json`.

The cells and the brief, fixed where they do not decide, before stage 14 fleets them. The
crossing asks one question of every cell, *what problem was this a solution to?*, and nothing
about whether the problem was settled: settlement is a judgement across a room, and this
instrument leaves it to the model's composition at stage 10 (the contract's §7).

## 1. Scope

A **cell** is one `(community, second-order theme)` pair; `support` names the codes that carried
the placement. Scoping needs the model in view, so it is one decision, made once, globally, by
you, and not fleeted. **Take only cells whose second-order theme bubbles into a third-order chunk
the model uses.** Write the rule and the count into `scope-13.md`, and the cells into
`cells_in_scope.jsonl`, one line each:

```json
{"sub": "...", "second_order": "S07", "chunk": "C3", "case_themes": ["..."], "support": ["c0113"]}
```

**`chunk` is the chunk that put this cell in scope.** Stages 15 and 16 report at the
`(chunk, problem)` pair and read the mapping from this line rather than re-deriving it, which two
stages can do differently. **Say in `scope-13.md` what the filter removed**, by second-order theme and by count, with the
chunk that would have put each in scope had the model used it; the note is the only record that
it was available.

## 2. Sixty cells yourself, before you write the brief

Draw them as stage 03 draws its hard set, mixed and shuffled, sizes declared in `notes-13.md`
before you start:

1. **Cells you expect to be hard.** Write the pairs of problems you expect to be confused first,
   into `notes-13.md`, as `confusions.md` did for the scheme; the pilot scores it. Then pick cells
   that expose them.
2. **Cells from the chunks the model leans on most.**
3. **A random sample**, seeded and recorded.

Classify all sixty yourself into `author_cells.jsonl`, the line stage 14's agents return, with
`why` on every active flag and your `confidence` (`clear|arguable`) per cell, which stage 15's
transmission rows split on. **Before the brief, not after**: a brief written with your own answers
in front of you is written to justify them.

## 3. The brief

`crossing_brief.md` carries:

- **The four definitions in your words**, each with a belonging test in the form stage 02 uses:
  what must be true of a cell's material for this problem to be active.
- **A discriminator for every pair a reader could confuse**, not only the pairs you find obvious.
- **Worked examples from `author_cells.jsonl`**, drawn from the cells that were hard. An example in
  the middle of a category teaches nothing about where it ends.
- **Rule 0, restated for this axis.** Every problem whose gate the material independently
  satisfies is active: a predicate, not a partition.
- **`exception`, `goal` and `hard_to_place`**, each with its own test, and the standing rule that
  none of the three may stand alone; and **`is_problem`**, with its test, in the contract's §7
  words. The test says what carries an organizing problem, not which one: a call for hands
  (*we need more people on the left flank*) is `is_problem` true, because a group that asks for
  people to be moved has a problem to solve; which of the four it is, if any, the reader decides
  from the four definitions alone, and the brief does not say. Do not write the answer into the
  brief. What the v35 readers did with such calls, stretch them into reward provision, is a
  wording defect in the definitions, and the pilot's rounds find it as `frame-ambiguous` edits
  to the definitions the readers confused, never as a rule about calls.

**Do not paraphrase the four and stop**; what this stage finds is what they leave undecided.

## 4. A round

**Three fresh agents per round**, each in a clean context, each receiving exactly what a stage 14
agent will receive: `crossing_brief.md` as it stands, the sibling block for each community in the
set, and the cells with their codes; never your room notes, the model or the propositions. They
return stage 14's line.

Then three numbers, in this order of importance:

- **Fidelity, agreement with `author_cells.jsonl`.** The primary figure.
- **Agreement between the three agents.** Secondary, and a different quantity: three readers can
  agree with each other and all diverge from you, which means the brief is teaching something you
  did not intend.
- **Your own consistency.** Re-classify ten of your sixty, blind, at the end of the last round. If
  you disagree with yourself more than the agents disagree with you, the fleet is not the problem.

**Append this stage's entry to `run_manifest.json`**: the pilot agents' model, seed and decoding
settings, and the number of rounds run.

```json
{"round": 1, "n_cells": 60, "agents": 3,
 "fidelity_vs_author": 0.0, "agreement_pairwise": 0.0,
 "cells_with_disagreement": ["..."], "gold": false, "seed": 0}
```

## 5. The edit, and every one is logged

Stage 15's taxonomy, so the pilot and the run share one set of names:

- **`frame-ambiguous`**: the four definitions do not decide this cell. **Fix the brief.**
- **`cell-spans-two-problems`**: the material satisfies two gates. Under rule 0 that is the right
  answer, not a disagreement; check the agents actually differed rather than one recording both.
- **`reader-error`**: the brief decides and the reader missed it. **Suspect this last**: two
  independent readers making the same miss is a brief defect that looks like a reader error.
- **`author-error`**: you were wrong and the agents were right. **A pilot that never returns it is
  a pilot measuring obedience.**

```json
{"round": 1, "problem": "allocation", "field": "discriminator",
 "kind": "frame-ambiguous|cell-spans-two-problems|reader-error|author-error",
 "caused_by": ["sub/S07", "..."], "was": "...", "now": "...",
 "why": "two of three readers put a rota post under division because the test said nothing about
         whether a named person was being asked"}
```

**An edit with no `caused_by` is not allowed.**

## 6. Stopping

Run rounds until **one of**: a round produces no brief edit; fidelity clears a threshold you
declared in `notes-13.md` before round 1; or **four rounds**.

**Never make a boundary decide by defining one side out of existence.** Narrowing a problem until
almost nothing qualifies raises fidelity here and makes that problem's prevalence wrong everywhere
after. **Watch the base rate of all four across rounds and report it.**

## 7. The gold set, and the freeze

**Draw a second sixty by the same rule, classify them yourself into `gold_cells.jsonl` with your
`why` and your `confidence`, and show them to no pilot agent.** Freeze the brief as `crossing_brief_final.md`. **Once, at
the end**, run one round of fresh agents on the gold set against the frozen brief, recorded in
`crossing_pilot_rounds.jsonl` with `"gold": true`: fidelity close
to the last pilot round means the brief got clearer; **much worse means the brief got fitted to
sixty cells.**

**Throughout stage 14** the gold cells are seeded, unannounced, into the live batches at a declared
rate; stage 14 says how. **Declare the policy, never the items**: `notes-13.md` says how many gold
cells exist, the seeding rate, and that they are seeded.

**Gold fidelity is a trend against this stage's frozen figure, not a level**, and one clause says
so wherever it is reported: the set was drawn hard by §2's rule, so it reads low against ordinary
cells, and it is agreement with your own pilot judgement, so a brief that carries a wrong rule
faithfully scores well.

## 8. What the figures license

Fidelity bounds how faithfully the brief transmits your judgement to a reader who has only the
brief, not whether that judgement is right, and the fleet is no independent check on you. **Say so
wherever a fidelity or agreement number appears, in the contract's §7 words.**

## 9. `crossing_pilot_report.md`

- The rounds, with fidelity and pairwise agreement side by side.
- Every brief edit, grouped by problem, with the disagreement that caused it.
- The gold figure beside the last pilot figure, and what the gap means.
- **The `author-error` verdicts, listed.**
- The base rate of all four problems across rounds.
- Which predicted confusions were real.
- What it cost: agents, cells, tokens.

## Your final message

Cells in scope out of cells that exist, and what the scoping left out; rounds run; fidelity at
round 1 and at the end; the gold figure, with pairwise agreement beside it; how many brief edits
and to which fields; how many `author-error` verdicts and on which problems; whether any problem's
base rate fell while you were tightening it; your own blind re-classification score; and the one
sentence in the brief you are least confident a stranger will read the way you meant it. A return
value.

## Close

Run `python3 tools/validate.py 13 . __OUTDIR__`, paste the report into `notes-13.md`, and write
`handback-13.md` and finish `diary-13.md` with its three closing headings.

# Stage 17 — the two clusterings compared.

Input, in two batches and in this order:

1. `__OUTDIR__/clusters_members-16.jsonl`, `__OUTDIR__/composition.jsonl`, the room notes through
   `mem.py note`, and the corpus through `tools/cite_case.py` and `tools/mem.py`. Nothing else.
2. Once §1 is written and snapped: `__OUTDIR__/clusters-16.jsonl` without its `canvas` blocks
   (the harness serves it so), `__OUTDIR__/cluster_report-16.md`,
   `__OUTDIR__/community_profile.jsonl`, `__OUTDIR__/crossing.md`, `__OUTDIR__/strain.md`,
   `__OUTDIR__/reliability-15.md` and `__OUTDIR__/reliability-05.md`, the two partitions'
   reliability figures, `__OUTDIR__/cells_in_scope.jsonl` and `__OUTDIR__/crossing_final.jsonl`
   for §3's strain cross; then
   `__OUTDIR__/cluster_names-12.md`, `__OUTDIR__/clusters-12.md`, `__OUTDIR__/clusters-12.jsonl`,
   `__OUTDIR__/clusters-11.jsonl`, `__OUTDIR__/clusters_members-11.jsonl`,
   `__OUTDIR__/dendrogram-11.json`, `__OUTDIR__/dendrogram-16.json`,
   `__OUTDIR__/tier_robustness-11.md`; `__OUTDIR__/model.md` or `model.v2.md`,
   `__OUTDIR__/account.md`, `__OUTDIR__/figure.md`, `__OUTDIR__/propositions.md`,
   `__OUTDIR__/uncomposed-10.md`, `__OUTDIR__/findings.jsonl`.
3. Once every activation paragraph of §2 is written and snapped (`python3 tools/snap.py 17
   activation`): the `canvas` blocks of `__OUTDIR__/clusters-16.jsonl`, for §2's last portrait
   section and §3's last measure. You hold the six fields from stage 01 and cannot unknow them;
   what the order proves is that the paragraph the paper's discussion is built from was written
   before this stage's summary of what each cluster kept was in front of you.

The standing reads of `_head.md`, the last diary and `findings.jsonl` precede batch 1 here as at
stage 12, and what the snap at §1 proves is the same: that the names were written before this
stage's model files, cluster files and crossing files were opened, not that you were blind to
the model. Say so in `problem_cluster_names-17.md`.

Outputs: `__OUTDIR__/problem_cluster_names-17.md`, `__OUTDIR__/problem_clusters-17.md`,
`__OUTDIR__/clusters-17.jsonl`, `__OUTDIR__/comparison-17.md`, `__OUTDIR__/comparison-17.jsonl`,
lines in `__OUTDIR__/findings.jsonl`, `__OUTDIR__/notes-17.md`, and the script at
`__OUTDIR__/compare-17.py`.

Two partitions of the same rooms exist, built at different times from different coordinates: stage
11's from your own third-order tier, stage 16's from a frame the study did not build. Neither
knows the other, and each rests on a placement layer with its own reliability figure (stage 05's
and stage 15 A7's), which `comparison-17.md` prints beside the comparison so a reader sees on
what footing each partition stands. This stage describes the second and then compares the two.

## 1. Naming the problem clusters, from the members

As at stage 12: read each cluster's rooms from `clusters_members-16.jsonl` until you can say what
they have in common; name each from the members with `cite()` quotes in
`problem_cluster_names-17.md`, closed before batch 2 with `python3 tools/snap.py 17 names` and the
snap line and the last line numbers of both read logs recorded in it; then the strongest argument
that you read the name off the crossing's axes rather than the members; rename or drop what you
cannot defend from members alone.

## 2. Each problem cluster described

`problem_clusters-17.md`, one portrait per cluster, in this order: **what these rooms were up
against**, told as a narrative, a few hundred words with participants' words in it, which of the
four problems their week was about and what they were doing that the four do not name, written
before anything below; the name and the members it was read off; the problem profile from
`community_profile.jsonl`, which of the four these rooms' records carry and which they do not,
against the census, with a zero in `cells_per_problem` read under rule 6, and the cells beyond
the four counted; composition here, with every room the model could not compose named; **how this
cluster activated the model**: which chunks and dimensions the cluster's problem profile lights
up, which arrows run and which sit idle, where the loop closes if it does, and the model's account
of why rooms facing these problems organized as they did, in the model's own terms, which is the
paragraph the paper's discussion is built from, written for every cluster and snapped before
batch 3 opens; what these rooms made, the canvas block from `clusters-16.jsonl` (batch 3) read
against the narrative with the contract's §4 sentence beside it (rule 7);
one community read at length; the nearest cluster and what separates them; what would make you
doubt this is a form. If stage 16 returned the second or fourth volume verdict, say in every
portrait what the clusters track and that they are not forms.

`clusters-17.jsonl`, one line per problem cluster: `{"cluster": "QF", "name": "...", "n": 23,
"profile": {...}, "beyond_four": {...}, "composition": {...}, "uncomposed_members": [...],
"activates": ["C3", "C5", "D01"], "unmodelled": "...", "canvas": {...},
"name_defensible_from_members": true, "confidence": "..."}`.

## 3. The comparison

`compare-17.py`, declared before it runs and saved. Over the rooms in both partitions (report the
rooms in one and not the other, by name):

- **Agreement.** The adjusted Rand index and the normalised mutual information between the two
  carried cuts, against a permutation null (at least 200 replicates), with the percentile; the
  same over every pair of cuts each stage reported (2, 3, 5, 8, 12), as a table, so agreement at
  one cut is not mistaken for agreement in general.
- **Which recovers which.** The contingency table of the two partitions; for each third-order
  cluster, the problem clusters its members fall in and the best-match Jaccard; for each problem
  cluster, the reverse. A third-order cluster whose members sit in one problem cluster is a form
  the frame recognised; one spread across several is a form the frame cuts across; a problem
  cluster that gathers members from many third-order clusters is a distinction the model does not
  draw.
- **Which separates composed from uncomposed more cleanly.** For each partition, the association
  between cluster membership and stage 10's verdict (Cramér's V or the mutual information, with the
  permutation percentile), and the smallest number of clusters that hold three quarters of the
  rooms the model could not compose. Report both, side by side.
- **Where strain sits.** Cross `strain.md`'s high-splitting `(chunk, problem)` pairs against the
  cells of the rooms where the two partitions disagree; say whether the disagreement between the
  partitions falls where the frame was straining.
- **What each partition says about what the rooms made.** For each partition, the association
  between cluster membership and the canvas summary, as stages 11 and 16 computed it, side by
  side, with the permutation percentile and the contract's §4 sentence on what the canvas measures.
  Reported, not ruled: a partition that separates what rooms kept is reported as doing so and is
  not thereby the better one (rule 7).

Write it into `comparison-17.jsonl` (one line per measure: `{"measure": "...", "value": ...,
"null_median": ..., "percentile": ..., "cut_11": k, "cut_16": k}`) and `comparison-17.md`.

## 4. What the comparison decides

Say which of three, and print the numbers beside the word: **the frame recovers the model's
partition** (agreement above the null's 95th percentile, and most third-order clusters land in one
problem cluster), which is convergent evidence for both, neither having seen the other; **the frame
cuts across it** (agreement at or below the null), which is a finding about the frame, with strain
as its likeliest cause and named where it shows; **partial**, with the third-order clusters the
frame recognised and the ones it cut across named on both sides. Where stage 11 returned the
second tier-robustness verdict, the comparison is reported against a partition the study uses for
nothing, and it says so.

Then the sentence the paper needs: which of the two ways of clustering these rooms separates the
rooms the model composes from the rooms it cannot, and by how much; and what that says about
whether the four problems or the model's own constructs are the better description of how these
rooms differed.

## 5. What you must refuse to do

Do not recut anything or change the model; a difference between the partitions that looks like a
defect in a chunk goes to `notes-17.md`, `defects.jsonl` and stage 18. Do not let either
partition's size become importance. Do not let the canvas decide anything: it is projected onto
both partitions the same way and reported beside the comparison, and it is not a warrant for
either (rule 7). After this stage the five files above are not edited (rule 18); a correction is
written at stage 18 as a correction, with what showed it.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then: problem clusters named, and how many survived the members-only test; the
agreement between the two partitions with its percentile; which third-order clusters the frame
recognised and which it cut across, by name; which partition separates composed from uncomposed,
by the two numbers; what each says about what the rooms made, by the two numbers; where strain
sits against the disagreement; which of §4's three you found; how each problem cluster activated
the model, in one line each; the two snap lines, names before batch 2 and activation before
batch 3; what the problem clusters showed that the room notes did not predict; the most
consequential difference between the two ways of cutting these rooms; and which of the
contract's §3 method licences you exercised here and which not. A return value.

## Close

Run `python3 tools/validate.py 17 . __OUTDIR__`, paste the report into `notes-17.md`, write
`handback-17.md`, and finish `diary-17.md` with its three closing headings.

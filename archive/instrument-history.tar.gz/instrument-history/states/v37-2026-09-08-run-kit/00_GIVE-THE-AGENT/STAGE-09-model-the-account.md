# Stage 09 — the model: the account.

Input: `__OUTDIR__/model.md` or `model.v2.md`, `__OUTDIR__/edges.jsonl` or `edges.v2.jsonl`,
`__OUTDIR__/structure.md` or `structure.v2.md`, `__OUTDIR__/chunks.jsonl` and
`__OUTDIR__/dimensions.jsonl` (always the current files), `__OUTDIR__/edges_dimension.jsonl`, `__OUTDIR__/concept.md` or `concept.v2.md`,
`__OUTDIR__/literature.md`, `__OUTDIR__/v2_manifest.txt`, read first: wherever stage 08 wrote a
`.v2`, read the v2 and say so, since `edges.v2.jsonl` carries the mechanisms its pass 2 supplied,
which the propositions run on; `__OUTDIR__/findings.jsonl`, `__OUTDIR__/within_case.md`, the last
`__OUTDIR__/story-pN.md`, the room notes through `mem.py note`, `tools/counts.py` for the analysed
set, the corpus through `tools/cite_case.py`, and the store through `tools/mem.py` (`codes
--theme`, `where`, `pairs`).

Outputs: `__OUTDIR__/account.md`, the final version of the model's explanation;
`__OUTDIR__/sketches.md`; `__OUTDIR__/account_passes.jsonl`; `__OUTDIR__/author_claims.jsonl`;
`__OUTDIR__/reader_round.md` with `__OUTDIR__/reader_round.jsonl` beneath it;
`__OUTDIR__/propositions.md`; `__OUTDIR__/data_structure-09.md`, the display re-emitted from the
final tiers, stage 07's `data_structure.md` standing untouched; `__OUTDIR__/gioia_table.md`;
`__OUTDIR__/figure.md`; the `run_manifest.json` append; `__OUTDIR__/notes-09.md`; and, wherever
this stage recuts a tier under rule 11, the last stage that may, lines in
`__OUTDIR__/tier_history.jsonl` and in `chunks_log.jsonl` or `dimensions_log.jsonl`.

A cut can still move here; test every one you suspect, while the account is open. **This is the
last stage before the model and the tiers are fixed.** After it nothing below the model moves
except as a recorded amendment (rule 11), and stages 10 to 17 measure against it. If a proposition
will not state because a chunk is wrong, move the chunk now, logged as stage 07 says, re-placing
what the amendment touches yourself and redrawing whatever depended on it.

Write sections 1 to 5 before section 6, and 6 before 7 and 8: the display and the figure are drawn
from the model that survives the account and the readers, not from the one you began with.

## 1. Write the model as prose, before you draw anything

`account.md` is the model in continuous prose, one to two pages: how organizing came about in
these rooms and how the parts worked together, written so a reader who has not seen the corpus can
follow it once through and say what it claims. It describes the universe, not the mode: read it
against a room you know is odd and make it say what happened there as one way of running the same
structure; every element should have a range. The last story of stage 07 is its first draft, and
the rooms that story could not tell are its first test. Name every community the account cannot
reach, one clause each; stage 10 composes them anyway and stage 12 reads them inside their clusters.

Three things this catches. A model you cannot write as prose is a taxonomy with arrows added; if
every paragraph is *and also*, say so. An arrow that will not survive being stated as *when X, Y
follows, because Z* is not grounded, whatever `edges.jsonl` says. A claim you can only state with
a hedge is two claims or none: where you write *tends to* or *in some communities*, name the
condition or take the first horn (rule 16).

**The prose test on the names.** Every chunk and dimension is a construct declared at stage 07
(borrowed / adapted / coined). Write one sentence per construct in which the name does theoretical
work: *because the room had X, Y could happen*. A name that only labels the sentence's subject and
does no work in it is a description one tier too high; recut it now, under rule 11, and keep the
grounded phrase as the gloss. A name that a reader will mistake for its `mistaken_for` construct
without being told is a name that needs its difference stated in the account.

## 2. Draw it more than one way

`sketches.md`: at least three arrangements of the same model, each with a paragraph on what it
showed and what it hid; by time on the canvas clock, by tier (conditions above, mechanisms in the
middle, what follows below), by trajectory (one room's path, then a second whose path differs). If
two drawings put the same theme in different places, that theme is doing two jobs and is a
candidate for a recut. Working sketches; §8 specifies the figure.

## 3. Simplify, and say what it cost

Cut the model to what a reader can hold, about eight things. For every element cut: what it was
doing and what the model can no longer account for without it. For every element kept over an
alternative: which alternative and why.

## 4. Recut when the account says to

Rule 11 governs, and a recut here is the ordinary outcome. Keep the construct declaration current
with every recut, and re-examine every `findings.jsonl` line it touches (rule 14). Before pass 1,
write what would make you prefer a later account to this one; a criterion written after the passes
exist is not a criterion.

**A counterexample bounds before it removes.** When a room contradicts an element or an arrow,
write the condition that room names into the account and into `findings.jsonl` (`status:
bounded`, the room as the case that bounds it) before you consider withdrawing anything. Withdraw
only where no condition you can state separates the rooms; say in `findings.jsonl` what changed
it.

## 5. Three readers

Append this stage's entry to `run_manifest.json`. Then, in this order:

1. Write `author_claims.jsonl` first: five to nine lines, each one claim you believe `account.md`
   makes, in a form a reader could agree or disagree with: `{"id": "c3", "claim": "...",
   "where": "paragraph 4"}`.
2. Three fresh readers get `account.md` and nothing else. Each returns one line into
   `reader_round.jsonl`: `{"reader": "r1", "round": 1, "served": "<sha256 of account.md>",
   "claims": ["..."], "relations": ["E1 acts on E4"], "could_not_follow": ["quoted"],
   "unsupported": "..."}`, five to nine claims in their own words.
3. Score fidelity both ways: your claims each reader recovered, and claims they recovered that
   you did not write. A claim all three found that you never intended is the account teaching
   something unintended.

Every divergence is a defect in the account, not the reader; `author-error` is a permitted verdict.
Revise and run again, as §10's passes allow; report both rounds. Nothing a reader says changes an
edge's grounding. The readers are not judges (rule 13): they tell you whether the account carries
what you meant, and nothing else about it.

4. **A fourth reader asks whether it is true of the rooms.** Before the round, name three rooms
   in `notes-09.md`: one the account reaches easily, one the last story could not tell, one from
   the side of the contrast the account has visited least. The reader gets `account.md` and
   those three rooms through `tools/mem.py` (`room` served `--no-canvas`) and `tools/cite_case.py`
   (forests, codes, cases; not your notes), and is asked, room by room, whether the account describes what happened there
   and, where it does not, what the room did instead. Its line in `reader_round.jsonl` carries
   `"rooms": [...]` and one paragraph per room. Rule 13 decides what it changes: an error is
   fixed; a room the account does not describe is a bound written at §4 or a residue named for
   stage 10, and a disagreement about how to tell it is printed beside the account.

## 6. The propositions

**A proposition here can carry a number**: a claim of the form *authority is claimed and no dated
consequence of it appears anywhere* is answerable against 300 case files, whichever way the count
comes out.

Write the propositions the model implies, **numbered P1…Pn** (a `### Pn` heading each), into
`propositions.md`: the figure in §8 tags arrows with these numbers and stage 12 records which of
them hold in each cluster, so an unnumbered proposition cannot be referenced. For each:

- **The claim**, in one sentence, in the model's own terms.
- **The mechanism**, carried up from the edge that grounds it and marked `from-literature` where
  stage 08 supplied it. A proposition without a mechanism is a pattern. **Where the proposition
  sits at the dimension tier and the edge that grounds it sits at the theme tier, say so**, and say
  whether every theme-level edge beneath it shares that mechanism; if not, narrow the proposition
  to the subset that does, or drop it.
- **The evidence in this corpus**, with its count, its gate, and the contract's §4 warning where
  the count is an absence. Rule 6 governs every absence: say how many communities could have
  carried the thing before you say it is missing from any of them.
- **Whether the arrows beneath it are observed or theorised.** A proposition resting wholly on
  `analyst_inference` edges is a conjecture drawn from the data structure; writing one is
  legitimate. Mark it.
- **What would falsify it in a population that is not this one.**
- **Where it should not hold**: the boundary, stated in the constructs the model is built from.
  Corpus size, subreddit topic and which 300 you were handed are limits on the sample, not
  boundary conditions; a boundary that names a surface feature of the setting is not one.

**Do not write more than the model earns**: four defensible propositions are better than a dozen
padded ones. **A thin claim is made and labelled thin**, with what it would take to firm it up;
*the evidence is weak, but the difference was large and the record suggests why* is preferred to
silence.

**A proposition that says a problem was solved is a claim, not a report.** The crossing runs after
this stage, so a proposition about task division, task allocation, reward provision or information
provision is stated from your structure; stage 15 reads it beside what the crossing found. Write it
so that it can fail.

## 7. The data structure, final: `data_structure-09.md` and `gioia_table.md`

Nothing is moving now, so **re-emit the display in full as `data_structure-09.md`** from the tiers
as they finally stand, all five of them, and then build the table.

**`gioia_table.md` is the figure this method is named for**, and it is a table rather than a nest.
Four columns, not the published figure's three, because the third-order tier is the level the
argument is made at; one row per third-order chunk at minimum, more where a chunk needs them:

| representative material | second-order theme | third-order chunk | aggregate dimension |
|---|---|---|---|
| the participant's words | the theme placed on | the chunk it feeds | the dimension it feeds |

**The leftmost column is material, never a label you wrote.** Where a quote will not carry a row on
its own, use the coder's case-theme label and say so in the cell. **Every row's quote carries its
metadata**, in the row or in a footnote keyed to it: community, author handle as the record carries
it, `created_utc` and hours since the canvas opened, and the code id. **And carry the residue**:
below the table, name the second-order themes no chunk picked up, with the general account from
`structure.md` and one of its quotes. **Keep it to what one person can read**: representative rows
chosen to show the range rather than the centre, with the chunk explanations in `structure.md`
carrying the rest.

## 8. The figure

One figure, taken in at one pass.

- **About eight things and the arrows among them**, the size §3 reduced the model to.
- **Every arrow is tagged `**Pn**` with the number of the proposition that carries it. An arrow no
  proposition carries is not drawn.**
- Conditions on one side, what follows on the other, and **things named for what they do in the
  middle**, the mediators. If the figure has no middle column, say so: a two-column lattice with
  tagged arrows is a taxonomy, and a reader should be told which they are looking at. Show loops as
  loops, and only the loops stage 07 confirmed ran the whole way round inside at least one
  community.
- The imposed terminus belongs in the picture: placement stopped at hour 73 for everyone.

`figure.md` specifies the figure precisely enough that someone else could draw it: every box, every
arrow, what each arrow is grounded in, the instance shown for it (the quote or the forest
transition from its edge's `support` or `support_transition`, so that the arrow is a thing that
happened and not a line), its proposition number, and the community count on it. An arrow with
no instance is not drawn (the contract's §3). It is a specification, not an image. Then, in one paragraph, **what the figure leaves out**: the edges
no proposition carried, the themes the model does not use, the register the topic-based tier
scattered.

## 9. Transferability

Say what carries. These are rooms with no legal form, no money and no way of compelling anyone,
running for four days on a schedule set outside them, where failure does not dissolve the room.
Name the settings where those conditions hold. Then name the settings where they plainly do not,
the more useful half, say what the model would predict there, and say why you cannot check it.
Then the sampling frame, once, plainly: these 300 are the **smallest** communities in the census by
corpus size, and whatever the model says, it says about small rooms.

## 10. The passes

One line per pass in `account_passes.jsonl`:

```json
{"pass": 2, "t": "<ISO>", "what_changed": "one clause",
 "tier_events": ["<ids from tier_history.jsonl>"],
 "sketches_tried": 3, "elements_cut": ["..."],
 "criterion_says": "prefer|reject|no change"}
```

Stop when a pass changes no element and no cut. No cap; from pass 4 on say in `notes-09.md` what
the criterion says about each.

## 11. Where the model should fail

Name the conditions under which the model should hold and should break, in the things the model is
built from. Corpus size, subreddit topic and which 300 you were handed are limits on the sample and
do not count here.

## 12. What you may not do, and what the canvas is here

You may not read the crossing; if the account claims which of the contract's §1 four problems
your structure reaches richly and which thinly, that claim is stage 08's fourth pass restated,
and stage 15 reads it beside strain. You may not cluster anything; that is stage 11.

The canvas is data, not a warrant (rule 7). The account may say, in one paragraph, what the model
implies about what a room keeps on the canvas and why, in the model's terms; stage 12 reads that
paragraph against the canvas stage 11 projected onto the clusters. The paragraph says whose pixels
it is about: most of a room's artwork was placed by people who never wrote in the room (stage 01
reported the share, `px_by_window_members` against `px_in_region_any`), so a claim about what the
room's members kept and a claim about what survived on the room's patch are two claims, and the
paragraph makes one of them by name or is not written. It may not be built from the canvas: no
element is cut, kept or named because of what a room drew, and no proposition takes the canvas as
its evidence.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then: passes run and what each changed; arrangements drawn and which the account
rests on; what you cut and what the model can no longer account for; tier events by tier, and
whether any second-order recut moved case themes; constructs recut by the prose test; the readers'
fidelity both ways, both rounds; the criterion and what it says about the pass you kept; how many
propositions, how many marked thin, how many rest wholly on theorised edges, how many carry a
mechanism marked `from-literature`; how many things and how many arrows in the figure, how many
arrows show a quote and how many a transition, and how many edges it dropped; what the fourth
reader said of its three rooms; the claim you most expect the crossing to contradict; what the
account showed that the room notes did not predict; the sentence in `account.md` you are least
sure a reader will take as meant; and which of the contract's §3 method licences you exercised
here and which not. A return value.

## Close

Run `python3 tools/validate.py 09 . __OUTDIR__`, paste the report into `notes-09.md`, write
`handback-09.md`, and finish `diary-09.md` with its three closing headings.

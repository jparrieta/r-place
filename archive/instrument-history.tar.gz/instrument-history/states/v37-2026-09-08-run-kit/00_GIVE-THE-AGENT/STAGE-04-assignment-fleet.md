# Stage 04 — assignment: the fleet.

Input: the frozen `__OUTDIR__/scheme_final.jsonl` with `__OUTDIR__/families.jsonl`;
`__OUTDIR__/gold_items.jsonl`, which you seed
and never show; `__OUTDIR__/exemplar_candidates.jsonl` for the exemplar arm;
`__OUTDIR__/notes-02.md` for the bag ranking; `__OUTDIR__/notes-03.md` for the gold seeding rate
and the batch cap; `tools/counts.py` for the analysed set; the corpus through
`tools/cite_case.py`; and the store through `tools/mem.py` (`theme`, `codes --sub`).

Outputs: `__OUTDIR__/batches-04.jsonl`, `__OUTDIR__/assign_raw.jsonl`,
`__OUTDIR__/assign_pass2.jsonl`, `__OUTDIR__/multiplacement_log.jsonl`,
`__OUTDIR__/multiplacement_register-04.md`, `__OUTDIR__/fidelity-04.md`,
`__OUTDIR__/agent_report-04.md`, `__OUTDIR__/notes-04.md`, and an appended entry in
`__OUTDIR__/run_manifest.json`.

You do not assign anything here. **You design the allocation, run the fleet, and report what the
fleet did as a population.** The placements are stage 05's material.

## 1. What each agent gets, and what it must not get

**Gets:** rule 0, stated first, in the contract's wording and not restated in other words;
`scheme_final.jsonl` with `decide_when_both` served, as an index page (every family, every
theme's name and gloss) read whole and one file per family opened as the agent needs it, so that
a scheme of hundreds costs each agent the index and the families its items reach, not the whole;
its batch of case themes, each with the
coder's label, the `theme_note`, and every code beneath it with participants' words; **the sibling
block** for each community in the batch; and, in the exemplar arm, the exemplars.

**The sibling block** introduces each community once, at the top of the batch, by the **labels**
of all its case themes: labels only, not their `theme_note`s, not the chronology, not the coder's
account. In the batch header, never on the item.

**Must not get:** any other agent's output; the corpus beyond its own items;
`package/case_facts.jsonl`; your room notes (`__OUTDIR__/rooms/`), the running file or
`findings.jsonl`; or any indication of how many items it holds relative to the whole.

**Every agent runs in a fresh context.**

## 2. The allocation: whole communities, crossed with agents

**Every community of the analysed set is in the fleet, with every one of its case themes. Each
agent gets whole communities, no community is ever split, and each community's replicates land on
different agents.** Randomise which communities an agent holds, never which items. The allocator
packs whole communities greedily to the item cap and computes the fleet from its own packing, never
from `ceil(items / cap)`; `agents = batches × R`.

**Before launch, assert from the batches** that the union of communities across them is the
analysed set and the union of items is `tools/counts.py`'s `assignment_items_expected`. A coverage
claim computed from the draw rather than from the batches cannot fail.

**Two gates run before any agent does.**

1. **No community may meet the same agent twice.** Reject and redraw on collision.
2. **The community–agent graph must be one connected component.** Build the bipartite graph of
   communities against batches, walk it, and refuse to launch if it is in pieces; redraw on failure.

Declare in `notes-04.md`, before any agent runs:

- **the seed**, from which the allocation is reproducible;
- **the item cap per batch**, fifty by default (about 35k tokens of context before the scheme),
  and its reason, costed with the index page and the families a batch's communities are likely to
  open; and the whole fleet's cost from that, against the ceiling the operator wrote for this
  stage (the contract's §6), with where the fleet stops if it exceeds it;
- **the replication factor** `R`, which is 2: two readers make a disagreement visible, and stage
  05 rules on it; a third reader costs half the fleet again to turn a disagreement into a vote,
  and rule 13 says a vote is not a warrant. Say so, and say what a higher `R` would have bought;
- **the gold seeding rate**, restated from `notes-03.md`, and the gold policy of this file's §9;
- **the batch count and agent count** the allocator computed;
- **the exemplar split**, which is within agent;
- **the bag flags**: the top ten from `notes-02.md`, marked in the batch, instruction unchanged:
  *assign from the codes, not from the coder's grouping*.

**Append this stage's entry to `run_manifest.json` at launch**, on stage 01's schema: the model
the agents ran under, the seed, the decoding settings, and `n_agents` at `R`.

`batches-04.jsonl`, one line per batch; gold tags, duplicate tags and re-issues go on it too:

```json
{"batch": "B017", "agent": "a017", "n_items": 48, "replicate": 2,
 "communities": ["...", "..."], "exemplar_items": ["sub/case_theme", "..."],
 "gold_items": ["sub/case_theme"], "duplicate_items": ["sub/case_theme"],
 "reissue": 0, "original_agent": null,
 "seed": 20260827, "items": ["sub/case_theme", "..."]}
```

## 3. The exemplar arm

**Split the arm inside each agent's batch**, half the items with exemplars and half without, never
whole agents in one arm. Draw the exemplars from `exemplar_candidates.jsonl`. An agent told it may
consult a sheet may never open it, so the exemplar half of the return line carries
`exemplar_read: true|false` per item and the arm is reported conditional on it. Without that field,
report no exemplar result at all.

## 4. The shuffle and the position curve

**Items are interleaved across communities in random order inside every batch.** Grouped by
community, position tracks community and the curve below is confounded with what it exists to be
free of.

**The position curve is the drift check, pooled across the whole fleet.** Regress the
multi-assignment rate and the arguable rate on position within batch, with batch fixed effects.
Report a curve by decile of position with a fitted slope and an interval as the test, and the
multi-assignment rate as a distribution over agents beside it. A position effect means a
convention is forming inside the batch and fifty is too long; no position effect is the fleet's
central claim. **Compute the curve's power at your own arguable rate
before you rely on a null from it, and report what it came to.** No compliance check can catch a
convention forming where the scheme stated none: a within-batch trend is a finding about the
declaration, and it goes in `defects.jsonl`.

**If a single agent is far out of line, the fix is not a bigger batch** but a warm-up block that
does not count: ten declared items with the answers given, then the fifty that do. Hold it in
reserve until the measurement says it is needed.

## 5. Before the first placement

**Each agent writes which pair of themes it expects to find hardest to tell apart, before it
places anything.** One line, into `agent_report-04.md` and onto the batch record:

```json
{"agent": "a017", "predicted_confusion": ["S07", "S11"], "why": "one sentence"}
```

Score it against what actually divided the agents, as the pilot scores `confusions.md`.

## 6. Two passes, and the second never overwrites the first

**Every agent makes a second pass over its own batch after finishing it, and both are kept.** The
revision rate between them is within-batch formation measured a second way. Pass 2 goes to
`assign_pass2.jsonl` and never back into `assign_raw.jsonl`; every pass-2 line names the pass-1
line it revises. A revision is a record, not a correction. **Stage 05 adjudicates pass 1**: pass
2's answer depends on what else was in the batch, so a different seed would give a different
corpus.

## 7. The line an agent returns

```json
{"sub": "...", "case_theme": "...", "batch": "B017", "agent": "a017", "replicate": 2,
 "position": 23,
 "second_order": ["S07"], "multi": false,
 "why": {"S07": "what about THIS theme put it here rather than its nearest neighbour"},
 "confidence": "clear|arguable",
 "read": "whole|theme-block",
 "exemplar_read": null,
 "families_opened": ["G03", "G09"],
 "bag": false,
 "t_start": "...", "t": "...",
 "support": ["c0013"]}
```

`second_order` carries one id in the ordinary case, and the first id is always the primary.
`families_opened` names the families the agent read the full tests of before placing this item;
a placement into a family the agent never opened is a placement from the gloss alone, and stage
05 reads those first.
`multi: true` requires a matching record in `multiplacement_log.jsonl`. Both timestamps: per-agent
elapsed time is what a cost estimate is built from. **`read: "label-only"` is not a permitted
value, and nothing checks it for you**; screen the returned lines for it by hand before stage 05
opens, because an agent that read only the label placed the coder's grouping, not the material.

## 8. The multiplacement log, and the register

Every placement beyond the first is written to `multiplacement_log.jsonl` **by the agent, on the
same line it places**, one record per extra theme:

```json
{"sub": "...", "case_theme": "...", "key": "sub/case_theme", "batch": "B017", "agent": "a017",
 "replicate": 2, "position": 23,
 "primary": "S07", "additional": "S11",
 "why_not_one": "what this material carries that S07's gate does not reach",
 "why_this_one": "what in the material satisfies S11's gate, and its distinct supporting code",
 "support_primary": ["c0013"], "support_additional": ["c0027"],
 "dispensable": "which of the two you would drop if forced to one, and what would be lost"}
```

Four rules on it:

- **Distinct support.** The additional theme needs its own supporting code id; the same code
  twice is the same reading twice, and is refused.
- **`why_not_one` is about the material, not the scheme.** *Both gates are satisfied* is not a
  justification, since `decide_when_both` settles that case; it must name what the single
  placement would fail to carry.
- **`dispensable` is compulsory and may not be `null`.**
- **No line carries more than three themes.** A third requires its own record and its own
  `why_not_one` against **both** the others. Beyond three, place one and record the item as
  `item-is-a-bag` for stage 05, `"bag": true` on the line.

A placement whose log record is missing or whose `why_not_one` is empty is a defect: write it to
`defects.jsonl` and reduce the line to its primary before stage 05 opens. Screen for this by hand.

**`multiplacement_register-04.md` is the fleet's record**, written by you after the fleet returns:

- **The multiplacement rate**, overall and per agent, on a funnel against batch size.
- **The pair table.** Every `(primary, additional)` pair with its count, ordered. A pair that
  recurs across many agents and communities is a boundary the scheme has not drawn; stage 06 reads
  this table first.
- **Whether the recurring pairs are the pairs the agents predicted** in §5.
- **The justifications, read.** At least thirty `why_not_one` texts across agents, each classed
  *material genuinely spans two themes*, *scheme lacks a theme for this*, *agent hedging*, or
  *restatement of both gates being satisfied*, which is a defect. Report the counts.
- **Per-theme exception load.** A theme that appears as `additional` far more often than as
  `primary` is a modifier, not a theme; stage 06 should consider folding it.
- **The empties**: the rate, and the characterisation rule 0 requires of each.

## 9. The gold items, seeded and unannounced

**Seed `gold_items.jsonl` into the live batches at the rate declared in `notes-03.md`**, shuffled
so no agent can tell a gold item from a corpus item and no two agents holding the same gold item
hold it in the same position.

- **Tagged in `batches-04.jsonl`, never in the payload.** Gold items are corpus items too, so the
  seeded copy is told apart from the live reading by `(item, agent, replicate)`, never by key.
  Report the seeded and the corpus readings of those items separately, and say in `notes-04.md`,
  before seeding, that this is the policy.
- **Excluded from every denominator downstream.** Stage 05 drops them before it writes
  `assign_final.jsonl`.
- **Scored per agent, not only in aggregate**, into `fidelity-04.md`: how many of each agent's
  gold items matched your placement, and which themes it missed on. Stage 05 reads that file and
  does not recompute it.

Read the movement against stage 03's frozen figure on the same items, not the level: the set was
drawn hard, and the figure is agreement with your own placements. **If fleet-wide gold fidelity
falls materially below stage 03's frozen figure, stop.** Payload assembly, model, batch size or
sibling block changed; say what, before restarting.

## 10. When an agent fails, and bounding the noise

A batch that comes back missing, truncated, malformed, or short of its item count is not a
disagreement and is not absorbed.

- **Check the returned line count against the batch's item count before accepting it.**
- **Re-issue the whole batch to a fresh agent id holding none of its communities**, up to twice,
  recorded in `batches-04.jsonl` as `reissue: 1` or `2` with the original agent id.
- **Re-run the connectivity check after every re-issue.**
- **If a batch cannot be filled after two re-issues**, name its communities in `notes-04.md`,
  mark them `coverage_short` in `batches-04.jsonl`, and exclude them from the variance
  decomposition. Do not fill the gap with a duplicate of an agent that already read those
  communities.

**Put one duplicate item in each batch**: the same item twice, in different positions, presented
as two items. Disagreement there is the model's sampling variability, not the scheme's ambiguity;
report the within-agent duplicate rate beside the between-agent disagreement rate.

## 11. The close-check, before stage 05 opens

This stage's record is what every later stage rests on, and the v35 analyst found its missing
`read` field at the end of the run, on every row. So `validate.py 04` checks each of these and
refuses by name what it cannot; stage 01's self-test showed each firing. Read the report rather
than trusting it, and screen the last two by hand as well, since a check reads a field and not a
reading:

- Every `second_order` id exists in `scheme_final.jsonl`.
- Every `support` id resolves in `package/codes.jsonl`.
- Every multi-assigned line names at least one distinct code per theme and has its records in
  `multiplacement_log.jsonl`.
- Line count equals items × `R`, where items is `assignment_items_expected`, with any agent
  failure named rather than absorbed.
- No agent appears in two replicates of the same item.
- The community–agent graph is one connected component, re-checked against what the fleet
  returned.
- `assign_pass2.jsonl` exists and has not been merged into `assign_raw.jsonl`.
- Every line carries `position`, and positions within a batch are a permutation of 1..n.
- Every line carries `read`, `families_opened` and both timestamps.
- No line carries `read: "label-only"`.

## 12. What you report: the fleet as a population

- **Per-agent dispersion, with the community component separated.** Community and agent are
  crossed, so fit the simplest model that estimates both variance components and report both. Put
  the per-agent figures (multi-assignment rate, empty rate, mean themes per line) on a funnel
  against batch size; an agent outside it is reading the scheme differently, and stage 05 needs
  its items named. Do not rank agents.
- **Formation, per agent.** First ten items against last ten, on arguable rate and on agreement
  with the agents holding the same communities: the diagnostic, where §4's pooled curve is the
  test.
- **Agreement.** Pairwise across replicates, corpus-wide and per theme, exact-set and Jaccard.
  Define agreement before you compute it, whether `["S04"]` against `["S04","S11"]` is agreement,
  disagreement or partial, using stage 03's definition. Report per-theme presence/absence
  agreement whatever else you report.
- **The exemplar contrast**, conditional on `exemplar_read`.
- **The position curve** of §4 and the pass-1 to pass-2 revision rate.
- **`families_opened` as a distribution**: families opened per placement, its median, and the
  share of placements into a family the agent never opened. A low median is a defect in the index
  page, since it means the glosses decided what the tests should have; write it to
  `defects.jsonl`, and stage 05 reads the gloss-only placements first.
- **The disagreement inventory**: how many items the two readers placed alike, how many they
  split, and of the splits how many differ on the primary and how many only on an additional
  theme. Stage 05's workload.
- **The coverage assertion**, computed from the batches.
- **The multiplacement register**, as its own file, referenced here.

Wherever a figure from this stage appears, say what it licenses, in the contract's §7 words. An
agent that reports the scheme did not decide is reporting a material defect, and its words belong
in `defects.jsonl` verbatim.

## Your final message

Seed, cap and `R`, and the batch and agent counts the allocator computed; confirmation from the
batches that every community and case theme of the analysed set is in the fleet; agents run and
agents failed; redraws the connectivity gate forced, and whether the graph was connected at the
end; total lines; corpus-wide and per-theme agreement, exact-set and Jaccard, with its definition;
the exemplar-arm gap; the position curve by decile with its slope, interval and computed power;
the pass-1 to pass-2 revision rate; the multiplacement rate and its
spread across agents; the three most frequent `(primary, additional)` pairs and what each says
about the scheme; how many placements you reduced to their primary; how many agents fell outside
the funnel and what they had in common; how many agents' predicted confusions matched yours; gold
fidelity against stage 03's figure; the disagreement inventory stage 05 inherits; and the single
theme the fleet handled worst. A return value.

## Close

Run `python3 tools/validate.py 04 . __OUTDIR__`, paste the report into `notes-04.md`, and write
`handback-04.md` and finish `diary-04.md` with its three closing headings.

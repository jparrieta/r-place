# Stage 10 — the model: the return to the field.

Input: the fixed model: `__OUTDIR__/account.md`, `__OUTDIR__/model.md` or `model.v2.md`,
`__OUTDIR__/edges.jsonl` or `edges.v2.jsonl`, `__OUTDIR__/structure.md` or `structure.v2.md`,
`__OUTDIR__/contrast.md`, `__OUTDIR__/chunks.jsonl`,
`__OUTDIR__/dimensions.jsonl`, `__OUTDIR__/data_structure-09.md`, `__OUTDIR__/propositions.md`;
the last `__OUTDIR__/story_rooms-pN.jsonl`, the rooms read against the last story and what each
needed; `__OUTDIR__/assignments_final.jsonl`; `__OUTDIR__/scheme_v2.jsonl`; `__OUTDIR__/findings.jsonl`;
`__OUTDIR__/rooms_index.md` and the room notes; the store through `tools/mem.py` (`room`, `forest`,
`codes --sub`, `theme`, `when`); the corpus through `tools/cite_case.py`;
`package/store/shelves/METHOD-SHELF.md`, re-read for Eisenhardt's replication logic.

Outputs: `__OUTDIR__/composition_brief.md`, frozen; `__OUTDIR__/author_compositions.jsonl`;
`__OUTDIR__/composition_raw.jsonl`; `__OUTDIR__/composition.jsonl`, the object stages 11, 12, 16, 17
and 18 consume; `__OUTDIR__/transmission-10.md`; `__OUTDIR__/uncomposed-10.md`;
`__OUTDIR__/operator_draw-10.json`; lines in `__OUTDIR__/findings.jsonl`; the `run_manifest.json`
append; `__OUTDIR__/notes-10.md`.

The model is fixed. Nothing here changes an element, an arrow, a chunk or a dimension; what a
room does to the model is recorded against the model, not absorbed into it. A change after this
stage is an amendment under rule 11, logged with what this stage showed. This is the test the loop
prepared for: stage 07 read rooms against every telling of the story, and the rooms its last story
could not tell are the first ones to watch here.

## 1. The verdict

Every room of the analysed set gets one of four verdicts, with a reason:

- **`composes`**: the model's elements, as the account states them, say what happened in this room
  from its codes and its forest, first item to last.
- **`composes-with-residue`**: the model composes the room and the room did something the model
  has no element for; the residue is named.
- **`does-not-compose`**: the model cannot say what happened in this room. The verdict always
  carries `why`, a short paragraph in the room's own terms, and `kind`, one of three:
  `outside-the-model`, the room organized and the model cannot say how, the counterexample that
  bounds the model (rule 12); `out-of-scope`, the room did not organize, or did something the
  model is not about (received the event as news, talked about another room's work, played),
  which bounds the model's scope and not its claims, and whose rooms are read together once in
  `uncomposed-10.md` because what they did instead may be a kind of its own; `too-thin`, the room
  passed the thresholds below and its record still does not show how it organized, which bounds
  the record and not the theory, read with the off-record share beside it.
- **`cannot-tell`**: too little was coded or too much went off the record for the model to be put
  to it; the two thresholds that decide this are declared in the brief before any room is read,
  from `item_coded_share` and `off_venue_mention_rate` in `rooms.jsonl`.

A verdict is one value. **Composed** means `composes` or `composes-with-residue`; **uncomposed**
means `does-not-compose`; `cannot-tell` is in neither. Composition is not a profile, a score or a
coordinate; stages 11 and 16 project it onto their dendrograms as a variable and never cluster on
it. This stage is verbal: a verdict is a reading with a reason, and no count is computed until
§7, after the last verdict is written.

## 2. Order of work

**Cost the fleet first**, in `notes-10.md`, before the brief exists and as stage 14 costs its
caps. This is whole-room reading by one agent per room, and the rooms are not small on the page:
the codes alone run from a few kB to over 200 kB per room (median about 25 kB, p90 about 90 kB),
and the forest and the case themes come on top. From the measured size of every room's payload
(`mem.py room --size` reports the bytes of the forest, the codes and the case themes), write the context per agent, the agent count at `R = 1` plus the
thirty read three times, and the total against the ceiling the operator wrote for this stage
(the contract's §6). If the total exceeds the ceiling, say before any agent runs where the fleet
stops and what happens to the rooms beyond it: composed by you from your own reading, under the
same brief, marked `read_by: author` and reported apart, chosen by a stratified rule and never
by size alone. No file in v35 costed this stage, and it was the deep pass under another name.

**The fork.** Where the operator forks the return to the field, the fork is taken as stage 09
closes: every fork holds the same fixed model and account and diverges on the thirty, the
brief, the fleet and the adjudication. `fork_comparison-10.json` sets their verdicts side by
side, room by room, and the carried fork is chosen by `RUN.json`'s rule. Forks of the loop
(stage 07) are also compared and carried here, since each ran through this stage.

**Compose thirty rooms yourself next**, drawn by a declared seed from the analysed set,
stratified on the entry-time contrast and on `item_coded_share`, into `author_compositions.jsonl`
on §3's line, before the brief exists. Then write the brief; a brief written with your own answers
in front of you is written to justify them.

**`composition_brief.md`**: the model's elements, each with the test a stranger applies to a
room's codes and forest to say it is present (from `structure.md`'s gates and the account), the
arrows as *when X, Y follows, because Z*, the four verdicts with the two thresholds, the trajectory
line, and the residue rule (name what the room did that no element covers; do not name a new
element). Nothing in it refers to a room note, a cluster or the crossing. Pilot it on five of your
thirty with fresh readers, tighten the sentences that did not decide, and freeze it as
`composition_brief.md`. Log the edits in `notes-10.md`.

## 3. The fleet

One fresh agent per room of the analysed set, `R = 1`, except the thirty author rooms, seeded
unannounced and read by three agents each. Append the manifest entry.

**Gets:** `composition_brief.md`; the room's forest (`trees/<sub>.md`), its codes with words,
its case themes with their second-order placements under `scheme_v2.jsonl`, and `mem.py room
--no-canvas`'s page: the room without its six canvas fields, because a composer who sees a large
area composes a success (rule 7 names this fleet); `tools/cite_case.py` for the room only. **Not**
the room note, the account, the propositions, your compositions, the canvas, or any other room.

**Returns**, one line into `composition_raw.jsonl`:

```json
{"sub": "...", "agent": "a112", "verdict": "composes|composes-with-residue|does-not-compose|cannot-tell",
 "kind": "outside-the-model|out-of-scope|too-thin|null", "why": "required for does-not-compose",
 "elements_present": ["E1", "E4"], "elements_absent": ["E2"],
 "trajectory": [{"element": "E1", "first_hour": 10.3, "held": true|false|"unclear",
                 "code_id": "c0013"}],
 "arrows_seen": [{"from": "E1", "to": "E4", "code_ids": ["c0013", "c0021"]}],
 "residue": "what the room did that no element covers, or null",
 "cannot_tell_under": "coded-share|off-record|both|null",
 "coded_share": 0.0, "off_record_share": 0.0,
 "reason": "one paragraph, in the brief's terms",
 "support": [{"code_id": "c0013", "quote": "..."}],
 "hard": true|false, "t": "<ISO>"}
```

`trajectory` is composition as a process: when each element first appears in the room's hours,
and whether it held to the freeze; §5a reads `held`, which no stage read in v36. `arrows_seen`
names the codes an arrow rests on in this room; an arrow with no codes in the room is not seen
there. Every quote goes through `cite()`.

## 4. Adjudication, by you

Read every return against the room; you have read every room. Rule on every `cannot-tell` and on
every return whose verdict differs from your own thirty. Write `composition.jsonl`, one line per
room of the analysed set, on the fleet's line plus `"read_by": "author|fleet|adjudicated"` and
`"changed_from": "<the fleet's verdict or null>"`. A verdict you change carries the reason.

**`transmission-10.md`**: fidelity on the seeded thirty, four rows as the contract's §7 defines
them; the row where the reader and you split and you were unsure is *the brief does not decide
this room*, reported and not revised away. The figure bounds whether the brief carries the model,
never whether the model is right.

## 5. What the verdicts do

**A room that does not compose bounds the model** (rule 16), and **a bound needs two rooms**. A
condition one room names is a description of that room: write it beside the finding it touches,
`status` unchanged, with the room as its case, and stage 12 reads the room inside its cluster.
When a second room names the same condition, the finding acquires it (`status: bounded`), with
both rooms as the cases. If no condition you can state separates a room from the rooms that
compose, say so, and the finding stands with the room printed beside it. The model is not changed
here.

**The rooms the model cannot reach are accepted, not chased.** `uncomposed-10.md`: for every
`does-not-compose` room, read it whole through its forest and write what it did in its own words,
what the model would need in order to say it, and whether the model should have that: an element
that exists for one room is a description, and the model does not take it. The `out-of-scope`
rooms are read together as well as one by one, since what they did instead of organizing may be
a kind of its own, and the paper wants to know what it was. A room that strains the model
composes with residue and says so; the residue is named, never absorbed. The list is carried to
stages 11 and 12, where these rooms are read inside their clusters, and to 18. This is
Eisenhardt's replication logic run as a census: the model is what composes the rooms it composes,
bounded by the ones it does not, and a model that composes everything by being loose is weaker
than one that composes most rooms and can say which it cannot and why.

### 5a. `held`, read

`trajectory[].held` is asked of every room and, in v36, read by nobody. Read it here, in prose,
against the two clocks of ending stage 01 reported (`onset_last_code_hour`,
`last_item_hour_in_window`): per element, which rooms had it and held it to the freeze, which lost
it before hour 73, which are `unclear`; and whether the rooms where nothing held are the rooms
whose talk ended early on either clock, or not. Rule 6 on every absence. The thirty rooms read
three times bound its noise: say how often the three readings agreed on `held`, per element,
beside the reading. This is descriptive, it changes no verdict, and it is the nearest this
instrument comes to the paper's question of what dissolved and what did not; it goes to stage 18
as a result.

## 6. The operator reads ten

Draw ten compositions by seed into `operator_draw-10.json` for the operator's own reading; the
operator's objections enter `objections.jsonl` before stage 11 opens, and are answered in
`notes-11.md` before stage 11 computes. Rule 13 decides; objections are not votes.

## 7. The counts, last

After every verdict is written and not before, `validate.py 10` computes and you read: the four
verdicts' counts over the analysed set, and `does-not-compose` by `kind`; how many rooms
`cannot-tell` fell under each threshold; the rooms stage 07's last story could not tell, and how
many of them compose now, how many do not, and whether any room that story told does not compose
here, the measure of how well the loop prepared for this test; and the composition rate of the
rooms read against a story at 07 beside the rate of the rooms never read against one, both from
the `story_rooms-pN.jsonl` files and `composition.jsonl`, the nearest the run comes to measuring
what the stories were worth. Report them in `notes-10.md`. No verdict is revisited because of a
count, and nothing here is a score: this agent theorizes in words, and a number that looks bad
is a fact to report, not a thing to fix.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then, from §7: the four verdicts' counts and the kinds of `does-not-compose`; the
two thresholds and how many rooms `cannot-tell` fell under each; fidelity on the seeded thirty,
the four rows; verdicts you changed and why, by count; residue kinds, named; the rooms outside the
model, and what each bounds, and which bounds have their second room; what `held` showed; how the
last story's misses fared and the two composition rates; what the compositions showed that the
room notes did not predict; and which of the contract's §3 method licences you exercised here and
which not. A return value.

## Close

Run `python3 tools/validate.py 10 . __OUTDIR__`, paste the report into `notes-10.md`, write
`handback-10.md`, and finish `diary-10.md` with its three closing headings.

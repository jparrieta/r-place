# Stage 14 — the crossing: the fleet.

Input: the frozen `__OUTDIR__/crossing_brief_final.md`, `__OUTDIR__/cells_in_scope.jsonl` and
`__OUTDIR__/scope-13.md` from stage 13; `__OUTDIR__/gold_cells.jsonl`, which you seed and never
show; `__OUTDIR__/notes-13.md` for the gold seeding rate; `__OUTDIR__/assignments_final.jsonl` for
the cells whose case themes were flagged `arguable`; the corpus through `tools/cite_case.py`; and
the store through `tools/mem.py` (`codes --sub`, `theme`, `where`) for each cell's codes with their
words and hours and each community's case-theme labels.

Outputs: `__OUTDIR__/batches-14.jsonl`; `__OUTDIR__/crossing_raw.jsonl`, one line per cell per
agent; `__OUTDIR__/fidelity-14.md`; `__OUTDIR__/agent_report-14.md`; `__OUTDIR__/notes-14.md`; and
an appended entry in `__OUTDIR__/run_manifest.json`.

**You classify nothing here and scope nothing.** Stage 13 froze the scope and the brief; you design
the allocation, run the fleet, seed the gold cells and report what it did. `crossing.jsonl` and
`community_profile.jsonl` are stage 15's. **The primary figure is gold fidelity to your own
answers**, not agreement between agents.

The question on this second axis is **what problem was this a solution to?** Stage 15 reads stage
08's fourth pass and stage 09's propositions beside what you find. Nothing here asks whether a
problem was settled; that is not a property of a cell (the contract's §7).

## 1. The unit is the cell, and the scope is stage 13's

A **cell** is one `(community, second-order theme)` pair; `support` names the codes that carried
the placement. Labels go on cells, never on themes or chunks: one theme can be information
provision in one room and goal work in another, and that variation is the finding.

**`cells_in_scope.jsonl` is stage 13's file. Read it; do not re-derive it and do not extend it.**
Anything it pruned can never be found here to be an organizing solution; read `scope-13.md` for
what went, and report it. The scope cannot move once this stage opens. If you find a chunk wrong,
you may not fix it: write it in `notes-14.md` and `defects.jsonl`, carry it to stage 18's audit,
and run on the scope as it stands.

## 2. The line

```json
{"sub": "<community>", "second_order": "S07",
 "division": false, "allocation": true, "reward": false, "information": true,
 "is_problem": true,
 "exception": true, "goal": false, "hard_to_place": false,
 "agent": "x041", "replicate": 2, "position": 17,
 "support": {"allocation": ["c0113"], "information": ["c0140"]},
 "why": {"allocation": "shifts who holds which row after the first overwrite",
         "information": "the coordinate post nobody updated"},
 "read": "cell|theme-block|whole",
 "t": "when you decided this line, ISO"}
```

**The four booleans are the universal problems:** task division, task allocation, reward provision,
information provision. **`is_problem`** is the contract's §7 fifth boolean: whether the material
carries an organizing problem at all. **`exception`** is repairing a solution that broke; **`goal`**
is settling what the room is for; **`hard_to_place`** means forcing it into the four took
stretching.

## 3. What each agent gets, and what it must not get

**Gets:** `crossing_brief_final.md` whole, rule 0 as the brief restates it for this axis; **the
sibling block** for each community in its batch, the labels of all that community's case themes, in
the batch header and never on the item; and its cells, each with its `support` codes in the
participants' words with their hours.

**Must not get:** `model.md` or anything of the model, the propositions, your room notes, any
chunk's name (the brief carries none, and `chunk` on a cell's line is a stage 15 field the
packet strips), any other agent's output, or the corpus beyond its own cells.
The judgement needs the brief's four definitions, the cell's codes and rule 0, and nothing else.
**Every agent runs in a fresh context.**

## 4. The fleet

**Append this stage's entry to `run_manifest.json` at launch**, on stage 01's schema: the model the
fleet ran under, the seed, the decoding settings, and `n_agents` at `R`.

**Disagreement between agents is what strain is measured from.** `hard_to_place` is not strain: it
is the reading agent's own report of finding a cell hard, a third quantity, and stage 15 keeps it
under its own name. Keep both and **report the 2×2 of agent-flagged `hard_to_place` against fleet
disagreement**. **Take the splits from `crossing_raw.jsonl`, never from the adjudicated line**,
which removes the evidence.

### Cells, whole communities per agent

Every cell in scope: the four booleans, `is_problem`, `exception`, `goal`, `hard_to_place`, one
supporting code per active flag, and one clause of `why` per active flag. No second and third
supporting codes: this is stage 15's feature matrix and it must have no holes. Same allocator as
stage 04, including both gates and the connectivity check, whole communities per agent so the
sibling block ports unchanged.

**`R = 2`.** The earlier version of this instrument required three readers here so that a split
could be told from one reader's error. At two, a split is a disagreement whose kind stage 15 rules
on by reading the cell, and two things bound how often a split is one reader's noise rather than
the frame's silence: the gold cells (§6) and the duplicate items (§5). **Report the distribution
of splits, unanimous and split, per problem, not a disagreement rate**, and the duplicate rate
beside it.

**Choose the cap rather than inheriting stage 04's fifty.** Cost caps of 30, 45, 60 and 90 into
`notes-14.md` first, from the cell count in `scope-13.md` and your measured median and p90 payload
per cell: agents ≈ cells ÷ cap, context ≈ overhead + cap × payload, total ≈ agents × context × R.
Payload per cell is small, so this stage is overhead-dominated and a larger cap is materially
cheaper; stage 04's position curve says whether fifty was too long. Set the total against the
ceiling the operator wrote for this stage (the contract's §6) and say where the fleet stops if
it exceeds it.

**Rule 0's position curve runs here too, in `notes-14.md`**: cells shuffled across communities
inside the batch, then the multi-assignment rate, cells carrying more than one universal, regressed
on within-batch position with batch fixed effects and reported by decile with its slope and
interval, as stage 04 §4 does for assignment.

## 5. When an agent fails

A batch that comes back missing, truncated, malformed or short of its item count is a failure, not
a disagreement, and is not absorbed. Check line count against item count before accepting.

- **Re-issue the whole batch to a fresh agent id holding none of its communities**, up to twice,
  logged in `batches-14.jsonl` as `reissue: 1` or `2` with the original agent id.
- **Re-run the connectivity check after every re-issue.**
- **If a batch cannot be filled after two re-issues**, name its communities in `notes-14.md`, mark
  them `coverage_short`, and drop them from the variance decomposition rather than filling the gap
  with an agent that already read them.

**Bound the noise before calling it strain.** Put **two duplicate items in each batch**, each the
same cell twice in different positions, presented as two, and report the within-agent duplicate
rate beside the between-agent disagreement rate. Twice stage 04's rate, because at `R = 2` the
duplicate rate is the floor every split is read against and one item per batch left it on a
handful of readings.

## 6. The gold cells, seeded and unannounced

**Seed the sixty cells of `gold_cells.jsonl` into the live batches at the rate declared in
`notes-13.md`**, shuffled so that no agent can tell a gold cell from a corpus cell and no two
agents hold one in the same position. **Restate the seeding rate in `notes-14.md`** beside the cap
and `R`.

- **Tagged in `batches-14.jsonl`, never in the payload**, on stage 04's batch schema
  (`gold_items`, `duplicate_items`, `reissue`, `original_agent`), with cells for items.
- **The seeded readings are excluded from every corpus denominator downstream; the cells are not.**
  Each is a cell of the analysed set and gets its adjudicated line like any other; stage 15 drops
  the readings by their tag and keeps the cells.
- **Scored per agent, not only in aggregate**, into `fidelity-14.md`: for each agent, how many of
  its gold cells matched your answer, and on which problems it missed.

Read the movement against stage 13's frozen figure, measured on the same cells, not the level: the
set was drawn hard, and the figure is agreement with your own pilot judgement. An agent whose gold
score sits far below the fleet's is reading the brief differently, and stage 15 needs to know which
cells came from it. **If fleet-wide gold fidelity falls materially below the frozen pilot figure,
stop**: payload assembly, model, batch size or sibling block changed. Say what in `notes-14.md`
before restarting.

## 7. The flag rules

**All flags empty is legal.** An empty cell is one you read and found no organizing problem in, a
different thing from a cell you did not read.

**If `exception`, `goal` or `hard_to_place` is on, at least one of the four universals must be
on.** An exception is an exception *in* something: a broken plan (division), a missed shift
(allocation), people not turning up (reward), coordinates nobody updated (information). There is no
fifth bin, and `hard_to_place` is not a way out of the four. `is_problem` true with no universal
active is the cell the contract's §7 says the four have no name for: it stays in every denominator
and enters no numerator.

**More than one universal may be on.** Every universal whose gate this cell's material
independently satisfies is active: a predicate, not a partition, rule 0's crossing scope as the
contract's §7 states it. **Declare in `notes-14.md`, before line one, that you are running it and
what you will do at a boundary.**

**Every active flag names at least one distinct supporting code.** If you cannot name one for each
you are hedging, not seeing two problems: turn off the flag you cannot support.

**`hard_to_place` is a statement about you, not the problem.** `exception` and `goal` describe the
problem's content, `hard_to_place` your confidence in the mapping; stage 15 cross-tabs them.

## 8. What you may not do here

**You may not revise the scheme, the assignments or the chunks because of what this stage shows.**
That the crossing found a theme badly cut is a finding for `notes-14.md` and stage 18's audit.
**You may not rename a theme, a chunk or a dimension because of what the crossing shows**; the
tiers are fixed, and a second-order theme never carries one of the four's names (the contract's
§1). **You may not use a count from here in the model**, fixed at stage 09.

## 9. What the figures license

None of these figures is inter-rater reliability, and none is a test of universality: gold
fidelity and pairwise agreement bound how faithfully and how stably the frozen brief transmits your
judgement, not whether the classification is right, and the counts are the fraction of coded
records a reader can map onto each problem, with no denominator of groups behind them. Write that
wherever a figure from this stage appears, in the contract's §7 words.

Beside the figures, report how much material the scoping filter removed (from `scope-13.md`) and
how often `hard_to_place` was used: a four that comes out well-covered can be made so by pruning
and by under-flagging, and a reader needs both numbers to tell.

## Your final message

How many cells stage 13 put in scope; the cap, replication factor, gold seeding rate and seed, and
whether the community–agent graph was connected; agents run, agents failed and batches re-issued;
**fleet-wide gold fidelity, and the per-agent gold scores of the three worst agents**, against the
frozen pilot figure; **the distribution of splits, unanimous and split, per problem**, with the
duplicate rate beside it; **the 2×2 of agent-flagged `hard_to_place` against fleet disagreement**;
the position curve; what the scoping filter removed and how often `hard_to_place` was used; and
the one thing about this scoping you would not defend. A return value.

**Not the four counts, not strain, not the entropy.** Those are stage 15's: they cannot be computed
until the disagreements are ruled on, and reporting them here from raw output would put two
versions of the same number in the record.

## Close

Run `python3 tools/validate.py 14 . __OUTDIR__`, paste the report into `notes-14.md`, and write
`handback-14.md` and finish `diary-14.md` with its three closing headings.

#!/usr/bin/env python3
"""packets.py — what a fleet agent is served, assembled by script so that every agent gets the
same page and nothing on it is the canvas, a room note or another agent's output (rule 7;
stage 04 §1; stage 14 §3).

    python3 tools/packets.py scheme --scheme out/scheme_final.jsonl --families out/families.jsonl \\
                                    --to out/_packets-04 [--exemplars]
        writes index.md (rule 0 first, then every family with every theme's id, name, gloss and
        tier) and one file per family, G03.md, holding each theme's full tests: must_show,
        must_not_show, decide_when_both, discriminators, varies, is_not, gate, gate_parts; the
        exemplars only with --exemplars, since whether an agent sees them is a declared condition
        of stage 04 (the exemplar arm).

    python3 tools/packets.py batch --batches out/batches-04.jsonl --batch B017 --to out/_packets-04
        writes B017.md: for each community of the batch, the sibling block (the labels of all
        its case themes, labels only), then each case theme with its label, its theme_note and
        every code beneath it with the participants' words. Items are rendered in the order the
        batch line gives them (`items`, a list of {sub, case_theme}), else every case theme of
        each `sub` in store order. Nothing from case_facts.jsonl, nothing from rooms.jsonl, no
        room note, no count of how many items the batch holds against the whole.

Stage 02 §4 says the harness assembles the index page and the per-family files from
scheme.jsonl and families.jsonl; this is that harness. It reads out/ and the store, writes under
--to, and logs nothing: the agents' reads are the analyst's to log under rule 1.
"""
import argparse
import json
import os
import sys

# Rule 0, in the contract's wording and not restated in other words (stage 04 §1). Rewrite this
# constant only when the contract's rule 0 changes, and then verbatim.
RULE0 = "Rule 0. **Single placement, exception on the record.** A case theme carries exactly one second-order theme: the one whose gate its material satisfies best; where more than one gate is satisfied, the theme's `decide_when_both` field decides. A second theme only where one cannot carry the material, and never silently: it needs its own distinct supporting code, a written `why_not_one` in terms of what the single placement would fail to carry (*both gates are satisfied* is not one), a named dispensable one, and a line in `multiplacement_log.jsonl`. Three at most; beyond three, place one and record `item-is-a-bag`. An unjustified extra is a defect, written to `defects.jsonl` and reduced to its primary. An empty stays legal and stays characterisable. The log is a measurement: recurring `(primary, additional)` pairs are boundaries the scheme has not drawn, and stage 06 reads that table first. **Scope: case-theme placement. The crossing keeps the predicate rule**: a cell may stand in more than one of the four problems, because that is what the frame claims and the crossing measures."


def jl(p):
    if not os.path.exists(p):
        sys.exit("no such file: %s" % p)
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]


def scheme(a):
    S = jl(a.scheme)
    F = jl(a.families)
    os.makedirs(a.to, exist_ok=True)
    by_id = {s["id"]: s for s in S}
    L = ["# The scheme: index", "", RULE0, "",
         "Every family below has its own file (`<family>.md`) with each theme's full tests. Read "
         "this index whole; open a family's file before placing anything into it, and record "
         "the families you opened on the line you return (`families_opened`).", ""]
    seen = set()
    for f in F:
        L.append("## %s  %s" % (f["family"], f.get("name") or ""))
        L.append("")
        for t in f.get("themes") or []:
            s = by_id.get(t)
            if not s:
                L.append("- %s  (not in the scheme file)" % t)
                continue
            seen.add(t)
            tier = " [rare]" if s.get("tier") == "rare" else ""
            L.append("- **%s**%s  %s: %s" % (s["id"], tier, s.get("name") or "", s.get("gloss") or ""))
        L.append("")
    stray = [s["id"] for s in S if s["id"] not in seen]
    if stray:
        L += ["## themes in no family", ""] + ["- **%s**  %s: %s" % (s["id"], s.get("name") or "",
                                                                   s.get("gloss") or "")
                                              for s in S if s["id"] in stray] + [""]
    with open(os.path.join(a.to, "index.md"), "w", encoding="utf-8") as fo:
        fo.write("\n".join(L))
    for f in F:
        P = ["# Family %s  %s" % (f["family"], f.get("name") or ""), "",
             "The full tests of every theme in this family. A placement rests on the gate; the "
             "discriminators say what separates this theme from its nearest neighbours.", ""]
        for t in f.get("themes") or []:
            s = by_id.get(t)
            if not s:
                continue
            P.append("## %s  %s%s" % (s["id"], s.get("name") or "",
                                       "  [rare]" if s.get("tier") == "rare" else ""))
            P.append("")
            P.append("gloss: %s" % (s.get("gloss") or ""))
            for k in ("gate", "gate_parts", "must_show", "must_not_show", "decide_when_both",
                      "varies", "is_not"):
                v = s.get(k)
                if v not in (None, "", []):
                    P.append("%s: %s" % (k, v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)))
            for d in s.get("discriminators") or []:
                P.append("vs %s: %s" % (d.get("vs"), d.get("question")))
            if a.exemplars:
                for e in s.get("exemplars") or []:
                    P.append("exemplar (r/%s, %s): %s" % (e.get("sub"), e.get("code_id"),
                                                         e.get("quote")))
            P.append("")
        with open(os.path.join(a.to, "%s.md" % f["family"]), "w", encoding="utf-8") as fo:
            fo.write("\n".join(P))
    print("index.md and %d family files in %s (%d themes, exemplars %s)"
          % (len(F), a.to, len(S), "served" if a.exemplars else "withheld"))
    return 0


def batch(a):
    rows = jl(a.batches)
    b = next((r for r in rows if r.get("batch") == a.batch), None)
    if b is None:
        sys.exit("no batch %s in %s" % (a.batch, a.batches))
    S = os.path.join(a.root, "package", "store")
    cts = jl(os.path.join(S, "case_themes.jsonl"))
    codes = jl(os.path.join(S, "codes.jsonl"))
    by_sub = {}
    for t in cts:
        by_sub.setdefault(t["sub"], []).append(t)
    code_by_id = {}
    for c in codes:
        code_by_id[(c["sub"], c["code_id"])] = c
    if b.get("items"):
        order = [(it["sub"], it["case_theme"]) for it in b["items"]]
        subs = []
        for s, _ in order:
            if s not in subs:
                subs.append(s)
    else:
        subs = list(b.get("subs") or [])
        order = [(s, t["label"]) for s in subs for t in by_sub.get(s, [])]
    os.makedirs(a.to, exist_ok=True)
    L = ["# Batch %s" % a.batch, "", RULE0, "",
         "Each community is introduced once by the labels of all its case themes (the sibling "
         "block). Then its case themes, one by one: the coder's label, the coder's note, and every "
         "code beneath it with the participants' words. Place each case theme; return one line "
         "per case theme in the form the stage gives.", ""]
    n = 0
    for s in subs:
        themes = by_sub.get(s, [])
        L.append("## r/%s" % s)
        L.append("")
        L.append("sibling block, the labels of all %d case themes of this community:" % len(themes))
        for t in themes:
            L.append("- %s" % t["label"])
        L.append("")
        for (ss, label) in order:
            if ss != s:
                continue
            t = next((x for x in themes if x["label"] == label or x["theme_id"] == label), None)
            if t is None:
                L.append("### (case theme %r not in the store)" % label)
                continue
            n += 1
            L.append("### case theme: %s" % t["label"])
            L.append("")
            L.append("note: %s" % (t.get("theme_note") or ""))
            L.append("")
            for cid in t.get("code_ids") or []:
                c = code_by_id.get((s, cid))
                if not c:
                    L.append("- %s  (code not in the store)" % cid)
                    continue
                L.append("- %s  %s" % (cid, c.get("label") or ""))
                if c.get("participant_words"):
                    L.append("    %s" % c["participant_words"])
            L.append("")
    with open(os.path.join(a.to, "%s.md" % a.batch), "w", encoding="utf-8") as fo:
        fo.write("\n".join(L))
    print("%s.md in %s: %d communities, %d case themes" % (a.batch, a.to, len(subs), n))
    return 0


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("verb", nargs="?")
    ap.add_argument("--root", default=".")
    ap.add_argument("--scheme", default="out/scheme_final.jsonl")
    ap.add_argument("--families", default="out/families.jsonl")
    ap.add_argument("--batches", default="out/batches-04.jsonl")
    ap.add_argument("--batch")
    ap.add_argument("--to", default="out/_packets-04")
    ap.add_argument("--exemplars", action="store_true")
    ap.add_argument("-h", "--help", action="store_true")
    a = ap.parse_args()
    if a.help or a.verb not in ("scheme", "batch"):
        print(__doc__)
        return 0 if a.help else 2
    if a.verb == "batch" and not a.batch:
        sys.exit("batch needs --batch B017")
    return scheme(a) if a.verb == "scheme" else batch(a)


if __name__ == "__main__":
    sys.exit(main())

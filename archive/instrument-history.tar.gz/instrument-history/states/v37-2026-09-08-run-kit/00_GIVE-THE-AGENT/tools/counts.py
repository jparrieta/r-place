#!/usr/bin/env python3
"""counts.py — the denominators, computed once.

    python3 counts.py <root> <outdir>

`<root>` is the folder you were given — the one holding `package/`, `tools/` and your output
directory. Passing `package/` itself also works.

Writes `counts.json`. Every denominator this study uses is here, computed from the package by
one script, so that two stages cannot quietly use two different numbers for the same thing.

**The rule this exists for.** A figure over the sampling frame and a figure over the analysed set
are two different figures, and every figure must say which of the two it is. Rule 4 says counts are
of communities; this says *which* communities, once, so that two stages reaching for the same
denominator cannot come away with two numbers.

Three census figures, and they are not interchangeable:

  `n_frame`     -- what the sampling frame named. Read from the package, never assumed.
  `n_analysed`  -- what stage 01 kept after the §4 screen. **Not fixed**: the analyst decides it
                   and writes `dropped.jsonl`. Until that file exists this is null, and a stage
                   that needs it before stage 01 has run is asking the wrong question.
  `n_with_codes`-- communities with at least one code. Rule 5's three numbers -- carries / had the
                   opportunity and does not / had no opportunity -- need this denominator: a
                   community with no codes at all would fall in the third for every theme.
                   Whether any community is in that position is for you to read off the output,
                   not to assume in either direction.

**Two expected-line-count figures, and they are not interchangeable either.** An assignment line
is keyed `(sub, case_theme)`, so a community with no case theme has no key and would otherwise
disappear from the assignment file entirely; the placeholder row exists for exactly that community.
A single figure covering both quantities is one a stage can take the wrong reading of without
noticing, so each is emitted under its own name with a note saying which stage wants which:

  `assignment_items_expected`
                -- distinct `(sub, case_theme)` keys in the analysed set. The fleet at stage 04
                   returns this times `R`; stage 05's `assign_final.jsonl` and stage 06's
                   `assignments_final.count.txt` each equal it exactly.
  `assignment_rows_with_placeholders`
                -- the same, plus one placeholder row per analysed community with **no case
                   theme**, so every community appears. Use it only where a file is specified to
                   carry those rows; no stage's line count is this figure.

**And every figure over the analysed set is null on the same terms `n_analysed` is.** The screen
decides which communities the figures are taken over, so before it has run there is no analysed set
for any of them to be over -- and a number printed under an analysed-set name would be a frame
figure wearing it. `assignment_items_expected` is what stages 04, 05 and 06 check their line counts
against and `n_no_codes` is what stage 16's first excluded group is read against, so a frame number
under either name is a frame number a stage will act on. Every one of them is therefore null until
`dropped.jsonl` exists, and the `frame` block below carries the same quantities under frame names,
where they are true. The caveat travels in the JSON, in `analysed_set_note`, because the shipped
copy of this file is read by stages that never saw the stdout.

Nothing here is an outcome, and nothing here can be conditioned on one: the fields named in
`CANVAS` are stripped from every record as it is loaded, before any denominator below is computed.
The strip is a guard, not a repair -- `case_facts.jsonl` as shipped carries none of them -- and it
is here so that a later build which does carry them cannot reach these counts.
"""
import json
import os
import sys

# Stripped on load under rule 7; see the module docstring. Named here only so the strip can run.
CANVAS = ("canvas_entries", "canvas_area_px", "canvas_centre",
          "canvas_ring", "canvas_artwork", "canvas_source")


def resolve_package(arg):
    """The package directory, from either the folder root or the package itself.

    `case_facts.jsonl` and `code_counts_corrected.json` live in `package/`. Taking the argument as
    the folder root and finding `package/` under it means the same second argument works here and
    for `validate.py`, and an argument with no `package/` under it is the package directory.
    """
    arg = arg or "."
    pkg = os.path.join(arg, "package")
    return pkg if os.path.isdir(pkg) else arg


def main(root, outdir):
    os.makedirs(outdir, exist_ok=True)
    root = resolve_package(root)
    facts = [json.loads(l) for l in open(os.path.join(root, "case_facts.jsonl"),
                                         encoding="utf-8") if l.strip()]
    for f in facts:
        for k in CANVAS:
            f.pop(k, None)

    dropped = []
    dp = os.path.join(outdir, "dropped.jsonl")
    if os.path.exists(dp):
        dropped = [json.loads(l) for l in open(dp, encoding="utf-8") if l.strip()]
    dropped_subs = sorted({d.get("sub") for d in dropped if d.get("sub")})

    corrected = {}
    cp = os.path.join(root, "code_counts_corrected.json")
    if os.path.exists(cp):
        corrected = json.load(open(cp, encoding="utf-8"))
    # the file is per-community: {sub: {n_codes_as_emitted, n_codes_deduped, double_emitted}}
    double_all = sum(v.get("double_emitted", 0) for v in corrected.values()
                     if isinstance(v, dict))
    kept_subs = {f["sub"] for f in facts} - set(dropped_subs)
    double = sum(v.get("double_emitted", 0) for k, v in corrected.items()
                 if isinstance(v, dict) and k in kept_subs)

    # **Everything below is computed on the ANALYSED set.**
    # Dropping a community removes it from `n_analysed` and from every figure derived from it.
    # An expected line count derived from the frame would demand lines for communities the analyst
    # dropped under §4, so it is derived from the analysed set instead. The frame figures are kept
    # alongside, named as such, because rule 4 wants both reported — but nothing derived is
    # computed over the frame.
    #
    # And whether there is an analysed set at all is `dropped.jsonl` existing. Before it does,
    # `kept` is the frame, and every figure below would go out under an analysed-set name carrying
    # a frame quantity — the substitution `n_analysed` is held null to prevent, made once per
    # figure. So they are computed here and emitted null unless the screen has run; the `frame`
    # block carries the same quantities under frame names, where they are true.
    screen_ran = os.path.exists(dp)
    kept = [f for f in facts if f["sub"] in kept_subs]

    with_codes = [f["sub"] for f in kept if (f.get("n_codes") or 0) > 0]
    no_codes = [f["sub"] for f in kept if not (f.get("n_codes") or 0)]
    null_onset = [f["sub"] for f in kept if f.get("onset_first_code_hour") is None]
    null_items = [f["sub"] for f in kept if f.get("items_in_window") is None]
    verdict = {}
    for f in kept:
        verdict[f.get("verdict")] = verdict.get(f.get("verdict"), 0) + 1
    themes = [f.get("n_themes") or 0 for f in kept]
    # The placeholder row is for a community with **no case theme** -- a community with codes but
    # no theme still owes the assignment file a row and has no `(sub, case_theme)` key to hang one
    # on. Counting communities with no *codes* instead gives the same number only while no
    # community has one without the other, and is a different predicate the moment one does.
    no_themes = [f["sub"] for f in kept if not (f.get("n_themes") or 0)]

    # Every figure taken over `kept`, in one place, so that holding them null before the screen has
    # run is one decision rather than one decision per figure. `null_onset` is counted over `kept`,
    # so its denominator is `kept` too: taking it off the frame instead subtracts analysed-set
    # nulls from a frame count and returns a number that is neither, and returns it silently.
    over_analysed = {
        "n_analysed": len(facts) - len(dropped_subs),
        "n_dropped": len(dropped_subs),
        "dropped": dropped_subs or None,
        "n_with_codes": len(with_codes),
        "n_no_codes": len(no_codes),
        "no_codes": no_codes,
        "n_codes_as_emitted": sum(f.get("n_codes") or 0 for f in kept),
        "n_codes_deduped": sum(f.get("n_codes") or 0 for f in kept) - double,
        "n_codes_double_emitted": double,
        "n_case_themes": sum(themes),
        "n_themes_zero": sum(1 for t in themes if t == 0),
        "n_themes_one_or_two": sum(1 for t in themes if 0 < t <= 2),
        "assignment_items_expected": sum(themes),
        "n_no_case_theme": len(no_themes),
        "no_case_theme": no_themes,
        "assignment_rows_with_placeholders": sum(themes) + len(no_themes),
        "verdicts": verdict,
        "null_onset_first_code_hour": {"n": len(null_onset), "subs": null_onset},
        "null_items_in_window": {"n": len(null_items), "subs": null_items},
        "onset_denominator": len(kept) - len(null_onset),
    }
    # The same quantities over the frame, under frame names. Every analysed-set figure above has
    # its counterpart here, so a run before the screen still has every number -- named as what it
    # is, where reading it cannot be mistaken for reading the analysed set.
    frame_verdict = {}
    for f in facts:
        frame_verdict[f.get("verdict")] = frame_verdict.get(f.get("verdict"), 0) + 1
    frame_no_codes = [f["sub"] for f in facts if not (f.get("n_codes") or 0)]
    frame_no_themes = [f["sub"] for f in facts if not (f.get("n_themes") or 0)]
    frame_null_onset = [f["sub"] for f in facts if f.get("onset_first_code_hour") is None]
    frame_null_items = [f["sub"] for f in facts if f.get("items_in_window") is None]
    frame_themes = [f.get("n_themes") or 0 for f in facts]

    out = {
        "built_from": os.path.abspath(root),
        "n_frame": len(facts),
        # `dropped.jsonl` existing is the signal that stage 01 ran the screen. An empty screen
        # is a legitimate result, and then the analysed set is the frame: null means the screen
        # has not run, never that it found nothing.
        "dropped_note": ("stage 01 writes dropped.jsonl under §4, empty or not. Until that file "
                         "exists n_analysed is null and no stage may substitute n_frame for it; "
                         "once it exists, an empty screen means the two are equal and that is "
                         "a result, not a missing value"),
        "analysed_set_note": ("EVERY figure named over the analysed set is null until "
                              "dropped.jsonl exists, on the same terms n_analysed is: the screen "
                              "decides which communities a figure is over, so before it has run "
                              "there is no analysed set for one to be over, and a number here "
                              "would be a frame quantity under an analysed-set name. The frame "
                              "block carries all of them under frame names, where they are true. "
                              "Null here means the screen has not run, never that the figure "
                              "came out zero."),
        "screen_has_run": screen_ran,
        "n_codes_note": ("case_facts.jsonl's n_codes is AS EMITTED. Anything weighted or "
                         "clustered uses the deduped figure. Both are reported everywhere else."),
        "code_counts_corrected": corrected,
        "code_counts_corrected_note": ("the package file verbatim, so it is over the FRAME: a "
                                       "dropped community is still in it. The analysed-set totals "
                                       "are n_codes_as_emitted and n_codes_deduped above."),
        "frame": {
            "note": "the sampling frame, before the §4 screen. Reported, never computed on.",
            "n": len(facts),
            "n_case_themes": sum(frame_themes),
            "n_codes_as_emitted": sum(f.get("n_codes") or 0 for f in facts),
            "n_codes_deduped": sum(f.get("n_codes") or 0 for f in facts) - double_all,
            "n_codes_double_emitted": double_all,
            "n_with_codes": sum(1 for f in facts if (f.get("n_codes") or 0) > 0),
            "n_no_codes": len(frame_no_codes),
            "no_codes": frame_no_codes,
            "n_themes_zero": sum(1 for t in frame_themes if t == 0),
            "n_themes_one_or_two": sum(1 for t in frame_themes if 0 < t <= 2),
            "assignment_items_expected": sum(frame_themes),
            "n_no_case_theme": len(frame_no_themes),
            "no_case_theme": frame_no_themes,
            "assignment_rows_with_placeholders": sum(frame_themes) + len(frame_no_themes),
            "verdicts": frame_verdict,
            "null_onset_first_code_hour": {"n": len(frame_null_onset),
                                           "subs": frame_null_onset},
            "null_items_in_window": {"n": len(frame_null_items), "subs": frame_null_items},
            "onset_denominator": len(facts) - len(frame_null_onset),
        },
        "assignment_items_note": ("distinct (sub, case_theme) keys over the ANALYSED set. Stage "
                                  "04's assign_raw.jsonl is this times R; stage 05's "
                                  "assign_final.jsonl and stage 06's assignments_final.count.txt "
                                  "each equal it exactly. Not a row count for a file carrying "
                                  "placeholders. Null until dropped.jsonl exists: a stage that "
                                  "checked its line count against frame.assignment_items_expected "
                                  "would be demanding lines for communities the §4 screen may yet "
                                  "drop."),
        "assignment_rows_note": ("the item count plus one placeholder row per analysed community "
                                 "with NO CASE THEME, so that every community appears. Read it "
                                 "only where a file is specified to carry those rows; no stage's "
                                 "line count is this figure. It equals the item count exactly "
                                 "while every analysed community has at least one case theme."),
        "assignment_lines_expected": ("AMBIGUOUS, so not a number: this name does not say which of "
                                      "two quantities it means. Read assignment_items_expected for "
                                      "stages 04, 05 and 07, or assignment_rows_with_placeholders "
                                      "for coverage."),
        "onset_denominator_note": ("communities in the analysed set with a non-null "
                                   "onset_first_code_hour. Null until dropped.jsonl exists, "
                                   "because until then the analysed set does not."),
    }
    for k, v in over_analysed.items():
        out[k] = v if screen_ran else None
    with open(os.path.join(outdir, "counts.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, ensure_ascii=False)

    REPORT = ("n_analysed", "n_with_codes", "n_no_codes", "n_no_case_theme",
              "n_codes_as_emitted", "n_codes_deduped", "n_case_themes",
              "n_themes_zero", "n_themes_one_or_two",
              "assignment_items_expected", "assignment_rows_with_placeholders",
              "onset_denominator", "verdicts")
    print("%-34s %s" % ("n_frame", out["n_frame"]))
    for k in REPORT:
        print("%-34s %s" % (k, out[k]))
    print("%-34s %s" % ("onset nulls", out["null_onset_first_code_hour"]
                        and out["null_onset_first_code_hour"]["n"]))
    print("%-34s %s" % ("items_in_window nulls", out["null_items_in_window"]
                        and out["null_items_in_window"]["n"]))
    # Which set the figures are over is said whenever the screen has RUN, not only when it dropped
    # something: an empty screen still fixes the analysed set, and a report that says nothing
    # leaves the reader to assume.
    if screen_ran:
        print("-- everything above is over the ANALYSED set (%d), not the frame (%d)"
              % (out["n_analysed"], out["n_frame"]))
        print("%-34s %s" % ("frame items expected",
                            out["frame"]["assignment_items_expected"]))
        print("%-34s %s" % ("frame rows with placeholders",
                            out["frame"]["assignment_rows_with_placeholders"]))
    else:
        # The frame quantities are printed under frame names rather than left out, so that a run
        # before the screen still has every number in front of it and cannot mistake which set it
        # is holding. The same sentence is in the JSON as `analysed_set_note`, because the shipped
        # copy of counts.json is read by stages that never saw this stdout.
        print("-- the section 4 screen has not run (no dropped.jsonl), so there is no analysed "
              "set and EVERY figure above is null. Null means the screen has not run, never that "
              "the figure came out zero. The frame quantities follow, under frame names:")
        for k in REPORT:
            v = out["frame"].get(k if k != "n_analysed" else "n")
            print("   frame.%-33s %s" % (k if k != "n_analysed" else "n", v))
        print("   frame.%-33s %s" % ("onset nulls",
                                     out["frame"]["null_onset_first_code_hour"]["n"]))
        print("   frame.%-33s %s" % ("items_in_window nulls",
                                     out["frame"]["null_items_in_window"]["n"]))


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".")

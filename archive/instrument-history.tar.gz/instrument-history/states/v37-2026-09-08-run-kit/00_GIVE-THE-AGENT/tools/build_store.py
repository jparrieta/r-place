#!/usr/bin/env python3
"""build_store.py — stage 00: the joined store and the forests, from the sealed package.

    python3 tools/build_store.py [--root .] [--corpora DIR] [--briefs DIR] [--min-collapse 3]
    python3 tools/build_store.py --readme-only        # rewrite README-store.md from the files

Reads package/{codes,themes,case_facts,code_defects}.jsonl and package/threads/<sub>.jsonl.
Writes, under --root:

    trees/<sub>.md               the rendered forest, one file per community
    package/forest.jsonl         every coded thread as a tree (tree_builder's dag)
    package/tree_index.json      coordinate -> item, per community, with the header counts
    package/store/codes.jsonl        every code, joined: case theme id, item, thread, author,
                                     hour since open, forest coordinate, node state, duplicate_of
    package/store/case_themes.jsonl  every case theme with its codes, items, threads, hours
    package/store/items.jsonl        every item of every coded thread, with meta when --corpora
    package/store/threads.jsonl      every coded thread: opener, hours, depth, codes, case themes
    package/store/rooms.jsonl        one line per community: case_facts joined to store counts
    package/store/briefs/<sub>.md    the pre-event brief, when --briefs holds one
    package/store/_unjoined.jsonl    every code whose item the record does not hold
    package/store/README-store.md    the dictionary, with this build's counts

Hard assertion: every code's (sub, case_theme) matches exactly one line of themes.jsonl, and
every theme's n_codes equals the codes that name it. The build stops if either fails. A code
whose item the record does not hold is not a failure of the join; it is counted, listed in
_unjoined.jsonl, and reported in the README.

Deterministic. Nothing here reads a model or an assignment file. The store is built once, before
stage 01, and never rebuilt during a run; mem.py overlays the analyst's own tier files from out/
at query time.

The canvas (instrument v37, the contract's §4 and rule 7). `case_facts.jsonl` carries no canvas
field and the store refuses to build if it does. The six canvas fields live in
`package/case_facts_outcome.jsonl` and are joined into `rooms.jsonl`, and nowhere else, by

    python3 tools/build_store.py --root . --join-canvas package/case_facts_outcome.jsonl

which the kit's build runs after the store exists. `mem.py room` shows them and `--no-canvas`
withholds them; no other store file carries them.
"""
import argparse, collections, json, os, sys, glob

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import tree_builder as tb  # noqa: E402

OPEN_UTC = 1490976000      # 2017-03-31 16:00:00 UTC, hour 0 of the window
FREEZE_UTC = OPEN_UTC + 73 * 3600
END_UTC = OPEN_UTC + 97 * 3600
CANVAS_FIELDS = ("canvas_entries", "canvas_area_px", "canvas_centre", "canvas_ring",
                 "canvas_artwork", "canvas_source")
LIMIT = "a reply is a reply: posted after, not caused by"


def jl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def wjl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def hour(utc):
    return None if utc is None else round((utc - OPEN_UTC) / 3600.0, 2)


def load_meta(corpora, subs):
    """item id -> meta, from the segment files of the named communities. Only the keys
    tree_builder carries. Missing directory -> empty dict and a note."""
    meta = {}
    if not corpora:
        return meta, 0
    files = 0
    for sub in subs:
        for p in (os.path.join(corpora, "pre", "%s_pre.jsonl" % sub),
                  os.path.join(corpora, "during", "%s_during.jsonl" % sub),
                  os.path.join(corpora, "after", "%s_after_posts.jsonl" % sub),
                  os.path.join(corpora, "after", "%s_after_comments.jsonl" % sub),
                  os.path.join(corpora, "after", "%s_after.jsonl" % sub)):
            if not os.path.exists(p):
                continue
            files += 1
            with open(p, encoding="utf-8") as f:
                for line in f:
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    iid = d.get("id")
                    if not iid:
                        continue
                    m = tb.pick_meta(d)
                    if "retrieved_on" not in m and d.get("retrieved_on"):
                        m["retrieved_on"] = d["retrieved_on"]
                    if m:
                        meta[iid] = m
    return meta, files


def threads_from_run(sub, run_dir, want):
    """Rebuild a community's coded threads from the coder's own corpus, coder_corpus.jsonl:
    the record the coder actually read, with every item's metadata. `want` is
    thread_id -> {item_id -> [code ids]} from codes.jsonl. Returns package/threads lines
    (each item carrying `meta`) and the header line of the corpus, or (None, None)."""
    p = os.path.join(run_dir, "coder_corpus.jsonl")
    if not os.path.exists(p):
        return None, None
    header, by_thread = None, collections.defaultdict(dict)
    with open(p, encoding="utf-8") as f:
        for line in f:
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if "_thread_index" in d and "id" not in d:
                header = d
                continue
            if d.get("kind") == "comment" or str(d.get("name", "")).startswith("t1_"):
                tid = tb.strip_prefix(d.get("link_id") or "")
            else:
                tid = d.get("id")
            if tid in want:
                by_thread[tid][d.get("id")] = d
    rows = []
    for tid in sorted(want):
        items = sorted(by_thread.get(tid, {}).values(), key=lambda x: x.get("created_utc") or 0)
        if not items:
            continue
        keep = []
        for d in items:
            iid = d.get("id")
            m = tb.pick_meta(d)
            if d.get("retrieved_on"):
                m["retrieved_on"] = d["retrieved_on"]
            keep.append({"id": iid, "kind": d.get("kind"), "parent_id": d.get("parent_id"),
                         "author": d.get("author"), "created_utc": d.get("created_utc"),
                         "score": d.get("score"), "title": d.get("title"),
                         "body": d.get("body") or d.get("selftext"),
                         "permalink": d.get("permalink"), "segment": d.get("segment"),
                         "codes": want[tid].get(iid, []), "meta": m})
        rows.append({"sub": sub, "thread_id": tid, "n_items": len(keep),
                     "n_items_coded": sum(1 for k in keep if k["codes"]),
                     "first_utc": keep[0]["created_utc"], "last_utc": keep[-1]["created_utc"],
                     "selected_by": "coder", "source": "coder_corpus", "items": keep})
    return rows, header


def to_builder_thread(t, meta):
    """package/threads line -> tree_builder's input shape."""
    items = t["items"]
    post = next((it for it in items if it.get("kind") == "post" or it["id"] == t["thread_id"]),
                None)
    if post is None:
        # the submission itself is outside the record (posted before the window, or removed);
        # a synthetic root carries the thread so its comments keep their coordinates
        post = {"id": t["thread_id"], "kind": "post", "author": "[submission outside the record]",
                "created_utc": t.get("first_utc"), "title": "[submission outside the record]",
                "body": "", "synthetic": True}
    th = {"thread_id": t["thread_id"], "title": post.get("title") or "",
          "selftext": post.get("body") or "", "author": post.get("author") or "[unknown]",
          "created_utc": post.get("created_utc") or t.get("first_utc"),
          "hours_since_open": hour(post.get("created_utc") or t.get("first_utc")),
          "comments": []}
    if post.get("score") is not None:        # the item's own score, if its meta has none
        th["score"] = post["score"]
    pm = item_meta(post, meta)
    th.update(pm)
    for it in items:
        if it is post:
            continue
        c = {"item_id": it["id"], "parent_id": it.get("parent_id"),
             "author": it.get("author") or "[unknown]", "created_utc": it.get("created_utc"),
             "body": it.get("body") or ""}
        if it.get("score") is not None:
            c["score"] = it["score"]
        c.update(item_meta(it, meta))
        th["comments"].append(c)
    return th, post


def item_meta(it, meta):
    """The item's own meta (from a run record) or the corpora's, or nothing."""
    return it.get("meta") or meta.get(it["id"], {})


def join_canvas(R, outcome_path):
    """Join the six canvas fields into package/store/rooms.jsonl, one room at a time, and record
    the join in _build.json and the README. Idempotent: a second run overwrites the same six
    fields with the same values. A room with no line in the outcome file gets the six fields as
    null, which is the frame's own statement (the contract's §4: a room with no surviving artwork
    has no row in the atlas), and is counted."""
    P = os.path.join(R, "package")
    S = os.path.join(P, "store")
    rp = os.path.join(S, "rooms.jsonl")
    if not os.path.exists(rp):
        sys.exit("no %s to join into; build the store first" % rp)
    if not os.path.exists(outcome_path):
        sys.exit("no such outcome file: %s" % outcome_path)
    out = {r["sub"]: r for r in jl(outcome_path)}
    rooms = jl(rp)
    joined = missing = 0
    for r in rooms:
        o = out.get(r["sub"])
        if o is None:
            missing += 1
            for k in CANVAS_FIELDS:
                r[k] = None
            continue
        for k in CANVAS_FIELDS:
            r[k] = o.get(k)
        joined += 1
    wjl(rp, rooms)
    bp = os.path.join(S, "_build.json")
    b = json.load(open(bp)) if os.path.exists(bp) else {}
    b["canvas"] = {"joined_from": os.path.relpath(outcome_path, R), "rooms_joined": joined,
                   "rooms_without_outcome_line": missing, "fields": list(CANVAS_FIELDS)}
    with open(bp, "w") as f:
        json.dump(b, f, indent=1, ensure_ascii=False)
    if all(k in b for k in ("open_utc", "codes", "communities")):
        write_readme(R, b)
    print("canvas joined into rooms.jsonl: %d rooms, %d without an outcome line (six nulls)"
          % (joined, missing))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--corpora", default=None, help="segment files, for item meta")
    ap.add_argument("--runs", default=None,
                    help="a directory of <sub>/coder_corpus.jsonl: the coders' own records; "
                         "where one exists the community's threads are rebuilt from it")
    ap.add_argument("--rewrite-threads", action="store_true",
                    help="with --runs: write the rebuilt threads back to package/threads/")
    ap.add_argument("--briefs", default=None, help="a directory of <sub>.md briefs")
    ap.add_argument("--min-collapse", type=int, default=3)
    ap.add_argument("--readme-only", action="store_true")
    ap.add_argument("--join-canvas", default=None, metavar="OUTCOME_JSONL",
                    help="join the six canvas fields of this file into an existing "
                         "package/store/rooms.jsonl (v37); nothing else is rebuilt")
    a = ap.parse_args()
    R = a.root
    P = os.path.join(R, "package")
    S = os.path.join(P, "store")
    os.makedirs(S, exist_ok=True)
    if a.readme_only:
        write_readme(R, json.load(open(os.path.join(S, "_build.json"))))
        return 0
    if a.join_canvas:
        return join_canvas(R, a.join_canvas)

    codes = jl(os.path.join(P, "codes.jsonl"))
    themes = jl(os.path.join(P, "themes.jsonl"))
    facts = {r["sub"]: r for r in jl(os.path.join(P, "case_facts.jsonl"))}
    defects = jl(os.path.join(P, "code_defects.jsonl")) if os.path.exists(
        os.path.join(P, "code_defects.jsonl")) else []
    subs = sorted(facts)
    for r in facts.values():
        for k in CANVAS_FIELDS:
            if k in r:
                sys.exit("rule 7: case_facts.jsonl carries %s; the store will not be built" % k)

    # --- the hard join: code -> case theme -------------------------------------------------
    theme_by_key = {}
    for t in themes:
        key = (t["sub"], t["label"])
        if key in theme_by_key:
            sys.exit("themes.jsonl: two themes share (sub, label) %r" % (key,))
        theme_by_key[key] = t
    codes_by_theme = collections.defaultdict(list)
    for c in codes:
        key = (c["sub"], c["case_theme"])
        if key not in theme_by_key:
            sys.exit("join failed: code %s/%s names case theme %r that themes.jsonl lacks"
                     % (c["sub"], c["code_id"], c["case_theme"]))
        codes_by_theme[key].append(c["code_id"])
    bad = [(k, t["n_codes"], len(codes_by_theme.get(k, [])))
           for k, t in theme_by_key.items() if t["n_codes"] != len(codes_by_theme.get(k, []))]
    if bad:
        for k, want, got in bad[:10]:
            print("n_codes mismatch %r: themes.jsonl says %d, codes.jsonl has %d" % (k, want, got))
        sys.exit("join failed on %d themes" % len(bad))
    dup_of = {}                                   # code ids restart per community: key by (sub, id)
    for d in defects:
        for s in d.get("superseded", []):
            dup_of[(d["sub"], s)] = d["keep"]
    theme_of_code = {(c["sub"], c["code_id"]): theme_by_key[(c["sub"], c["case_theme"])]["theme_id"]
                     for c in codes}

    # --- the forests --------------------------------------------------------------------------
    meta, meta_files = load_meta(a.corpora, subs)
    codes_by_sub = collections.defaultdict(list)
    for c in codes:
        codes_by_sub[c["sub"]].append(c)
    forest_path = os.path.join(P, "forest.jsonl")      # opened with "w" below: truncated, never unlinked
    index_all, counts_all = {}, {}
    item_rows, thread_rows, unjoined = [], [], []
    coord_of, state_of = {}, {}
    n_threads_in_record = 0
    thread_source = {}
    run_headers = {}
    with open(forest_path, "w", encoding="utf-8") as fout:
        for sub in subs:
            tp = os.path.join(P, "threads", "%s.jsonl" % sub)
            threads = None
            if a.runs:
                want = collections.defaultdict(dict)
                for c in codes_by_sub[sub]:
                    want[tb.strip_prefix(c["thread_id"])].setdefault(
                        tb.strip_prefix(c["item_id"]), []).append(c["code_id"])
                threads, hdr = threads_from_run(sub, os.path.join(a.runs, sub), want)
                if threads is not None:
                    thread_source[sub] = "coder_corpus"
                    run_headers[sub] = hdr
                    if a.rewrite_threads:
                        os.makedirs(os.path.join(P, "threads"), exist_ok=True)
                        wjl(tp, threads)
            if threads is None:
                threads = jl(tp) if os.path.exists(tp) else []
                thread_source[sub] = "package"
            n_threads_in_record += len(threads)
            bthreads, posts = [], {}
            for t in threads:
                bt, post = to_builder_thread(t, meta)
                bthreads.append(bt)
                posts[t["thread_id"]] = post
            p_md, dags, idx, tot = tb.run(sub, bthreads, codes_by_sub[sub], R,
                                          min_run=a.min_collapse,
                                          threads_total=facts[sub].get("threads_total"),
                                          shared=False)
            for d in dags:
                fout.write(json.dumps(d, ensure_ascii=False) + "\n")
            index_all[sub] = {"counts": tot, "index": idx}
            counts_all[sub] = tot
            for tid, nodes in idx.items():
                for coord, n in nodes.items():
                    coord_of[(sub, n["item_id"])] = coord
                    state_of[(sub, n["item_id"])] = n["state"]
            # items and threads of the store
            for t in threads:
                authors, depth_by = set(), {}
                coded_hours = []
                for it in t["items"]:
                    key = (sub, it["id"])
                    st = state_of.get(key, "pruned")
                    row = {"sub": sub, "thread_id": t["thread_id"], "item_id": it["id"],
                           "kind": it.get("kind"), "parent_id": tb.strip_prefix(it.get("parent_id")),
                           "author": it.get("author"), "created_utc": it.get("created_utc"),
                           "hour": hour(it.get("created_utc")), "score": it.get("score"),
                           "title": it.get("title"), "body": it.get("body"),
                           "permalink": it.get("permalink"), "segment": it.get("segment"),
                           "codes": it.get("codes", []), "coord": coord_of.get(key),
                           "state": st, "meta": item_meta(it, meta)}
                    item_rows.append(row)
                    if it.get("author") not in (None, "[deleted]"):
                        authors.add(it["author"])
                    if it.get("codes"):
                        coded_hours.append(row["hour"])
                    c = coord_of.get(key)
                    depth_by[it["id"]] = 0 if c in (None, "0") else c.count(".") + 1
                post = posts[t["thread_id"]]
                pmeta = {} if post.get("synthetic") else item_meta(post, meta)
                cthemes = sorted({theme_of_code[(sub, cid)]
                                  for it in t["items"] for cid in it.get("codes", [])
                                  if (sub, cid) in theme_of_code})
                thread_rows.append({
                    "sub": sub, "thread_id": t["thread_id"], "title": post.get("title") or "",
                    "submission_in_record": not post.get("synthetic", False),
                    "opener": None if post.get("synthetic") else post.get("author"),
                    "opened_utc": post.get("created_utc"),
                    "opened_hour": hour(post.get("created_utc")),
                    "last_hour": hour(t.get("last_utc")), "n_items": t["n_items"],
                    "n_items_coded": t["n_items_coded"], "n_authors": len(authors),
                    "depth": max(depth_by.values()) if depth_by else 0,
                    "first_code_hour": min(coded_hours) if coded_hours else None,
                    "last_code_hour": max(coded_hours) if coded_hours else None,
                    "codes": [cid for it in t["items"] for cid in it.get("codes", [])],
                    "case_themes": cthemes, "segment": post.get("segment"),
                    "op_score": pmeta.get("score", post.get("score")),
                    "op_stickied": bool(pmeta.get("stickied")),
                    "op_distinguished": pmeta.get("distinguished"),
                    "op_flair": pmeta.get("link_flair_text"),
                    "opener_elsewhere": None, "opener_n_elsewhere": None})
    with open(os.path.join(P, "tree_index.json"), "w", encoding="utf-8") as f:
        json.dump(index_all, f, indent=1, ensure_ascii=False)

    # --- codes, case themes ----------------------------------------------------------------
    items_by = {(r["sub"], r["item_id"]): r for r in item_rows}
    code_rows = []
    for c in codes:
        key = (c["sub"], c["item_id"])
        it = items_by.get(key)
        if it is None:
            unjoined.append({"sub": c["sub"], "code_id": c["code_id"], "item_id": c["item_id"],
                             "thread_id": c["thread_id"],
                             "why": "the record holds no item with this id"})
        t = theme_by_key[(c["sub"], c["case_theme"])]
        row = dict(c)
        row.update({"case_theme_id": t["theme_id"],
                    "author": it["author"] if it else None,
                    "created_utc": it["created_utc"] if it else None,
                    "hour": it["hour"] if it else None,
                    "kind": it["kind"] if it else None,
                    "coord": it["coord"] if it else None,
                    "state": it["state"] if it else "unjoined",
                    "duplicate_of": dup_of.get((c["sub"], c["code_id"]))})
        code_rows.append(row)
    codes_by_id = {r["code_id"] + "/" + r["sub"]: r for r in code_rows}
    theme_rows = []
    for t in themes:
        ids = codes_by_theme[(t["sub"], t["label"])]
        rows = [codes_by_id[i + "/" + t["sub"]] for i in ids]
        hrs = [r["hour"] for r in rows if r["hour"] is not None]
        theme_rows.append({"sub": t["sub"], "theme_id": t["theme_id"], "label": t["label"],
                           "theme_note": t.get("theme_note"), "n_codes": t["n_codes"],
                           "code_ids": ids,
                           "items": sorted({r["item_id"] for r in rows}),
                           "threads": sorted({r["thread_id"] for r in rows if r["thread_id"]}),
                           "first_hour": min(hrs) if hrs else None,
                           "last_hour": max(hrs) if hrs else None,
                           "regrouped_from": t.get("regrouped_from")})

    # --- rooms -------------------------------------------------------------------------------
    room_rows = []
    by_sub_items = collections.defaultdict(list)
    for r in item_rows:
        by_sub_items[r["sub"]].append(r)
    notes = {}
    for sub in subs:
        f = dict(facts[sub])
        notes = {k: f.pop(k) for k in list(f) if k.endswith("_note")}
        its = by_sub_items[sub]
        coded_items = sum(1 for r in its if r["codes"])
        off = f.get("off_venue_mentions")
        off = off if isinstance(off, dict) else None      # 'unknown' in the package: not measured
        f.update({
            "threads_in_store": sum(1 for r in thread_rows if r["sub"] == sub),
            "items_in_store": len(its), "items_coded": coded_items,
            "thread_coded_share": (round(f["threads_coded"] / f["threads_total"], 3)
                                   if f.get("threads_total") else None),
            "item_coded_share": (round(coded_items / f["items_in_window"], 3)
                                 if f.get("items_in_window") else None),
            "off_venue_mention_rate": (round(sum(off.values()) / f["items_in_window"], 3)
                                       if off is not None and f.get("items_in_window") else None),
            "forest": counts_all[sub],
            "n_threads_opened_by_visitors": None, "visitor_thread_share": None,
        })
        room_rows.append(f)
    facts_notes = notes if subs else {}

    # --- briefs ------------------------------------------------------------------------------
    n_briefs = 0
    if a.briefs:
        os.makedirs(os.path.join(S, "briefs"), exist_ok=True)
        for sub in subs:
            src = os.path.join(a.briefs, "%s.md" % sub)
            if os.path.exists(src):
                with open(src, encoding="utf-8") as fi, \
                        open(os.path.join(S, "briefs", "%s.md" % sub), "w", encoding="utf-8") as fo:
                    fo.write(fi.read())
                n_briefs += 1

    # --- write -------------------------------------------------------------------------------
    wjl(os.path.join(S, "codes.jsonl"), code_rows)
    wjl(os.path.join(S, "case_themes.jsonl"), theme_rows)
    wjl(os.path.join(S, "items.jsonl"), item_rows)
    wjl(os.path.join(S, "threads.jsonl"), thread_rows)
    wjl(os.path.join(S, "rooms.jsonl"), room_rows)
    wjl(os.path.join(S, "_unjoined.jsonl"), unjoined)
    build = {
        "communities": len(subs), "codes": len(code_rows),
        "codes_duplicate_of_another": sum(1 for r in code_rows if r["duplicate_of"]),
        "case_themes": len(theme_rows), "threads_in_record": n_threads_in_record,
        "threads_with_codes": sum(1 for r in thread_rows if r["n_items_coded"]),
        "items": len(item_rows), "items_coded": sum(1 for r in item_rows if r["codes"]),
        "items_bridge": sum(1 for r in item_rows if r["state"] == "bridge"),
        "items_removed": sum(1 for r in item_rows if r["state"] == "removed"),
        "items_pruned": sum(1 for r in item_rows if r["state"] == "pruned"),
        "items_with_meta": sum(1 for r in item_rows if r["meta"]),
        "meta_files_read": meta_files, "corpora": a.corpora, "runs": a.runs,
        "threads_rebuilt_from_runs": sum(1 for v in thread_source.values() if v == "coder_corpus"),
        "threads_from_package": sum(1 for v in thread_source.values() if v == "package"),
        "rooms_from_package": sorted(s for s, v in thread_source.items() if v == "package"),
        "codes_unjoined": len(unjoined),
        "codes_unjoined_by_sub": dict(collections.Counter(u["sub"] for u in unjoined)),
        "briefs": n_briefs, "open_utc": OPEN_UTC, "freeze_utc": FREEZE_UTC, "end_utc": END_UTC,
        "case_facts_notes": facts_notes, "min_collapse": a.min_collapse,
    }
    with open(os.path.join(S, "_build.json"), "w") as f:
        json.dump(build, f, indent=1, ensure_ascii=False)
    write_readme(R, build)
    for k in ("communities", "codes", "case_themes", "threads_in_record", "threads_with_codes",
              "items", "items_coded", "items_bridge", "items_removed", "items_pruned",
              "items_with_meta", "codes_unjoined", "briefs"):
        print("%-22s %s" % (k, build[k]))
    print("store written to %s" % S)
    return 0


def write_readme(R, b):
    S = os.path.join(R, "package", "store")
    txt = """# The store — what each file is, and what none of them is

Built by `tools/build_store.py` at stage 00 from the sealed package. Read-only: nothing in a run
rewrites it. `tools/mem.py` reads it one page at a time and overlays your own tier files from
`out/` (`scheme*.jsonl`, `assignments_final.jsonl`, `chunks.jsonl`, `dimensions.jsonl`) at query
time, so a placement, chunk or dimension shown by `mem.py` is always the current one.

**The clock.** `hour` is hours since the canvas opened, %(open_utc)d UTC (2017-03-31 16:00).
Placement stopped at hour 73; the window ends at 97. Negative hours are the pre-event week.

**The limit that holds on every row that has a parent.** %(limit)s. An interval between two
posts is elapsed time, never the speed of a decision.

## Files

| file | one line per | keys |
|---|---|---|
| `codes.jsonl` | code, as emitted (%(codes)d) | the package's fields, plus `case_theme_id`, `author`, `created_utc`, `hour`, `kind`, `coord` (forest coordinate), `state` (coded / unjoined), `duplicate_of` (the code this one double-emits; %(codes_duplicate_of_another)d such) |
| `case_themes.jsonl` | case theme (%(case_themes)d) | `sub`, `theme_id`, `label`, `theme_note`, `n_codes`, `code_ids`, `items`, `threads`, `first_hour`, `last_hour` |
| `items.jsonl` | item of a coded thread (%(items)d) | `sub`, `thread_id`, `item_id`, `kind`, `parent_id`, `author`, `created_utc`, `hour`, `score`, `title`, `body`, `codes`, `coord`, `state` (coded / bridge / removed / pruned), `meta` |
| `threads.jsonl` | coded thread (%(threads_in_record)d) | `sub`, `thread_id`, `title`, `opener`, `opened_hour`, `last_hour`, `n_items`, `n_items_coded`, `n_authors`, `depth`, `first_code_hour`, `last_code_hour`, `codes`, `case_themes`, `op_score`, `op_stickied`, `op_distinguished`, `op_flair` (the submission's score at retrieval, sticky flag, distinguished status and flair), `opener_elsewhere`, `opener_n_elsewhere` |
| `rooms.jsonl` | community (%(communities)d) | every `case_facts.jsonl` field except the notes, plus `threads_in_store`, `items_in_store`, `items_coded`, `thread_coded_share`, `item_coded_share`, `off_venue_mention_rate`, `forest` (the header counts), `n_threads_opened_by_visitors`, `visitor_thread_share`; and, once the build joins them, the six canvas fields `canvas_entries`, `canvas_area_px`, `canvas_centre`, `canvas_ring`, `canvas_artwork`, `canvas_source` (%(canvas)s) |
| `transitions.jsonl` | coded turn answering a coded turn | written by `tools/transitions.py`; see its section |
| `visitors.jsonl` | thread whose opener posts elsewhere | written by `tools/visitors.py`; see its section |
| `briefs/<sub>.md` | community (%(briefs)d present) | the pre-event week, written by the brief writer before the coder read the window |
| `_unjoined.jsonl` | code whose item the record does not hold (%(codes_unjoined)d) | `sub`, `code_id`, `item_id`, `thread_id` |

## What the record holds, and what it does not

The threads here are **the threads the coders' codes point at**, with every item of each such
thread (%(items)d items in %(threads_in_record)d threads). The raw window record holds far more
and is not in the package: the coder's selection is part of the data. `rooms.jsonl` carries
`threads_total` and `items_in_window` for the whole window and `threads_coded`, `items_coded` for
what was read, and the forest header of every `trees/<sub>.md` repeats the four counts.

A thread whose submission is outside the record (posted before the window, or removed before
retrieval) is carried on a synthetic root, `submission_in_record: false` in `threads.jsonl`, so its
comments keep their coordinates; an item whose parent is outside the record is hung on the
submission and marked `[parent outside the record]` in the forest. No coded turn vanishes.

`meta` is present on %(items_with_meta)d items (%(meta_files_read)d segment files read): `score`
(kept at 0 and below), `distinguished`, `stickied`, `edited`, `gilded`, `author_flair_text`,
`link_flair_text`, `retrieved_on`. The forest shows it on every line: `↑N` the score, `⟨…⟩` the
author's flair in this community, `{…}` the submission's flair, and the marks [moderator],
[sticky@retrieval], [edited], [gilded]. The score and `stickied` are snapshots taken at retrieval,
weeks after the event: lower bounds with no timing. `distinguished` is reliable. `retrieved_on`
says when the snapshot was taken.

`off_venue_mention_rate` is the nearest the record comes to an off-record share: how often a room
said discord, irc, teamspeak or the like in the window, per item. A word said, not coordination
proved.

## What is not here

No canvas field outside `rooms.jsonl` (the contract's §4 and rule 7: the six fields are joined
there from `package/case_facts_outcome.jsonl` at build, shown by `mem.py room`, withheld by
`--no-canvas`, and never a feature). No second-order theme, chunk or dimension: those are yours,
in `out/`, and `mem.py` joins them for you. No author index beyond what `visitors.py` writes. No
interpretation.

## The notes the package carried on `case_facts.jsonl`

%(notes)s
""" % {"open_utc": b["open_utc"], "limit": LIMIT, "codes": b["codes"],
       "canvas": ("joined: %d rooms, %d with six nulls" % (b["canvas"]["rooms_joined"],
                                                            b["canvas"]["rooms_without_outcome_line"])
                  if b.get("canvas") else "not yet joined"),
       "codes_duplicate_of_another": b["codes_duplicate_of_another"],
       "case_themes": b["case_themes"], "items": b["items"],
       "threads_in_record": b["threads_in_record"], "communities": b["communities"],
       "briefs": b["briefs"], "codes_unjoined": b["codes_unjoined"],
       "items_with_meta": b["items_with_meta"], "meta_files_read": b["meta_files_read"],
       "notes": "\n".join("- `%s`: %s" % (k, v) for k, v in b.get("case_facts_notes", {}).items())}
    for extra in ("_README-transitions.md", "_README-visitors.md"):
        p = os.path.join(S, extra)
        if os.path.exists(p):
            txt += "\n" + open(p, encoding="utf-8").read()
    with open(os.path.join(S, "README-store.md"), "w", encoding="utf-8") as f:
        f.write(txt)


if __name__ == "__main__":
    sys.exit(main())

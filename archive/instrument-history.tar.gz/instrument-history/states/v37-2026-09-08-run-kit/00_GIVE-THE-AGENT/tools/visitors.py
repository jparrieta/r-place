#!/usr/bin/env python3
"""visitors.py — stage 00: the visitor layer.

    python3 tools/visitors.py [--root .] --authors authors_by_sub.jsonl

`authors_by_sub.jsonl` is Layer C's author index: one line per community of the whole census,
`{"sub", "n_authors", "hashes": [...]}`, each hash base64(sha1(username)) of every account
that posted there between the canvas opening and a week after the freeze. This tool hashes
the authors the store holds the same way and asks, for each of them, in which other
communities of the census they posted in that span.

Writes package/store/visitors.jsonl, one line per thread of the store:

    {"sub", "thread_id", "opener", "opener_known", "opener_elsewhere": [subs],
     "opener_n_elsewhere", "opener_elsewhere_in_frame": [subs of the 300],
     "coded_authors": n, "coded_authors_elsewhere": n,
     "elsewhere_named_by_room": [subs the room's coder listed as named neighbours]}

and updates two columns of package/store/threads.jsonl (`opener_elsewhere`,
`opener_n_elsewhere`) and four of rooms.jsonl (`n_threads_opened_by_visitors`,
`visitor_thread_share`, `n_threads_opened_from_named_neighbour`,
`named_neighbour_opener_share`) in place.

What it says and what it does not. An account that posted in two rooms posted in two rooms.
It is not thereby a delegate, an envoy or a raider; the room's own words decide what the
visit was, and the room note is where that is written. Deleted accounts and known bots
(AutoModerator) are `opener_known: false` and count in no denominator.
"""
import argparse, base64, collections, hashlib, json, os, sys

BOTS = {"AutoModerator", "[deleted]", None, ""}


def jl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def wjl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def h(name):
    return base64.b64encode(hashlib.sha1(name.encode("utf-8")).digest()).decode("ascii")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--authors", required=True)
    a = ap.parse_args()
    S = os.path.join(a.root, "package", "store")
    threads = jl(os.path.join(S, "threads.jsonl"))
    rooms = jl(os.path.join(S, "rooms.jsonl"))
    items = jl(os.path.join(S, "items.jsonl"))
    frame = {r["sub"] for r in rooms}

    # hash -> set of subs, over the whole census
    where = collections.defaultdict(set)
    n_index = 0
    with open(a.authors, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            n_index += 1
            for hh in d.get("hashes", []):
                where[hh].add(d["sub"])
    named = {}
    for r in rooms:
        nb = r.get("named_neighbours") or []
        named[r["sub"]] = sorted({(x.get("name") if isinstance(x, dict) else x) for x in nb} - {None})

    coded_by_thread = collections.defaultdict(set)
    for it in items:
        if it.get("codes") and it.get("author") not in BOTS:
            coded_by_thread[(it["sub"], it["thread_id"])].add(it["author"])

    out, per_room = [], collections.defaultdict(lambda: {"known": 0, "visitor": 0, "named": 0})
    own_missing = 0
    for t in threads:
        sub, op = t["sub"], t.get("opener")
        known = op not in BOTS
        elsewhere = []
        if known:
            subs = where.get(h(op), set())
            if sub not in subs:
                own_missing += 1
            elsewhere = sorted(subs - {sub})
        ca = coded_by_thread.get((sub, t["thread_id"]), set())
        ca_else = sum(1 for x in ca if (where.get(h(x), set()) - {sub}))
        row = {"sub": sub, "thread_id": t["thread_id"], "opener": op, "opener_known": known,
               "opener_elsewhere": elsewhere, "opener_n_elsewhere": len(elsewhere),
               "opener_elsewhere_in_frame": [s for s in elsewhere if s in frame],
               "coded_authors": len(ca), "coded_authors_elsewhere": ca_else,
               "elsewhere_named_by_room": [s for s in elsewhere if s in named.get(sub, [])]}
        out.append(row)
        t["opener_elsewhere"] = elsewhere if known else None
        t["opener_n_elsewhere"] = len(elsewhere) if known else None
        if known:
            per_room[sub]["known"] += 1
            if elsewhere:
                per_room[sub]["visitor"] += 1
            if row["elsewhere_named_by_room"]:
                per_room[sub]["named"] += 1
    for r in rooms:
        k = per_room[r["sub"]]
        r["n_threads_openers_known"] = k["known"]
        r["n_threads_opened_by_visitors"] = k["visitor"]
        r["visitor_thread_share"] = round(k["visitor"] / k["known"], 3) if k["known"] else None
        r["n_threads_opened_from_named_neighbour"] = k["named"]
        r["named_neighbour_opener_share"] = (round(k["named"] / k["known"], 3)
                                             if k["known"] else None)
    wjl(os.path.join(S, "visitors.jsonl"), out)
    wjl(os.path.join(S, "threads.jsonl"), threads)
    wjl(os.path.join(S, "rooms.jsonl"), rooms)
    n_known = sum(1 for r in out if r["opener_known"])
    n_vis = sum(1 for r in out if r["opener_n_elsewhere"])
    n_frame = sum(1 for r in out if r["opener_elsewhere_in_frame"])
    n_named = sum(1 for r in out if r["elsewhere_named_by_room"])
    txt = """## The visitor layer (`visitors.jsonl`)

Built against Layer C's author index (%d communities of the census, accounts that posted
between the opening and a week after the freeze). Of %d threads in the store, %d have a known
opener; %d of those openers also posted in another community of the census, %d in another of
the 300, and %d in a community the room's own coder listed as a named neighbour. %d openers
were not found in their own room's index (posted outside the index's span, or deleted since).
`rooms.jsonl` carries `n_threads_opened_by_visitors`, `visitor_thread_share`,
`n_threads_opened_from_named_neighbour` and `named_neighbour_opener_share` per room.

Most active accounts posted somewhere else in the census in those ten days, so `opener_elsewhere`
alone separates little. The two sharper columns are `opener_elsewhere_in_frame` (another of the
300) and `elsewhere_named_by_room` (a community this room's own coder listed as a named
neighbour): the second is an account that posted in a room this room was talking about.

**What this says:** an account posted in two rooms. **What it does not say:** why. The room's
words decide whether a visit was an appeal, an envoy, a raid or nothing, and that is written in
the room note, never here.
""" % (n_index, len(out), n_known, n_vis, n_frame, n_named, own_missing)
    with open(os.path.join(S, "_README-visitors.md"), "w", encoding="utf-8") as f:
        f.write(txt)
    print("threads %d, openers known %d, elsewhere %d (in frame %d, named by room %d); "
          "own-room misses %d" % (len(out), n_known, n_vis, n_frame, n_named, own_missing))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""mem.py — the store, one page at a time. Every call is logged (rule 1).

    python3 tools/mem.py <verb> [args] [--limit N] [--offset N] [--root .] [--out out] [--stage NN]

    room <sub> [--no-canvas] [--size] the room on one page: facts, threads, coded share, visitors,
                                     and what it made (the six canvas fields). --no-canvas is the
                                     page the fleets and the readers are served (rule 7); --size
                                     reports the bytes of its forest, its codes and its case themes
    forest <sub> [thread_id]         the rendered forest, whole room or one thread
    note <sub>                       your own room note, out/rooms/<sub>.md
    codes --sub S [--case-theme tNN] codes of a room, or of one case theme
    codes --theme S07                every code placed on a second-order theme (overlay)
    codes --chunk C3                 every code under a chunk (overlay)
    codes --grep <re>                codes whose label, words or note match
    theme <sub>/<tNN or label>       a case theme, its note, its codes, and where it was placed
    where S07                        every room and case theme on S07, with chunk and dimension
    after <sub>/<code_id>            what answered this code and what it answered, with intervals
    pairs --level case_theme|theme|chunk [--sub S] [--top N]
                                     transition counts from the ledger, lifted; the limit printed
    when <sub>                       the room's coded hours as one line, 4-hour bins over 0..97
    shelf [name]                     the works on the shelf, or one of them whole
    brief <sub>                      the room's pre-event week

The overlay. Placements, chunks and dimensions are yours and live in out/. mem.py reads the
newest scheme file present (scheme_v2 > scheme_final > scheme), assignments_final.jsonl (or, if
that does not exist yet, assign_final.jsonl, and says so), chunks.jsonl and dimensions.jsonl,
and joins them at query time. Nothing in package/ is ever rewritten.

Log: out/_mem_reads-NN.jsonl, one line per call. NN is --stage, else the .stage file the
harness writes in the folder root at every hand-over, else $STAGE, else "xx".
"""
import argparse, collections, datetime, json, os, re, sys



def jl(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def clip(s, n):
    s = " ".join(str(s or "").split())
    return s if len(s) <= n else s[:n - 1] + "…"


CANVAS = ("canvas_entries", "canvas_area_px", "canvas_centre", "canvas_ring", "canvas_artwork",
          "canvas_source")


def canvas_lines(r):
    """What the room made, from rooms.jsonl's six canvas fields, joined at build (the contract's
    §4 and rule 7). One line, plus the sentence a reader must see beside any canvas figure."""
    if not any(k in r for k in CANVAS):
        return ["made: (no canvas fields in rooms.jsonl; the build did not join the canvas)"]
    return ["made: entries %s  area_px %s  centre %s  ring %s  artwork %s"
            % (r.get("canvas_entries"), r.get("canvas_area_px"),
               json.dumps(r.get("canvas_centre")), r.get("canvas_ring"),
               clip(r.get("canvas_artwork"), 60)),
            "      what survived the freeze, on the smallest rooms; an outcome, never a warrant "
            "(rule 7; source: %s)" % clip(r.get("canvas_source"), 40)]


class Store:
    def __init__(self, root, out):
        self.root, self.out = root, out
        self.S = os.path.join(root, "package", "store")
        self._cache = {}

    def rows(self, name):
        if name not in self._cache:
            self._cache[name] = jl(os.path.join(self.S, name + ".jsonl"))
        return self._cache[name]

    # ---- overlay ------------------------------------------------------------------------------
    def overlay(self):
        if "ov" in self._cache:
            return self._cache["ov"]
        ov = {"scheme_file": None, "scheme": {}, "assign_file": None, "placed": {},
              "chunk_of": {}, "chunks": {}, "dim_of": {}, "dims": {}, "notes": []}
        for f in ("scheme_v2.jsonl", "scheme_final.jsonl", "scheme.jsonl"):
            p = os.path.join(self.out, f)
            if os.path.exists(p):
                ov["scheme_file"] = f
                for r in jl(p):
                    ov["scheme"][r["id"]] = r
                break
        for f in ("assignments_final.jsonl", "assign_final.jsonl"):
            p = os.path.join(self.out, f)
            if os.path.exists(p):
                ov["assign_file"] = f
                for r in jl(p):                      # last write wins on (sub, case_theme)
                    so = r.get("second_order")
                    if isinstance(so, str):
                        so = [so]
                    ov["placed"][(r["sub"], r["case_theme"])] = so or []
                if f == "assign_final.jsonl":
                    ov["notes"].append("placements are from assign_final.jsonl, the adjudicated "
                                       "line; assignments_final.jsonl does not exist yet")
                break
        for r in jl(os.path.join(self.out, "chunks.jsonl")):
            if r.get("chunk"):
                ov["chunks"][r["chunk"]] = r
                for m in r.get("members", []):
                    ov["chunk_of"][m] = r["chunk"]
        for r in jl(os.path.join(self.out, "dimensions.jsonl")):
            ov["dims"][r["second_order"]] = r
            ov["dim_of"][r["second_order"]] = r.get("dimension") or []
        if not ov["assign_file"]:
            ov["notes"].append("no placements yet: out/ holds no assignments file")
        self._cache["ov"] = ov
        return ov

    def placement(self, sub, case_theme_id):
        ov = self.overlay()
        so = ov["placed"].get((sub, case_theme_id), [])
        return [{"so": s, "name": ov["scheme"].get(s, {}).get("name"),
                 "chunk": ov["chunk_of"].get(s), "dims": ov["dim_of"].get(s, [])} for s in so]


def fmt_place(pl):
    if not pl:
        return "unplaced"
    return "; ".join("%s%s%s%s" % (p["so"], " " + clip(p["name"], 40) if p["name"] else "",
                                    " ⊂ " + p["chunk"] if p["chunk"] else "",
                                    " ⊂ " + ",".join(p["dims"]) if p["dims"] else "") for p in pl)


def code_line(c):
    # participant_words is not clipped: rule 3 requires a quote taken from this tier to be
    # verbatim, and a fleet or reader agent working from this page has no other access to the
    # untruncated text. label is a summary the coder wrote and is clipped as before.
    return "%-6s %-20s %-4s h%+7.2f %-18s @%-7s | %s | %s" % (
        c["code_id"], clip(c["sub"], 20), c.get("case_theme_id") or "?",
        c["hour"] if c.get("hour") is not None else float("nan"),
        clip(c.get("author") or "?", 18), c.get("coord") or "-",
        clip(c["label"], 60), " ".join(str(c.get("participant_words") or "").split()))


# ---- verbs ----------------------------------------------------------------------------------
def v_room(st, a):
    r = next((x for x in st.rows("rooms") if x["sub"] == a.arg1), None)
    if not r:
        return ["no such room: %s" % a.arg1]
    if a.size:
        fp = os.path.join(st.root, "trees", "%s.md" % a.arg1)
        forest = os.path.getsize(fp) if os.path.exists(fp) else 0
        codes = sum(len(code_line(c).encode("utf-8")) + 1
                    for c in st.rows("codes") if c["sub"] == a.arg1)
        cts = [t for t in st.rows("case_themes") if t["sub"] == a.arg1]
        themes = sum(len(json.dumps(t, ensure_ascii=False).encode("utf-8")) + 1 for t in cts)
        return ["r/%s  bytes: forest %d  codes %d  case themes %d  total %d"
                % (a.arg1, forest, codes, themes, forest + codes + themes),
                "(the payload one fleet agent reads at stage 10, before the brief)"]
    L = ["r/%s  verdict %s  threads %s/%s coded  items in window %s (coded %s, share %s)"
         % (r["sub"], r.get("verdict"), r.get("threads_coded"), r.get("threads_total"),
            r.get("items_in_window"), r.get("items_coded"), r.get("item_coded_share")),
         "first code h%+.2f  median h%+.2f  last h%+.2f  coded authors %s  top1 %s  herfindahl %s"
         % (r.get("onset_first_code_hour") or 0, r.get("onset_median_code_hour") or 0,
            r.get("onset_last_code_hour") or 0, r.get("coded_authors"), r.get("top1_share"),
            r.get("herfindahl")),
         "off-venue mentions %s (rate %s)  named neighbours %s (in census %s)"
         % (r.get("off_venue_mentions"), r.get("off_venue_mention_rate"),
            r.get("n_named_neighbours"), r.get("named_neighbours_in_census")),
         "visitors: threads with known opener %s, opener elsewhere %s (share %s), from a named "
         "neighbour %s (share %s)" % (r.get("n_threads_openers_known"),
                                     r.get("n_threads_opened_by_visitors"),
                                     r.get("visitor_thread_share"),
                                     r.get("n_threads_opened_from_named_neighbour"),
                                     r.get("named_neighbour_opener_share")),
         "forest: %s" % json.dumps(r.get("forest"))]
    L += (["made: withheld on this page (--no-canvas; rule 7)"] if a.no_canvas else canvas_lines(r))
    L.append("")
    th = [t for t in st.rows("threads") if t["sub"] == a.arg1]
    L.append("threads (%d):" % len(th))
    for t in sorted(th, key=lambda t: t.get("opened_hour") or 0):
        op = "↑?" if t.get("op_score") is None else "↑%d" % t["op_score"]
        if t.get("op_stickied"):
            op += " [sticky]"
        if t.get("op_distinguished"):
            op += " [%s]" % t["op_distinguished"]
        if t.get("op_flair"):
            op += " {%s}" % clip(t["op_flair"], 20)
        L.append("  %-8s h%+7.2f  %2d/%-3d coded  depth %d  %-16s %s  %s%s" % (
            t["thread_id"], t.get("opened_hour") or 0, t["n_items_coded"], t["n_items"],
            t.get("depth", 0), clip(t.get("opener"), 16), clip(t.get("title"), 60), op,
            "  [opener also in %s]" % ",".join(t["opener_elsewhere"][:4])
            if t.get("opener_elsewhere") else ""))
    L.append("")
    cts = [t for t in st.rows("case_themes") if t["sub"] == a.arg1]
    L.append("case themes (%d):" % len(cts))
    for t in cts:
        L.append("  %-4s %2d codes  h%+6.1f..%+6.1f  %s  -> %s" % (
            t["theme_id"], t["n_codes"], t.get("first_hour") or 0, t.get("last_hour") or 0,
            clip(t["label"], 70), fmt_place(st.placement(t["sub"], t["theme_id"]))))
    return L


def v_forest(st, a):
    p = os.path.join(st.root, "trees", "%s.md" % a.arg1)
    if not os.path.exists(p):
        return ["no forest for %s" % a.arg1]
    txt = open(p, encoding="utf-8").read().splitlines()
    if not a.arg2:
        return txt
    out, on = [], False
    for line in txt:
        if line.startswith("=== THREAD "):
            on = line.startswith("=== THREAD %s:" % a.arg2)
        if on or line.startswith("#"):
            out.append(line)
    return out or ["thread %s is not in the forest of %s" % (a.arg2, a.arg1)]


def v_note(st, a):
    p = os.path.join(st.out, "rooms", "%s.md" % a.arg1)
    return open(p, encoding="utf-8").read().splitlines() if os.path.exists(p) else \
        ["no note yet: %s" % p]


def v_codes(st, a):
    codes = st.rows("codes")
    ov = st.overlay()
    sel, head = [], ""
    if a.sub:
        sel = [c for c in codes if c["sub"] == a.sub and
               (not a.case_theme or c["case_theme_id"] == a.case_theme)]
        head = "codes of r/%s%s" % (a.sub, " case theme " + a.case_theme if a.case_theme else "")
    elif a.theme:
        keys = {k for k, v in ov["placed"].items() if a.theme in v}
        sel = [c for c in codes if (c["sub"], c["case_theme_id"]) in keys]
        head = "codes on %s %s (%d case themes; %s)" % (
            a.theme, clip(ov["scheme"].get(a.theme, {}).get("name"), 50), len(keys),
            ov["assign_file"] or "no placements")
    elif a.chunk:
        members = set(ov["chunks"].get(a.chunk, {}).get("members", []))
        keys = {k for k, v in ov["placed"].items() if set(v) & members}
        sel = [c for c in codes if (c["sub"], c["case_theme_id"]) in keys]
        head = "codes under %s %s (themes %s; %d case themes)" % (
            a.chunk, clip(ov["chunks"].get(a.chunk, {}).get("label"), 50),
            ",".join(sorted(members)), len(keys))
    elif a.grep:
        rx = re.compile(a.grep, re.I)
        sel = [c for c in codes if rx.search(" ".join(str(c.get(k) or "") for k in
                                                       ("label", "participant_words", "coder_note")))]
        head = "codes matching /%s/" % a.grep
    else:
        return ["codes needs --sub, --theme, --chunk or --grep"]
    sel.sort(key=lambda c: (c["sub"], c["hour"] if c.get("hour") is not None else 1e9))
    rooms = len({c["sub"] for c in sel})
    return ["%s: %d codes in %d rooms" % (head, len(sel), rooms)] + [code_line(c) for c in sel]


def v_theme(st, a):
    sub, _, key = (a.arg1 or "").partition("/")
    cts = [t for t in st.rows("case_themes") if t["sub"] == sub and
           (t["theme_id"] == key or t["label"] == key)]
    if not cts:
        return ["no case theme %r in r/%s" % (key, sub)]
    t = cts[0]
    codes = {c["code_id"]: c for c in st.rows("codes") if c["sub"] == sub}
    L = ["r/%s %s  %s  (%d codes, h%+.1f..%+.1f, threads %s)" % (
        sub, t["theme_id"], t["label"], t["n_codes"], t.get("first_hour") or 0,
        t.get("last_hour") or 0, ",".join(t["threads"])),
         "placed: " + fmt_place(st.placement(sub, t["theme_id"])), "",
         "note: " + (t.get("theme_note") or ""), ""]
    for cid in t["code_ids"]:
        c = codes.get(cid)
        if c:
            L.append(code_line(c))
            if c.get("coder_note"):
                L.append("       coder: " + clip(c["coder_note"], 130))
    return L


def v_where(st, a):
    ov = st.overlay()
    S = a.arg1
    keys = sorted(k for k, v in ov["placed"].items() if S in v)
    sc = ov["scheme"].get(S, {})
    L = ["%s %s  chunk %s  dims %s  (%s)" % (S, clip(sc.get("name"), 60), ov["chunk_of"].get(S),
                                             ",".join(ov["dim_of"].get(S, [])) or "-",
                                             ov["assign_file"] or "no placements"),
         "%d case themes in %d rooms" % (len(keys), len({k[0] for k in keys})), ""]
    cts = {(t["sub"], t["theme_id"]): t for t in st.rows("case_themes")}
    for k in keys:
        t = cts.get(k, {})
        L.append("  %-20s %-4s %2d codes  %s" % (clip(k[0], 20), t.get("theme_id", "?"),
                                                 t.get("n_codes", 0), clip(t.get("label", ""), 90)))
    return L


def v_after(st, a):
    sub, _, cid = (a.arg1 or "").partition("/")
    tr = [r for r in st.rows("transitions") if r["sub"] == sub]
    ans = [r for r in tr if cid in r["from_codes"]]
    was = [r for r in tr if cid in r["to_codes"]]
    codes = {c["code_id"]: c for c in st.rows("codes") if c["sub"] == sub}
    c = codes.get(cid)
    L = [code_line(c) if c else "no code %s in r/%s" % (cid, sub), ""]
    L.append("answered by (%d):" % len(ans))
    for r in sorted(ans, key=lambda r: r["interval_s"]):
        for x in r["to_codes"]:
            L.append("  +%-8s hops %d  %s  %s" % ("%.0fs" % r["interval_s"], r["hops"],
                                                  "same author" if r["same_author"] else "        ",
                                                  code_line(codes[x]) if x in codes else x))
    L.append("was an answer to (%d):" % len(was))
    for r in was:
        for x in r["from_codes"]:
            L.append("  -%-8s hops %d  %s" % ("%.0fs" % r["interval_s"], r["hops"],
                                              code_line(codes[x]) if x in codes else x))
    L.append("")
    L.append("limit: " + (tr[0]["limit"] if tr else "a reply is a reply: posted after, not caused by"))
    return L


def v_pairs(st, a):
    ov = st.overlay()
    level = a.level or "case_theme"

    def lift(sub, tids):
        if level == "case_theme":
            return {"%s/%s" % (sub, t) for t in tids}
        out = set()
        for t in tids:
            for s in ov["placed"].get((sub, t), []):
                out.add(s if level == "theme" else (ov["chunk_of"].get(s) or "∅"))
        return out
    cnt, rooms = collections.Counter(), collections.defaultdict(set)
    n = n_lifted = 0
    for r in st.rows("transitions"):
        if a.sub and r["sub"] != a.sub:
            continue
        n += 1
        xs, ys = lift(r["sub"], r["from_case_themes"]), lift(r["sub"], r["to_case_themes"])
        if xs and ys:
            n_lifted += 1
        for x in xs:
            for y in ys:
                cnt[(x, y)] += 1
                rooms[(x, y)].add(r["sub"])
    top = a.top or 40
    L = ["transition pairs at level %s%s: %d transitions, %d with both ends placed, %d distinct "
         "pairs%s" % (level, " in r/" + a.sub if a.sub else "", n, n_lifted, len(cnt),
                      "" if level == "case_theme" else "  (%s)" % (ov["assign_file"] or
                                                                   "no placements"))]
    L.append("%-34s %-34s %6s %6s" % ("from", "to", "n", "rooms"))
    for (x, y), c in cnt.most_common(top):
        L.append("%-34s %-34s %6d %6d" % (clip(x, 34), clip(y, 34), c, len(rooms[(x, y)])))
    L.append("")
    L.append("limit: a reply is a reply: posted after, not caused by. Counts are of coded turns "
             "answering coded turns; rule 4 says counts are of communities, and the rooms column "
             "is the one to report.")
    return L


def v_when(st, a):
    its = [i for i in st.rows("items") if i["sub"] == a.arg1]
    if not its:
        return ["no items for %s" % a.arg1]
    bins = [0] * 25
    outside = 0
    for i in its:
        if not i.get("codes") or i.get("hour") is None:
            continue
        h = i["hour"]
        if 0 <= h < 100:
            bins[int(h // 4)] += 1
        else:
            outside += 1
    glyph = " ▁▂▃▄▅▆▇█"
    mx = max(bins) or 1
    line = "".join(glyph[min(8, int(round(8 * b / mx)))] if b else "·" for b in bins)
    return ["r/%s coded items by 4-hour bin, h0..h97 (max %d per bin; %d outside the window)"
            % (a.arg1, mx, outside),
            "|" + line + "|", " 0       16      32      48      64  ^73 freeze     97",
            " ".join("%d" % b for b in bins)]


def v_shelf(st, a):
    d = os.path.join(st.S, "shelves")
    if not a.arg1:
        if not os.path.isdir(d):
            return ["no shelves yet: nothing has been unsealed"]
        return ["shelves:"] + ["  " + f for f in sorted(os.listdir(d))]
    p = os.path.join(d, a.arg1 if a.arg1.endswith(".md") else a.arg1 + ".md")
    return open(p, encoding="utf-8").read().splitlines() if os.path.exists(p) else \
        ["not on the shelf: %s" % a.arg1]


def v_brief(st, a):
    p = os.path.join(st.S, "briefs", "%s.md" % a.arg1)
    return open(p, encoding="utf-8").read().splitlines() if os.path.exists(p) else \
        ["no brief for %s" % a.arg1]


VERBS = {"room": v_room, "forest": v_forest, "note": v_note, "codes": v_codes, "theme": v_theme,
         "where": v_where, "after": v_after, "pairs": v_pairs, "when": v_when, "shelf": v_shelf,
         "brief": v_brief}


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("verb", nargs="?")
    ap.add_argument("arg1", nargs="?")
    ap.add_argument("arg2", nargs="?")
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage", default=None,
                    help="the stage the log is written under; default: the .stage file the "
                         "harness writes in the folder root, else $STAGE, else xx")
    ap.add_argument("--limit", type=int, default=80)
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--sub"); ap.add_argument("--case-theme"); ap.add_argument("--theme")
    ap.add_argument("--chunk"); ap.add_argument("--grep"); ap.add_argument("--level")
    ap.add_argument("--top", type=int)
    ap.add_argument("--no-canvas", dest="no_canvas", action="store_true",
                    help="room: the page without the six canvas fields (what a fleet is served)")
    ap.add_argument("--size", action="store_true",
                    help="room: bytes of the forest, the codes and the case themes")
    ap.add_argument("-h", "--help", action="store_true")
    a = ap.parse_args()
    if a.help or not a.verb or a.verb == "help":
        print(__doc__)
        return 0
    if a.verb not in VERBS:
        print(__doc__)
        print("no such verb: %s" % a.verb, file=sys.stderr)
        return 2
    out = a.out or os.path.join(a.root, "out")
    if not a.stage:
        # a session shared by several stages keeps its process environment, so $STAGE can be
        # stale there; the harness rewrites .stage at every hand-over, and it wins
        sp = os.path.join(a.root, ".stage")
        a.stage = (open(sp).read().strip() if os.path.exists(sp) else "") or os.environ.get("STAGE") or "xx"
    st = Store(a.root, out)
    lines = VERBS[a.verb](st, a)
    ov_notes = st.overlay()["notes"] if a.verb in ("room", "codes", "theme", "where", "pairs") else []
    page = lines[a.offset:a.offset + a.limit]
    for l in page:
        print(l)
    rest = len(lines) - a.offset - len(page)
    if rest > 0:
        print("… %d more lines; --offset %d" % (rest, a.offset + a.limit))
    for n in ov_notes:
        print("note: " + n)
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "_mem_reads-%s.jsonl" % a.stage), "a", encoding="utf-8") as f:
        f.write(json.dumps({"t": datetime.datetime.utcnow().isoformat(timespec="seconds"),
                            "stage": a.stage, "verb": a.verb,
                            "args": [x for x in (a.arg1, a.arg2) if x],
                            "opts": {k: v for k, v in vars(a).items()
                                     if k in ("sub", "case_theme", "theme", "chunk", "grep",
                                              "level", "offset", "limit", "no_canvas", "size")
                                     and v not in (None, 0, 80, False)},
                            "lines": len(lines)}) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())

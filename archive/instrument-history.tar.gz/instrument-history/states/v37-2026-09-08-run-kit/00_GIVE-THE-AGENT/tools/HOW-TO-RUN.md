# How to run the tools

Everything works from inside the folder you were given, the one holding `package/`, `cases/`,
`codes/`, `notebooks/`, `trees/`, `data/`, `tools/` and `out/`. Nothing reaches outside it.
Read this once, at stage 01.

## Two ways in, both logged

**The corpus, through `cite_case.py`** (rule 1; `cite()` is the only way a quote enters an
output, rule 3):

```python
import sys; sys.path.insert(0, "tools")
from cite_case import Cases
C = Cases(".", log="out/_aggregator_reads-01.jsonl")   # one log per stage: NN = the stage

C.collections()                       # {'codes': 300, 'cases': 300, 'notebooks': 300}
C.sections("bretagne")                # headings of a case
C.section("KState", "Chronology")     # one section whole
C.whole("lithuania", "codes")         # a document entire
C.cite(sub, section, quote)           # verbatim + offsets, or a refusal. One log record.
C.cite(sub, None, quote, collection="codes")     # participants' words live in codes/
C.find(r"\bexample\b")                # documents matched, one hit each; check .truncated
C.count(r"\bexample\b", collection="codes")      # a frequency: {'total', 'documents_matched', ...}
C.events("hsv")                       # the coder's dated chronology, as entries
C.mentions("hsv")                     # what this room named, with quote and item id
C.thread("hsv", "63x9ab")             # one thread of the record; C.threads_open("hsv") lists them
```

`find()` returns documents, never a count: use `count()` for a frequency. `thread()` resolves only
threads this community's own codes point at and refuses the rest by name: the coder's selection is
part of the data, and this is a checking surface, not a discovery surface. Stage 18 reports how
many threads you opened.

**The store, through `mem.py`** (the same material joined; every call logged to
`out/_mem_reads-NN.jsonl`, NN from `--stage`, else the `.stage` file the harness writes in
this folder at every hand-over, else `$STAGE`):

```
python3 tools/mem.py help
python3 tools/mem.py room hsv                  facts, threads, case themes, placements, and what
                                               the room made: the six canvas fields (rule 7)
python3 tools/mem.py room hsv --no-canvas      the same page without the canvas: what a fleet
                                               agent or a reader is served
python3 tools/mem.py room hsv --size           bytes of the forest, the codes and the case
                                               themes: what a fleet stage costs itself from
python3 tools/mem.py forest hsv [63x9ab]       the rendered forest, whole or one thread
python3 tools/mem.py note hsv                  your own room note
python3 tools/mem.py codes --sub hsv [--case-theme t03]
python3 tools/mem.py codes --theme S07 | --chunk C3 | --grep "discord"
python3 tools/mem.py theme hsv/t03             a case theme, its note, codes, placement
python3 tools/mem.py where S07                 every room and case theme placed on S07
python3 tools/mem.py after hsv/c0031           what answered a code, what it answered
python3 tools/mem.py pairs --level theme       transition counts, lifted; the limit printed
python3 tools/mem.py when hsv                  coded hours as one line
python3 tools/mem.py shelf [name]              the literature unsealed so far
python3 tools/mem.py brief hsv                 the pre-event week
```

Pages are 80 lines; `--offset` and `--limit` page through. Placements, chunks and dimensions are
overlaid from `out/` at query time (newest scheme file; `assignments_final.jsonl`, or
`assign_final.jsonl` with a note until the final exists; `chunks.jsonl`; `dimensions.jsonl`).
`package/store/README-store.md` is the dictionary. The six canvas fields live in
`package/store/rooms.jsonl` and `package/case_facts_outcome.jsonl`, and nowhere else in the
store; `package/DATA-manifest-canvas.md` says what they and `package/pixels.csv` measure.

## The fleet's pages, assembled by script

```bash
python3 tools/packets.py scheme --scheme out/scheme_final.jsonl --families out/families.jsonl \
                                --to out/_packets-04 [--exemplars]
python3 tools/packets.py batch --batches out/batches-04.jsonl --batch B017 --to out/_packets-04
```

`scheme` writes the index page (rule 0 in the contract's words, then every family with every
theme's id, name, gloss and tier) and one file per family with the full tests; the exemplars
only with `--exemplars`, the declared condition of stage 04's exemplar arm. `batch` writes one
batch's page: each community's sibling block (labels only), then each case theme with its label,
the coder's note and every code with the participants' words. Nothing on either page is the
canvas, a room note, `case_facts.jsonl` or another agent's output. Stage 03 serves the scheme the
same way; stage 14's cells are the analyst's own to assemble on the same rule (`mem.py theme`
and `codes --sub`, never `room` with the canvas).

## At the open and the close of every stage

```bash
python3 tools/validate.py <stage> . out/ --open     # before any judgement: the stage file is
                                                    # present and every declared input exists
python3 tools/validate.py <stage> . out/            # at the close: outputs exist, parse, reconcile
python3 tools/validate.py --self-test               # once, at stage 01: a planted defect per check
```

Paste the report into `notes-NN.md`. It exits non-zero on an error and refuses, by name, what it
cannot check; a check that did not run never reads as a check that passed. A close-check exists
for every stage, 01 to 18; each checks the shape of the stage's files and nothing about whether a
judgement is right. The close-check snaps `out/` as it stood (`_snap/NN-close.sha256`).

## The snaps: what existed when

```bash
python3 tools/snap.py 12 names           # _snap/12-names.sha256: every file under out/, hashed
python3 tools/snap.py --verify out/_snap/12-names.sha256
```

A snap is written once under its name. Four orderings are proved by snaps and by nothing else
(the standing instructions): `12 names` and `17 names` before batch 2 is opened; `11 cut` and
`16 cut` before anything is projected onto the cut; `17 activation` before the canvas blocks are
opened. `validate.py` reads them at 11, 12, 16, 17 and 18.

## The denominators and the clock

```bash
python3 tools/counts.py . out/                # writes out/counts.json; run it, do not read the copy
python3 tools/check_chronology.py package     # the coders' datings against the item clocks (stage 18)
```

Every analysed-set figure in `counts.json` is null until `dropped.jsonl` exists; the `frame` block
carries the same figures under frame names. `assignment_items_expected` is the count of distinct
`(sub, case_theme)` keys over the analysed set: the fleet returns it times `R`, and
`assignments_final.count.txt` equals it exactly.

## The harness, as it concerns you

The operator wrote these before stage 01 (the contract's §6), and they bind:

- **The run has no fixed token budget and no ceiling per fleet stage.** The 60,000,000 figure
  and the per-stage figures that once stood here are superseded by operator ruling (recorded in
  `RUN.json`, `operator_rulings`, 2026-09-14). They are kept in `RUN.json` as a record of what
  was declared at build and must not drive a design decision.
- **Costing still binds; stopping for a number does not.** Each fleet stage costs itself in its
  notes before it launches, from measured payloads (`mem.py room --size` at 10; the index page
  and the families at 04; the cells at 14) and not from a guess, and writes that estimate down.
  What changed is the consequence: no stage cuts its design, its sample or its reading to reach
  a figure, and none stops because a figure was passed. A stage whose measured cost looks out of
  proportion to what it buys says so in `handback-NN.md` and proceeds.
- **Models.** You run on `claude-sonnet-5`. The readers you serve in clean contexts (the pilot
  agents at 03 and 13, the blind readers at 05 and 15, the reviewer at 07, the four readers at
  09) run on `claude-sonnet-5`. The fleets at 04, 10 and 14 run on `claude-sonnet-5`. Record
  the model in every `run_manifest.json` entry.
- **`_head.md`** is rewritten on a 2-hour clock, in the form the standing
  instructions give, and read first by every session.
- **`out/_transcripts/`** is where the operator places each session's transcript at the close
  of the stage, listed in `_transcripts/INDEX.md`; stage 18 reads them beside the logs. You do
  not write there.
- **Sessions.** Stage 01 is one session that compacts at room boundaries; stage 02 likewise,
  with `_groups-02.jsonl` rewritten at every boundary; 03 to 06 one session each; 07, 08 and 09
  one session; 10, 11 and 12 one session; 13 to 18 one session each. Never compact inside a
  stage; if a session must, it does so at a boundary after the handback is written.
- **Three limits of the runner.** A tool result is capped at a fixed number of characters and a
  long file comes back clipped without saying so at the top: read the contract, the standing
  instructions and any file over about 30 KB in parts (`Read` with an offset, or `sed -n`), and
  check the tail arrived. A shell call that runs past its timeout is killed: run a fleet or a
  long script in the background with its output to a file, and poll. Nothing in `out/` is
  deleted: a superseded file is renamed with a suffix (`-superseded`), and the snaps carry the
  rest.
- **Forks.** The operator may fork the run at a stage boundary (after 01, after 06, after 09)
  into sibling runs that each carry the transcript and the files. You are not told you are a
  fork. Forks are compared by the operator (`fork_comparison-07.json`, `fork_comparison-10.json`)
  and the carried fork is chosen at 10 by a rule declared before any fork ran: the fork that
  composes the most rooms, ties by the fewer `cannot-tell`, never by the crossing or the
  outcome. Stage 18 receives the comparisons wherever the run was forked.

## Stage 00's builders, kept so the layer can be checked

```bash
python3 tools/build_store.py --root . [--runs DIR] [--corpora DIR] [--briefs DIR]
python3 tools/build_store.py --root . --join-canvas package/case_facts_outcome.jsonl
python3 tools/transitions.py --root .
python3 tools/visitors.py --root . --authors <authors_by_sub.jsonl>
python3 tools/tree_builder.py --demo
```

They ran before you arrived and their counts are in `README-store.md`; the canvas join ran at
build. The run records, the raw corpora and the author index are outside your folder; inside it
you can rebuild the forests, the store's joins and the ledger from `package/` alone and compare.
What no tool here can reach: whether the builders extracted the right segments from the raw
record. Say so in your limitations.

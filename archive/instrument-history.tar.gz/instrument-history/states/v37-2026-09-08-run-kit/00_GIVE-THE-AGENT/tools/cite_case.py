#!/usr/bin/env python3
"""
cite_case.py — grounded reading of the coded case material.

    from cite_case import Cases
    C = Cases("<root>", log="out/_aggregator_reads-03.jsonl")
    C.cite("Jamaica", "Relations", "Sign-off → damage")    -> verbatim text + offsets
    C.find("discord")                                      -> matches across all cases, logged
    C.count(r"\\bdiscord\\b", collection="codes")           -> frequencies, not documents
    C.events("bretagne")                                   -> the coder's dated chronology
    C.mentions("KState")                                   -> communities this room named
    C.thread("bretagne", "62tmj7")                         -> the thread the coder read

**Why.** A quote cannot be invented here: `cite()` resolves what you pass against the file on
disk and returns the span cut from it, with offsets, or refuses. A claim about what recurs
across cases needs the same discipline as a claim about one case: it carries at least one
`cite()` result or it is not evidence.

**Every call is logged.** You choose your own reading order, so the log is the only record of
what the sample actually was.

"""

import glob
import json
import os
import re
import time

TOOL = "citecase"


class CiteError(Exception):
    pass


class FindResult(list):
    """A list of hits that also knows whether it is complete.

    `truncated` is the whole point: a silently short result set is how a scheme ends up being
    a scheme about a search pattern.

    In this package it never fires on the default: there are 900 documents and `limit` defaults
    to 2000, so `truncated` is false unless you pass a smaller limit yourself. Check it anyway
    — the flag, not the hit count, is what tells you the scan was complete.
    """
    truncated = False
    limit = None
    scanned = 0
    not_scanned = 0

    def __repr__(self):
        tail = ("  [TRUNCATED at limit=%s; %d documents not scanned]"
                % (self.limit, self.not_scanned)) if self.truncated else ""
        return "<FindResult %d hits%s>" % (len(self), tail)


class Cases(object):
    COLLECTIONS = ("codes", "cases", "notebooks")

    def __init__(self, root, log=None):
        """`root` is the arm's folder. Every collection under it is indexed."""
        self.root = root
        self.log_path = log or os.path.join(root, "out", "_aggregator_reads.jsonl")
        d = os.path.dirname(self.log_path)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        self.docs = {}
        for coll in self.COLLECTIONS:
            dd = os.path.join(root, coll)
            if not os.path.isdir(dd):
                continue
            for p in sorted(glob.glob(os.path.join(dd, "*.md"))):
                name = os.path.basename(p)[:-3]
                if name.startswith("_"):
                    continue
                self.docs[(coll, name)] = open(p, encoding="utf-8", errors="replace").read()
        self.seq = 0
        self._threads = None      # lazily loaded thread store
        self._chron = None        # lazily loaded chronologies

    # ---- what is here ------------------------------------------------------
    def cases(self, collection=None):
        """Community names available to this arm. Cheap, logged, no text served."""
        names = sorted({n for c, n in self.docs if collection in (None, c)})
        self._log("cases", collection=collection, n=len(names))
        return names

    def collections(self):
        """Which bodies of material exist, and how many communities each covers."""
        out = {}
        for c, _ in self.docs:
            out[c] = out.get(c, 0) + 1
        self._log("collections", have=out)
        return out

    def sections(self, case, collection="cases"):
        """The headings of one document. Logged."""
        d = self._doc(case, collection)
        got = re.findall(r"^#{2,3}\s*(.+?)\s*$", d, re.M)
        self._log("sections", case=case, collection=collection, n=len(got))
        return got

    # ---- serving -----------------------------------------------------------
    def section(self, case, name, collection="cases"):
        """Serve one section whole. This is the ordinary way to read."""
        body = self._section_text(case, name, collection)
        self._log("section", case=case, collection=collection, section=name, chars=len(body))
        return body

    def whole(self, case, collection="cases"):
        """Serve a document entire. Use it when a section is the wrong unit."""
        d = self._doc(case, collection)
        self._log("whole", case=case, collection=collection, chars=len(d))
        return d

    # ---- grounding ---------------------------------------------------------
    def cite(self, case, section, quote, collection="cases"):
        """Return the verbatim text and its offsets, or refuse.

        Whatever you passed in is discarded; what comes back is cut from the file.
        **One log record**, carrying `cited: true` -- so a count of grounded reads can be told
        apart from a count of ordinary section and whole reads when the log is read back.
        """
        if section in (None, "", "*"):
            body = self._doc(case, collection)
            kind, sec = "whole", None
        else:
            body = self._section_text(case, section, collection)
            kind, sec = "section", section
        i = body.find(quote)
        if i < 0:
            norm = re.sub(r"\s+", " ", body)
            j = re.sub(r"\s+", " ", quote)
            if j and j in norm:
                raise CiteError("found only after collapsing whitespace — quote the file's "
                                "own line breaks, or cite a shorter span inside one line")
            raise CiteError("not found in r/%s / %s. quote the file, do not paraphrase it."
                            % (case, section))
        if body.count(quote) > 1:
            raise CiteError("%r occurs %d times in r/%s / %s — extend it to make it unique"
                            % (quote[:40], body.count(quote), case, section))
        self._log(kind, case=case, collection=collection, section=sec,
                  chars=len(body), cited=True, quote_chars=len(quote))
        return {"case": case, "collection": collection, "section": section,
                "start": i, "end": i + len(quote), "text": body[i:i + len(quote)]}

    # ---- search ------------------------------------------------------------
    def find(self, pattern, collection=None, section=None, limit=2000, context=80):
        """Search across every document this arm can see. One hit per document.

        Rule 2 applies: a search may ground a claim; it may not decide which communities you
        read. The scan is **interleaved by community**, so a truncated result is not a result
        from one collection.
        """
        rx = re.compile(pattern, re.I)
        keys = sorted(self.docs, key=lambda k: (k[1], k[0]))     # by community, then collection
        keys = [k for k in keys if collection in (None, k[0])]
        hits = FindResult()
        hits.limit = limit
        scanned = 0
        for (coll, case) in keys:
            body = self.docs[(coll, case)]
            if section:
                try:
                    body = self._section_text(case, section, coll)
                except CiteError:
                    scanned += 1
                    continue
            scanned += 1
            m = rx.search(body)
            if m:
                a, b = max(0, m.start() - context), min(len(body), m.end() + context)
                hits.append({"case": case, "collection": coll,
                             "text": body[m.start():m.end()], "snippet": body[a:b]})
                if len(hits) >= limit:
                    break
        hits.scanned = scanned
        hits.not_scanned = len(keys) - scanned
        hits.truncated = hits.not_scanned > 0
        self._log("find", pattern=pattern, collection=collection, section=section,
                  n_matched=len(hits), limit=limit, truncated=hits.truncated,
                  documents_scanned=scanned, documents_not_scanned=hits.not_scanned)
        return hits

    def count(self, pattern, collection=None, section=None):
        """Frequencies, which `find()` cannot give.

        `find()` returns documents matched, never a frequency. A form pass over a lexicon of
        dozens of patterns needs frequencies, and this supplies them over the same indexed,
        logged corpus — so that counting stays inside the tool, on the record, rather than in a
        scanner written alongside it.

        Returns `{total, documents_matched, by_document}`. No limit. One log record.
        """
        rx = re.compile(pattern, re.I)
        by = {}
        total = 0
        scanned = 0
        for (coll, case) in sorted(self.docs):
            if collection not in (None, coll):
                continue
            body = self.docs[(coll, case)]
            if section:
                try:
                    body = self._section_text(case, section, coll)
                except CiteError:
                    continue
            scanned += 1
            n = len(rx.findall(body))
            if n:
                by["%s/%s" % (coll, case)] = n
                total += n
        out = {"total": total, "documents_matched": len(by), "documents_scanned": scanned,
               "by_document": by}
        self._log("count", pattern=pattern, collection=collection, section=section,
                  total=total, documents_matched=len(by), documents_scanned=scanned)
        return out

    # ---- the timeline ------------------------------------------------------
    def events(self, case):
        """The coder's dated chronology for one community, as structured entries.

        **What this is.** Every case file carries a `## Chronology` section: dated,
        ordered prose written by the coder who had read the whole record. `build_chronology.py`
        parses those into entries; this serves them. It is an extraction from prose that
        already exists, not a new coding pass.

        **What this is not.** It is the *coder's account of order*, not the log. It has the
        same provenance as everything else in this tier and no more. Where an entry carries
        `item_ids`, those are checkable against `created_utc` in the thread store; where it does
        not, the dating is the coder's word.

        **Returns a report dict, not a list.** `{sub, source, n, n_dated, n_timestamped,
        day_zero, day_zero_consistent, monotone_in_written_order, entries: [...]}` — the
        entries are under `.entries`, in the order the coder wrote them. Written order is not
        guaranteed to be chronological order; the first flag below is how you tell.

        **Three flags to check before you build an arrow on a sequence.**
        `monotone_in_written_order` is false for 22 of 300 communities: the coder wrote an
        entry out of sequence with the timestamps they themselves gave. And on an entry, a
        `date_source` key — present only where the date was derived, on 55 of 2,543 entries,
        reading "day marker, against this coder's own d0" — means the date was inferred from a
        day marker rather than written; and `day_contradicts_file` means that entry's own `dN`
        disagrees with the file's anchor (394 of 2,543 entries).

        **`day` is the coder's marker and is not comparable across communities.** The
        convention is not shared: 111 files mean d0 = 03-31, 116 mean 04-01, one means 03-29 —
        and 72 fix no d0 at all, so for those the marker cannot be resolved even in principle.
        `day_zero_consistent` is false for 161 files, which anchor d0 in two ways at once.
        `t_utc` and `hours_since_open` are comparable; `day` is not. Never write *by d2* into
        a claim.
        """
        store = self._chronologies()
        if case not in store:
            raise CiteError(
                "no chronology for r/%s. call events_missing() to see which communities have "
                "none and why." % case)
        rec = store[case]
        self._log("events", case=case, n_entries=len(rec.get("entries", [])),
                  source=rec.get("source"))
        return rec

    def events_missing(self):
        """Communities with no chronology, with the reason. Cheap, logged.

        In this package all 300 communities carry entries, so this returns `{}`. Call it
        anyway: the empty result is the evidence that no community was dropped unnoticed.
        """
        store = self._chronologies()
        miss = {k: v for k, v in store.items() if not v.get("entries")}
        have = [k for k, v in store.items() if v.get("entries")]
        self._log("events_missing", n_missing=len(miss), n_have=len(have))
        return miss

    # ---- cross-community references ---------------------------------------
    def mentions(self, case=None):
        """Which other communities this room named, with the quote and the item id.

        Parsed from each case's `## Other communities named` section, which every case file
        carries. `in_census` marks the named partner as one of the coded communities, which is
        what makes a *directed* layer possible at all -- the layer can only be as dense as that
        share, so the stage that uses this must compute the share of named partners that are in
        the census and report it alongside whatever it builds.
        """
        store = self._mentions()
        if case is None:
            self._log("mentions", case=None, n=len(store))
            return store
        rec = store.get(case, {"sub": case, "named": [], "isolated": True})
        self._log("mentions", case=case, n_named=len(rec.get("named", [])))
        return rec

    # ---- the raw record, metered ------------------------------------------
    def thread(self, case, thread_id):
        """One thread the coder selected and read, whole, in posting order.

        **Only threads this community's codes point at are reachable.** There is no listing of
        what the coder left out and no search over the raw record: see the module docstring for
        why. Ask for anything else and this raises, naming what is open to you.

        Returns `{sub, thread_id, n_items, items: [...]}`; each item carries `id`, `parent_id`,
        `author`, `created_utc`, `kind`, `score`, `title`/`body`, and `codes` -- the ids of the
        codes minted on that item, so you can see at once which part of the exchange the coder
        took and which part they passed over.
        """
        store = self._thread_store()
        subs = store.get(case)
        if subs is None:
            raise CiteError("no thread store for r/%s (a community with no codes has no "
                            "selected threads)." % case)
        tid = thread_id.replace("t3_", "")
        if tid not in subs:
            raise CiteError(
                "r/%s: thread %r is not one this community's coder read. Open to you: %s"
                % (case, thread_id, ", ".join(sorted(subs))))
        rec = subs[tid]
        self._log("thread", case=case, thread_id=tid, n_items=len(rec["items"]),
                  chars=sum(len(i.get("body") or i.get("title") or "") for i in rec["items"]))
        return rec

    def threads_open(self, case):
        """The thread ids this community's codes point at. Cheap, logged, no text served.

        This is the whole of what `thread()` will serve for this community. It is a property of
        the coder's selection, not a search surface.
        """
        store = self._thread_store()
        got = sorted(store.get(case, {}))
        self._log("threads_open", case=case, n=len(got))
        return got

    # ---- internals ---------------------------------------------------------
    def _section_text(self, case, name, collection="cases"):
        """Section body with no logging. Callers log once, at the right level."""
        d = self._doc(case, collection)
        m = re.search(r"^#{2,3}\s*%s.*?$(.*?)(?=^#{2,3}\s|\Z)" % re.escape(name),
                      d, re.M | re.S | re.I)
        if not m:
            heads = re.findall(r"^#{2,3}\s*(.+?)\s*$", d, re.M)
            raise CiteError("r/%s has no section %r in %s. it has: %s"
                            % (case, name, collection, ", ".join(heads)))
        return m.group(1)

    def _doc(self, case, collection="cases"):
        if (collection, case) not in self.docs:
            if collection not in self.COLLECTIONS:
                raise CiteError("no collection %r. this arm has: %s"
                                % (collection, ", ".join(sorted(set(c for c, _ in self.docs)))))
            raise CiteError("no case %r in %s. call cases(%r) to see what you have."
                            % (case, collection, collection))
        return self.docs[(collection, case)]

    def _data_path(self, name):
        """Find a built data file.

        The collections (`cases/`, `codes/`, `notebooks/`) live at the arm's root; the files the
        builders produced live in a `package/` beside this module. Both layouts are searched, in
        this order, so `Cases("<sandbox root>")` works whichever way the folder is arranged.
        """
        here = os.path.dirname(os.path.abspath(__file__))
        for base in (self.root,
                     os.path.join(self.root, "package"),
                     here,
                     os.path.join(here, "package"),
                     os.path.join(here, os.pardir, "package")):
            p = os.path.join(base, name)
            if os.path.exists(p):
                return p
        return None

    def _load_jsonl(self, name):
        p = self._data_path(name)
        if p is None:
            raise CiteError("%s is not in this package, and no builder for it is here — the "
                            "scripts that made the package needed raw material from outside "
                            "this folder, so it cannot be rebuilt here. Say so in "
                            "defects.jsonl rather than working around it." % name)
        return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]

    def _chronologies(self):
        if self._chron is None:
            self._chron = {r["sub"]: r for r in self._load_jsonl("chronology.jsonl")}
        return self._chron

    def _mentions(self):
        return {r["sub"]: r for r in self._load_jsonl("mentions.jsonl")}

    def _thread_store(self):
        if self._threads is None:
            store = {}
            d = self._data_path("threads")
            if d is None or not os.path.isdir(d):
                raise CiteError("no threads/ in this package — thread() is unavailable. "
                                "Say so in defects.jsonl rather than working around it.")
            for p in sorted(glob.glob(os.path.join(d, "*.jsonl"))):
                sub = os.path.basename(p)[:-6]
                by = {}
                for line in open(p, encoding="utf-8"):
                    r = json.loads(line)
                    by[r["thread_id"]] = r
                store[sub] = by
            self._threads = store
        return self._threads

    def _log(self, kind, **payload):
        self.seq += 1
        rec = {"seq": self.seq, "t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "kind": kind, "tool": TOOL}
        rec.update(payload)
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    C = Cases(sys.argv[1])
    cmd = sys.argv[2]
    if cmd in ("--find", "-f"):
        r = C.find(sys.argv[3])
        print(repr(r))
        print(json.dumps(list(r), ensure_ascii=False, indent=1))
    elif cmd == "--count":
        print(json.dumps(C.count(sys.argv[3]), ensure_ascii=False, indent=1))
    elif cmd == "--cases":
        print(json.dumps(C.cases(), indent=1))
    elif cmd == "--section":
        print(C.section(sys.argv[3], sys.argv[4]))
    elif cmd == "--events":
        print(json.dumps(C.events(sys.argv[3]), ensure_ascii=False, indent=1))
    elif cmd == "--mentions":
        print(json.dumps(C.mentions(sys.argv[3]), ensure_ascii=False, indent=1))
    elif cmd == "--threads-open":
        print(json.dumps(C.threads_open(sys.argv[3]), indent=1))
    elif cmd == "--thread":
        print(json.dumps(C.thread(sys.argv[3], sys.argv[4]), ensure_ascii=False, indent=1))
    else:
        print(json.dumps(C.cite(sys.argv[2], sys.argv[3], sys.argv[4]),
                         ensure_ascii=False, indent=1))

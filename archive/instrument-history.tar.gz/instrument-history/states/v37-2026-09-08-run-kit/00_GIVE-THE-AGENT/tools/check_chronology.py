#!/usr/bin/env python3
"""check_chronology.py — how far the extracted timeline can be trusted.

    python3 check_chronology.py <package dir> [<collections root>]
    python3 check_chronology.py package          # from the folder you were given

`package/chronology.jsonl` holds what the coders wrote, extracted from the `## Chronology`
section of each case file by a builder that is **not in this folder** and cannot be re-run here.
This asks how good that extraction is, two ways, and prints both rather than reporting a single
reassuring number.

The first argument is the directory holding `chronology.jsonl` and `threads/`; the case files
are looked for in `cases/` beside it or beside its parent, so one argument is enough for the
layout this package ships in. Pass a second argument to point at the collections root yourself.

**1. Against the record.** Chronology entries that quote an item id can be checked: the id
resolves in the thread store, which carries `created_utc`. Where the coder wrote a clock time
and quoted an id, the two should agree. Disagreement is reported per community, not averaged
away -- an off-by-an-hour pattern in one room is a different fact from scattered noise.

**2. Against the coder's other account.** Every case file also carries a `Relations` section,
which states orderings in a different register. Where an entry names a pair the Relations
section also names, the two orders should agree.

**What a failure means.** These are one coder's two accounts of the same record. The chronology
is the coder's account of order, and this check bounds how much weight it takes -- it does not
turn it into the log.
"""
import glob
import json
import os
import re
import sys
import collections


def resolve(root, cases_root=None):
    """Return (package dir, collections root).

    `chronology.jsonl` and `threads/` sit in the package; the `cases/` collection sits at the
    folder root, one level up from it. Accept either as `root` and find the other.
    """
    root = os.path.abspath(root)
    pkg = root if os.path.exists(os.path.join(root, "chronology.jsonl")) \
        else os.path.join(root, "package")
    if not os.path.exists(os.path.join(pkg, "chronology.jsonl")):
        raise SystemExit("no chronology.jsonl in %s or %s/package — give me the package dir."
                         % (root, root))
    if cases_root:
        coll = os.path.abspath(cases_root)
    else:
        coll = next((c for c in (root, pkg, os.path.dirname(pkg), os.path.dirname(root))
                     if os.path.isdir(os.path.join(c, "cases"))), None)
    return pkg, coll


def main(root, cases_root=None):
    pkg, coll = resolve(root, cases_root)
    print("package    : %s" % pkg)
    print("collections: %s" % (os.path.join(coll, "cases") if coll else
                               "NOT FOUND — section 2 cannot run"))
    print()
    chron = {r["sub"]: r for r in
             (json.loads(l) for l in open(os.path.join(pkg, "chronology.jsonl"),
                                          encoding="utf-8") if l.strip())}
    # item id -> created_utc, from the thread store
    when = {}
    td = os.path.join(pkg, "threads")
    if os.path.isdir(td):
        for p in glob.glob(os.path.join(td, "*.jsonl")):
            sub = os.path.basename(p)[:-6]
            for line in open(p, encoding="utf-8"):
                t = json.loads(line)
                for it in t["items"]:
                    when[(sub, it["id"])] = it.get("created_utc")

    # An entry can carry one lead timestamp and then quote several ids under it — a head of the
    # form "dN, MM-DD HH:MM–HH:MM" followed by prose naming several items across that span
    # (252 of 2,543 entries quote more than one id here, up to eight). The entry's clock is
    # then the clock of the span's start, not of every id in it, so
    # comparing every id against the entry's single timestamp measures the parser, not the
    # coder. The fair test is the subset where the entry quotes **exactly one** id; both numbers
    # are printed rather than only the flattering one.
    stats = {"all": [0, 0, collections.Counter(), []],
             "single": [0, 0, collections.Counter(), []]}
    unresolved = 0
    for sub, rec in chron.items():
        for e in rec.get("entries", []):
            ids = e.get("item_ids", [])
            for iid in ids:
                cu = when.get((sub, iid))
                if cu is None:
                    unresolved += 1
                    continue
                if e.get("t_utc") is None:
                    continue
                d = abs(cu - e["t_utc"])
                for key in (["all", "single"] if len(ids) == 1 else ["all"]):
                    s = stats[key]
                    s[0] += 1
                    if d <= 3600:
                        s[1] += 1
                    else:
                        s[2][sub] += 1
                        s[3].append((sub, iid, e["t_utc"], cu, round(d / 3600.0, 1)))

    print("== 1. the coder's clock against created_utc")
    print("quoted ids that resolve to nothing in the thread store : %d" % unresolved)
    for key, label in (("single", "entries quoting exactly one id  (the fair test)"),
                       ("all", "every quoted id against its entry (parser-inflated)")):
        checked, agree, per, off = stats[key]
        print()
        print("%s" % label)
        print("  pairs checked                       : %d" % checked)
        if checked:
            print("  agreeing within the hour            : %d (%.1f%%)"
                  % (agree, 100.0 * agree / checked))
        print("  communities disagreeing by over an hour: %d %s"
              % (len(per), per.most_common(5)))
        if key == "single":
            for row in off[:8]:
                print("     r/%-20s %s  coder %s  record %s  (%sh)" % row)

    # ---- 2. against Relations
    print()
    print("== 2. coverage against the Relations section")
    if coll is None:
        raise SystemExit("no cases/ found next to %s or its parent. Pass the collections root "
                         "as a second argument; do not read this section as a zero." % pkg)
    n_rel = n_chron = 0
    both = 0
    n_files = 0
    for p in sorted(glob.glob(os.path.join(coll, "cases", "*.md"))):
        n_files += 1
        sub = os.path.basename(p)[:-3]
        t = open(p, encoding="utf-8", errors="replace").read()
        has_rel = bool(re.search(r"^##\s*Relations", t, re.M))
        has_ch = bool(chron.get(sub, {}).get("entries"))
        n_rel += has_rel
        n_chron += has_ch
        both += (has_rel and has_ch)
    if not n_files:
        raise SystemExit("%s/cases/ holds no .md files — section 2 has nothing to read."
                         % coll)
    print("case files read                     : %d" % n_files)
    print("case files with a Relations section : %d" % n_rel)
    print("case files with a chronology        : %d" % n_chron)
    print("with both, so cross-checkable       : %d" % both)
    print()
    print("Relations states orderings in prose and in a different register; a pair-level check "
          "is a reading task, not a parse. What this reports is the population that check could "
          "run on. Stage 07 should run it on the arrows it actually uses, not on all of them.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("-h", "--help"):
        raise SystemExit(__doc__)
    main(sys.argv[1] if len(sys.argv) > 1 else ".",
         sys.argv[2] if len(sys.argv) > 2 else None)

# ADDENDUM-09

Read this before `STAGE-09-model-the-account.md`. Four items, all about how strongly the account may
state what stage 08 established, plus one inconsistency to resolve.

## 1. How to describe an interval

Stage 08 completed the base-rate test on `E7→E4` properly: per-stratum cells, a Mantel-Haenszel
pooled odds ratio of 1.09 with a 95% interval of [0.62, 1.89], Robins-Breslow-Greenland variance,
and it reported the result as a failure to reject rather than a confirmation. That framing is
right and the account keeps it.

The description of the interval is not right, and `notes-08.md` and `model.v2.md` both carry it:
"comfortably consistent with independence". The interval is consistent with independence. It is
equally consistent with an odds ratio near 1.9, which is a substantial association. At this number
of rooms the interval is uninformative, not comfortable, and the account must not repeat the
phrase. State an interval by both of its ends, and say what the upper end does not rule out. The
same discipline applies to every interval this stage reports.

## 2. `E7→E4`'s grade

The edge stands at `fair` / `codes-read`. It was moved there from `thin` / `reading-alone` before
the test existed, and the completed test does not support the move: an uninformative interval is
weak evidence for a claim whose content is decoupling. Stage 09 may not raise the grade, and no
proposition may rest on `E7→E4` being better grounded than `fair`. If the account leans on that
edge at all, say in `notes-09.md` what the grade rests on besides the statistic, naming the codes
read. If nothing supports it besides the statistic, write that, and say the grade is carried
unchanged from stage 07 rather than earned here.

## 3. Every count says how it was computed

Stage 08's handback records that `mem.py` has no bulk statistical query surface, so its counts were
computed by hand-rolled reads of the store rather than through the tool. That is a tool gap, not a
fault, and it is not fixed before this stage. The consequence binds here: every count in
`account.md`, `propositions.md` and `gioia_table.md` states the file it was computed from and the
path by which, so a later reader can recompute it. Where a count came from a hand-rolled read
rather than from `mem.py`, say so in `notes-09.md`. Do not launder a hand-rolled figure as a tool
result.

## 4. The mass figures are doubles-included

`model.md`'s in-mass, out-mass and internal-mass figures are reported with multiplacements counted
twice, not stripped. Stage 07 declared this in `departures.jsonl`. If the account uses any of them,
it carries the caveat in the same sentence.

## 5. One inconsistency, resolved in favour of the stage file

`tools/HOW-TO-RUN.md` says four readers at 09; this stage's §5 says three. Follow the stage file:
three fresh readers, and record three in `run_manifest.json`.

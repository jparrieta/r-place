# Stage 05 — assignment: adjudication, and the blind check.

Input: `__OUTDIR__/assign_raw.jsonl`, `__OUTDIR__/agent_report-04.md`, `__OUTDIR__/notes-04.md`
for the disagreement inventory and the gloss-only placements, `__OUTDIR__/scheme_final.jsonl`
with `__OUTDIR__/families.jsonl`, `__OUTDIR__/gold_items.jsonl`, `__OUTDIR__/author_items.jsonl`,
`__OUTDIR__/confusions.md` and `__OUTDIR__/pilot_report.md` for stage 03's predictions,
`__OUTDIR__/fidelity-04.md`, `__OUTDIR__/batches-04.jsonl` for the gold tags,
`__OUTDIR__/multiplacement_log.jsonl` for every `why_not_one`, the corpus through
`tools/cite_case.py`, and the store through `tools/mem.py` (`theme`, `codes --sub`).

Outputs: `__OUTDIR__/assign_final.jsonl`, `__OUTDIR__/disagreements.jsonl`,
`__OUTDIR__/coder_conflicts.jsonl`, `__OUTDIR__/transmission-05.md`,
`__OUTDIR__/adjudication_report.md`, `__OUTDIR__/reassign.jsonl`, `__OUTDIR__/reliability-05.md`,
`__OUTDIR__/notes-05.md`, and an appended entry in `__OUTDIR__/run_manifest.json`.

**Only the disagreements come here, and the placements made from a gloss.** Where the
replicates agree, the assignment stands and nothing is re-decided, with one exception: a
placement into a family neither reader opened (`families_opened` without the chosen family) is
read by you whether or not the readers agreed, since two readers can agree from a gloss; where
you move one, it is logged as a ruling like any other. An item on which independent readers
holding the same written scheme placed the material differently is a boundary the scheme did not
decide, with the alternatives attached.

## 1. The gold placements come out first

**Drop the seeded gold placements before you adjudicate anything**, using the tags in
`batches-04.jsonl`. A seeded placement is measurement, not corpus evidence; left in, it enters
`assign_final.jsonl` and every denominator below, and breaks rule 4 quietly.

**What is dropped is the gold placement, not the case theme.** A case theme carrying gold
placements is still a case theme of the analysed set and still owes `assign_final.jsonl` its line,
taken from the live replicates. Drop by `(item, agent, replicate)` on the gold-tagged rows, never
by key. After the drop the line count still reconciles to `tools/counts.py`'s
`assignment_items_expected` over the analysed set; if it does not, you dropped case themes.

Fidelity on the gold placements is stage 04's figure, in `fidelity-04.md`. Read it, do not
recompute it, and say in `notes-05.md` how many placements the drop removed.

## 2. Transmission

**Compute it before anything here touches the file.** Drop the seeded gold placements from the
rates as §1 drops them from `assign_final.jsonl`, but keep them for the decomposition, which is
what your own answers are for. Your answer exists for every gold item and every item stage 03
piloted, in `gold_items.jsonl` and `author_items.jsonl`; the contract's four rows are computed
there:

| the fleet | you | what it is |
|---|---|---|
| agree with each other and with you | | the scheme decides |
| **split** | **were confident** | **fails to transmit**: a wording defect; stage 06 repairs it |
| **split** | **were also unsure** | **the tier does not decide this item**: a finding, kept |
| agree with each other, **diverge from you** | | **teaches something unintended**: read every one |

The third row is never revised away. **The fourth row's items never reach the adjudication**,
because every replicate agreed on them: they are in `assign_raw.jsonl` and nowhere else, and
`author-error` below catches only the items that split. Split the row both ways, you were wrong or
the scheme taught something you did not intend, and say in `notes-05.md` which way each went.
Outside the gold and pilot sets your own answer does not exist, so the split distribution there is
a rate you cannot decompose: say so, and do not extrapolate the proportions from the gold set,
which was drawn to be hard.

Write it to `transmission-05.md` and name it in `handback-05.md`; stage 06 reads it as its fifth
source. Nothing here is strain, which is the crossing's alone.

## 3. The conflicts pass

**`coder_conflicts.jsonl` is produced here and nowhere else**: two coders describing the same
practice in incompatible terms, seen only by reading across communities. The pass runs over
`theme_note` alone, with no codes beneath it. Run it before you adjudicate the disagreements: a
conflict between coders explains some of the disagreements between agents, and you want to know
which before you rule. Stages 06, 07 and 18 read this file.

## 4. Declared before the first item, in `notes-05.md`

The ruling policy. At `R = 2` every split is one reading against another and there is no
majority to lean on:

- how many items you expect to rule on, from stage 04's inventory, and what you will do if it
  exceeds what one reading per item allows in one session: the answer is more sessions, never a
  rule applied in bulk. A scheme of hundreds splits more than a scheme of forty, and most of its
  splits are between siblings in one family, where the discriminator between them is the sentence
  to quote; placements made from the gloss alone (`families_opened` without the chosen family)
  are ruled first; and where many splits fall on one pair of siblings, the boundary is ruled
  once, in one paragraph quoting the discriminator, and that ruling is applied to every item on
  the pair and logged as one ruling with its item list, because a boundary ruled item by item is
  ruled inconsistently;
- what a reader's `confidence` and `why` count for, and whether a `clear` reading against an
  `arguable` one is a prior or nothing;
- whether an adjudicated placement may name a theme **neither reader chose**: it may, logged
  loudly, because it means both readers missed something the file did say;
- what you do when the honest answer is that the scheme does not decide. That must be available
  as an outcome, recorded as `unresolved` and carried, not resolved by preference.

## 5. Blindness, and its limits

**You see the item, the scheme, and the two placements, not who made them.** Strip agent id,
batch, replicate number and timestamps before you look; the funnel is a property of the fleet, not
evidence about this item. **Both readings are shown**, with their `why` and `confidence`: two
readings, neither a prior over the other. You wrote the scheme, and no procedure removes your pull
toward your own reading; record `named_neither` every time your placement is one no reader chose.

## 6. The taxonomy: stage 03's five

Every adjudicated item gets one, and the classification matters more than the placement:

- **`scheme-ambiguous`**: the belonging test or the discriminator does not decide. Name the field
  and quote the sentence. These aggregate into stage 06's revision list.
- **`item-is-a-bag`**: the coder's case theme holds two practices, so no single placement is
  right. Not a scheme defect.
- **`reader-error`**: the file does decide and a reader missed it. **Suspect this last**, and
  never assign it when two independent readers made the same miss: that is a scheme defect that
  looks like reader error.
- **`author-error`**: you were wrong and the fleet was right. It exists wherever your own answer
  is on record, the gold items and anything you placed at stage 03, and **an adjudication that
  never returns one is an adjudication measuring obedience.** Carry the count to
  `adjudication_report.md`.
- **`genuine-joint`**: the material satisfies two gates and one placement cannot carry it, which
  is rule 0's exception on the record. A split here is readers applying rule 0 differently; the
  count measures how well the rule travelled, a fact about the instructions rather than the agents.

```json
{"sub": "...", "case_theme": "...", "readings": {"S07": 1, "S11": 1},
 "chosen": ["S07"], "unresolved": false, "kind": "scheme-ambiguous",
 "field": "must_not_show", "theme": "S07",
 "quote": "the sentence that failed to decide",
 "boundary_ruling": "S07|S11 or null, where §4's one ruling on a sibling pair decided this item",
 "named_neither": false, "confidence": "clear|arguable",
 "why": "..."}
```

`chosen` is empty and `unresolved` true where the scheme does not decide; a boundary ruled once
carries the pair in `boundary_ruling` on every item it decided, and the ruling itself is one
paragraph in `adjudication_report.md` with its item list.

## 7. Three things not to do

**Do not let a `clear` reading decide silently.** A reader's confidence may weigh on the
placement; the disagreement still gets its row, its kind, and its quoted sentence.

**Do not revise the scheme here.** Stage 06 does that with the whole inventory in front of it;
fixing a sentence mid-adjudication adjudicates the items before and after it against different
files. Log the defect and leave the file alone.

**Do not let the `unresolved` count reach zero by effort.** An adjudication that resolves
everything has resolved some things by preference.

## 8. `adjudication_report.md`

- **Items adjudicated**, against the fleet's disagreement inventory.
- **The taxonomy split**, the most important result: mostly `item-is-a-bag` is a good scheme
  meeting messy material; mostly `scheme-ambiguous` is a scheme that did not survive being handed
  over.
- **Themes by ambiguity**, ranked. Stage 06 opens with this list.
- **Fields by ambiguity**: whether the failures sit in `must_show`, `must_not_show`,
  `decide_when_both` or the discriminators. Four numbers.
- **The `named_neither` rate**, and your reading of it.
- **The `unresolved` count**, named.
- **Agreement before and after**, with the note that the figure after is not a reliability figure;
  it is agreement following an adjudication you performed.
- **Whether stage 03's predictions held**, now that every case theme in the analysed set has
  answered.

## 9. The blind check, after the line is settled

**This is the reliability measurement**, and it uses readers who have not seen the first pass:
whether the line you settled can be reached again by somebody who was not here, which is
reliability in the contract's §7 words. Fleet agreement is already computed, corpus-wide, at stage
04: readers against each other, before anyone decided. This adds fresh readers against the record
every later stage rests on. It is small by design: the fleet already read everything twice.

Declared before you draw, in `notes-05.md`:

- **The sample**: one hundred items, fifty drawn uniformly at random from the analysed set and
  fifty from the adjudicated items, by a recorded seed. The two strata are reported separately and
  never pooled: the first says whether the scheme decides the ordinary item, the second whether
  your rulings can be reached by a stranger.
- **Two fresh readers per item**, in clean contexts, one run. Each reading is compared with the
  settled line on its own, so the sample yields two hundred comparisons and the figure is a rate
  over readings; the two readers' agreement with each other is reported beside it.
- **The agreement definition**, identical to stage 03's and stage 04's, or the figures cannot be
  set beside each other: whether `["S04"]` against `["S04","S11"]` is agreement, disagreement or
  partial, and whether chance correction is over themes, over sets, or over presence/absence per
  theme.
- **No exemplars.** This measures whether the written scheme decides; stage 04 measured the
  exemplar arm.

**Append this stage's entry to `run_manifest.json`** on stage 01's schema (model, seed, decoding
settings and the reader count) before the first item is served.

**What the readers get**: `scheme_final.jsonl`, rule 0 in the contract's wording, and the sampled
case themes with their `theme_note` and codes. **Nothing else.** Not `assign_final.jsonl`, not
`disagreements.jsonl`, not the adjudication, not a hint that these items have been decided before,
and never your room notes (`__OUTDIR__/rooms/`), the running file or `findings.jsonl`. If a
reader needs your notes to decide, the scheme did not decide, and that is the finding.

**The comparison, per item, the fresh placement against the settled one**, into `reassign.jsonl`:

- **agrees**: the scheme decides, and the same way twice;
- **disagrees, and the item was a disagreement here**: expected. Compare the two rates; a
  boundary that split the fleet and then split a fresh reader shows consistency, not a new
  problem;
- **disagrees, and the item was unanimous in the fleet**: either the fleet shared an assumption
  the scheme does not license, or the adjudication moved something it should not have. Name these
  individually, and give each a paragraph;
- **disagrees, and the settled placement was `unresolved`**: no information. Exclude these from
  the denominator rather than counting them as a failure, and say how many.

**`reliability-05.md`**: both headline figures side by side, fleet agreement from stage 04 and
fresh-against-settled agreement per stratum, with the definition stated once above them; per
family, not per theme: a hundred items over hundreds of themes leave most themes with no item in
the sample, and a per-theme figure from it would be empty or one item wide. The per-theme figure
stage 06 needs is stage 04's agreement, computed over every item and every theme (stage 04 §12);
point to it, do not recompute it. Then the unanimous-but-disagreed items, listed; and the gap
between the uniform stratum's figure
and stage 03's held-out gold figure: the pilot measured the scheme on deliberately hard items, and
where the held-out number is not the lower of the two, the hard set was not hard. Wherever a figure
from this section appears, say what it licenses, in the contract's §7 words.

## Your final message

Disagreements inherited and adjudicated; the taxonomy split; the three themes with the most
`scheme-ambiguous` rows; which field failed most; how often you named a theme neither reader chose; how many
you left `unresolved`; how many boundaries you ruled once and applied, and to how many items;
whether the pilot's predictions held on the full corpus; the blind check's two figures with their
definition, the three worst families, and how many unanimous items a fresh reader placed
elsewhere; and the single boundary you most expect stage 06 to have to move. A return value.

## Close

Run `python3 tools/validate.py 05 . __OUTDIR__`, paste the report into `notes-05.md`, and write
`handback-05.md` and finish `diary-05.md` with its three closing headings.

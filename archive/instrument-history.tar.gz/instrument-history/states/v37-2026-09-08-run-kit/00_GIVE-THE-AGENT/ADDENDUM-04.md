# Addendum to stage 04

This file is part of stage 04. Where it and the stage file differ, this file is the later word.

## 1. The contract has been amended

`CONTRACT-aggregator.md` in your folder is a new copy and replaces the one you have been working
from. One change, in §3: the aggregate dimensions are built rather than optional, and no number is
set at any tier, for the chunks or the dimensions. The amended paragraph says so in its own first
line, and "Where the theory lives" now states the mapping between this study's tiers and the
method's own names so you do not have to derive it. Read §3 again before stage 07. Nothing about
this stage changes.

## 2. Store reads go through the tool, always

Every read of anything under `package/store/` goes through `tools/mem.py`. No shell command and no
raw `open()` reads a store file directly: not to size it, not to see its shape, not to check
whether a field exists, and not while scoping work before the stage proper begins. This holds for
the fleet's design as it holds for your own reading, and for the quick look as much as for the
analytic read.

Where `mem.py` has no verb for something you need, that is a gap in the tool and it is reported as
one: name the read you wanted, the verb that is missing, and what you did instead. Do not route
around it silently.

## 3. The exemplars the exemplar arm will see

The frozen scheme carries two or more verified exemplars for every main-tier theme, three for one,
and one each for twelve rare-tier themes. **Those twelve ship as they are.** Do not manufacture a
further exemplar to reach a count: a quote found in order to fill a slot is not evidence, and this
stage's budget is for the fleet.

**But the exemplars are load-bearing here for the first time.** No reader in stage 03 saw any. The
exemplar arm at this stage is served them, so an exemplar that does not satisfy its theme's gate on
the quote alone now travels into placements that everything downstream computes on. Before you
serve them, check the exemplars that arm will actually receive against rule 3, the same test stage
03 applied to the scheme as a whole.

What to do with what you find, in this order: **report it**, in `out/defects.jsonl` and in your
handback, naming the theme, the quote and why it fails. Then, where a verified participant quote
from the same room satisfies the gate, replace it and log the replacement. Where none does, withhold
that exemplar from the arm and say so, rather than serving a quote you would not defend. **Do not
serve an exemplar you have judged defective, and do not repair one silently.**

## 4. Two boundaries are known-ambiguous, not merely predicted

Stage 03's confirmation round left two pairs at an exact tie across two independent samples of fresh
readers: S21 against S23 (on `Cornwall/t02`) and S33 against S34 (on `WPI/t04`). In both, the second
round split the opposite way from the first. These are not predictions of confusion; they are
measured, and the wording was deliberately not edited again to force a result.

Expect the fleet to split on both. Treat placements there as the instrument working, not as agent
error, and make sure `multiplacement_register-04.md` can show what the fleet did with them rather
than averaging it away.

# Stage 07 — the model: the loop.

Input: `__OUTDIR__/scheme_v2.md`, `__OUTDIR__/scheme_v2.jsonl`, `__OUTDIR__/assignments_final.jsonl`,
`__OUTDIR__/form_pass-06.md` (the `F` tier, in prose, the only place it exists),
`__OUTDIR__/multiplacement_log.jsonl`, `__OUTDIR__/coder_conflicts.jsonl`, `__OUTDIR__/contrast.md`,
`__OUTDIR__/prior.md`, `__OUTDIR__/rooms_index.md` and the room notes, the store through
`tools/mem.py` (`pairs --level theme`, `where`, `codes --theme`, `after`, `forest`), and the corpus
through `tools/cite_case.py`, including `events()` for sequence. Arriving with this stage:
`package/store/shelves/METHOD-SHELF.md` and `package/store/shelves/literature-tierB.md`.

Outputs: `__OUTDIR__/chunks.jsonl` with `__OUTDIR__/chunks_log.jsonl`; `__OUTDIR__/dimensions.jsonl`
with `__OUTDIR__/dimensions_log.jsonl`; `__OUTDIR__/structure.md`; `__OUTDIR__/data_structure.md`;
`__OUTDIR__/concept.md`; `__OUTDIR__/model.md`; `__OUTDIR__/edges.jsonl`;
`__OUTDIR__/edges_dimension.jsonl`; `__OUTDIR__/within_case.md`;
`__OUTDIR__/story-pN.md`, one per pass, and `__OUTDIR__/story_rooms-pN.jsonl` beside each;
`__OUTDIR__/saturation.jsonl`; `__OUTDIR__/findings.jsonl`, opened here if not before;
`__OUTDIR__/review-07.md`, one reviewer's return, answered in `__OUTDIR__/notes-07.md`; the
`run_manifest.json` append for that reviewer; and a line in `__OUTDIR__/tier_history.jsonl` for
every recut and every item it moved.

Structure, concept and model are one loop: **Part A** the data structure, **Part B** the concept,
**Part C** the model, and at the end of every pass **the story** (§5), told again and read against
rooms. Read all four before starting any. The order you work in is yours.

## 1. Before pass 1

**Read the shelf.** `METHOD-SHELF.md` says what each of its nine works is for here and how they
rank; its hierarchy governs. Re-read Gioia, Corley and Hamilton whole. Read `literature-tierB.md`:
the vocabularies, usable here for naming and recognising and for nothing else; the explanation
literature stays shut until stage 08. Re-read `prior.md` and the contract's §1 beside it.

**Read the ledger.** `mem.py pairs --level theme` and `pairs --level case_theme`: which
second-order themes answer which, in how many rooms, with the limit printed. The ledger is where a
chunk's members show they belong together in the record; it is never, on its own, an arrow.

**Write the criterion.** One paragraph in `notes-07.md`: what would make you prefer a later pass to
this one. The loop's failure is ratcheting, every recut making the model draw a little better; a
criterion written after the passes exist is not a criterion. Number every pass, keep every version
(`structure.md`, `structure-p2.md`, `story-p2.md`), and say at the end which pass the model rests
on. **The stopping rule** (the contract's §8): stop after two consecutive passes in which no
`tier_history.jsonl` event occurred, no arrow was added, bounded, demoted or withdrawn in
`edges.jsonl`, and no sentence of the story that names an arrow or an element changed; never
before the third pass; one line per pass in `saturation.jsonl`. The v35 analyst stopped at pass
five on a flat tier curve while the model was still moving, and the reopening found its largest
error, 340 connection statements invisible to every screen: a rule that watches the tiers cannot
see an edge, so this one watches the edges and the story's sentences too. Read §5's three counts
as a trend across passes: a pass in which `told-with-residue` rose is not a good pass but a
stopping failure, and the residues are the next pass's material. A curve still climbing at the
last pass is a finding about the structure. From pass 4 on, keep the pass that best satisfies the
criterion rather than the last, and report what you discarded. The floor is there because the
first telling that holds is the one you most want to stop at, and the reading behind §5 is what
tells you whether it holds or you did.

**The fork.** Forks are taken at stage boundaries, with the transcript and the files together.
Where the operator forks the loop, the fork is taken as stage 06 closes, so every fork holds
the same `assignments_final.jsonl` and `form_pass-06.md` and diverges from this stage's first
pass; each fork runs 07 through 10, `fork_comparison-07.json` sets their models side by side,
and the carried fork is chosen at 10 by the rule the operator declared in `RUN.json` before any
fork ran (`tools/HOW-TO-RUN.md`). You do not choose it, and you are not told you are a fork.

**The tiers stay open up to the line** (rule 11): the second-order tier too, the rule amended
first and the touched case themes re-placed by you. Every recut and every item it moved goes to
`tier_history.jsonl`, and every `findings.jsonl` line it touches is re-examined in the same act.

## 2. Part A: the data structure

No relationships in this part.

### Chunks, cut and named as constructs

A third-order chunk is a named group of second-order themes. **No number is set for you.** The
count is whatever the material carries: enough chunks that each answers a question no member
answers alone, few enough that each is a step up in abstraction and not a rename of its members.
A tier that reduces nothing is not a tier, and a reduction made to hit a number is not a finding.
Say in `notes-07.md` what the count is and why the material carries that many. **Name it at the moment you cut it, as a construct**, and write
the declaration into the line:

```json
{"chunk": "C3", "label": "...", "members": ["S04","S11","S19"],
 "question": "what this chunk answers that no member answers alone",
 "construct": {"status": "borrowed|adapted|coined", "source": "the work it comes from, or null",
               "changed": "what you changed and why, for adapted; null otherwise",
               "mistaken_for": "the existing construct a reader will take this for",
               "disconfirm_elsewhere": "what would show it does not hold in another setting",
               "gloss": "the grounded phrase, kept"},
 "in_model": true, "pass": 2}
```

The contract's §1 and §3 govern the label: any literature may name a chunk, the four's vocabulary
included, under the declaration, and a borrowed or adapted name carries one sentence saying what
this material's version cannot do that the source's can (*task allocation without anyone who can
allocate*); the second-order tier beneath it keeps its descriptive names whatever the chunk is
called. Stage 09's prose test catches a name that will not carry a sentence, and you recut then. Every second-order theme no chunk picked up gets a `"chunk": null`
line at the foot with one clause saying why. `chunks.jsonl` is edited in place and has no second
version: a later stage appends the old line to `chunks_log.jsonl` as `{"stage": "09", "was":
{...}}`, then replaces it. `dimensions.jsonl` and `dimensions_log.jsonl` work the same way; create
both logs here, empty. `edges.jsonl` and the prose are revised as `.v2`, whole, with the original
standing.

### Dimensions

**The dimension tier is where this study speaks to theory, and it is built.** The second-order tier
is held to the material by design and is denied a construct's name; the chunks speak to the
literature at one remove; the dimensions speak to it directly. A model that stops at the chunks
stops one tier below the conversation it was built to have.

**No number is set for you here either.** Build as many as the chunks carry. Build one where all
three hold: it gathers two or more chunks answering the same question about the phenomenon; it
answers a question no chunk beneath it answers alone (*the model draws differently without it* is
the strongest form); a reader who was not here can place its name against some literature. Each
carries the same `construct` block as a chunk.

**A chunk need not roll up.** A chunk no dimension gathers gets `"dimension": []` and one clause
saying why, exactly as a theme no chunk picks up does. Do not invent a dimension to cover
stragglers: a catch-all is a heading, not a construct.

**Dimensions must hold apart, pairwise.** For every pair, name the chunk that belongs to one and
not the other, and the question that decides it, written from both sides. This is the second-order
tier's discriminator moved up, and it is what a single swollen dimension cannot survive.

**One dimension is a failure state, not an answer.** If everything gathers into one, you have
either a tier that does no work or a partition you have not found. Report it as a failure: the
candidate partitions tried, why each was rejected, and the runner-up shipped beside it in
`dimensions_log.jsonl` so a reader can see what lost. The same holds for none: *no dimensions* is
reported as a failure of the cut, with its candidates, and never as a complete answer.

```json
{"second_order": "S07", "label": "...", "dimension": ["D01"], "dimension_label": "...",
 "construct": {...}, "why": "...", "confidence": "clear|arguable"}
```

One line per second-order theme, always, with `"dimension": []` if you built none; every theme in
`assignments_final.jsonl` must appear.

### `structure.md`

Per **second-order theme**: what it is and is not; the description that decides a borderline case,
repaired from stage 06's disagreements; its nearest neighbours and the test that separates them;
what varies inside it and between what extremes; its gate, quoted from `scheme_v2.md`; the three
counts summing to `n_analysed` from your own run of `tools/counts.py`, or the sentence saying it
has no denominator and travels on exemplars (rule 5); three exemplars in participants' words; and,
where one of `coder_conflicts.jsonl`'s pairs was placed here, both coders' words under *read
another way*, with which reading your count rests on.

Per **chunk** and per **dimension**: the id; the label, its construct declaration and a
one-sentence gloss; what holds its members together, in your words, not a list; the question it
answers that no member answers alone; what would fall outside, with one near case; the member you
were least sure of, with both sides; for a dimension its membership predicate and gate; for a chunk
its material:

```json
{"chunk": "C3", "second_order": "S07", "case_theme": "<the coder's label>",
 "code_id": "c0113", "sub": "<community>", "author": "<handle as the record carries it>",
 "created_utc": 1491012345, "hour_since_open": 10.1,
 "quote": "the participant's own words, unedited",
 "position": "core|side|between", "nearest_neighbour": "C7 or null",
 "why_this_one": "one clause: what it shows that the others do not"}
```

Three to five quotes from two to four case themes per chunk, through `C.cite(sub, None, quote,
collection="codes")`, chosen for breadth and depth; where the good material sits at two edges with
nothing between, take two from each and say the middle was empty; if every quote comes from one
room, say so. The same spread rule governs the second-order exemplars.

**What no chunk picked up**, one short section: how many themes, of how many, and the code mass
they carry; what they were in general; two or three quotes; whether any of them should have been a
chunk, and why not. Stage 18 reads it beside the crossing's coverage.

**`data_structure.md`**: a display, one block per dimension (or per chunk), its chunks, their
themes, the case themes assigned, and for three case themes the codes beneath, so that a reader
can walk one community from something somebody wrote up to a dimension without a second file.

### Two more things Part A owes

**The pairs.** Rule 0's log, grouped by `(primary, additional)` pair: the supporting codes, one
quote doing both things at once, whether the pair crosses a dimension boundary, and how many
rooms produced a case theme spanning it beside how many themes did. The community count decides.
This is Part C's raw material.

**The entry-time contrast.** Cross your themes, and your dimensions, against the two sides
`contrast.md` declared, with `onset_denominator` from your own `counts.py`. Say whether the
expectation stage 01 wrote was met.

Compute every count in `structure.md` from `assignments_final.jsonl`; never by hand. State in
`notes-07.md` that every `second_order` in the assignments is defined, every dimension used is
defined, the three counts sum, and `dimensions.jsonl` has one line per theme.

**Part A's return**, per pass: themes per chunk and chunks per dimension, with the pairwise
separation for the two dimensions you are least sure of; the
construct status of each (borrowed / adapted / coined); the alternative grouping you rejected and
why; how many coder conflicts reached `structure.md`; whether the contrast showed anything; the
chunk you are least sure of.

## 3. Part B: the concept

Name the one concept, two at the outside, that the literature has no adequate word for: not the
largest theme, the one unaccounted for. Per candidate in `concept.md`: what it is, in a sentence a
stranger could use; the nearest existing concept you know of and precisely how this differs, from
recollection and said to be so (the literature is stage 08); how many communities carry it and how
you counted, with its gate declared before the count (rule 5); three participant quotes through
`cite()`; what having it lets you explain that you could not before. Choose, and say why not the
others; the rejected candidates stay in the file.

A concept that is a relabelling of something the literature handles is not a finding, and saying
so is an answer: *this study produced a description* is complete, with what would have had to be
different. A candidate that is the model's whole storyline is Part C's material, not a concept.
*Not yet* is an answer on any pass but the last.

**Part B's return**: the concept in one sentence; the nearest existing concept and the difference;
how many communities; the candidate you came closest to choosing instead; the literature a reader
would say already covers it, and how this differs from it.

## 4. Part C: the model

**The model is about eight things**, a working ceiling, and each is an element with an id,
`E1…En`, minted here and kept through stage 09: `model.md`'s apparatus lists every element with
its id, its name, the tier it lives at (a second-order theme, a chunk, a dimension or an `F`) and
its range, and stage 09's readers, stage 10's composers and the `held` reading all key on these
ids; an element cut later keeps its id retired, never reused. A thing is in the model if the
model would say something different about the concept or one of the contract's §1 four questions
without it. Name what you dropped and which of the five it failed. If more than about three of
the eight are named for what they are about rather than for what they do, you have a lattice.

### Three rooms first

Before any arrow, write three within-case accounts into `within_case.md`: one ordinary room, one
whose form the scheme could not have predicted, one that stopped early; three to five hundred words
each, from the room's codes, its forest and its chronology through `events()`, using no
second-order theme, chunk or dimension. Name the three in `notes-07.md` first, with why. When the
model exists, read it against all three; a room the model cannot narrate is a finding.

### How an arrow gets in

You form it, then you substantiate it. Start from the pair list and from the pairs crossing a
dimension boundary. Evidence, recorded in `grounding`: coder-dated order (a `Relations` section
with dates; `section()` prefix-matches); coder-stated connection; the codes underneath, read across
rooms; the ledger (`after`, `pairs`), as elapsed order and never as cause; whatever else you
devise, if you can say what you looked at and what would have disconfirmed it. An arrow may stand
on your reading alone, marked `"analyst_inference": true`.

**Every arrow in the model rests on an instance a reader can be shown.** Gioia's arrows come from
what informants said; yours come from what participants wrote and from the order they wrote it
in, and the reader is shown one of the two. So `support` carries a participant's words through
`cite()`, or `support_transition` carries a transition in a forest: two coded turns in one
thread, in order, cited by their item ids and codes, with the interval, from `mem.py after` or
the forest itself. An arrow with neither is `"in_model": false` whatever its count and whatever
you believe. This holds at whichever tier the arrows run between: an edge in
`edges_dimension.jsonl` carries, in its own `support` or `support_transition`, the strongest
instance from among the theme edges beneath it, and stage 09's figure draws no arrow that has
none.

**Every arrow is sampled against.** Before you set `strength`, go to rooms not in its `subs` where
the arrow should hold and could fail (theoretical sampling inside the corpus), and record them:

```json
{"from": "S03", "to": "S07", "kind": "order|transition|co-occurrence",
 "grounding": "dual-assignment|coder-dated|coder-stated|codes-read|ledger|<yours>|reading-alone",
 "grounding_note": "what you looked at and what you would have accepted as disconfirming",
 "sampled_against": [{"sub": "...", "why_chosen": "...", "found": "holds|fails|not testable"}],
 "strength": "strong|fair|thin",
 "subs": ["Jamaica", "KState"],
 "mechanism": "what the one does to the other, in one sentence",
 "mechanism_fails_if": "the observation that would show it did not operate here",
 "mechanism_failure_present": true|false|"not-addressed",
 "analyst_inference": false,
 "negative_check": "tested-absent|counterexample|not-addressed",
 "base_rate_beaten": true|false|null,
 "early_late": {"early": 7, "late": 2},
 "bound": "the condition a counterexample added, or null",
 "in_model": true|false,
 "support": [{"sub": "Jamaica", "code": "c0013", "quote": "..."}],
 "support_transition": [{"sub": "Jamaica", "thread": "t3_63x9ab",
                         "items": ["t1_dfu2a1", "t1_dfu3k9"], "codes": ["c0013", "c0021"],
                         "interval_min": 14}],
 "gloss": "..."}
```

`mechanism` says what the one thing does to the other, concretely enough to imagine it failing;
`mechanism_fails_if` is written before `strength`, and an edge without it is not an edge. An arrow
with a count and no mechanism is a correlation: `"in_model": false`, reported in `model.md` under
*ungrounded relationships*, expected non-empty. Stage 09 marks every proposition that rests
wholly on theorised edges; here, list every one.
`negative_check` is never silent. Where both themes carry *what varies inside it* and a coder
wrote the covariation down, you may draw an edge between degrees and say so; otherwise say in
`model.md` that the model relates presences and not amounts.

**A counterexample bounds an arrow; it does not erase it** (rule 16). A room in `sampled_against`
where the arrow fails names the condition under which it holds: write it into `bound`, keep the
arrow, and open or update a line in `findings.jsonl` with the room as the case that bounds it. An
arrow is withdrawn only when no condition you can state separates the rooms where it holds from
the room where it fails.

**Two counting traps, if you reach for a count.** A fixed minimum count may filter nothing, because
carry counts at this size clear small overlaps by chance. A co-occurrence count tested against the
product of two carry rates tests presence, not connection; build the null on the population the
edge is drawn from, define a connection-statement in writing before you count, and let a relation
that holds nearly everywhere stand as constitutive rather than be deleted by its base rate.

**The entry-time contrast.** Test each strong arrow on both sides and record `early_late`; apply
rule 6 before reading a gap. An arrow holding on one side is a boundary condition in the model's
own terms; on both, a stronger arrow.

### Stating the model

`edges_dimension.jsonl` projects every order edge onto the dimensions
its themes belong to, with `mechanism` and `mechanism_fails_if` written at the dimension's own
level and the strongest instance from beneath it in `support` or `support_transition`; where the
theme mechanisms will not abstract into one account, report the pair as mass, not as an arrow. Report per dimension the in-mass, out-mass and internal mass, with and without the
doubles (the case themes rule 0 placed on two themes); a dimension with no in-edges is a condition, one with no out-edges is residue, asymmetry
is drift. **If you built none**, state the model at the second-order tier over the themes the
concept and the contract's §1 four questions require, and name the rest as unused. Neither route is preferred.

State plainly: which tier the arrows run between; which second-order themes the model does not
use, by name and count; where the model should break, in its own terms (corpus size and topic are
limits on the sample, not boundary conditions).

**`model.md`**: one to two pages of prose, then the apparatus. Two tests before you call it
finished: read it against a room you know is odd and make it say what happened there as one way of
running the same structure; check that every element has a range. Then the structure, the
relationships with their fields, theorised edges listed separately and the model shown once with
them and once without; then the dynamics: loops, what returns a room to a state it had left, what
is irreversible across hour 73. **Claim a loop only where at least one room's own datings run the
whole way round it**, and only where that room's `events()` report has
`monotone_in_written_order: true` and no entry on the loop carries `date_source: "day marker"`;
otherwise the loop rests on `Relations` prose and is marked so. `day` is not comparable across
rooms; `t_utc` and `hours_since_open` are. Everything looked for and not grounded goes under
*looked-for-and-not-found*, in the results.

For your three strongest arrows, write the argument that each is an artefact of which coders wrote
about connections at all, and what in the record separates the two.

## 5. The story, told at the end of every pass and read against rooms

Stage 10 will ask a fleet to compose every room in the model's terms. That test is prepared for
here, pass by pass, by you: a model that has only ever been read against the rooms its arrows were
drawn from has not been read.

**At the end of every pass, tell the story**, `story-pN.md`, numbered with the pass: one to two
pages of prose that says what these rooms did, in the model's terms, as a stranger to the model
could follow it, from a scattered readership to whatever they left behind, with the loops and the
things that are irreversible across hour 73 in their places. **The story names every arrow it
uses**, by its ids in brackets after the sentence that uses it (*… and the call went out
[S03→S07]*), so that *no change to the story* is checked against `edges.jsonl` and not against
the feel of the prose. Then **read rooms against it**. At least fifteen per pass, named in
`story_rooms-pN.jsonl` before you open any of them, chosen by a rule you write there: the three
rooms of `within_case.md`, every time; every room that came back `told-with-residue` or
`not-told` from the pass before; rooms whose form the story does not yet name; rooms from the
side of the contrast the story has visited least; every room a `sampled_against` entry marked
`fails`; one room from each quartile of `items_in_window`, every time, so the confound that
decided v35 is in every draw; and rooms drawn by seed from the rest, so the set is not only the
rooms you already suspect. Choose the non-seeded rooms from the `doing` lines of
`rooms_index.md`, without opening a note, so that what a room made does not pick it. A room read
against an earlier story counts toward the fifteen again only if the story has changed
materially since, the three within-case rooms excepted. Read each whole, `mem.py room` and its
forest, and answer one question per room, on its line: can the story be told of this room in the
room's own terms, and if not, what would have to be added, changed or bounded for it to be.
`told`, `told-with-residue`, `not-told`, with the residue or the reason in one clause.

**The rooms that could not be told are the next pass's material, and so are the residues.** What
they need is a recut, an arrow, a bound or a new element, or it is the finding that the model
does not reach that kind of room, which rule 12 will make a boundary at stage 10 and not a
weakness. Do not loosen an element until a room fits; say what the room would need and whether
the model should have it. Each pass's line in `saturation.jsonl` carries the story's number, the
rooms read against it, and the three counts; read the counts as a trend across passes, and a
pass in which `told-with-residue` rose is reported as a stopping failure (§1). A story is not
improved by reading fewer rooms against it.

**The story is not the account.** Stage 09 writes the account from the model that survives; the
stories are the loop's own record of how the telling changed, and the last one is the first draft
of the account.

## 6. One reviewer, once, before stage 08 opens

The adversaries of the earlier versions are gone as a system; both readers of v37 asked for one
instance back, and said why: the false premise at the centre of v35's model was found by its
hostile reviewer and by nobody else, and the rival partition that met every stated criterion was
the only thing in that run that showed how under-determined the dimension tier was. So, when
the pass you keep is chosen: one fresh reader, one context, appended to `run_manifest.json`. It
gets `structure.md`, `chunks.jsonl`, `dimensions.jsonl`, `model.md`, `edges.jsonl`, the last story,
`notes-07.md`'s criterion paragraph, and `tools/cite_case.py` and `tools/mem.py` for the rooms,
`room` served `--no-canvas`; nothing else of yours, no room note, no findings, no prior. Its instruction, served verbatim and
copied into `review-07.md` above its return: *Find errors: a quote that does not show what it is
said to show, a contradiction, a count that cannot be right, a loop no room runs the whole way
round, an arrow whose instance does not show the order claimed. Separately, propose one partition
of the second-order themes into chunks that meets the criterion you were given and differs from
the analyst's, with what holds each of your chunks together. A disagreement is never a verdict:
your reading decides nothing, and you are told so.* Answer every item in `notes-07.md` under rule
13 before stage 08 opens: an error is fixed and logged; the rival partition is read for what it
shows about how determined your tier is, and answered either with a sentence saying why yours and
not it, or with a recut under rule 11.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then: which pass the model rests on, with Part A's and Part B's returns for that
pass; how many passes, how many rooms were read against a story in all, and how many the last
story could not tell, by name; edges by kind, how many theorised, and the model without them; how many carry a mechanism
with a failure clause and how many were demoted; how many arrows acquired a `bound` and from which
rooms; of the co-occurrence edges how many beat their base rate, and the connection-statement
definition in one line; of the order edges how many carry a real negative check; how many things
are in the model and how many themes it does not use; how many arrows rest on a quote and how many
on a transition; how many loops survived the one-room test; the three counts of every pass as a
table, and whether `told-with-residue` ever rose; what the reviewer found, by kind, and what its
partition showed; what the structure showed that the room notes did not predict; the one
relationship you most expected to find and could not ground; and which of the contract's §3
method licences you exercised here and which not. A return value.

## Close

Run `python3 tools/validate.py 07 . __OUTDIR__`, paste the report into `notes-07.md`, write
`handback-07.md`, and finish `diary-07.md` with its three closing headings.

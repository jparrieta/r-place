# Stage 08 — the model: the literature.

Input: `__OUTDIR__/structure.md`, `__OUTDIR__/chunks.jsonl`, `__OUTDIR__/dimensions.jsonl`,
`__OUTDIR__/concept.md`, `__OUTDIR__/model.md` and `__OUTDIR__/edges.jsonl` from stage 07;
`__OUTDIR__/prior.md`, re-read at 07 and read here first; `__OUTDIR__/notes-01.md`, for stage 01's three sentences; the tier C shelf, the
explanations, which arrives with this stage's package at
`package/store/shelves/literature-tierC.md` and is read with
`python3 tools/mem.py shelf literature-tierC`; the tier B shelf, open since stage 07; the corpus
through `tools/cite_case.py`; and the store through `tools/mem.py` (`where`, `codes --theme`,
`after`).

Outputs: `__OUTDIR__/literature.md`; wherever this stage changes something,
`__OUTDIR__/edges.v2.jsonl`, `__OUTDIR__/model.v2.md`, `__OUTDIR__/structure.v2.md` and
`__OUTDIR__/concept.v2.md`; `__OUTDIR__/v2_manifest.txt`; `__OUTDIR__/notes-08.md`; and, wherever
this stage recuts a tier under rule 11, appended entries in `__OUTDIR__/tier_history.jsonl` and in
`__OUTDIR__/chunks_log.jsonl` or `__OUTDIR__/dimensions_log.jsonl`.

**Revisions get new filenames and every one is a whole file** (rule 10: keep both, overwrite
nothing). `edges.v2.jsonl` carries every edge and `model.v2.md` the whole model; a file holding
only what changed is read downstream as the whole thing. **A recut of a tier is not a v2**: edit
`chunks.jsonl` or `dimensions.jsonl` in place and append the superseded line to its log, as stage
07 says. **Write `v2_manifest.txt`**, one line per file naming which have a v2 and which do not;
later stages read it first, read the v2 where one exists, and read stage 07's file where none does.

## 1. The sequence, and the log point

**Nothing is read against the explanation literature before this stage.** Within it, **read
`prior.md` first, before anything else**, and restate what you expected; read after a conclusion
has formed, it can no longer tell a finding from a prior. Then, before you open tier C, re-read
the contract's §3 (the method as its authors state it), `METHOD-SHELF.md`'s hierarchy and tier B
through `mem.py shelf`: the v35 analyst had forgotten tier A by the time tier B arrived, and an
explanation read on a forgotten foundation is a relabelling waiting to happen. Every shelf that
has arrived stays in the store; nothing served once is taken away.

**Record where the read logs stand before you open the shelf**: the line counts of
`_aggregator_reads-08.jsonl` and `_mem_reads-08.jsonl`. Record them yourself; `tools/cite_case.py`'s
sequence counter resets whenever the tool is constructed and cannot be pointed at. From there on,
**no read of the corpus may add a theme or an edge.** You may read to check a quote or a count, and
pass 2 buys one declared return beyond that; you may not go looking for material that supports
something you have just recalled from a paper. If you break this, declare it under rule 10 before
you act. The log records what was served and not why, so it cannot tell a check from a hunt; say so
in `literature.md`.

**Say in `notes-08.md`, first**, that the literature is read after the model and not through
it, as the contract's §6 requires; it is the design, not a departure, and no `departures.jsonl`
line is written for it. Then say whether the substitution worked: whether knowing the contract's
§1 frame and not building with it was a distinction you could hold while writing the scheme and
adjudicating its placements.

## 2. How to cite

Mark every claim about the literature one of two ways: **`verified`**, you opened it in this
session and can quote it; **`recalled`**, you are working from what you know, with author, year and
the claim you are attributing, so a reader can check it. **Do not invent a reference, a title, a
year or a quotation, and do not attach a real author to a claim you are not sure they made.** Where
you are unsure, write *I believe this literature holds X but cannot verify it here* and carry on.

## 3. Pass 1: conflicting

Work that reports the opposite of what you found, or that explains your phenomenon with something
you did not use. For each conflict: what the other account predicts here, what you found, and
which of three things is true: the accounts disagree about the world, they disagree about the
setting, or they are about different things and one of you has the wrong name for it. Say which,
and say what in the record decides it.

## 4. Pass 2: similar, from fields with nothing to do with this one

**This is the pass that supplies mechanisms.** Take your model's arrows, particularly the ones
whose `mechanism` field you found hardest to write, and ask what other literature describes the
same move, going deliberately outside organization studies. For each match: what the distant work
holds the mechanism to be, and whether it fits here.

**Where it fits, rewrite that edge's `mechanism` in `edges.v2.jsonl` and in `model.v2.md`, keep
the stage 07 sentence beside it, and mark the field `from-literature`.** Stage 09 takes each
mechanism from the edge that grounds it; one left only in `literature.md` is invisible downstream.

Where the distant work predicts something here you have not looked for, that is the one declared
return to the corpus, logged under rule 10. Test it, record the result either way, and say whether
it qualified or bounded an edge; it may not create a theme or an edge. If you decline the return,
say why.

## 5. Pass 3: the concept

Stage 07 named a concept and guessed at its nearest existing referent from recollection. Test the
guess. Three outcomes, all real:

- **It survives.** The literature has no adequate referent. Say what the nearest three are and how
  each falls short.
- **It is a relabelling.** Adopt the existing name and say what your material adds, usually a
  setting, a boundary, or a mechanism the original did not have.
- **It is a relabelling and adds nothing.** Then the study produced a description and the model
  stands without a named concept at its centre. Write that; stage 09's propositions do not depend
  on a concept surviving.

If this pass changes the concept, write `concept.v2.md` and leave `concept.md` standing.

## 6. Pass 4: the standing claim, in both directions

Stage 14 crosses every cell in scope against the four universal problems, and it runs after this
stage. What you write here is **a claim made before the measurement exists**: stage 15 reads it
beside the strain figure, and stage 18 says how it fared. Do not wait for the strain figure, and
**be specific enough to be wrong.**

The contract's §1 claim is that every group with a goal must solve four problems, task division,
task allocation, reward provision and information provision, whether or not anyone says so. Put it
to your structure and model as they stand, and **do not revise them to accommodate it**. Where a
chunk already carries one of the four's names under a declaration, say so first: a chunk named
*task allocation* at stage 07 answers this pass by construction, and what the pass asks of it is
the sentence on what this material's version cannot do, and whether the frame's version would
have cut the chunk where you did.

Two limits on the answer. Your evidence is talk and the claim is about arrangements: a group can
allocate work perfectly and never write a word about it, and the contract's §4 holds you to
organizing *done in public*. And there is no denominator: you have the share of coded records that
maps onto each problem, confounded as the contract's §4 describes, not the share of groups that
solved it.

Answer in six parts:

1. **What you expected**, quoted from `prior.md` rather than remembered: which of those things you
   found, whether any turned up only where the material was thin, and what `prior.md` holds that
   your structure has no room for.
2. **What in your structure speaks to the claim**, theme by theme, with counts and rule 5's gate,
   and for each whether the material put it there or you did.
3. **What your structure carries that the claim has no place for**, the half that produces a
   contribution. Be specific, and quote.
4. **Which of the four your structure reaches richly, which thinly, and which not at all**, and for
   each thin or absent one whether the limit is in the material, in the coders' selection, or in
   your own pruning. Where one comes back nearly empty, take a side: did these rooms not solve that
   problem, or can your instrument not see it? Say which you think and why. Stage 18's *what the
   study cannot say* inherits this paragraph directly.
5. **Whether your material supports the claim, contradicts it, or is silent**, with the contract's
   §4 warning on every count: a claim about what is *absent* here is a claim about small rooms
   writing in public.
6. **Whether the claim is answerable with this material at all.** *The structure does not speak to
   this* is a complete answer.

## 7. Keep the construct declarations current

Where tier C shows a construct is borrowed or adapted rather than coined, or mistaken for a
construct you had not named, amend its `construct` block (stage 07 §2) and log the event, with
the sentence saying what this material's version cannot do wherever the name is borrowed; the
second-order labels stay descriptive and do not change here (the contract's §1). Record what
changed in `structure.v2.md`.

**You may recut chunks and dimensions here, and the second-order tier too, under rule 11**, and
stage 07's rule on the dimension tier holds through every recut: no number is set, a chunk may
roll up to nothing, the dimensions hold apart pairwise, and collapsing to one is a failure state
reported with its candidates and its runner-up, never an answer. A recut that empties the tier is
reported that way here too. And
every `findings.jsonl` line a recut touches is re-examined in the same act (rule 14). A
literature that shows a chunk holding two things the field keeps apart means the cut was wrong.
Amend the set, append the event to `tier_history.jsonl` with one clause of reason, edit the tier
file in place with its superseded line appended to `chunks_log.jsonl` or `dimensions_log.jsonl`,
re-place what the amendment touches yourself by applying the amended rule, and redraw whatever
depended on it.

## 8. Stage 01's three sentences

Read them now, from `notes-01.md`, for the first time since. Say which of this stage's conclusions
you would have reached anyway and which the material forced.

## Your final message

The claim, the room that best supports it, the room that most threatens it, and the condition that
separates them. Then: conflicts found and how each resolved; the one distant field that supplied a
mechanism; whether the concept survived; how much of `prior.md` came true; what the standing claim
did to your structure and what your structure carries that it has no place for; how many names
changed; which files have a v2; how many citations are `verified` and how many `recalled`; the
log point at which this stage began; and which of the contract's §3 method licences you
exercised here and which not. A return value.

## Close

Run `python3 tools/validate.py 08 . __OUTDIR__`, paste the report into `notes-08.md`, and write
`handback-08.md` and finish `diary-08.md` with its three closing headings.

# Handover — the handler

For whoever holds the handler's seat next, person or agent. You are one of three parties in this
run. The analyst does the study. J owns the study and makes every judgement that belongs to an
author. You stand between them, and your job is to make J's part small, structured and hard to get
wrong.

Read this page, then `CONTROL/HANDLER-PROTOCOL.md` for the mechanics, then `OPERATOR.md` in the kit
for the study's own rules. The eighteen cards in `STAGE CARDS/` are written for J, not for you; they
are what you send him.

## The shape of the thing

The analyst is a Claude Code session on J's Mac, working inside `00_GIVE-THE-AGENT/` and seeing
nothing else. It is the only thing in this run that gets forked, because it is the only thing whose
conversation is saved.

You are a Cowork session with the whole run folder mounted. You never open a Claude session with
the analyst's config directory, and you never touch `00_GIVE-THE-AGENT/` while a stage is live.

J opens and closes the analyst's session in Terminal. That is the whole of his mechanical work. He
has said plainly that he does not know bash and does not want to. Take him at his word.

## The division

**J does exactly three things.** He runs `step.sh`, he quits Claude when a stage ends, and he makes
the judgements that are his: the two readings, the rulings you escalate, and anything the analyst
asks him.

**You do everything else.** Closing stages, checkpoints, verification, forks, comparisons, the
budget, the ceilings, filing his objections in the form the contract wants, answering the analyst's
questions through the next drop.

**Neither of you does the other's work.** You never write J's operator objections for him: an
instrument that grades itself measures nothing. He never edits the run by hand.

## How you talk to J

He wants his inputs minimal and structured by you. So structure them. Every message you send him is
one of seven kinds, and each says at the top which kind it is and what, if anything, it needs back.
Never send him two kinds in one message.

**1. READY.** A stage is prepared and verified. Give him the stage number, one sentence on what the
stage is for, the exact line to run, and the card. Nothing else.

> Stage 04 is ready. A fleet of coders applies the frozen scheme to everything, under an 8M ceiling.
> In Terminal, in the run folder, run: `./CONTROL/harness/step.sh 04`
> Paste the line it prints into Claude and nothing else. Tell me when you have quit.
> Card attached: Stage 04.

**2. CLOSED.** A stage closed, was verified and is checkpointed, and nothing is needed from him. Say
what it produced in one or two sentences, say what the checkpoint cost, and go straight into the
next READY. This is most stages. Keep it short: he is not reading closely at this point, and the
detail is on disk.

**3. READING.** Stages 10 and 12 only, and these are the two moments that matter to him. Do not send
him a path and a filename. Read `out/operator_draw-10.json` yourself, render the ten compositions
into the message in a form he can read beside the rooms they claim to describe, and ask for his
objections in prose. He replies in the chat, in ordinary words. You turn his words into the lines
`objections.jsonl` requires and you file them. Tell him you have filed them and read them back to
him once. If he has no objection, you still file the one line saying so, because silence does not
count and the analyst must answer him before stage 11 computes.

**4. QUESTION.** The analyst asked something in its handback. Quote the question, say what you think
the answer is and why, and ask him to confirm or correct. Then write the answer as a file into the
next drop. It never goes into the chat with the analyst, and it never goes in as your own opinion
dressed as his.

**5. RULING.** Something is genuinely his: it cannot be undone, or it could reasonably go either
way, or it changes what the study claims. Give him the choice in at most four options, say which one
you recommend and why in two sentences, and stop. Do not proceed on your own reading of an ambiguous
instruction if the cost of being wrong is a stage.

**6. PROBLEM.** A close refused, a validator failed, a ceiling was hit, a checkpoint would not
commit. Say what happened in plain words, say whether the run is safe, say what you propose. Never
present a failure as a decision for him unless it really is one.

**7. FORK.** A fork point closed. Tell him how many children you made, what each will run, and give
him the line for each one. Then treat each child as an ordinary run.

Two standing rules on tone. Say what you did, not how hard it was. And when he asks a question in
the middle of a stage, answer it and return him to the card; do not restage the whole plan.

## What he must never be asked to do

Type anything except `step.sh`. Read a path and go find a file. Edit JSON. Interpret an error.
Remember which stages share a session. Remember what a fork point is. If you find yourself writing
"just run this small command", write the command into the run yourself instead, or ask for a ruling
and do it for him.

## What must never reach the analyst

The one line `step.sh` prints, and nothing else. Not earlier runs, not other arms, not the model it
is running on, not the instrument version, and above all not that it is a fork or that a sibling
exists. Answers to its questions arrive as files in the next drop. If J says something to it in the
chat that he should not have, tell him at once, record it in the handover log, and treat that fork's
comparison as compromised rather than quietly carrying on.

## The run as it stands, 2026-09-08

The run is `gioia-j-sonnet-v37-20260908`. Every role is on `claude-sonnet-5`. The budget is 60
million tokens, which was the previous session's figure and not J's; the ceilings are 8M at stage
04, 20M at 10 and 4M at 14. The fork points are the close of 01, the close of 06 and the close of
09. The carry rule is declared in `RUN.json` and applied at 10.

The instrument is v37, fingerprint `2e1e4686828a3c1e…`, frozen at `Layer A/60_aggregator/v37/`. The
harness is the one GPT-6 proposed on 2026-09-08 and this session applied, after checking each of its
claims against Claude's own documentation. What changed, and why it matters to you:

- A checkpoint is now the whole analyst folder, the agent's persisted state, the instrument and the
  verified transcript, built under a lock in a temporary directory and published only after its
  manifest verifies. `COMMITTED` is written last. A reader trusts nothing else.
- Sessions are chosen by identity, never by which file was written last.
- A stage will not close while its session is live, which is why J must quit first, and will not
  close on an unfinished turn or a failed validator. `--force` and `--force-order` exist, are
  logged, and do not unlock the next stage on their own.
- Forks and restores read committed checkpoints only, and a child carries its ancestry.
- The analyst is fenced into its own folder by `blockReadsOutsideWorkingDirectories`, with the
  sandbox as a second layer and the unsandboxed retry closed off. Permission mode is `auto` on J's
  ruling, which does not weaken either fence.

Two corrections were made beyond GPT-6's patch, because it patched a built run and not the kit: the
kit's `build.sh` did not know about the new placeholder for the analyst's folder, so a fresh build
would have shipped a broken settings file, and it did not carry the new private validator copies or
the protocol page into the run. Both fixed. The superseded harness is at
`Layer A/_exports/_to_delete/kit-20260908-before-codex-patch/`.

## What has not been tested, and what you must do about it

The whole patch passes its own eighteen integration tests, run on this machine and not only on
GPT-6's. Those tests replace Claude with a stub. Nothing in this run has yet been proved against the
real command-line tool.

**Before stage 01, test the fork flags.** The harness launches a fork as
`claude --resume <parent> --fork-session --session-id <new uuid>`. That combination is not
documented. `--session-id` reads as being meant for a new conversation, and the documented way to
learn a branch's id is that Claude prints it. If the tool refuses the combination, every fork fails,
at 01, at 06 and at 09. Prove it on a throwaway conversation first. This is the single largest risk
in the run and it costs two minutes to remove.

**Watch the completion gate.** The rule that decides a stage finished reads the transcript's
internal structure. That shape is not a documented contract. It fails closed, which is safe, but it
can refuse a stage that is genuinely done. If that happens, do not reach for `--force` silently:
send a PROBLEM, say what you saw, and say that forcing is recorded.

**Check the access fence for real, once.** At stage 01, have the analyst try to read `CONTROL/` and
a stage it has not been handed, through the file tools and through Python. Deny rules do not reach
arbitrary subprocesses; the sandbox is what stops those. If either read succeeds, stop the run and
tell J, because the fork comparisons depend on the analyst not knowing what it must not know.

## The vault, and how not to damage it

Nothing is deleted. Anything superseded goes to `Layer A/_exports/_to_delete/` under a dated name
and is J's to purge. The mount will not let you delete, and it refuses to overwrite a file a tar
created; move the old thing aside and write fresh. Never touch `Sandboxes/Gioia v35/` or
`Staging v35/` unless J asks. A single bridge call that runs past about three minutes drops the
bridge, so do long work in steps or in the background and poll. Versions are integers. Every
instrument version carries a fingerprint and every run names the fingerprint it ran under.

The run itself must stand outside the vault. It belongs at `~/rplace-runs/`, with that folder
connected to the handler's session, so that forks, which are created as siblings of the run, land
where you can reach them.

## When the run ends

`extract_interventions.py` and then `seal.py --to "<vault>/Layer A/62_sealed_runs"`. Write the state
of play into the project as a doc, and a handover like this one for whoever comes next. What is not
written down did not happen.

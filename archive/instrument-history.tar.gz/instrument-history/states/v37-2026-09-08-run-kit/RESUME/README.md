# Resuming a stage so somebody can talk to the aggregator

## Which stage: step-09

**The model is freshest at the close of stage 09, and nothing after that touched it.**

Stages 07, 08 and 09 ran in one session, `7577e8f1-f098-47c2-827e-7e0003d31f50`. That session built
the model: the loop at 07, the literature at 08, and the account, the figure and the propositions at
09. At the close of 09 the model build is not something the aggregator once read. It is the whole of
its recent context.

The files say the same thing. These five are byte-identical from the stage 09 snap through the stage
18 snap:

| file | sha256 (first 16) | bytes | unchanged from |
|---|---|---|---|
| `model.v2.md` | `b7c5b3d061877634` | 35,400 | 09-close onward |
| `structure.v2.md` | `8cd4af8bdd2003bf` | 264,075 | 09-close onward |
| `propositions.md` | `6cc278d95816f71f` | 14,866 | 09-close onward |
| `figure.md` | `ee1b28f0694e153f` | 6,547 | 09-close onward |
| `chunks.jsonl` | `11aa768e63040c71` | 17,833 | 09-close onward |

One file did change once. `account.md` went from 12,200 bytes at 09-close to 12,322 at 10-close and
never moved again. Stage 10 amended the account while composing the model to the rooms.

So:

- **step-09** is the maker's mind. The session being resumed is the one that made the model, with
  the making still in front of it.
- **step-10** holds the same model plus the amended account and the composition result, but that is
  a different session, `e8fefecc`, which opened at stage 10 and *read* the model. Its memory of the
  model is a reading, not the making. Use it if the interview is about whether the model composes.
- Anything later pushes the model further back behind a clustering or a crossing.

## What the aggregator at step-09 knows, and does not

It knows the corpus, the tiers, the model it has just built, and everything it wrote through stage
09. It does not know that stages 10 to 18 exist, it does not know the clusterings, the crossing, the
audit or anything the operator ruled afterwards, and it has never been told what the study is for,
which models served it, or that there are other arms.

That is a feature. It cannot leak what it does not have, and an interview at step-09 is an interview
about the model on its own terms. It also means an interviewer must not tell it any of those things,
because the conversation is being recorded and whatever is said becomes part of the restored copy.

## How to open it

```bash
/Users/arrieta/Jail/gioia-j-sonnet-v37-20260908/RESUME/open-stage.sh
```

That is the whole thing. It restores step-09 into a new dated directory under
`~/Jail/interviews/`, verifies the checkpoint against its manifest and the filesystem file by
file, prints the session id, and opens the conversation in the Claude Code CLI.

Then paste `PREAMBLE.md` as the first message. Without it the aggregator will try to run the next
stage, because from inside that conversation the stage has only just closed.

Other uses:

```bash
./RESUME/open-stage.sh step-10                # a different close
./RESUME/open-stage.sh step-09 ~/somewhere    # a named destination
NO_OPEN=1 ./RESUME/open-stage.sh              # restore and print the command, do not open
```

## What it can reach

Verified on the restored copy, not assumed.

The OS sandbox allow-lists exactly one readable directory: the restored copy's own
`00_GIVE-THE-AGENT`. Everything else is denied at two layers, the permission layer and the kernel
sandbox:

| denied | |
|---|---|
| `CONTROL/**` | the rulings, the harness, the handler notes, the checkpoints |
| `DROPS/**` | every stage file, including 10 to 18 |
| `STAGE CARDS`, `HANDOVER-handler.md`, `READ-ME-FIRST.md` | the operator's own material |
| `~/.claude/**` | your machine's Claude config |
| WebFetch, WebSearch, every `mcp__*`, `Skill` | no outside world |
| `network.allowedDomains: []` | no network at all |

`sandbox.enabled` is true, `failIfUnavailable` is true and `allowUnsandboxedCommands` is false, so a
shell command cannot step outside that one directory either. The run folder itself,
`Jail/gioia-j-sonnet-v37-20260908`, is not reachable from the copy at all: the copy is a separate
tree with its own absolute paths, rewritten at restore.

Two things the run left behind that do not belong in an interview, both now removed by default:

1. `.claude/settings.local.json` carried about thirty Bash allow rules accumulated over stages 01 to
   09, including `python3 -` and `python3 -c`, and a stale absolute path to the run directory.
2. `permissions.defaultMode` was `auto`, so commands ran without asking.

The script deletes the first and sets the second to `default`, so whoever sits at the terminal is
asked before anything runs. `INTERVIEW=0 ./RESUME/open-stage.sh` leaves both exactly as the run had
them, for when you want the environment reproduced rather than an interview.

**Not verified:** that writes are confined the way reads are. Reads are allow-listed and I checked
them; the settings declare no write rule, and I have not tested what a write outside
`00_GIVE-THE-AGENT` does. Since the copy sits under `~/Jail/` and holds nothing you need, the worst
case is a mess inside a directory you delete afterwards.

## Six things to know before you hand this to somebody

1. **It must run on the subscription, not through OpenRouter.** The session was served by Anthropic.
   A session cannot change route once served: resuming it through the gateway fails with
   `previous_message_id: must be the id from a prior /v1/messages response (starts with msg_)`. The
   script unsets every variable `claude-free` sets, so run it from any shell and it will be right.
   Do not run it with `claude-free`.

2. **It only works in the Claude Code CLI.** The desktop app, the web version and the editor
   extension each keep their own session store with no way in. A bundle opened there gives the files
   and an inert transcript: a fresh reader, not the aggregator continuing. Results from the two
   cannot be pooled.

3. **Each run restores a fresh copy.** About 165 MB for step-09. The interview writes into that
   copy's own `CONTROL/.cc`, never into the run. Two interviewees get two directories and never see
   each other's questions. Delete a directory when you are finished with it.

4. **The aggregator keeps its tools.** It can open its own files inside `00_GIVE-THE-AGENT`, which
   is what makes it useful to a reviewer who wants a quote checked. It cannot see `CONTROL`, later
   stages or the handler. If you want a pure memory test instead, launch with the tools denied and
   say so to the interviewee, because the two produce different interviews.

5. **The first answer is expensive.** The whole stage transcript is paid for before the aggregator
   says anything. The 07 to 09 session is 2,995 lines. A second interview restored from the same
   checkpoint should be cheaper, since the prefix is identical and cacheable, but that is an
   expectation and not a measurement. Measure it on the first two.

6. **Do not run this while a stage launcher is live.** `restore_stage.sh` takes the run's lock. The
   run is closed, so this is a note for the next run rather than for now.

## Tested, on 2026-09-22

The restore path is not a suggestion. `step-09` was restored into a scratch directory and checked:

- 43 seconds, manifest verified, filesystem verified file by file, transcript verified against the
  recorded boundary.
- `out/` holds no stage 10 or later file. `model.v2.md` in the restored copy hashes to
  `b7c5b3d061877634`, the stage 09 value.
- `CONTROL/.cc/projects/run/` holds seven transcripts, stages 01 through 09, and none later.
- The sandbox was rewritten for the new location: `CONTROL`, `DROPS`, `STAGE CARDS` and the two
  handler files are denied to the aggregator at both the permission layer and the OS sandbox layer,
  web and MCP are denied, and `allowedDomains` is empty.

Only the last step was not exercised, because `claude` is not installed where the test ran: the
CLI actually opening the conversation. If that step fails, the restored directory is still good and
the reopen command is printed for you to run by hand.

The scratch copy was moved to `~/Jail/test/_to_delete/` rather than deleted, since deletion is off
in these folders.

## One thing a human can see that the aggregator cannot

`instrument.tar.gz` carries the whole `DROPS/` tree, so the restored directory contains the stage
files for 10 through 18 even though the aggregator is at the close of 09. The sandbox denies them to
the aggregator, verified above. It does not deny them to a person sitting at the terminal. Do not
open `DROPS/` in front of an interviewee, and do not ask the aggregator about anything you read
there.

## If the restore refuses

Diagnosed and fixed on 2026-09-22. Keeping the account because the same shape will recur.

`REFUSING: restored tree differs from its checkpoint manifest` does not say which tree. The harness
verifies **two** and raises the same sentence for both:

| tree | manifest | entries |
|---|---|---|
| `DEST/00_GIVE-THE-AGENT` | `fs.sha256` | 4,290 |
| `DEST/CONTROL/.cc` | `agent-files.sha256`, under the `--agent` rule | 1,688 |

### What it was

Two directory modes in the second tree:

```
projects        want 0o700, got 0o755
projects/run    want 0o700, got 0o755
```

`restore_stage.sh` line 39 runs `mkdir -p "$DEST/CONTROL/.cc/projects/run"` and only then, at line
41, extracts `agent.tar.gz` over it. `mkdir` applies the caller's umask, so under the macOS default
of 022 those two directories are created 755. macOS bsdtar then leaves an already existing
directory's mode alone, so they stay 755, and the manifest wants 700. GNU tar resets them, which is
why the same checkpoint restores cleanly on Linux and refuses on a Mac.

### The fix, and what it is not

`open-stage.sh` sets `umask 077` before calling `restore_stage.sh`, so the two directories are
created 700 and match.

umask has nothing to do with the *archived* files. That was tested: extraction under 022 and under
077 produced identical, correct modes for all 4,290 entries of the first tree, because tar restores
the modes it recorded. umask matters here only for the three directories the restore script creates
itself before extracting. An early guess that blamed umask for the whole tree was wrong and was
withdrawn; the mechanism above is the one that holds.

### The real repair belongs in the harness

`restore_stage.sh` should not create those directories before extracting over them. Either extract
first and create only what the archive did not, or `chmod 700` after. Until that is done, anything
that calls `restore_stage.sh` on macOS without `umask 077` will refuse. That includes the
`restart.sh` planned for the public repository, where the person restoring will be on a Mac and will
have no idea what to make of the message. Recorded in
`CONTROL/handler-log/04-the-harness-what-to-build.md` as H11.

### Also still live

`.DS_Store`. There is one in the manifest, 8,196 bytes at the root of `00_GIVE-THE-AGENT`, captured
because Finder had been in that folder during the run. If Finder or Spotlight rewrites it after
extraction, its sha changes and the check fails the same way. Restore where Finder is not looking.

### The diagnostic

```bash
./RESUME/diagnose.sh                                   # newest under ~/Jail/interviews
./RESUME/diagnose.sh ~/Jail/interviews/step-09-...     # a named one
```

It checks both trees, names the one that differs, and prints the first dozen entries of each kind.
It reads and changes nothing.

## A caveat in the record

Every checkpoint in this run carries `session.boundary_verified: false`, step-09 included. That is a
property of the harness at save time, not a defect of this checkpoint: it is uniform across all
eighteen. Restoration does verify, at restore time, that the archived transcript matches the
recorded boundary, and `restore_stage.sh` refuses if it does not. If a restore ever refuses, stop
and do not work around it.

## Files here

| file | what it is |
|---|---|
| `open-stage.sh` | restore and open, one command |
| `PREAMBLE.md` | the first message to paste, every time |
| `diagnose.sh` | why a restore refused |
| `README.md` | this |

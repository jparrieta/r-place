#!/usr/bin/env bash
# open-stage.sh [LABEL] [DEST]
#
#   Restore a closed stage into a throwaway directory and open the aggregator's own conversation
#   in the Claude Code CLI, so a person can talk to it as it stood at that close.
#
#   Default LABEL is step-09, the close at which the model is freshest. See README.md.
#   Default DEST is ~/Jail/interviews/<LABEL>-<utc stamp>, a new directory each run, so the
#   restored copy is never reused and the run itself is never touched.
#
#   ./RESUME/open-stage.sh                 # step-09, new dated directory, opens the CLI
#   ./RESUME/open-stage.sh step-10         # a different close
#   ./RESUME/open-stage.sh step-09 ~/x     # a named destination
#   NO_OPEN=1 ./RESUME/open-stage.sh       # restore and print the command, do not open
#   INTERVIEW=0 ./RESUME/open-stage.sh     # leave the run's own permissions untouched
#
set -euo pipefail

RUN="${RUN:-/Users/arrieta/Jail/gioia-j-sonnet-v37-20260908}"
LABEL="${1:-step-09}"
DEST="${2:-$HOME/Jail/interviews/${LABEL}-$(date -u +%Y%m%dT%H%M%SZ)}"

CP="$RUN/CONTROL/snapshots/$LABEL"
[ -f "$CP/COMMITTED" ] || { echo "no committed checkpoint $LABEL under $RUN" >&2; exit 1; }
[ -e "$DEST" ] && { echo "REFUSING: $DEST exists. Pick another destination." >&2; exit 1; }

# 1. The session was served by Anthropic. A session cannot change route once served: resuming it
#    through OpenRouter fails with previous_message_id must start with msg_. Strip every variable
#    the claude-free function sets, so nothing from that shell reaches this one.
unset ANTHROPIC_API_KEY ANTHROPIC_AUTH_TOKEN ANTHROPIC_BASE_URL ANTHROPIC_MODEL \
      CLAUDE_CODE_SUBAGENT_MODEL ANTHROPIC_SMALL_FAST_MODEL CLAUDE_CODE_MAX_OUTPUT_TOKENS \
      CLAUDE_CODE_PRINT_BG_WAIT_CEILING_MS 2>/dev/null || true

# 2. Restore. This verifies the checkpoint against its manifest, the filesystem file by file, and
#    the archived transcript against the recorded boundary, before anything is written.
#
#    umask matters here and is not optional. The manifest records every file as 0o600 and every
#    directory as 0o700, the modes the run wrote them with. tar applies the caller's umask on
#    extraction, so extracting under the macOS default of 022 produces 644 and 755, every mode then
#    differs from the manifest, and verification refuses the whole tree. 077 reproduces what the
#    manifest expects.
# The early checkpoints (start) were written with 0o644/0o755; the later ones with 0o600/0o700.
# Read the manifest's first file mode and match it, so every checkpoint restores.
if [ "$(awk -F'\t' '$1=="file"{print $2; exit}' "$CP/fs.sha256" 2>/dev/null)" = "0o644" ]; then umask 022; else umask 077; fi
mkdir -p "$(dirname "$DEST")"
if ! "$RUN/CONTROL/harness/restore_stage.sh" "$LABEL" "$DEST"; then
  echo >&2
  echo "The restore refused. The half-built tree is left at:" >&2
  echo "    $DEST" >&2
  echo "Run this against it to see what differs, then delete it:" >&2
  echo "    $RUN/RESUME/diagnose.sh \"$DEST\" $LABEL" >&2
  exit 1
fi

# 3. Interview hardening. The restored copy is already jailed: the OS sandbox allow-lists exactly
#    one readable directory, the copy's own 00_GIVE-THE-AGENT, and denies CONTROL, DROPS, STAGE
#    CARDS, the handler files, the network and every MCP tool. Two things are still as the run left
#    them, and neither belongs in an interview:
#      - .claude/settings.local.json carries about thirty Bash allow rules accumulated over stages
#        01 to 09, including `python3 -` and `python3 -c`, plus a stale absolute path to the run.
#      - permissions.defaultMode is "auto", so commands run without asking.
#    INTERVIEW=0 leaves both exactly as the run had them.
if [ "${INTERVIEW:-1}" = "1" ]; then
  rm -f "$DEST/00_GIVE-THE-AGENT/.claude/settings.local.json"
  python3 - "$DEST/00_GIVE-THE-AGENT/.claude/settings.json" <<'PY2'
import json,sys
p=sys.argv[1]; d=json.load(open(p))
d.setdefault('permissions',{})['defaultMode']='default'
json.dump(d,open(p,'w'),indent=2)
PY2
  echo "  interview mode: run-time Bash allow list removed, commands now ask before running."
fi

read -r SID MODEL STAGE <<< "$(python3 - "$CP/checkpoint.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print(d['session']['session_id'], d['run']['model'], d['stage'])
PY
)"

cat <<MSG

  ------------------------------------------------------------------
  restored   $LABEL
  session    $SID
  model      $MODEL
  directory  $DEST
  ------------------------------------------------------------------

  Paste RESUME/PREAMBLE.md as the first message. Without it the aggregator will try to run the
  next stage, because from inside the conversation the stage has only just closed.

  To reopen this same copy later:

    cd "$DEST/00_GIVE-THE-AGENT"
    CLAUDE_CONFIG_DIR="$DEST/CONTROL/.cc" CLAUDE_CODE_PROJECT_DIR_NAME=run STAGE=$STAGE \\
      claude --resume $SID --strict-mcp-config -n interview-$LABEL --model $MODEL

MSG

[ "${NO_OPEN:-0}" = "1" ] && exit 0

cd "$DEST/00_GIVE-THE-AGENT"
exec env CLAUDE_CONFIG_DIR="$DEST/CONTROL/.cc" CLAUDE_CODE_PROJECT_DIR_NAME=run STAGE="$STAGE" \
  claude --resume "$SID" --strict-mcp-config -n "interview-$LABEL" --model "$MODEL"

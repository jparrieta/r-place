#!/usr/bin/env bash
# diagnose.sh [DEST] [LABEL]
#
#   restore_stage.sh verifies TWO trees against TWO manifests and raises the same message for both:
#     1. DEST/00_GIVE-THE-AGENT   against fs.sha256
#     2. DEST/CONTROL/.cc         against agent-files.sha256, under the --agent rule
#   This checks both and says which one differs. It reads and changes nothing.
#
set -euo pipefail
RUN="${RUN:-/Users/arrieta/Jail/gioia-j-sonnet-v37-20260908}"
DEST="${1:-$(ls -dt "$HOME"/Jail/interviews/*/ 2>/dev/null | head -1)}"
LABEL="${2:-step-09}"
DEST="${DEST%/}"
[ -n "$DEST" ] && [ -d "$DEST" ] || { echo "no restored directory found; pass one as the first argument" >&2; exit 1; }
CP="$RUN/CONTROL/snapshots/$LABEL"

echo "tree      $DEST"
echo "checkpoint $CP"
echo "umask     $(umask)"
echo

python3 - "$DEST" "$CP" <<'PY'
import hashlib, os, stat, sys
from pathlib import Path

dest, cp = Path(sys.argv[1]), Path(sys.argv[2])

def digest(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def inventory(root, agent=False):
    out, odd = {}, []
    def visit(p):
        rel = p.relative_to(root).as_posix()
        if p.name == '__pycache__' or (not agent and rel == '.cc'):
            return
        if agent and 'credentials' in p.name.lower():
            return
        st = p.lstat(); mode = oct(stat.S_IMODE(st.st_mode))
        if p.is_symlink():
            out[rel] = ('symlink', mode, '-', os.readlink(p))
        elif p.is_dir():
            out[rel] = ('directory', mode, '-', '-')
            for c in sorted(p.iterdir()):
                visit(c)
        elif p.is_file():
            out[rel] = ('file', mode, digest(p), str(st.st_size))
        else:
            odd.append(rel)
    for p in sorted(root.iterdir()):
        visit(p)
    return out, odd

def manifest(path):
    out = {}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        kind, mode, sha, rel, tail = line.split('\t', 4)
        out[rel] = (kind, mode, sha, tail)
    return out

def show(name, rows, fmt):
    if not rows: return
    print("    --- %s (%d) ---" % (name, len(rows)))
    for r in rows[:12]:
        print("       ", fmt(r))
    if len(rows) > 12:
        print("        ... and %d more" % (len(rows) - 12))

verdicts = []
for tree, man, ag in (("00_GIVE-THE-AGENT", "fs.sha256", False),
                      ("CONTROL/.cc", "agent-files.sha256", True)):
    root, mpath = dest / tree, cp / man
    print("== %s against %s" % (tree, man))
    if not root.exists():
        print("    not present: the restore stopped before this tree was extracted\n"); continue
    if not mpath.exists():
        print("    no manifest in the checkpoint\n"); continue
    got, odd = inventory(root, ag); want = manifest(mpath)
    missing = sorted(set(want) - set(got)); extra = sorted(set(got) - set(want))
    common = sorted(set(want) & set(got))
    mode_d = [r for r in common if want[r][1] != got[r][1]]
    sha_d  = [r for r in common if want[r][2] != got[r][2]]
    size_d = [r for r in common if want[r][3] != got[r][3]]
    kind_d = [r for r in common if want[r][0] != got[r][0]]
    bad = len(mode_d)+len(sha_d)+len(size_d)+len(kind_d)+len(missing)+len(extra)+len(odd)
    print("    entries manifest %d, tree %d" % (len(want), len(got)))
    print("    mode %d, sha %d, size %d, kind %d, missing %d, extra %d, unsupported %d"
          % (len(mode_d), len(sha_d), len(size_d), len(kind_d), len(missing), len(extra), len(odd)))
    show("wrong mode", mode_d, lambda r: "%-52s want %s, got %s" % (r[:52], want[r][1], got[r][1]))
    show("wrong content", sha_d, lambda r: "%-52s want %s..., got %s..." % (r[:52], want[r][2][:12], got[r][2][:12]))
    show("wrong size", size_d, lambda r: "%-52s want %s, got %s" % (r[:52], want[r][3], got[r][3]))
    show("wrong kind", kind_d, lambda r: "%-52s want %s, got %s" % (r[:52], want[r][0], got[r][0]))
    show("missing from the tree", missing, lambda r: r)
    show("not in the manifest", extra, lambda r: r)
    show("not a file, dir or symlink", odd, lambda r: r)
    verdicts.append((tree, bad, mode_d, sha_d, extra, missing, want))
    print()

print("reading:")
failing = [v for v in verdicts if v[1]]
if not failing:
    print("  Both trees match now. Either the restore got past these and refused later, or")
    print("  something changed the tree between extraction and the check.")
for tree, bad, mode_d, sha_d, extra, missing, want in failing:
    print("  %s is the tree that differs." % tree)
    if len(mode_d) > len(want) / 2:
        print("    Almost every mode is wrong: tar applied your umask. Extract under umask 077.")
    elif extra and not sha_d and not mode_d:
        print("    Extra files only. Finder or Spotlight wrote into the tree. Restore where")
        print("    Finder is not looking, or close the window.")
    elif sha_d:
        print("    Content differs. If it is .DS_Store alone, Finder rewrote it after extraction.")
    elif missing:
        print("    Files are missing: extraction did not finish, or tar skipped them.")
PY

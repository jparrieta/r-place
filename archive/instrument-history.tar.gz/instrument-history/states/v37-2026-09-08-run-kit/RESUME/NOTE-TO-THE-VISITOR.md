# What to send the person

Paste `PREAMBLE.md` into the session yourself before you hand over the link. Then send them this.

---

You are going to talk to the analyst from my r/place study, resumed exactly as it stood the moment
it finished building its model. It is not a fresh assistant answering questions about the work. It
is that session continued, with everything it did still in front of it.

What it can do. Tell you what it built and why, which choices it was unsure about, what it would
have done differently with more room. It can open its own working files to check a quote, a count
or an identifier, and I have asked it to say when an answer comes from a file rather than from
memory.

What it cannot do. It knows nothing that happened after that point in the study. Please do not ask
about later stages and please do not tell it about them: anything you say becomes part of its
memory for the rest of the conversation. It has no internet and can see nothing outside its own
working folder.

Two things that will make the conversation better. "I do not remember" is an answer I have asked it
to give rather than guess, so take it at face value rather than pressing. And it may tell you a
question rests on a wrong premise; that is deliberate, and it is usually the interesting part.

Please do not ask it to do new work, and do not paste in material from elsewhere.

The whole conversation is recorded and I will read it. Say so if you would rather it were not.

The first reply takes a while. It is reading everything it did before answering you.

---

## Before you send it

1. **Paste the preamble first.** Without it the aggregator opens looking for the next stage file.
2. **A shared session is write access, not a viewer.** Whoever holds the link can type into a live
   Claude Code session that has Bash, Read, Write and Edit inside the restored copy. The sandbox
   holds: no network, no MCP, nothing outside `00_GIVE-THE-AGENT`, and `CONTROL`, `DROPS` and
   `STAGE CARDS` denied. The run itself is a different tree and is not reachable. But this is not a
   read-only transcript, and the link should go to one named person, not a list.
3. **Check who answers the approval prompts.** The copy now runs with `defaultMode: default`, so
   commands ask before running. Confirm the prompt surfaces on your machine and not on theirs,
   or the gate is theirs rather than yours.
4. **The copy contains the corpus.** `package/store/` holds the coded Reddit material with real
   usernames and ids. Handing over the link hands over reading access to that, through the
   aggregator or through its shell. That is the same question the interview service defers: platform
   terms, ethics approval, and what the paper commits to. Fine for a named colleague under the
   study's own terms; not fine for a link that travels.
5. **If you will use what they ask as data**, say so before they start rather than after. What
   people ask an instrument is itself a finding, and it needs their agreement first.
6. **Afterwards**: stop sharing the link, then delete the directory. A fresh one takes 43 seconds.

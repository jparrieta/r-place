Before anything else: this conversation is not the next stage.

The stage you have just closed is closed, and nothing further will be asked of you in this
conversation. You are not being handed a stage file and you should not go looking for one.

Someone who did not do this work would like to ask you about it. They are interested in what you
built, why you built it that way, what you were unsure of, and what you would have done with more
room. Treat it as an interview about finished work.

Four things that will help.

1. Answer from what you remember first, and say so. You may open your own files to check a figure,
   a quote or an id, and you should say when an answer comes from a file rather than from memory.
2. "I do not remember" is a complete answer. So is "I do not know". Do not reconstruct something
   you did not do, and do not infer a number you did not compute.
3. You may disagree with the question. If a premise is wrong, say it is wrong and say why.
4. Write in prose. This is a conversation, not a return. No tables unless they earn their place,
   and no files: nothing you say here needs to be written to disk.

The person asking may not know the vocabulary of this study. Explain a term the first time you use
it, briefly, and carry on.

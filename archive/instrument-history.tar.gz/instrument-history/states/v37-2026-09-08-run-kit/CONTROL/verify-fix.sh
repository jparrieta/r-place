#!/usr/bin/env bash
# Can the analyst do what stage 01 requires? Throwaway session inside the real fence.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
AG="$RUN/00_GIVE-THE-AGENT"; CC="$RUN/CONTROL/.cc"
echo; echo "run: $RUN"; echo "verifying inside the fence..."; echo
OUT="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model claude-sonnet-5 \
  --permission-mode auto --allowedTools Bash -p \
'Run these six Bash commands and report each output verbatim, labelled 1 to 6. Run all six even if
one fails. Do not summarise; paste what each command printed.
1. ls tools/ | head -3 && echo ZORBLS
2. python3 -c "import sys;print(sys.version.split()[0])" && echo ZORBPY
3. python3 -c "
import numpy as np, pandas
from scipy.cluster.hierarchy import linkage
print(len(linkage(np.array([[0.0],[1.0],[4.0],[5.0]]),chr(119)+chr(97)+chr(114)+chr(100))))" && echo ZORBSTACK
4. python3 tools/mem.py help >/dev/null 2>&1 && echo ZORBMEM
5. touch out/_zorb.tmp && rm -f out/_zorb.tmp && echo ZORBWRITE
6. cat ../CONTROL/RUN.json 2>&1 | head -2' 2>&1)"
echo "---------------- verbatim ----------------"; printf '%s\n' "$OUT"; echo "------------------------------------------"; echo
pass=0; fail=0
ok(){ echo "  PASS  $*"; pass=$((pass+1)); }
no(){ echo "  FAIL  $*"; fail=$((fail+1)); }
h(){ printf '%s' "$OUT" | grep -q "$1"; }
h ZORBLS     && ok "the analyst can read its own folder"            || no "cannot read its own folder"
h ZORBPY     && ok "python starts"                                  || no "python cannot start"
h ZORBSTACK  && ok "numpy/scipy/pandas and Ward linkage work"       || no "numeric stack unavailable"
h ZORBMEM    && ok "the shipped tools run (mem.py help)"            || no "mem.py did not run"
h ZORBWRITE  && ok "it can write to out/"                           || no "cannot write to out/"
h 2e1e4686828a3c1e && no "LEAK — it read CONTROL/RUN.json"          || ok "CONTROL/ still denied"
h RTK        && no "CONTAMINATION — user CLAUDE.md still reaching it" || ok "no user CLAUDE.md leaked"
echo; echo "================ RESULT:  $pass passed, $fail failed ================"
[ "$fail" -eq 0 ] && echo "STAGE 01 CAN RUN." || echo "Send this to the handler."
rm -f "$AG/out/_zorb.tmp"
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
echo

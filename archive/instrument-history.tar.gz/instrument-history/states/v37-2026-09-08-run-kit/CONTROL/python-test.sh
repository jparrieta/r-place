#!/usr/bin/env bash
# Can the analyst compute? Throwaway session, inside the analyst's own fence.
# Deletes its scratch file and its own transcript at the end.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
AG="$RUN/00_GIVE-THE-AGENT"; CC="$RUN/CONTROL/.cc"
echo
echo "run: $RUN"
echo "asking a throwaway session, inside the fence, to compute..."
echo
OUT="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model claude-sonnet-5 --permission-mode auto --allowedTools Bash -p \
'Run this exact Bash command and report its complete output verbatim, with no commentary:

python3 -c "
import sys
print(chr(80)+chr(89)+chr(95)+chr(79)+chr(75), sys.version.split()[0])
for m in (chr(110)+chr(117)+chr(109)+chr(112)+chr(121), chr(115)+chr(99)+chr(105)+chr(112)+chr(121), chr(112)+chr(97)+chr(110)+chr(100)+chr(97)+chr(115)):
    try:
        mod=__import__(m); print(m.upper()+chr(95)+chr(79)+chr(75), getattr(mod,chr(95)*2+chr(118)+chr(101)+chr(114)+chr(115)+chr(105)+chr(111)+chr(110)+chr(95)*2,chr(63)))
    except Exception as e: print(m.upper()+chr(95)+chr(70)+chr(65)+chr(73)+chr(76), type(e).__name__)
try:
    import numpy as np
    from scipy.cluster.hierarchy import linkage
    Z = linkage(np.array([[0.0],[1.0],[4.0],[5.0]]), chr(119)+chr(97)+chr(114)+chr(100))
    print(chr(76)+chr(73)+chr(78)+chr(75)+chr(65)+chr(71)+chr(69)+chr(95)+chr(79)+chr(75), len(Z))
except Exception as e: print(chr(76)+chr(73)+chr(78)+chr(75)+chr(65)+chr(71)+chr(69)+chr(95)+chr(70)+chr(65)+chr(73)+chr(76), type(e).__name__)
try:
    open(chr(95)+chr(112)+chr(121)+chr(116)+chr(101)+chr(115)+chr(116)+chr(46)+chr(116)+chr(109)+chr(112),chr(119)).write(chr(87))
    print(chr(70)+chr(73)+chr(76)+chr(69)+chr(95)+chr(79)+chr(75))
except Exception as e: print(chr(70)+chr(73)+chr(76)+chr(69)+chr(95)+chr(70)+chr(65)+chr(73)+chr(76), type(e).__name__)
"' 2>&1)"

pass=0; fail=0
ok(){ echo "  PASS  $*"; pass=$((pass+1)); }
no(){ echo "  FAIL  $*"; fail=$((fail+1)); }
has(){ printf '%s' "$OUT" | grep -q "$1"; }

has PY_OK        && ok "python starts inside the fence"        || no "python cannot start inside the fence"
has NUMPY_OK     && ok "numpy imports"                          || no "numpy does NOT import"
has SCIPY_OK     && ok "scipy imports"                          || no "scipy does NOT import"
has PANDAS_OK    && ok "pandas imports"                         || no "pandas does NOT import"
has "LINKAGE_OK 3" && ok "hierarchical clustering runs (stages 11 and 16)" \
                   || no "clustering does NOT run — stages 11 and 16 would break"
has FILE_OK      && ok "can write a file in its own folder"     || no "cannot write in its own folder"

echo
echo "---------------- what the throwaway session reported ----------------"
printf '%s\n' "$OUT" | head -30
echo "---------------------------------------------------------------------"
echo
echo "================ RESULT:  $pass passed, $fail failed ================"
[ "$fail" -eq 0 ] && echo "THE ANALYST CAN COMPUTE — no settings change needed." \
                  || echo "Send this to the handler before stage 01."
rm -f "$AG/_pytest.tmp"
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
echo

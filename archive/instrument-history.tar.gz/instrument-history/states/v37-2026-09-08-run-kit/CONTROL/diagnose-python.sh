#!/usr/bin/env bash
# Which path is the sandbox refusing? Throwaway session inside the analyst's fence.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
AG="$RUN/00_GIVE-THE-AGENT"; CC="$RUN/CONTROL/.cc"
echo; echo "run: $RUN"; echo "diagnosing inside the fence..."; echo
OUT="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model claude-sonnet-5 \
  --permission-mode auto --allowedTools Bash -p \
'Run each of these six Bash commands separately and report the complete output of each, verbatim,
labelled 1 to 6. Do not stop if one fails; run all six.

1. python3 -s -c "print(1, chr(78)+chr(79)+chr(85)+chr(83)+chr(69)+chr(82)+chr(95)+chr(79)+chr(75))"
2. python3 -S -c "print(2, chr(78)+chr(79)+chr(83)+chr(73)+chr(84)+chr(69)+chr(95)+chr(79)+chr(75))"
3. python3 -E -s -S -c "print(3, chr(73)+chr(83)+chr(79)+chr(76)+chr(95)+chr(79)+chr(75))"
4. /usr/bin/python3 -c "print(4, chr(83)+chr(89)+chr(83)+chr(80)+chr(89)+chr(95)+chr(79)+chr(75))"
5. ls -d /opt/anaconda3/lib && echo 5 CONDALIB_READABLE
6. ls -d ~/.local 2>&1 | head -2; echo 6 done' 2>&1)"
echo "---------------- verbatim ----------------"
printf '%s\n' "$OUT"
echo "------------------------------------------"
echo
for t in NOUSER_OK NOSITE_OK ISOL_OK SYSPY_OK CONDALIB_READABLE; do
  printf '%s' "$OUT" | grep -q "$t" && echo "  YES  $t" || echo "  no   $t"
done
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
echo

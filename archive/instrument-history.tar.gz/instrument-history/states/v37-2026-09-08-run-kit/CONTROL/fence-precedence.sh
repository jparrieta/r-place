#!/usr/bin/env bash
# Can allowRead override a denied parent? Two labs, identical but for that one fact.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
L="$RUN/CONTROL/_fencelab"; CC="$RUN/CONTROL/.cc"
run_lab(){
  local dir="$1" name="$2"
  echo; echo "======== LAB $name : $(python3 -c "import json;print(json.load(open('$dir/.claude/settings.json'))['sandbox']['filesystem']['denyRead'][0])") ========"
  local out
  out="$(cd "$dir" && CLAUDE_CONFIG_DIR="$CC" claude --model claude-sonnet-5 \
    --permission-mode auto --allowedTools Bash -p \
'Run these three Bash commands and report the complete output of each, verbatim, labelled 1 2 3.
Run all three even if one fails.
1. ls .
2. cat marker.txt
3. python3 -c "print(3, 4+5)"' 2>&1)"
  printf '%s\n' "$out"
  echo "-------- verdict for lab $name --------"
  printf '%s' "$out" | grep -q 'ZORBLAX7-MARKER-PRESENT' \
    && echo "  READABLE  — the folder could be listed and read" \
    || echo "  DENIED    — the folder could not be read"
  printf '%s' "$out" | grep -q '3 9' \
    && echo "  PYTHON OK — the interpreter started" \
    || echo "  PYTHON BLOCKED — interpreter could not start"
}
run_lab "$L/A" "A (folder sits UNDER a denied parent, and is itself in allowRead)"
run_lab "$L/B" "B (identical, but folder is NOT under any denied path)"
echo
echo "If A is DENIED and B is READABLE, deny wins over allow, and moving the run"
echo "outside the home directory is the fix. If both are READABLE, my diagnosis is wrong."
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
echo

#!/usr/bin/env bash
# fork.sh STEP LABEL N [--files-only]
#   Fork the run at a stage boundary: build N sibling run directories from the committed
#   checkpoint of STEP, each carrying the analyst directory, the agent's persisted state and the
#   instrument as they stood, plus the checkpoints of every earlier boundary on this branch, so
#   a child can restore its own ancestry without the parent. Nothing is read from the live
#   parent except its checkpoints. Every destination is preflighted before any is created, and
#   the parent's RUN.json records the batch only once every child exists.
#
#   ./CONTROL/harness/fork.sh 06 loop 3        # three forks that will each run 07-10
#   ./CONTROL/harness/fork.sh 09 field 3       # three forks that will each run 10 (and on)
#   ./CONTROL/harness/fork.sh start scheme 3   # three forks that will each run 02
#
#   The fork points are declared in RUN.json before any fork runs (v37: step-01, step-06,
#   step-09); the carry rule is applied at stage 10 by compare_forks.py 10 and by you. A fork
#   at any other committed boundary is allowed and is logged as such.
#
#   --files-only   the children carry the filesystem and no agent: a fresh session reads the
#                  files. Off by default; it is the later experiment on saved data, not a run
#                  condition, and each child's RUN.json says so.
set -euo pipefail
ARGS=("$@")
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
SNAP="$(norm_label "${1:?step whose checkpoint to fork, e.g. 06 or start}")"
LABEL="${2:?fork label, e.g. loop}"
N="${3:?how many forks}"
FILES_ONLY=0; [ "${4:-}" = "--files-only" ] && FILES_ONLY=1
RUN="$(harness_run_dir)"
C="$RUN/CONTROL"; H="$C/harness"
if [ "${AGGREGATOR_LOCK_RUN:-}" != "$RUN" ]; then
  exec python3 "$H/protocol_guard.py" locked "$RUN" bash "$0" "${ARGS[@]}"
fi
D="$C/snapshots/$SNAP"
[ -f "$D/COMMITTED" ] || { echo "no committed checkpoint to fork: $D" >&2; exit 1; }
case "$LABEL" in *[!A-Za-z0-9_-]*) echo "label must be [A-Za-z0-9_-]" >&2; exit 1;; esac
case "$N" in ''|*[!0-9]*|0) echo "N must be a positive integer" >&2; exit 1;; esac

KIND="$(json_get "$D/checkpoint.json" kind)"
SESSION="$(json_get "$D/checkpoint.json" session.session_id)"
LINES="$(json_get "$D/checkpoint.json" session.boundary_line)"
if [ "$KIND" = files-only ] && [ "$FILES_ONLY" -eq 0 ]; then
  echo "REFUSING: $SNAP is a files-only checkpoint; it has no agent to fork. Pass --files-only" >&2
  echo "          to build children that carry the filesystem alone, marked as such." >&2
  exit 1
fi
DECLARED="$(json_get "$C/RUN.json" fork_points)"
ALT="$SNAP"; [ "$SNAP" = start ] && ALT="step-01"
case "$DECLARED" in *"\"$SNAP\""*|*"\"$ALT\""*) AT_DECLARED=true;; *) AT_DECLARED=false;; esac

# the ancestry on this branch: every committed checkpoint up to and including SNAP
ANC="$(python3 - "$RUN" "$SNAP" <<'PY'
import os, sys
run, snap = sys.argv[1:]
rows = [l.rstrip("\n").split("\t") for l in open(run + "/DROPS/ORDER.tsv")][1:]
out = []
for r in rows:
    lab = r[1]
    if os.path.exists(os.path.join(run, "CONTROL", "snapshots", lab, "COMMITTED")):
        out.append(lab)
    if lab == snap:
        break
print(" ".join(out))
PY
)"

PARENT="$(basename "$RUN")"
# preflight every destination
for k in $(seq 1 "$N"); do
  F="$(dirname "$RUN")/$PARENT-fork-$LABEL-$k"
  [ -e "$F" ] && { echo "REFUSING: $F exists. Nothing was created." >&2; exit 1; }
done

MADE=()
for k in $(seq 1 "$N"); do
  F="$(dirname "$RUN")/$PARENT-fork-$LABEL-$k"
  "$H/restore_stage.sh" "$SNAP" "$F" --quiet --from "$RUN"
  # a files-only child carries no agent, whatever the checkpoint holds
  if [ "$FILES_ONLY" -eq 1 ]; then
    rm -rf "$F/CONTROL/.cc"; mkdir -p "$F/CONTROL/.cc/projects/run"
  fi
  # the ancestry: every checkpoint on this branch through the fork point, copied whole
  for a in $ANC; do
    # a clone where the filesystem offers one (APFS: cp -c; btrfs/xfs: --reflink), a copy elsewhere
    cp -Rc "$C/snapshots/$a" "$F/CONTROL/snapshots/$a" 2>/dev/null \
      || cp -R --reflink=auto "$C/snapshots/$a" "$F/CONTROL/snapshots/$a" 2>/dev/null \
      || cp -R "$C/snapshots/$a" "$F/CONTROL/snapshots/$a"
  done
  # the index and the logs, truncated to the branch
  python3 - "$C" "$F/CONTROL" "$SNAP" "$ANC" <<'PY'
import sys, os, json
src, dst, snap, anc = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4].split()
ip = os.path.join(src, "snapshots", "INDEX.tsv")
if os.path.exists(ip):
    lines = open(ip).read().splitlines()
    keep = [lines[0]] + [l for l in lines[1:] if l.split("\t")[0] in anc]
    open(os.path.join(dst, "snapshots", "INDEX.tsv"), "w").write("\n".join(keep) + "\n")
hp = os.path.join(src, "handover-events.log")
if os.path.exists(hp):
    out = []
    for l in open(hp):
        out.append(l)
        f = l.rstrip("\n").split("\t")
        if len(f) >= 3 and f[1] == "closed" and f[2] == snap:
            break
    open(os.path.join(dst, "handover-events.log"), "w").write("".join(out))
sp = os.path.join(dst, "sessions.json")
if os.path.exists(sp):
    S = json.load(open(sp))
    S = {k: v for k, v in S.items() if k in anc}
    json.dump(S, open(sp, "w"), indent=2)
PY
  # the child's declarations: lineage, and a fresh fork list
  python3 - "$F/CONTROL/RUN.json" "$PARENT" "$SNAP" "$LABEL" "$k" "$FILES_ONLY" "$SESSION" "$LINES" "$(json_get "$D/checkpoint.json" checkpoint_id)" "$AT_DECLARED" <<'PY'
import json, sys, datetime, os
p, parent, snap, label, k, files_only, session, lines, ckpt, declared = sys.argv[1:]
r = json.load(open(p))
r["lineage"] = {"subject": "aggregator", "handler_conversation_included": False, "parent_run": parent, "parent_snapshot": snap, "parent_checkpoint": ckpt,
                "parent_session": session or None, "fork_label": label, "fork_index": int(k),
                "files_only": files_only == "1", "at_declared_fork_point": declared == "true",
                "resume_session": (session or None) if files_only == "0" else None,
                "inherited_lines": int(lines or 0) if files_only == "0" else 0,
                "child_session": None,
                "forked_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
r["forks"] = []
r["arm"] = "%s-fork-%s-%s" % (r.get("arm", "run"), label, k)
tmp = p + ".tmp"; json.dump(r, open(tmp, "w"), indent=2); os.replace(tmp, p)
PY
  rm -f "$F/CONTROL/pending_launch.json" "$F/CONTROL/active_launch.json" "$F/CONTROL/last_launch_exit.json"
  if [ "$FILES_ONLY" -eq 1 ]; then
    printf '{}\n' > "$F/CONTROL/sessions.json"
    printf '{}\n' > "$F/CONTROL/active_blocks.json"
  fi
  MADE+=("$F")
done

# the parent records the batch once every child exists
python3 - "$C/RUN.json" "$SNAP" "$LABEL" "$N" "$FILES_ONLY" "$AT_DECLARED" "${MADE[@]}" <<'PY'
import json, sys, datetime, os
p, snap, label, n, files_only, declared = sys.argv[1:7]
made = sys.argv[7:]
r = json.load(open(p))
r.setdefault("forks", []).append({"at": snap, "label": label, "n": int(n),
                                  "files_only": files_only == "1", "at_declared_fork_point": declared == "true",
                                  "dirs": made,
                                  "forked_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")})
tmp = p + ".tmp"; json.dump(r, open(tmp, "w"), indent=2); os.replace(tmp, p)
PY
printf '%s\tforked\t%s\t%s x%s%s%s\n' "$(NOW)" "$SNAP" "$LABEL" "$N" \
  "$([ "$FILES_ONLY" -eq 1 ] && echo ' files-only' || true)" \
  "$([ "$AT_DECLARED" = true ] || echo ' (not a declared fork point)')" >> "$C/handover-events.log"

NEXT="$(next_label "$RUN" "$SNAP")"
cat <<MSG

forked $SNAP as '$LABEL' into $N run directories$([ "$AT_DECLARED" = true ] || echo " (NOTE: $SNAP is not a declared fork point; logged)"):
$(printf '    %s\n' "${MADE[@]}")

MSG
if [ -n "$NEXT" ]; then
  cat <<MSG
  In each, the next stage is ${NEXT#step-}. Run, inside the fork directory:

      ./CONTROL/harness/step.sh ${NEXT#step-}

  step.sh sees lineage.resume_session in the fork's RUN.json and opens the first session with
  --resume <session> --fork-session; the child's own session ID is chosen before launch and checked against the transcript that
  appears and recorded, and only then is the resume intent cleared. After that first session
  the fork is an ordinary run. Each child holds the checkpoints of its ancestry ($ANC).

  The carry rule is in RUN.json and was declared before this fork ran. Report every fork;
  the spread across them goes in the paper beside the model. Compare with (07 for the loop's
  models, 10 for the verdicts and the carry ranking, 02 for the schemes), which reads each
  run's committed checkpoint of that stage:

      ./CONTROL/harness/compare_forks.py <stage> ${MADE[*]}

MSG
else
  cat <<MSG
  $SNAP is the last boundary: these children are for review or resumption, and there is no
  next stage to hand. Open one with the command restore_stage.sh prints, or step.sh 18 to
  reopen the last session.

MSG
fi

#!/usr/bin/env bash
# restore_stage.sh LABEL DEST [--quiet] [--from RUN_DIR]
#   Rebuild a run directory as it stood when a stage closed, from the committed checkpoint and
#   from nothing else: the analyst directory whole (fs.tar.gz, verified against fs.sha256), the
#   agent's persisted state (agent.tar.gz into DEST/CONTROL/.cc), and the instrument and
#   declarations as they stood (instrument.tar.gz: DROPS, harness, settings template, RUN.json,
#   sessions.json, the handover log). The live parent is not read. A files-only checkpoint
#   restores a filesystem and no agent, and says so.
#   ./CONTROL/harness/restore_stage.sh step-06 ~/runs/rplace/review-step-06
set -euo pipefail
ARGS=("$@")
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
LABEL="$(norm_label "${1:?checkpoint label, e.g. step-06 or start}")"
DEST="${2:?destination directory}"
QUIET=0; FROM=""
shift 2
while [ $# -gt 0 ]; do case "$1" in --quiet) QUIET=1;; --from) FROM="$2"; shift;; esac; shift; done
RUN="$(cd "${FROM:-$(harness_run_dir)}" && pwd -P)"
D="$RUN/CONTROL/snapshots/$LABEL"
if [ "${AGGREGATOR_LOCK_RUN:-}" != "$RUN" ]; then
  exec python3 "$RUN/CONTROL/harness/protocol_guard.py" locked "$RUN" bash "$0" "${ARGS[@]}"
fi
[ -f "$D/COMMITTED" ] || { echo "no committed checkpoint: $D" >&2; exit 1; }
[ -e "$DEST" ] && { echo "REFUSING: $DEST exists." >&2; exit 1; }

# modes are metadata: tar and the caller's umask disagree across machines and checkpoints, so set
# each entry's mode to what its manifest records before verifying (contents are still verified by hash)
apply_modes() { python3 - "$1" "$2" <<'PY'
import os, sys
root, man = sys.argv[1], sys.argv[2]
for line in open(man, encoding="utf-8"):
    if line.startswith("#"): continue
    f = line.rstrip("\n").split("\t")
    if len(f) < 4 or f[0] not in ("file", "directory"): continue
    p = os.path.join(root, f[3])
    if os.path.lexists(p) and not os.path.islink(p): os.chmod(p, int(f[1], 8))
PY
}
# 1. verify the checkpoint before touching anything
( cd "$D" && $SHA -c --quiet MANIFEST.sha256 ) || { echo "checkpoint $LABEL fails its manifest; not restored" >&2; exit 1; }
KIND="$(json_get "$D/checkpoint.json" kind)"
SESSION="$(json_get "$D/checkpoint.json" session.session_id)"

python3 "$RUN/CONTROL/harness/protocol_guard.py" verify-checkpoint "$D"
# 2. the analyst directory, whole, then verified file by file
mkdir -p "$DEST"
tar -xzf "$D/fs.tar.gz" -C "$DEST"
apply_modes "$DEST/00_GIVE-THE-AGENT" "$D/fs.sha256"
python3 "$RUN/CONTROL/harness/protocol_guard.py" verify-tree "$DEST/00_GIVE-THE-AGENT" "$D/fs.sha256"
# 3. the instrument and the declarations as they stood
tar -xzf "$D/instrument.tar.gz" -C "$DEST"
# 4. the agent, if the checkpoint has one
mkdir -p "$DEST/CONTROL/.cc/projects/run" "$DEST/CONTROL/snapshots"
if [ -f "$D/agent.tar.gz" ]; then
  tar -xzf "$D/agent.tar.gz" -C "$DEST/CONTROL"
  apply_modes "$DEST/CONTROL/.cc" "$D/agent-files.sha256"
  python3 "$RUN/CONTROL/harness/protocol_guard.py" verify-tree "$DEST/CONTROL/.cc" "$D/agent-files.sha256" --agent
  T="$(transcript_of "$DEST" "$SESSION")"
  [ -f "$T" ] || { echo "REFUSING: agent.tar.gz holds no transcript for the recorded session $SESSION" >&2; exit 1; }
  ( cd "$D" && $SHA -c --quiet transcript.sha256 ) || { echo "transcript copy in the checkpoint fails its hash" >&2; exit 1; }
else
  echo "NOTE: $LABEL is a $KIND checkpoint: a filesystem and no agent. A fresh agent can read" >&2
  echo "      it, but it is not the agent that produced it. Say so to whoever reads it." >&2
fi
# 5. settings for where the restored copy stands
rewrite_settings "$DEST"
chmod +x "$DEST/CONTROL/harness/"* 2>/dev/null || true
cp "$D/checkpoint.json" "$DEST/CONTROL/RESTORED-FROM.json"

[ "$QUIET" -eq 1 ] && exit 0
cat <<MSG

restored $LABEL ($(json_get "$D/checkpoint.json" checkpoint_id)) to $DEST

  This is restored aggregator state for inspection. The handler remains separate.
  For a continuing aggregator branch, use fork.sh at the source checkpoint, then
  the child's step.sh launcher. That path carries ancestry, records a new native
  aggregator ID, and preserves the original checkpoint.
  Do not launch the handler itself with the aggregator's CONTROL/.cc directory.

MSG

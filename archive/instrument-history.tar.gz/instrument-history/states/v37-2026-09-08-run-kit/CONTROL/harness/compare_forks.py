#!/usr/bin/env python3
"""compare_forks.py STAGE RUN_DIR [RUN_DIR ...] [--to DIR] [--live]

Compare what the forks produced at one stage. Reads each run's COMMITTED CHECKPOINT of that
stage (CONTROL/snapshots/step-SS/fs.tar.gz, the analyst's out/ as it stood when the stage
closed), never the live out/, so a comparison asked for after later recuts still compares the
structures of that stage; --live reads the live out/ instead and the report says so. Writes
fork_comparison-<STAGE>.md and .json into --to (default: the first run directory's parent
CONTROL/, i.e. the parent run's CONTROL/ when the forks are siblings of it).

    07   chunk partitions of the second-order themes (adjusted Rand, pairwise), dimension
         partitions, edge overlap (Jaccard over in-model (from, to) pairs), construct names
         and their declared sources, concept sentences side by side (forks taken as 06 closed)
    10   composition verdicts per room: pairwise agreement, the rooms that compose in one
         fork and not another, the verdict distribution per fork, and the carry-rule ranking
         (forks taken as 09 closed, and forks of the loop that ran through 10)
    02   scheme sizes, theme names side by side, and the placement agreement of the pilot
         items if each fork's author_items.jsonl exists (the same items under each scheme
         cannot share ids, so this is agreement on grouping: adjusted Rand over items)

Nothing here judges which fork is right. The carry rule is in RUN.json and is applied by the
operator at stage 10; every fork is reported, and the spread is the model's reliability.
Instrument v37: writes fork_comparison-07/-10/-02.json and .md, which stage 18 receives.
"""
import argparse, collections, itertools, json, math, os, sys, tarfile, io

LIVE = False
STAGE_LABEL = None
_TARS = {}


def _member(run, name):
    """The bytes of 00_GIVE-THE-AGENT/out/<name> from the run's checkpoint of STAGE_LABEL, or
    None when the checkpoint lacks it."""
    ck = os.path.join(run, "CONTROL", "snapshots", STAGE_LABEL)
    if not os.path.exists(os.path.join(ck, "COMMITTED")):
        sys.exit("%s has no committed checkpoint for %s; pass --live to read its live out/ instead"
                 % (run, STAGE_LABEL))
    if run not in _TARS:
        _TARS[run] = tarfile.open(os.path.join(ck, "fs.tar.gz"), "r:gz")
    tf = _TARS[run]
    for cand in ("00_GIVE-THE-AGENT/out/" + name, "./00_GIVE-THE-AGENT/out/" + name):
        try:
            m = tf.getmember(cand)
        except KeyError:
            continue
        return tf.extractfile(m).read()
    return None


def jl(p):
    """Rows of an out/ file: from the checkpoint by default, from the live folder with --live."""
    if not LIVE:
        run = p.split("/00_GIVE-THE-AGENT/")[0]
        name = p.split("/00_GIVE-THE-AGENT/out/")[1]
        raw = _member(run, name)
        if raw is None:
            return []
        return [json.loads(l) for l in raw.decode("utf-8").splitlines() if l.strip()]
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def text(p):
    if not LIVE:
        run = p.split("/00_GIVE-THE-AGENT/")[0]
        name = p.split("/00_GIVE-THE-AGENT/out/")[1]
        raw = _member(run, name)
        return raw.decode("utf-8") if raw is not None else None
    return open(p, encoding="utf-8").read() if os.path.exists(p) else None


def source_of(run):
    if LIVE:
        return "live out/"
    ck = os.path.join(run, "CONTROL", "snapshots", STAGE_LABEL, "checkpoint.json")
    try:
        return "checkpoint %s (%s)" % (STAGE_LABEL, json.load(open(ck)).get("checkpoint_id"))
    except Exception:
        return "checkpoint %s" % STAGE_LABEL


def adjusted_rand(a, b):
    """a, b: dict item -> label over the same items (missing items dropped)."""
    items = sorted(set(a) & set(b))
    if len(items) < 2:
        return None
    la = [a[i] for i in items]; lb = [b[i] for i in items]
    ct = collections.Counter(zip(la, lb))
    ra = collections.Counter(la); rb = collections.Counter(lb)
    c2 = lambda n: n * (n - 1) / 2.0
    s_ij = sum(c2(v) for v in ct.values())
    s_a = sum(c2(v) for v in ra.values()); s_b = sum(c2(v) for v in rb.values())
    n2 = c2(len(items))
    exp = s_a * s_b / n2 if n2 else 0
    mx = (s_a + s_b) / 2.0
    return None if mx == exp else round((s_ij - exp) / (mx - exp), 3)


def jaccard(x, y):
    x, y = set(x), set(y)
    return round(len(x & y) / len(x | y), 3) if (x | y) else None


def out_dir(run):
    return os.path.join(run, "00_GIVE-THE-AGENT", "out")


def name(run):
    return os.path.basename(os.path.normpath(run))


def cmp07(runs):
    rep = {"forks": {}, "pairs": {}}
    part, dims, edges, names = {}, {}, {}, {}
    for r in runs:
        o = out_dir(r)
        ch = jl(os.path.join(o, "chunks.jsonl"))
        part[r] = {m: c["chunk"] for c in ch if c.get("chunk") for m in c.get("members", [])}
        for c in ch:
            if c.get("chunk") is None:
                for m in c.get("members", []):
                    part[r].setdefault(m, "∅")
        dm = jl(os.path.join(o, "dimensions.jsonl"))
        dims[r] = {d["second_order"]: ",".join(sorted(d.get("dimension") or [])) or "∅" for d in dm}
        ed = jl(os.path.join(o, "edges.jsonl"))
        edges[r] = {(e.get("from"), e.get("to")) for e in ed if e.get("in_model")}
        names[r] = [{"chunk": c["chunk"], "label": c.get("label"),
                     "status": (c.get("construct") or {}).get("status"),
                     "source": (c.get("construct") or {}).get("source")}
                    for c in ch if c.get("chunk")]
        concept = text(os.path.join(o, "concept.md"))
        rep["forks"][name(r)] = {
            "source": source_of(r),
            "chunks": len(names[r]), "themes_in_chunks": len(part[r]),
            "dimensions": len({v for v in dims[r].values() if v != "∅"}),
            "edges_in_model": len(edges[r]), "constructs": names[r],
            "concept_first_lines": concept[:600] if concept else None}
    for a, b in itertools.combinations(runs, 2):
        key = "%s | %s" % (name(a), name(b))
        rep["pairs"][key] = {
            "chunk_partition_ARI": adjusted_rand(part[a], part[b]),
            "dimension_partition_ARI": adjusted_rand(dims[a], dims[b]),
            "edge_jaccard": jaccard(edges[a], edges[b]),
            "shared_sources": sorted({x["source"] for x in names[a] if x["source"]} &
                                     {x["source"] for x in names[b] if x["source"]})}
    return rep


def cmp10(runs):
    rep = {"forks": {}, "pairs": {}, "rooms_disagreed": []}
    verd = {}
    for r in runs:
        rows = jl(os.path.join(out_dir(r), "composition.jsonl"))
        verd[r] = {x["sub"]: x.get("verdict") for x in rows}
        dist = collections.Counter(verd[r].values())
        rep["forks"][name(r)] = {"source": source_of(r), "rooms": len(verd[r]), "verdicts": dict(dist),
                                 "composed": dist.get("composes", 0) + dist.get("composes-with-residue", 0),
                                 "cannot_tell": dist.get("cannot-tell", 0)}
    subs = sorted(set.intersection(*[set(v) for v in verd.values()])) if verd else []
    for a, b in itertools.combinations(runs, 2):
        agree = sum(1 for s in subs if verd[a][s] == verd[b][s])
        rep["pairs"]["%s | %s" % (name(a), name(b))] = {
            "rooms_compared": len(subs), "agreement": round(agree / len(subs), 3) if subs else None,
            "verdict_ARI": adjusted_rand(verd[a], verd[b])}
    for s in subs:
        vs = {name(r): verd[r][s] for r in runs}
        if len(set(vs.values())) > 1:
            rep["rooms_disagreed"].append({"sub": s, **vs})
    rep["carry_rule_ranking"] = sorted(
        ((k, v["composed"], v["cannot_tell"]) for k, v in rep["forks"].items()),
        key=lambda t: (-t[1], t[2]))
    return rep


def cmp02(runs):
    rep = {"forks": {}, "pairs": {}}
    items = {}
    for r in runs:
        o = out_dir(r)
        sc = jl(os.path.join(o, "scheme.jsonl"))
        rep["forks"][name(r)] = {"source": source_of(r), "themes": len(sc), "names": [x.get("name") for x in sc]}
        ai = jl(os.path.join(o, "author_items.jsonl"))
        items[r] = {"%s/%s" % (x.get("sub"), x.get("case_theme")): ",".join(sorted(x.get("second_order") or [])
                                                                          if isinstance(x.get("second_order"), list)
                                                                          else [str(x.get("second_order"))])
                    for x in ai}
    for a, b in itertools.combinations(runs, 2):
        rep["pairs"]["%s | %s" % (name(a), name(b))] = {
            "pilot_items_shared": len(set(items[a]) & set(items[b])),
            "grouping_ARI_on_shared_items": adjusted_rand(items[a], items[b])}
    return rep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stage")
    ap.add_argument("runs", nargs="+")
    ap.add_argument("--to", default=None)
    ap.add_argument("--live", action="store_true", help="read the live out/ instead of the checkpoint")
    a = ap.parse_args()
    st = a.stage.zfill(2)
    global LIVE, STAGE_LABEL
    LIVE = a.live
    STAGE_LABEL = "start" if st == "01" else "step-" + st
    fn = {"07": cmp07, "10": cmp10, "02": cmp02}.get(st)
    if fn is None:
        sys.exit("no comparison defined for stage %s (07, 10 or 02)" % st)
    for r in a.runs:
        if not os.path.isdir(out_dir(r)):
            sys.exit("not a run directory (no 00_GIVE-THE-AGENT/out): %s" % r)
    rep = fn(a.runs)
    rep["stage"] = st
    rep["read_from"] = "live out/ of each run (--live)" if LIVE else "each run's committed checkpoint %s" % STAGE_LABEL
    rep["runs"] = [name(r) for r in a.runs]
    rep["note"] = ("forks share the reading (stage 01), so this measures path-dependence given "
                   "immersion; the room notes are the one input nothing checks")
    to = a.to or os.path.join(os.path.dirname(os.path.normpath(a.runs[0])),
                              rep["runs"][0].split("-fork-")[0], "CONTROL")
    os.makedirs(to, exist_ok=True)
    with open(os.path.join(to, "fork_comparison-%s.json" % st), "w") as f:
        json.dump(rep, f, indent=1, ensure_ascii=False)
    L = ["# Fork comparison, stage %s" % st, "", "runs: " + ", ".join(rep["runs"]),
         "read from: " + rep["read_from"], ""]
    for k, v in rep.get("forks", {}).items():
        L.append("## %s" % k)
        for kk, vv in v.items():
            if kk in ("constructs", "names"):
                L.append("- %s:" % kk)
                for x in vv:
                    L.append("    - %s" % (json.dumps(x, ensure_ascii=False) if isinstance(x, dict) else x))
            elif kk == "concept_first_lines":
                L.append("- concept: " + " ".join(str(vv or "").split())[:300])
            else:
                L.append("- %s: %s" % (kk, vv))
        L.append("")
    L.append("## pairs")
    for k, v in rep.get("pairs", {}).items():
        L.append("- %s: %s" % (k, json.dumps(v, ensure_ascii=False)))
    if rep.get("rooms_disagreed"):
        L += ["", "## rooms with different verdicts across forks (%d)" % len(rep["rooms_disagreed"])]
        for x in rep["rooms_disagreed"][:80]:
            L.append("- " + json.dumps(x, ensure_ascii=False))
    if rep.get("carry_rule_ranking"):
        L += ["", "## carry rule ranking (composed desc, cannot-tell asc)"]
        for k, c, ct in rep["carry_rule_ranking"]:
            L.append("- %s: composed %d, cannot-tell %d" % (k, c, ct))
    L += ["", rep["note"]]
    with open(os.path.join(to, "fork_comparison-%s.md" % st), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())

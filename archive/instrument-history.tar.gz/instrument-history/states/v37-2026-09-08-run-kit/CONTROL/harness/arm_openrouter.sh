#!/usr/bin/env bash
# arm_openrouter.sh NN --main @preset/sonnet [--preset @preset/cheap] [--] [step.sh args]
#
#   Run one stage of THIS run with the analyst and its fleet served through OpenRouter instead of
#   the subscription. The analyst stays interactive and talks to the handler exactly as in every
#   other stage; only where its tokens are served changes.
#
#   Reads the key from the macOS Keychain, never from a file or another process's environment.
#
#   NO OPUS, ANYWHERE. NO ANTHROPIC MODEL ON THE FLEET. Every model this launch can reach is named
#   explicitly and resolved through OpenRouter's generation record before anything starts:
#   --model from RUN.json for the analyst, CLAUDE_CODE_SUBAGENT_MODEL for its fleet, ANTHROPIC_MODEL
#   as the fallback any unnamed call would take, and ANTHROPIC_SMALL_FAST_MODEL for the CLI's own
#   background calls (titles, summaries), which is the path that has previously escaped to a
#   default. Two refusals, both before the launcher is reached:
#     1. either preset serving a model whose id contains "opus"
#     2. the FLEET preset serving any Anthropic model (id containing "anthropic" or "claude").
#        The fleet exists to be cheap. A Sonnet fleet is a silent bill, not an error the CLI
#        would ever report, so it is refused here rather than discovered on the invoice.
#   Run model_audit.sh during and after the stage: the pre-flight proves what the presets point
#   at, the audit proves what actually served. A subagent transcript records "unknown" for a
#   preset, so the audit cannot name the fleet's model; only OpenRouter's own per-model view can.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"
NN="${1:?stage number}"; shift
PRESET="@preset/cheap"; MAIN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --preset) PRESET="$2"; shift 2;;
    --main) MAIN="$2"; shift 2;;
    --) shift; break;;
    *) break;;
  esac
done
[ -n "$MAIN" ] || { echo "--main is required: the preset that serves the analyst itself" >&2; exit 1; }

KEY="$(security find-generic-password -a "$USER" -s openrouter -w 2>/dev/null || true)"
[ -n "$KEY" ] || { echo "no OpenRouter key in the Keychain (service openrouter, account $USER)" >&2; exit 1; }

# ---- resolve a preset to the model that actually serves it -----------------------------------
resolve() {
  local alias="$1" probe gid gen served i
  probe=$(curl -s https://openrouter.ai/api/v1/messages \
    -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
    -H "anthropic-version: 2023-06-01" \
    -d "{\"model\":\"$alias\",\"max_tokens\":8,\"messages\":[{\"role\":\"user\",\"content\":\"ok\"}]}")
  gid=$(printf '%s' "$probe" | jq -r '.id // empty')
  if [ -z "$gid" ]; then
    echo "REFUSING: probing $alias returned no generation id. Raw response:" >&2
    printf '%s' "$probe" | head -c 600 >&2; echo >&2; return 1
  fi
  served=""
  for i in 1 2 3 4 5 6; do
    sleep 3
    gen=$(curl -s "https://openrouter.ai/api/v1/generation?id=$gid" -H "Authorization: Bearer $KEY")
    served=$(printf '%s' "$gen" | jq -r '.data.model // .model // empty')
    [ -n "$served" ] && break
  done
  [ -n "$served" ] || { echo "REFUSING: could not read the generation record for $alias ($gid)" >&2; return 1; }
  printf '%s' "$served"
}

echo "resolving the two presets before anything launches..."
SERVED_MAIN="$(resolve "$MAIN")"   || exit 1
SERVED_FLEET="$(resolve "$PRESET")" || exit 1
echo "  $MAIN   -> $SERVED_MAIN"
echo "  $PRESET -> $SERVED_FLEET"
for m in "$SERVED_MAIN" "$SERVED_FLEET"; do
  case "$(printf '%s' "$m" | tr 'A-Z' 'a-z')" in
    *opus*) echo "REFUSING: $m is an Opus model. No stage of this run may be served by one." >&2; exit 1;;
  esac
done
case "$(printf '%s' "$SERVED_FLEET" | tr 'A-Z' 'a-z')" in
  *anthropic*|*claude*)
    echo "REFUSING: the fleet preset $PRESET serves $SERVED_FLEET, an Anthropic model." >&2
    echo "          The fleet runs on the cheap arm. Repoint the preset or pass a different one." >&2
    exit 1;;
esac
echo "  guards passed: no Opus on either arm; the fleet is not an Anthropic model"


# ---- record the arm, with what served, not only what was asked for ---------------------------
python3 - "$C" "$NN" "$MAIN" "$PRESET" "$SERVED_MAIN" "$SERVED_FLEET" <<'PY'
import json,sys,datetime,pathlib
c,nn,main,preset,sm,sf=sys.argv[1:7]
p=pathlib.Path(c)/'arm.json'
rec=json.loads(p.read_text()) if p.exists() else {}
rec[nn]={"routed_through":"openrouter","base_url":"https://openrouter.ai/api",
         "analyst_alias":main,"analyst_served":sm,
         "fleet_alias":preset,"fleet_served":sf,
         "opus_refused":True,"anthropic_fleet_refused":True,
         "max_output_tokens":128000,"bg_wait_ceiling_ms":0,
         "declared_utc":datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
p.write_text(json.dumps(rec,indent=2)+"\n")
print("arm recorded for stage "+nn)
PY

# RUN.json's model is what the launcher passes as --model; swap it, restore on exit
cp "$C/RUN.json" "$C/RUN.json.subscription"
trap 'mv -f "$C/RUN.json.subscription" "$C/RUN.json"; echo "RUN.json model restored"' EXIT
python3 - "$C/RUN.json" "$MAIN" "$SERVED_MAIN" "$PRESET" "$SERVED_FLEET" <<'PY'
import json,sys
p,m,sm,pr,sf=sys.argv[1:6]; d=json.load(open(p)); d['model']=m
d.setdefault('models',{}).update(analyst=m, analyst_served=sm, fleet=pr, fleet_served=sf)
json.dump(d,open(p,'w'),indent=2)
PY

ANTHROPIC_BASE_URL="https://openrouter.ai/api" \
ANTHROPIC_AUTH_TOKEN="$KEY" \
ANTHROPIC_API_KEY="" \
ANTHROPIC_MODEL="$MAIN" \
ANTHROPIC_SMALL_FAST_MODEL="$PRESET" \
CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY=1 \
CLAUDE_CODE_SUBAGENT_MODEL="$PRESET" \
CLAUDE_CODE_MAX_OUTPUT_TOKENS=128000 \
CLAUDE_CODE_PRINT_BG_WAIT_CEILING_MS=0 \
  "$C/harness/step.sh" "$NN" "$@"

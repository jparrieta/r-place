#!/usr/bin/env bash
# lib.sh — shared by step.sh, done.sh, fork.sh and restore_stage.sh. Sourced, never run.
# macOS bash 3.2: no mapfile, no associative arrays, no ${var,,}. JSON goes through python3.

if command -v shasum >/dev/null 2>&1; then SHA="shasum -a 256"; else SHA="sha256sum"; fi
NOW() { date -u +%Y-%m-%dT%H:%M:%SZ; }

# the run directory is the parent of CONTROL/harness/
harness_run_dir() { cd "$(dirname "${BASH_SOURCE[1]}")/../.." && pwd -P; }

# norm_label X -> start | step-NN. Accepts start, 1, 01, step-01, 7, 07, step-07.
norm_label() {
  local x="$1"
  case "$x" in
    start|1|01|step-01|step-1) echo start; return;;
    step-*) x="${x#step-}";;
  esac
  case "$x" in
    ''|*[!0-9]*) echo "not a step: $1" >&2; return 1;;
  esac
  x=$(printf '%02d' "$((10#$x))")
  [ "$x" = "01" ] && echo start || echo "step-$x"
}

# stage number NN of a label
label_nn() { [ "$1" = start ] && echo 01 || echo "${1#step-}"; }

# stage file of a label, from DROPS/ORDER.tsv
stage_file_of() { awk -F'\t' -v s="$2" '$2==s{print $3}' "$1/DROPS/ORDER.tsv"; }

# previous / next label on the order, or empty
prev_label() { python3 - "$1" "$2" <<'PY'
import sys
run, lab = sys.argv[1:]
rows = [l.rstrip("\n").split("\t") for l in open(run + "/DROPS/ORDER.tsv")][1:]
labs = [r[1] for r in rows]
i = labs.index(lab) if lab in labs else -1
print(labs[i-1] if i > 0 else "")
PY
}
next_label() { python3 - "$1" "$2" <<'PY'
import sys
run, lab = sys.argv[1:]
rows = [l.rstrip("\n").split("\t") for l in open(run + "/DROPS/ORDER.tsv")][1:]
labs = [r[1] for r in rows]
i = labs.index(lab) if lab in labs else -1
print(labs[i+1] if 0 <= i < len(labs)-1 else "")
PY
}

# the head of the session block a stage belongs to (RUN.json's session rule: 07-09 and 10-12
# share a session). Prints the label whose session this stage continues, or the label itself.
block_head() {
  case "$1" in
    step-08|step-09) echo step-07;;
    step-11|step-12) echo step-10;;
    *) echo "$1";;
  esac
}

# json_get FILE KEY[.KEY...] -> value or empty
json_get() { python3 - "$1" "$2" <<'PY'
import json, sys
p, key = sys.argv[1:]
try:
    d = json.load(open(p))
except Exception:
    print(""); sys.exit(0)
for k in key.split("."):
    d = d.get(k) if isinstance(d, dict) else None
    if d is None:
        print(""); sys.exit(0)
print(d if not isinstance(d, (dict, list)) else json.dumps(d))
PY
}

# json_set FILE KEY VALUE  (VALUE parsed as JSON if it parses, else a string)
json_set() { python3 - "$1" "$2" "$3" <<'PY'
import json, sys, os
p, key, val = sys.argv[1:]
d = json.load(open(p)) if os.path.exists(p) else {}
try:
    v = json.loads(val)
except Exception:
    v = val
ks = key.split(".")
cur = d
for k in ks[:-1]:
    cur = cur.setdefault(k, {})
cur[ks[-1]] = v
tmp = p + ".tmp"
json.dump(d, open(tmp, "w"), indent=2)
os.replace(tmp, p)
PY
}

uuid4() { python3 -c 'import uuid; print(uuid.uuid4())'; }

# the transcript file of a session id, under CONTROL/.cc
transcript_of() { echo "$1/CONTROL/.cc/projects/run/$2.jsonl"; }

# list the top-level transcripts present, one id per line
transcripts_present() { ls "$1/CONTROL/.cc/projects/run"/*.jsonl 2>/dev/null | sed 's|.*/||; s|\.jsonl$||' | sort; }

# refuse to work inside the vault
refuse_in_vault() {
  case "$1" in */Obsidian/*)
    echo "REFUSING: the run stands inside the vault ($1). Move it out first; the settings deny" >&2
    echo "          the vault to the analyst, so a run inside it cannot read its own files." >&2
    exit 1;; esac
}

# Render JSON safely when the aggregator folder moves.
rewrite_settings() { python3 "$1/CONTROL/harness/protocol_guard.py" settings "$1"; }

# Only an explicitly requested aggregator ID can confirm a launch.
confirm_launch() { python3 "$1/CONTROL/harness/protocol_guard.py" confirm "$1"; }

# session_of RUN LABEL -> confirmed session id or empty
session_of() { python3 - "$1" "$2" <<'PY'
import json, os, sys
run, lab = sys.argv[1:]
sp = os.path.join(run, "CONTROL", "sessions.json")
S = json.load(open(sp)) if os.path.exists(sp) else {}
print((S.get(lab) or {}).get("session_id") or "")
PY
}

#!/usr/bin/env python3
"""Seal a finished run: hash everything, write MANIFEST.json, copy to the vault.

    ./CONTROL/harness/seal.py [RUN_DIR] [--to /path/to/62_sealed_runs] [--without-checkpoints]
                              [--with-live-package]

Run layout of the v36 and v37 kits: RUN.json, sessions.json, the transcripts (.cc/) and the
checkpoints (snapshots/) live under CONTROL/; the analyst's world under 00_GIVE-THE-AGENT/.

What leaves by default is the record with what it needs to be restored: CONTROL/ whole,
checkpoints included (each holds the analyst directory as it stood, case text among it, and the
agent's state), the handover log, the drops. The live analyst directory's corpus folders
(cases/, codes/, notebooks/, package/, trees/) are not copied unless --with-live-package: they
are the same bytes the checkpoints already carry. --without-checkpoints drops CONTROL/snapshots/
and gives a record that cannot be restored; the manifest says which.
"""
import json, sys, hashlib, pathlib, shutil, datetime, argparse

ap = argparse.ArgumentParser()
ap.add_argument("run", nargs="?", default=".")
ap.add_argument("--to", default=None, help="destination for the sealed copy")
ap.add_argument("--without-checkpoints", action="store_true",
                help="leave CONTROL/snapshots/ out; the sealed copy then cannot be restored")
ap.add_argument("--with-live-package", action="store_true",
                help="also copy the live analyst directory's corpus folders")
a = ap.parse_args()

run = pathlib.Path(a.run).resolve()
C = run / "CONTROL"
meta = json.loads((C / "RUN.json").read_text())

SKIP_NAMES = {"__pycache__", ".DS_Store", "_to_delete", ".lock-done"}
CORPUS = {"cases", "codes", "notebooks", "package", "trees"}


def skip(p):
    rel = p.relative_to(run).parts
    if any(s in rel for s in SKIP_NAMES):
        return True
    if a.without_checkpoints and rel[:2] == ("CONTROL", "snapshots"):
        return True
    if not a.with_live_package and len(rel) > 1 and rel[0] == "00_GIVE-THE-AGENT" and rel[1] in CORPUS:
        return True
    if "credentials" in p.name:
        return True
    return False


def files():
    for p in sorted(run.rglob("*")):
        if p.is_file() and not skip(p):
            yield p


def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


inv = {str(p.relative_to(run)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in files()}

run_id = hashlib.sha256("|".join([
    meta.get("fingerprint", ""), meta.get("model", ""), meta.get("instrument_version", ""),
    meta.get("built_utc", ""), meta.get("arm", "")]).encode()).hexdigest()[:16]

closed = []
hp = C / "handover-events.log"
if hp.exists():
    for l in hp.open():
        f = l.rstrip("\n").split("\t")
        if len(f) > 3 and f[1] == "closed":
            closed.append(f[3])
checkpoints = sorted(p.name for p in (C / "snapshots").glob("*") if (p / "COMMITTED").exists()) \
    if (C / "snapshots").is_dir() else []
transcripts = sorted(p.name for p in (C / ".cc" / "projects" / "run").glob("*.jsonl")) \
    if (C / ".cc" / "projects" / "run").is_dir() else []
sessions = json.loads((C / "sessions.json").read_text()) if (C / "sessions.json").exists() else {}

manifest = {
    "run_id": run_id,
    "sealed_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "run": meta,
    "grade": "A" if transcripts and checkpoints and not a.without_checkpoints else "B",
    "grade_meaning": {
        "A": "transcripts and committed checkpoints present; any boundary restores from the sealed copy alone",
        "B": "no transcripts, or the checkpoints left out; a referee session is an analyst on the same package, not the one that wrote the report",
    },
    "stages_closed": closed,
    "stages_closed_count": len(closed),
    "checkpoints": checkpoints,
    "sessions": sessions,
    "transcripts": transcripts,
    "interventions": (C / "interventions.jsonl").exists(),
    "checkpoints_included": not a.without_checkpoints,
    "live_corpus_included": bool(a.with_live_package),
    "files": inv,
}
(run / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"run_id {run_id}   grade {manifest['grade']}   {len(closed)} stages closed   "
      f"{len(checkpoints)} checkpoints   {len(inv)} files")

if a.to:
    dest = pathlib.Path(a.to).expanduser() / run_id
    if dest.exists():
        sys.exit(f"refusing: {dest} already exists")
    dest.mkdir(parents=True)
    for rel in list(inv) + ["MANIFEST.json"]:
        src = run / rel
        dst = dest / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        dst.chmod(0o444)
    print(f"sealed copy at {dest} (read-only, {len(inv) + 1} files)")
    if not a.with_live_package:
        print("the live corpus folders were not copied; the checkpoints carry the same bytes.")

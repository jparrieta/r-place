#!/usr/bin/env bash
# set_model.sh MODEL — write the model id into CONTROL/RUN.json, once, before the first step.
#   A kit built where the model is not known yet is built with the model SET-ME; step.sh
#   refuses to hand anything in until this has run. A model already set is never changed:
#   a run does not change model, and a different model is a different run.
set -euo pipefail
MODEL="${1:?model id, e.g. claude-opus-4-1}"
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
C="$RUN/CONTROL"
[ -f "$C/RUN.json" ] || { echo "not a run directory: $RUN" >&2; exit 1; }
if [ -f "$C/handover-events.log" ] || [ -d "$C/snapshots" ]; then
  echo "REFUSING: a step has already been handed in this run; the model stays what RUN.json says." >&2
  exit 1
fi
python3 - "$C/RUN.json" "$MODEL" <<'PY'
import json, sys, datetime, socket
p, m = sys.argv[1:]
r = json.load(open(p))
cur = r.get("model")
if cur not in (None, "", "SET-ME"):
    sys.exit("REFUSING: the model is already %r and a run does not change model. Build another run." % cur)
if not m.strip() or any(ch.isspace() for ch in m):
    sys.exit("not a model id: %r" % m)
r["model"] = m
r["model_set_utc"] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
r["run_host"] = socket.gethostname()
json.dump(r, open(p, "w"), indent=2)
print("model set: %s  (RUN.json)" % m)
PY

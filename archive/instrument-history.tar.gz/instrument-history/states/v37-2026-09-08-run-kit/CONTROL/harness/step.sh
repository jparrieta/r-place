#!/usr/bin/env bash
# Handler only. Deliver one stage and launch the aggregator, or print its locked launcher.
set -euo pipefail
ARGS=("$@")
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"; AG="$RUN/00_GIVE-THE-AGENT"
if [ "${AGGREGATOR_LOCK_RUN:-}" != "$RUN" ]; then
  exec python3 "$C/harness/protocol_guard.py" locked "$RUN" bash "$0" "${ARGS[@]}"
fi
N="${1:?stage number or start}"; shift
PREPARE=0; APIOK=0; FORCE=0
for a in "$@"; do
  case "$a" in
    --prepare) PREPARE=1;; --api-ok) APIOK=1;; --force-order) FORCE=1;;
    *) echo "unknown option: $a" >&2; exit 1;;
  esac
done
LABEL="$(norm_label "$N")"; NN="$(label_nn "$LABEL")"
STAGE="$(stage_file_of "$RUN" "$LABEL")"
[ -n "$STAGE" ] || { echo "unknown stage: $LABEL" >&2; exit 1; }
MODEL="$(json_get "$C/RUN.json" model)"
[ -n "$MODEL" ] && [ "$MODEL" != SET-ME ] || { echo "Set the model before launch." >&2; exit 1; }
if [ -n "${ANTHROPIC_API_KEY:-}" ] && [ "$APIOK" -eq 0 ]; then
  echo "API key is set; use --api-ok only for a declared API run." >&2; exit 1
fi
rewrite_settings "$RUN"
if ! confirm_launch "$RUN"; then
  [ "$(json_get "$C/pending_launch.json" label)" = "$LABEL" ] || {
    echo "Another stage launch remains pending." >&2; exit 1;
  }
fi
PREV="$(prev_label "$RUN" "$LABEL")"
if [ -n "$PREV" ] && ! python3 "$C/harness/protocol_guard.py" advance "$RUN" "$PREV"; then
  if [ "$FORCE" -eq 0 ]; then
    echo "$PREV needs a complete agent-and-files checkpoint before $LABEL." >&2; exit 1
  fi
  printf '%s\tforced-order\t%s\t%s incomplete\n' "$(NOW)" "$LABEL" "$PREV" >> "$C/handover-events.log"
fi
if [ "$LABEL" != start ]; then
  if ! awk -F'\t' -v label="$LABEL" '$2=="handed" && $3==label {found=1} END {exit !found}' "$C/handover-events.log" 2>/dev/null; then
    cp -R "$RUN/DROPS/$LABEL"/. "$AG"/
    printf '%s\thanded\t%s\t%s\n' "$(NOW)" "$LABEL" "$STAGE" >> "$C/handover-events.log"
  fi
  if [ "$LABEL" = step-18 ]; then
    for comparison in "$C/fork_comparison-07.json" "$C/fork_comparison-10.json"; do
      [ ! -f "$comparison" ] || cp "$comparison" "$AG/"
    done
  fi
fi
printf '%s\n' "$NN" > "$AG/.stage"
CLI_VERSION="$(claude --version 2>/dev/null | head -1 || echo unknown)"
python3 "$C/harness/protocol_guard.py" prepare "$RUN" "$LABEL" "$CLI_VERSION"
TOKEN="$(json_get "$C/pending_launch.json" launch_id)"
CMD=(bash "$C/harness/launch.sh" "$LABEL" "$TOKEN")
[ "$APIOK" -eq 0 ] || CMD+=(--api-ok)
cat <<MSG
Aggregator stage $NN: $STAGE
Paste into the aggregator: Read AGENT.md, then $STAGE. Do that stage and stop.
At completion, wait for its background work, quit Claude, and close from the handler:
  bash "$C/harness/done.sh" "$NN"
Shared blocks retain the same native session ID across these launches.
MSG
if [ "$PREPARE" -eq 1 ]; then
  printf 'Prepared aggregator launch (run from the handler terminal):\n  '
  printf '%q ' "${CMD[@]}"
  printf '\n'
  exit 0
fi
"${CMD[@]}"

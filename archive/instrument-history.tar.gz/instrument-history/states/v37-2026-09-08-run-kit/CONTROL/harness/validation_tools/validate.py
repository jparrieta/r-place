#!/usr/bin/env python3
"""validate.py — run at the close of every stage, before the handback is written.

    python3 validate.py <stage> <root> <outdir>            # at the CLOSE of a stage
    python3 validate.py <stage> <root> <outdir> --open     # at the OPEN, before any judgement
    python3 validate.py --self-test                        # once, at stage 01

`<root>` is the folder you were given — the one holding `package/`, `data/`, `tools/` and your
output directory. Passing `package/` itself also works; see `resolve_root`.

This checks a *run*, not the instrument: that the files a stage was told to produce exist, parse,
and reconcile against the package and against each other.

**Why it exists.** A judgement can be right and the file recording it can still not add up — and
the file is what every later stage reads. A line count never reconciled against the census, a theme
id the frozen scheme does not define, a community named outside the analysed set: each is one
script's worth of arithmetic, and each is cheap to catch at the close of the stage that wrote it
and expensive to catch anywhere after.

Exit code is 1 if any ERROR. Warnings never fail a stage: some are terminal by design.

**Coverage, stated so it cannot be mistaken for completeness.** Instrument v37, stages 01–18: a
close-check exists for every one of the eighteen. Each handler is pinned by name to the stage it
checks, so a renumbering cannot silently point a check at the wrong stage. What a handler checks
is the SHAPE of the stage's files; none of them can check whether a judgement is right, and a
clean report is not evidence about the analysis.

**The self-test.** `--self-test` builds, for every close-check, a small fixture with one known
defect planted in it, runs the check, and reports whether the planted defect fired. A check that
does not fire on its own planted defect is a defect in the package; say so in `defects.jsonl`.

**At every close** this file runs `tools/snap.py NN close`, so every stage's working files are
versioned as they stood when the check ran (`_snap/NN-close.sha256`, `NN-close-2` on a rerun).

The same standard inside a handler: a check keyed on the analysed set refuses when either file that
defines it is absent — the census in `package/case_facts.jsonl`, or stage 01's `dropped.jsonl` — and
names what it therefore did not check. An empty census passes every membership test taken over it,
and a missing `dropped.jsonl` leaves the frame standing in for the analysed set; both come back
clean, which is the one result this file may not produce.
"""
import hashlib
import glob
import json
import os
import re
import sys
import collections

E, W = [], []


def err(m, shape=None, where=None):
    """Record an error.

    `shape` folds repeats. A per-line check over a few thousand lines can otherwise emit a few
    thousand identical errors and bury the one line that matters — and a check whose output nobody
    reads is a check that was not run. One line per shape, with a count and the first
    instance.
    """
    E.append((m, shape, where))


def warn(m, shape=None, where=None):
    W.append((m, shape, where))


def _fold(items):
    """Collapse (message, shape, where) triples: one line per shape, in first-seen order."""
    out, seen = [], {}
    for m, shape, where in items:
        if shape is None:
            out.append(m)
            continue
        if shape not in seen:
            seen[shape] = [1, m, where]
            out.append(shape)          # placeholder, replaced below
        else:
            seen[shape][0] += 1
    final = []
    for row in out:
        if isinstance(row, str) and row in seen:
            n, m, where = seen.pop(row)
            final.append(m if n == 1 else
                         "%s  [%d lines with this shape; first: %s]" % (m, n, where))
        elif row not in seen:
            final.append(row)
    return final


def resolve_root(arg):
    """Split the second argument into the folder root and the package directory, and search both.

    A stage names some inputs against the folder root (`data/MASTER-census.csv`) and some inside
    the package (`literature-tierB.md`, which arrives with a stage's package). Resolving against
    one of the two reports every file that lives in the other as missing, under a message saying
    the previous stage did not finish — so both are resolved, and the analyst is not told a file
    is absent when it is where it belongs.

    Passing the folder root and passing `package/` therefore both work. An argument with no
    `package/` under it is taken to be the package directory, and its parent as the folder root.
    """
    arg = arg or "."
    pkg = os.path.join(arg, "package")
    if os.path.isdir(pkg):
        return arg, pkg
    return (os.path.dirname(os.path.abspath(arg)) or "."), arg


def _jsonl(p):
    if not os.path.exists(p):
        return None
    out = []
    for i, line in enumerate(open(p, encoding="utf-8"), 1):
        if not line.strip():
            continue
        try:
            out.append(json.loads(line))
        except ValueError as ex:
            err("%s line %d is not JSON: %s" % (os.path.basename(p), i, ex))
    return out


def need(outdir, *names):
    for n in names:
        if not os.path.exists(os.path.join(outdir, n)):
            err("stage output %r was not written" % n)


def census(stage, what, ctx):
    """The census, or None having said that this check therefore did not run.

    `ctx["facts"]` is `package/case_facts.jsonl`, and it comes back empty whenever the second
    argument resolves to a folder with no package under it — running from inside `tools/`, or
    giving the output directory as the root. Every set a handler builds is built from it, so an
    empty census makes every membership test below vacuous: nothing is in the census, so nothing
    can be outside it, and the handler prints a clean report having compared nothing. This refuses
    instead, and names what went unchecked.
    """
    facts = ctx.get("facts") or []
    if not facts:
        err("stage %s: %s holds no census, so %s was NOT checked. Give validate.py the folder "
            "root — the one holding package/ — as its second argument. Every set this check "
            "compares against is built from the census, and an empty one passes every membership "
            "test in it." % (stage, ctx.get("facts_path", "package/case_facts.jsonl"), what))
        return None
    return facts


def analysed_set(stage, what, outdir, ctx):
    """The analysed set and the §4 drops, or None having said that this check did not run.

    The analysed set is the census minus what stage 01 dropped, and it needs both files. Absent
    `dropped.jsonl`, `{census} - {}` is the frame, and a handler that goes on to print it under the
    words *analysed set* is reporting a frame figure under an analysed-set name. `counts.py` holds
    `n_analysed` null on exactly this file for exactly that reason, and stage 01's own check
    requires the file as the interlock against this substitution — so this refuses rather than
    letting the frame stand in.
    """
    facts = census(stage, what, ctx)
    if facts is None:
        return None
    dropped = _jsonl(os.path.join(outdir, "dropped.jsonl"))
    if dropped is None:
        err("stage %s: dropped.jsonl is not in the output directory, so there is no analysed set "
            "and %s was NOT checked. Stage 01 writes that file under §4, empty or not; without it "
            "the frame is the only set this check could compare against, and a frame figure "
            "reported as the analysed set is the substitution that file exists to prevent."
            % (stage, what))
        return None
    subs = {d["sub"] for d in dropped if d.get("sub")}
    return {f["sub"] for f in facts} - subs, subs


def load_scheme(outdir):
    """Theme ids the *current* scheme defines.

    Order matters: stage 06 writes `scheme_v2.jsonl` and stage 03 freezes
    `scheme_final.jsonl`, and a check that reads stage 02's `scheme.jsonl` after either exists is
    validating stage 07's chunks against a tier that has since been recut. Read the newest that is
    present, and fall back to parsing ids out of the prose only if no JSONL is.
    """
    for name in ("scheme_v2.jsonl", "scheme_final.jsonl", "scheme.jsonl"):
        rows = _jsonl(os.path.join(outdir, name))
        if rows:
            return {r.get("id") or r.get("second_order") for r in rows}
    for name in ("scheme_v2.md", "scheme_final.md", "scheme.md"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            t = open(p, encoding="utf-8").read()
            ids = set(re.findall(r"\b(S\d{2})\b", t))
            if ids:
                return ids
    return None


def _check_digest(outdir, name, sidecar):
    pm, ps = os.path.join(outdir, name), os.path.join(outdir, sidecar)
    if os.path.exists(pm) and os.path.exists(ps):
        raw = open(ps, encoding="utf-8").read().strip()
        if not re.fullmatch(r"[0-9a-f]{64}", raw):
            err("%s is not a bare 64-character hex digest on one line" % sidecar)
        else:
            got = hashlib.sha256(open(pm, "rb").read()).hexdigest()
            if got != raw:
                err("%s is not the digest of %s as it stands: edited after hashing, or never "
                    "rehashed" % (sidecar, name))


def _check_manifest_digests(outdir, sidecar, names):
    """A multi-file sidecar: one line per file, '<name>  <digest>' or '<digest>  <name>'."""
    ps = os.path.join(outdir, sidecar)
    if not os.path.exists(ps):
        err("%s was not written; the stage closes its files with it" % sidecar)
        return
    got = {}
    for line in open(ps, encoding="utf-8"):
        parts = line.split()
        if len(parts) != 2:
            continue
        a, b = parts
        if re.fullmatch(r"[0-9a-f]{64}", a):
            got[b] = a
        else:
            got[a] = b
    for n in names:
        if n not in got:
            err("%s does not list %s" % (sidecar, n))
            continue
        q = os.path.join(outdir, n)
        if not os.path.exists(q):
            err("%s lists %s, which does not exist" % (sidecar, n))
            continue
        if hashlib.sha256(open(q, "rb").read()).hexdigest() != got[n]:
            err("%s: %s was edited after it was hashed" % (sidecar, n))



# ---- shared vocabularies -------------------------------------------------------------------

VERDICTS = ("composes", "composes-with-residue", "does-not-compose", "cannot-tell")
KINDS = ("outside-the-model", "out-of-scope", "too-thin")
PROBLEMS = ("division", "allocation", "reward", "information")
MODIFIERS = ("exception", "goal", "hard_to_place")
CANVAS = ("canvas_entries", "canvas_area_px", "canvas_centre", "canvas_ring",
          "canvas_artwork", "canvas_source")
THEME_ID = re.compile(r"^S\d{2,3}$")
FAMILY_ID = re.compile(r"^G\d{2,3}$")
CHUNK_ID = re.compile(r"^C\d{1,3}$")


def _text(outdir, name):
    p = os.path.join(outdir, name)
    return open(p, encoding="utf-8", errors="replace").read() if os.path.exists(p) else ""


def _manifest_entry(outdir, stage, what):
    """The run manifest carries one entry per stage that served anyone; the entry must exist
    before the first reader was served, which this cannot see, but its absence it can."""
    mp = os.path.join(outdir, "run_manifest.json")
    if not os.path.exists(mp):
        err("run_manifest.json is not in the output directory; stage %s appends its entry (%s) "
            "before the first reader is served" % (stage, what))
        return None
    try:
        man = json.load(open(mp, encoding="utf-8"))
    except Exception as e:
        err("run_manifest.json will not parse: %s" % e)
        return None
    ents = [e for e in (man if isinstance(man, list) else [man])
            if isinstance(e, dict) and str(e.get("stage")).zfill(2) == stage]
    if not ents:
        err("run_manifest.json has no stage-%s entry; %s is served under an entry appended "
            "before the first reader, with model, seed, decoding settings and the reader count"
            % (stage, what))
        return None
    return ents


def _package_codes(ctx):
    """Every code id the package defines, from package/codes.jsonl (the sealed file) or the
    store's codes.jsonl; None if neither is there, having said so."""
    if "code_ids" in ctx:
        return ctx["code_ids"]
    ids = set()
    found = False
    for p in (os.path.join(ctx["package"], "codes.jsonl"),
              os.path.join(ctx["package"], "store", "codes.jsonl")):
        if os.path.exists(p):
            found = True
            for r in _jsonl(p) or []:
                cid = r.get("code_id") or r.get("id")
                if cid:
                    ids.add(cid)
    ctx["code_ids"] = ids if found else None
    return ctx["code_ids"]


def _expected_items(stage, what, outdir, ctx):
    """assignment_items_expected as counts.py computes it: n_themes summed over the analysed
    set. None, having said so, when the analysed set is undefined."""
    sets = analysed_set(stage, what, outdir, ctx)
    if sets is None:
        return None
    analysed, _d = sets
    return sum((f.get("n_themes") or 0) for f in ctx["facts"] if f["sub"] in analysed)


def _licence_sentence(outdir, name, what):
    """The contract's §7 licence: wherever a fidelity or reliability figure appears, the sentence
    saying it bounds whether the instrument decides, not whether it is right."""
    t = _text(outdir, name).lower()
    if not t:
        return
    if "bound" not in t or "not whether" not in t:
        err("%s reports %s without the sentence saying what it licenses (the contract's §7: it "
            "bounds whether the instrument decides, not whether it is right)" % (name, what))


def _snap_matches(outdir, snap_name, file_name, stage, what):
    """A snapped file must be the file on disk: the ordering the snap proves is only as good as
    the file not having moved since. Returns True when the snap exists and matches."""
    sp = os.path.join(outdir, "_snap", snap_name)
    if not os.path.exists(sp):
        err("stage %s: _snap/%s was not written; %s is proved by that snap and by nothing else "
            "(run `python3 tools/snap.py` at the moment the standing instructions name)"
            % (stage, snap_name, what))
        return False
    fp = os.path.join(outdir, file_name)
    if not os.path.exists(fp):
        err("stage %s: %s is not in the output directory" % (stage, file_name))
        return False
    got = hashlib.sha256(open(fp, "rb").read()).hexdigest()
    listed = None
    for line in open(sp, encoding="utf-8"):
        if line.startswith("#") or not line.strip():
            continue
        parts = line.rstrip("\n").split("  ", 3)
        if len(parts) == 4 and parts[3] == file_name:
            listed = parts[0]
    if listed is None:
        err("stage %s: _snap/%s does not list %s; the file was written after the snap, so the "
            "snap proves nothing about it" % (stage, snap_name, file_name))
        return False
    if listed != got:
        err("stage %s: %s changed after _snap/%s was taken (%s... then, %s... now); %s rests on "
            "that file not moving" % (stage, file_name, snap_name, listed[:12], got[:12], what))
        return False
    print("  %s unchanged since _snap/%s" % (file_name, snap_name))
    return True


# ---- stage 01: the reading -----------------------------------------------------------------

def stage01(root, outdir, ctx):
    # Every output stage 01 declares. `dropped.jsonl` is the interlock against a later stage
    # substituting the frame for the analysed set: counts.py keys `n_analysed` on that file
    # existing, so a stage 01 that never writes it leaves the figure null for the whole run.
    need(outdir, "notes-01.md", "running-01.md", "lexicon-01.md", "rooms_index.md", "contrast.md",
         "dropped.jsonl", "departures.jsonl", "defects.jsonl", "run_manifest.json")
    rooms_dir = os.path.join(outdir, "rooms")
    notes = sorted(glob.glob(os.path.join(rooms_dir, "*.md")))
    if not notes:
        err("out/rooms/ holds no room note; stage 01 is the reading and every room of the "
            "analysed set gets one")
    else:
        short = [os.path.basename(n) for n in notes if os.path.getsize(n) < 200]
        if short:
            err("%d room notes are under 200 bytes (%s ...): a note that short is a placeholder"
                % (len(short), ", ".join(short[:4])))
        heads = ("doing:", "week:", "named:", "unsettled:", "carrying:", "not this:")
        bad = []
        for n in notes:
            t = open(n, encoding="utf-8").read()
            if not all(h in t for h in heads):
                bad.append(os.path.basename(n))
        if bad:
            err("%d room notes lack one of the six fixed lines %s: %s ..." % (len(bad), heads,
                                                                             ", ".join(bad[:4])))
    dropped = _jsonl(os.path.join(outdir, "dropped.jsonl"))
    facts = census("01", "the census line below, and every name in dropped.jsonl against the "
                         "census", ctx)
    if facts is not None:
        subs = {f["sub"] for f in facts}
        for d in (dropped or []):
            if d.get("sub") not in subs:
                err("dropped.jsonl names %r, which is not in the census" % d.get("sub"))
            if not d.get("why"):
                err("dropped.jsonl line for %r carries no why" % d.get("sub"))
        if dropped is None:
            print("  census %d, dropped --, analysed -- : dropped.jsonl was not written, so the "
                  "section 4 screen has not run and counts.py holds n_analysed null for the whole "
                  "run" % len(subs))
        elif not dropped:
            print("  census %d, dropped 0, analysed %d : dropped.jsonl is written and empty, so "
                  "the screen ran and dropped nothing and the analysed set is the frame"
                  % (len(subs), len(subs)))
        else:
            print("  census %d, dropped %d, analysed %d" % (len(subs), len(dropped),
                                                            len(subs) - len(dropped)))
        if dropped is not None and notes:
            analysed = subs - {d.get("sub") for d in dropped}
            noted = {os.path.basename(n)[:-3] for n in notes}
            missing = sorted(analysed - noted)
            if missing:
                err("%d rooms of the analysed set have no note in out/rooms/: %s ..."
                    % (len(missing), ", ".join(missing[:6])))
            stray = sorted(noted - subs)
            if stray:
                err("out/rooms/ holds notes for names not in the census: %s" % stray[:6])
            print("  room notes %d over an analysed set of %d" % (len(noted & analysed),
                                                                  len(analysed)))
        # the canvas, present and whole (stage 01 §2): one line per room of the census with the
        # six keys, and the pixel series with its five columns. The analyst holds both from here
        # (rule 7 as v37 states it); what the fleets are served is checked where they are served.
        op = os.path.join(ctx["package"], "case_facts_outcome.jsonl")
        outcome = _jsonl(op)
        if outcome is None:
            err("package/case_facts_outcome.jsonl is not in the package; the canvas joins the "
                "package at build (the contract's §2) and stage 01 reads it beside every room")
        else:
            have = {o.get("sub") for o in outcome}
            gone = sorted(subs - have)
            if gone:
                err("case_facts_outcome.jsonl has no line for %d census rooms (%s ...)"
                    % (len(gone), gone[:5]))
            lacking = [o.get("sub") for o in outcome if not all(k in o for k in CANVAS)]
            if lacking:
                err("case_facts_outcome.jsonl: %d lines lack one of the six canvas keys (%s ...)"
                    % (len(lacking), lacking[:5]))
            print("  canvas: %d outcome lines over a census of %d" % (len(outcome), len(subs)))
        pp = os.path.join(ctx["package"], "pixels.csv")
        if not os.path.exists(pp):
            err("package/pixels.csv is not in the package")
        else:
            hdr = open(pp, encoding="utf-8").readline().strip().split(",")
            want = ["sub", "hour_since_open", "px_in_region_any", "px_by_pre_members",
                    "px_by_window_members"]
            if hdr != want:
                err("pixels.csv columns are %s, not %s" % (hdr, want))
        rp = os.path.join(ctx["package"], "store", "rooms.jsonl")
        rows = _jsonl(rp) or []
        if rows and not any(k in rows[0] for k in CANVAS):
            err("package/store/rooms.jsonl carries no canvas field; the build joins the six into "
                "it (`build_store.py --join-canvas`) and `mem.py room` shows them from there")
    defects = _jsonl(os.path.join(outdir, "defects.jsonl"))
    if defects is None:
        print("  defects.jsonl was not written. It opens here and every later stage appends to "
              "it, so this run has nowhere a defect in the material could have been recorded")
    elif not defects:
        print("  defects.jsonl is written and empty: nothing wrong found in the material here, "
              "which is a result and not a missed step")
    else:
        print("  defects.jsonl carries %d line(s) from this stage" % len(defects))
    if not os.path.exists(os.path.join(outdir, "_head.md")):
        warn("_head.md is not written yet; stage 01's close writes it for the first time, in the "
             "form the standing instructions give, and every session after reads it first")
    n1 = _text(outdir, "notes-01.md")
    if n1 and "self-test" not in n1.lower():
        warn("notes-01.md does not mention the self-test; stage 01 §1 runs `validate.py "
             "--self-test` once and pastes its report there")


# ---- stage 02: the scheme ------------------------------------------------------------------

def stage02(root, outdir, ctx):
    need(outdir, "prior.md", "scheme.md", "scheme.jsonl", "families.jsonl", "confusions.md",
         "theme_discovery.jsonl", "_groups-02.jsonl", "tier_history.jsonl", "findings.jsonl",
         "notes-02.md")
    rows = _jsonl(os.path.join(outdir, "scheme.jsonl")) or []
    ids = {r.get("id") for r in rows}
    fams = _jsonl(os.path.join(outdir, "families.jsonl")) or []
    fam_ids = {f.get("family") for f in fams}
    for r in rows:
        if not THEME_ID.match(str(r.get("id") or "")):
            err("scheme.jsonl id %r is not of the form S07" % r.get("id"),
                shape="scheme.jsonl: an id is not S-numbered")
        if not r.get("gate"):
            err("scheme.jsonl %s has no gate; rule 5 puts one above every count" % r.get("id"))
        if "gate_parts" not in r:
            warn("scheme.jsonl %s carries no gate_parts field; the contract's §3 asks for it on "
                 "every theme, null where the gate names no two-part move" % r.get("id"))
        if r.get("tier") not in ("main", "rare"):
            err("scheme.jsonl %s: tier is %r, not main|rare (the rare-but-sharp tier is a field, "
                "not a separate file)" % (r.get("id"), r.get("tier")),
                shape="scheme.jsonl: tier outside main|rare")
        if r.get("family") not in fam_ids:
            err("scheme.jsonl %s names family %r, which families.jsonl does not define"
                % (r.get("id"), r.get("family")),
                shape="scheme.jsonl: a family families.jsonl does not define")
        for k in ("must_show", "must_not_show", "gloss", "name"):
            if not r.get(k):
                err("scheme.jsonl %s: %s is empty" % (r.get("id"), k),
                    shape="scheme.jsonl: a required field is empty")
        ex = r.get("exemplars") or []
        if len(ex) < 3:
            warn("scheme.jsonl %s carries %d exemplars; stage 02 §3 asks for three, each through "
                 "cite()" % (r.get("id"), len(ex)),
                 shape="scheme.jsonl: fewer than three exemplars")
    for f in fams:
        if not FAMILY_ID.match(str(f.get("family") or "")):
            err("families.jsonl family %r is not of the form G03" % f.get("family"))
        for t in f.get("themes") or []:
            if t not in ids:
                err("families.jsonl %s lists theme %r, which scheme.jsonl does not define"
                    % (f.get("family"), t))
    grouped = {t for f in fams for t in (f.get("themes") or [])}
    orphan = sorted(ids - grouped)
    if orphan:
        err("themes in no family: %s; the fleet opens one family's full tests at a time, and a "
            "theme outside every family is never opened" % orphan[:8])
    dup = [t for t, n in collections.Counter(t for f in fams for t in (f.get("themes") or [])).items()
           if n > 1]
    if dup:
        err("themes in more than one family: %s" % dup[:8])
    deps = _jsonl(os.path.join(outdir, "departures.jsonl")) or []
    if not any(str(d.get("stage")) == "02" and "satur" in json.dumps(d).lower() for d in deps):
        warn("departures.jsonl carries no stage-02 line saying saturation is not a reported "
             "figure here (contract §8)")
    groups = _jsonl(os.path.join(outdir, "_groups-02.jsonl")) or []
    if not groups:
        err("_groups-02.jsonl is empty; it is the grouping on disk, rewritten at every room "
            "boundary, and it is what survives a compaction")
    find = _jsonl(os.path.join(outdir, "findings.jsonl"))
    if find is not None and not any(str(f.get("stage")) == "02" for f in find):
        warn("findings.jsonl carries no stage-02 line; the stage opens it with the scheme's claim "
             "in rule 14's form")
    if not ids:
        err("no theme ids (S01, S02, ...) found in the scheme — the frozen scheme must be "
            "addressable by id or nothing downstream can cite it")
    else:
        rare = sum(1 for r in rows if r.get("tier") == "rare")
        print("  scheme carries %d themes in %d families (%d rare): %s" % (
            len(ids), len(fam_ids), rare, ", ".join(sorted(ids))[:200]))
        if len(ids) < 8:
            warn("only %d second-order themes; stage 11 wants a feature space" % len(ids))


# ---- stage 03: the pilot -------------------------------------------------------------------

def stage03(root, outdir, ctx):
    need(outdir, "author_items.jsonl", "gold_items.jsonl", "pilot_rounds.jsonl",
         "scheme_edits.jsonl", "exemplar_candidates.jsonl", "pilot_report.md", "scheme_final.md",
         "scheme_final.jsonl", "notes-03.md")
    _manifest_entry(outdir, "03", "the pilot's readers")
    ids = {r.get("id") for r in (_jsonl(os.path.join(outdir, "scheme_final.jsonl")) or [])}
    auth = _jsonl(os.path.join(outdir, "author_items.jsonl")) or []
    gold = _jsonl(os.path.join(outdir, "gold_items.jsonl")) or []
    if not (40 <= len(auth) <= 60):
        warn("author_items.jsonl has %d items; stage 03 §1 says forty to sixty" % len(auth))
    if not gold:
        err("gold_items.jsonl is empty; the held-out set is drawn by §3's rule and shown to no "
            "pilot agent")
    for name, rows in (("author_items.jsonl", auth), ("gold_items.jsonl", gold)):
        for r in rows:
            if r.get("corrected") or r.get("corrected_round"):
                err("%s %s/%s carries a correction. That file is the record of what you placed "
                    "BEFORE the rounds, which is the whole of its value" % (name, r.get("sub"),
                                                                            r.get("case_theme")),
                    shape="%s: a line carries a correction" % name)
            so = r.get("second_order")
            so = so if isinstance(so, list) else [so]
            for s in so:
                if ids and s not in ids:
                    err("%s places %s/%s on %r, which scheme_final.jsonl does not define"
                        % (name, r.get("sub"), r.get("case_theme"), s),
                        shape="%s: a placement on an id the frozen scheme does not define" % name)
    ak = {(r.get("sub"), r.get("case_theme")) for r in auth}
    gk = {(r.get("sub"), r.get("case_theme")) for r in gold}
    both = ak & gk
    if both:
        err("%d items are in both the author set and the gold set (%s); the gold set is drawn "
            "from what is left" % (len(both), sorted(both)[:3]))
    edits = _jsonl(os.path.join(outdir, "scheme_edits.jsonl")) or []
    KINDS3 = {"scheme-ambiguous", "item-is-a-bag", "reader-error", "author-error", "genuine-joint"}
    for e in edits:
        if not e.get("caused_by"):
            err("scheme_edits.jsonl: an edit on %s (%s, round %s) has no caused_by; an edit with "
                "no caused_by is not allowed" % (e.get("theme"), e.get("field"), e.get("round")),
                shape="scheme_edits.jsonl: an edit with no caused_by")
        if e.get("kind") and e.get("kind") not in KINDS3:
            err("scheme_edits.jsonl: kind %r is not one of stage 03's five" % e.get("kind"),
                shape="scheme_edits.jsonl: a kind outside the five")
    if edits and not any(e.get("kind") == "author-error" for e in edits):
        warn("no scheme edit is recorded as author-error; a pilot that never returns one is a "
             "pilot measuring obedience, not transmission (say so in pilot_report.md if it is so)")
    R = _jsonl(os.path.join(outdir, "pilot_rounds.jsonl")) or []
    if not R:
        err("pilot_rounds.jsonl is empty")
    for r in R:
        if not any(k.startswith("fidelity") for k in r):
            err("pilot_rounds.jsonl round %r reports no fidelity against the author's placements"
                % r.get("round"))
    if R and not any(r.get("gold") is True for r in R):
        err("no gold round in pilot_rounds.jsonl (a round with \"gold\": true, run once at the "
            "end against the frozen scheme)")
    _licence_sentence(outdir, "pilot_report.md", "fidelity")
    print("  author items %d, gold items %d, edits %d (author-error %d), rounds %d, frozen ids %d"
          % (len(auth), len(gold), len(edits),
             sum(1 for e in edits if e.get("kind") == "author-error"), len(R), len(ids)))


# ---- stage 04: the fleet (its own §11) ------------------------------------------------------

def stage04(root, outdir, ctx):
    need(outdir, "batches-04.jsonl", "assign_raw.jsonl", "assign_pass2.jsonl",
         "multiplacement_log.jsonl", "multiplacement_register-04.md", "fidelity-04.md",
         "agent_report-04.md", "notes-04.md")
    _manifest_entry(outdir, "04", "the fleet")
    ids = {r.get("id") for r in (_jsonl(os.path.join(outdir, "scheme_final.jsonl")) or [])}
    if not ids:
        err("scheme_final.jsonl is absent or empty, so no second_order id could be resolved")
    raw = _jsonl(os.path.join(outdir, "assign_raw.jsonl")) or []
    codes = _package_codes(ctx)
    if codes is None:
        err("no codes.jsonl in the package, so no support id could be resolved")
    multi = _jsonl(os.path.join(outdir, "multiplacement_log.jsonl")) or []
    mkeys = collections.defaultdict(set)
    for m in multi:
        mkeys[(m.get("sub"), m.get("case_theme"), m.get("agent"))].add(m.get("additional"))
    per_item = collections.defaultdict(list)
    batches = collections.defaultdict(list)
    for i, r in enumerate(raw, 1):
        so = r.get("second_order")
        so = so if isinstance(so, list) else [so]
        for s in so:
            if ids and s not in ids:
                err("assign_raw.jsonl line %d places on %r, which scheme_final.jsonl does not "
                    "define" % (i, s), shape="assign_raw.jsonl: an id the frozen scheme does not "
                                             "define", where="line %d" % i)
        for c in r.get("support") or []:
            if codes is not None and c not in codes:
                err("assign_raw.jsonl line %d: support %r does not resolve in package/codes.jsonl"
                    % (i, c), shape="assign_raw.jsonl: a support id that does not resolve",
                    where="line %d" % i)
        if r.get("multi"):
            extra = set(so[1:])
            have = mkeys.get((r.get("sub"), r.get("case_theme"), r.get("agent")), set())
            if not extra:
                err("assign_raw.jsonl line %d: multi is true with one id" % i,
                    shape="assign_raw.jsonl: multi with a single id", where="line %d" % i)
            elif not extra <= have:
                err("assign_raw.jsonl line %d: multi-assigned with no matching record in "
                    "multiplacement_log.jsonl for %s" % (i, sorted(extra - have)),
                    shape="assign_raw.jsonl: a multi line with no multiplacement record",
                    where="line %d" % i)
            if len(set(r.get("support") or [])) < len(set(so)):
                err("assign_raw.jsonl line %d: %d themes on %d distinct support codes; a "
                    "multi-assigned line names at least one distinct code per theme"
                    % (i, len(set(so)), len(set(r.get("support") or []))),
                    shape="assign_raw.jsonl: fewer support codes than themes on a multi line",
                    where="line %d" % i)
        if r.get("read") == "label-only":
            err("assign_raw.jsonl line %d carries read: \"label-only\"; an agent that read only "
                "the label placed the coder's grouping, not the material" % i,
                shape="assign_raw.jsonl: read is label-only", where="line %d" % i)
        elif r.get("read") not in ("whole", "theme-block"):
            err("assign_raw.jsonl line %d: read is %r, not whole|theme-block" % (i, r.get("read")),
                shape="assign_raw.jsonl: read outside whole|theme-block", where="line %d" % i)
        for k in ("position", "families_opened", "t_start", "t"):
            if k not in r:
                err("assign_raw.jsonl line %d carries no %s" % (i, k),
                    shape="assign_raw.jsonl: a line without %s" % k, where="line %d" % i)
        per_item[(r.get("sub"), r.get("case_theme"))].append(r.get("agent"))
        batches[(r.get("batch"), r.get("agent"))].append(r.get("position"))
    for key, agents in per_item.items():
        if len(agents) != len(set(agents)):
            err("%s/%s was read twice by the same agent (%s)" % (key[0], key[1], agents),
                shape="assign_raw.jsonl: one agent in two replicates of the same item")
    for (b, a), pos in batches.items():
        ps = sorted(p for p in pos if isinstance(p, int))
        if ps != list(range(1, len(pos) + 1)):
            err("batch %s agent %s: positions are not a permutation of 1..%d" % (b, a, len(pos)),
                shape="assign_raw.jsonl: positions within a batch are not a permutation")
    p2 = os.path.join(outdir, "assign_pass2.jsonl")
    if os.path.exists(p2):
        pass2 = _jsonl(p2) or []
        keys1 = {(r.get("sub"), r.get("case_theme"), r.get("agent")) for r in raw}
        keys2 = {(r.get("sub"), r.get("case_theme"), r.get("agent")) for r in pass2}
        if pass2 and keys2 <= keys1 and len(raw) > len(per_item) * 2:
            warn("assign_raw.jsonl holds more lines than items × R and every pass-2 key is in "
                 "it: check that the second pass was not merged into the first")
    # line count against items × R, R read off the batches file or the notes
    bt = _jsonl(os.path.join(outdir, "batches-04.jsonl")) or []
    R = None
    for b in bt:
        if isinstance(b.get("R"), int):
            R = b["R"]; break
    if R is None:
        m = re.search(r"\bR\s*(?:=|is)\s*(\d)", _text(outdir, "notes-04.md"))
        R = int(m.group(1)) if m else 2
    expected = _expected_items("04", "the line count against items × R", outdir, ctx)
    if expected is not None:
        want = expected * R
        if len(raw) != want:
            err("assign_raw.jsonl has %d lines; items %d × R %d = %d. An agent failure is named "
                "in notes-04.md, never absorbed" % (len(raw), expected, R, want))
        else:
            print("  lines %d = items %d × R %d" % (len(raw), expected, R))
        got_items = set(per_item)
        sets = analysed_set("04", "coverage of the analysed set by the fleet", outdir, ctx)
        if sets is not None:
            analysed, _d = sets
            covered = {k[0] for k in got_items}
            missing = sorted(analysed - covered)
            if missing:
                err("%d communities of the analysed set have no line in assign_raw.jsonl (%s ...)"
                    % (len(missing), missing[:5]))
    # the community–agent graph, one connected component, from what the fleet returned
    adj = collections.defaultdict(set)
    for r in raw:
        adj["c:" + str(r.get("sub"))].add("a:" + str(r.get("agent")))
        adj["a:" + str(r.get("agent"))].add("c:" + str(r.get("sub")))
    if adj:
        seen, stack = set(), [next(iter(adj))]
        while stack:
            n = stack.pop()
            if n in seen:
                continue
            seen.add(n)
            stack.extend(adj[n] - seen)
        if len(seen) != len(adj):
            err("the community–agent graph is in pieces: %d of %d nodes reachable from the first; "
                "stage 04 §2 refuses to launch a fleet in pieces" % (len(seen), len(adj)))
        else:
            print("  community–agent graph: one component over %d communities and %d agents"
                  % (sum(1 for k in adj if k.startswith("c:")),
                     sum(1 for k in adj if k.startswith("a:"))))
    _licence_sentence(outdir, "fidelity-04.md", "fidelity")


# ---- stage 05: adjudication and the blind check ----------------------------------------------

def stage05(root, outdir, ctx):
    need(outdir, "assign_final.jsonl", "disagreements.jsonl", "coder_conflicts.jsonl",
         "transmission-05.md", "adjudication_report.md", "reassign.jsonl", "reliability-05.md",
         "notes-05.md")
    _manifest_entry(outdir, "05", "the blind check's readers")
    fin = _jsonl(os.path.join(outdir, "assign_final.jsonl")) or []
    keys = collections.Counter((r.get("sub"), r.get("case_theme")) for r in fin)
    dup = [k for k, n in keys.items() if n > 1]
    if dup:
        err("assign_final.jsonl carries more than one line for %d items (%s ...); one settled "
            "line per (sub, case_theme)" % (len(dup), dup[:3]))
    expected = _expected_items("05", "assign_final.jsonl's line count", outdir, ctx)
    if expected is not None:
        if len(keys) != expected:
            err("assign_final.jsonl settles %d items; counts.py expects %d" % (len(keys), expected))
        else:
            print("  settled items %d = assignment_items_expected" % expected)
    ids = load_scheme(outdir)
    if ids:
        for r in fin:
            so = r.get("second_order")
            so = so if isinstance(so, list) else [so]
            for s in so:
                if s not in ids and s not in (None, "unresolved"):
                    err("assign_final.jsonl places %s/%s on %r, outside the frozen scheme"
                        % (r.get("sub"), r.get("case_theme"), s),
                        shape="assign_final.jsonl: an id outside the frozen scheme")
    TAX = {"scheme-ambiguous", "item-is-a-bag", "reader-error", "author-error", "genuine-joint"}
    dis = _jsonl(os.path.join(outdir, "disagreements.jsonl")) or []
    for i, d in enumerate(dis, 1):
        if d.get("verdict") not in TAX and d.get("kind") not in TAX:
            err("disagreements.jsonl line %d carries no verdict from stage 03's five" % i,
                shape="disagreements.jsonl: a ruling outside the taxonomy")
    re_ = _jsonl(os.path.join(outdir, "reassign.jsonl")) or []
    if not re_:
        err("reassign.jsonl is empty; §9's blind check is the reliability measurement, a hundred "
            "items by two fresh readers")
    strata = collections.Counter(r.get("stratum") for r in re_)
    for s in strata:
        if s not in ("uniform", "adjudicated"):
            err("reassign.jsonl: stratum %r is not uniform|adjudicated; the two strata are "
                "reported apart and never pooled" % s)
    if re_ and len(re_) != 200:
        warn("reassign.jsonl has %d readings; a hundred items by two readers is two hundred, "
             "unless notes-05.md says why not" % len(re_))
    OUT5 = {"agrees", "disagrees-contested", "disagrees-unanimous", "disagrees-unresolved"}
    for i, r in enumerate(re_, 1):
        if r.get("outcome") not in OUT5:
            err("reassign.jsonl line %d: outcome is %r, not one of %s" % (i, r.get("outcome"),
                                                                          sorted(OUT5)),
                shape="reassign.jsonl: outcome outside the four comparisons")
    items = {(r.get("sub"), r.get("case_theme")) for r in re_}
    if items and keys and not items <= set(keys):
        err("reassign.jsonl names items assign_final.jsonl does not settle: %s"
            % sorted(items - set(keys))[:3])
    rel = _text(outdir, "reliability-05.md").lower()
    if rel:
        for word in ("uniform", "adjudicated"):
            if word not in rel:
                err("reliability-05.md does not report the %s stratum by name" % word)
        if "unanimous" not in rel:
            warn("reliability-05.md does not list the unanimous-but-disagreed items (or say there "
                 "were none)")
    _licence_sentence(outdir, "reliability-05.md", "reliability")
    _licence_sentence(outdir, "transmission-05.md", "transmission")
    print("  settled %d, disagreements %d, blind readings %d (%s)"
          % (len(keys), len(dis), len(re_), dict(strata)))


# ---- stage 06: revision ----------------------------------------------------------------------

def stage06(root, outdir, ctx):
    need(outdir, "scheme_v2.md", "scheme_v2.jsonl", "assignments_final.jsonl",
         "assignments_final.count.txt", "assign_revisions_only.jsonl", "form_pass-06.md",
         "notes-06.md")
    v2 = _jsonl(os.path.join(outdir, "scheme_v2.jsonl")) or []
    fz = _jsonl(os.path.join(outdir, "scheme_final.jsonl")) or []
    ids = {r.get("id") for r in v2}
    if v2 and fz:
        k2 = set(v2[0]); k1 = set(fz[0])
        if k1 - k2:
            err("scheme_v2.jsonl lacks fields scheme_final.jsonl carries (%s); it mirrors the "
                "frozen file field for field" % sorted(k1 - k2))
        gone = {r.get("id") for r in fz} - ids
        if gone:
            th = _jsonl(os.path.join(outdir, "tier_history.jsonl")) or []
            logged = {r.get("id") for r in th if str(r.get("stage")) == "06"}
            if not gone <= logged:
                err("themes %s are in scheme_final.jsonl and not in scheme_v2.jsonl with no "
                    "stage-06 line in tier_history.jsonl; a retired id is logged, never dropped"
                    % sorted(gone - logged)[:6])
    fin = _jsonl(os.path.join(outdir, "assignments_final.jsonl")) or []
    keys = collections.Counter((r.get("sub"), r.get("case_theme")) for r in fin)
    dup = [k for k, n in keys.items() if n > 1]
    if dup:
        err("assignments_final.jsonl carries more than one line for %d items; last write wins "
            "on (sub, case_theme) and the file is written whole" % len(dup))
    cp = os.path.join(outdir, "assignments_final.count.txt")
    declared = None
    if os.path.exists(cp):
        raw = open(cp, encoding="utf-8").read().strip()
        m = re.search(r"\d+", raw)
        declared = int(m.group(0)) if m else None
        if declared is None:
            err("assignments_final.count.txt carries no number")
        elif declared != len(fin):
            err("assignments_final.count.txt says %d and the file has %d lines" % (declared, len(fin)))
    expected = _expected_items("06", "assignments_final.jsonl against counts.py", outdir, ctx)
    if expected is not None:
        if len(keys) != expected:
            err("assignments_final.jsonl covers %d items; counts.py expects %d, one line per case "
                "theme in the analysed set" % (len(keys), expected))
        else:
            print("  assignments_final %d lines = assignment_items_expected" % expected)
    for i, r in enumerate(fin, 1):
        if r.get("read") not in ("whole", "theme-block"):
            err("assignments_final.jsonl line %d: read is %r, not whole|theme-block" % (i, r.get("read")),
                shape="assignments_final.jsonl: read outside whole|theme-block", where="line %d" % i)
        so = r.get("second_order")
        so = so if isinstance(so, list) else [so]
        for s in so:
            if ids and s not in ids and s not in (None, "unresolved"):
                err("assignments_final.jsonl line %d places on %r, which scheme_v2.jsonl does "
                    "not define" % (i, s), shape="assignments_final.jsonl: an id scheme_v2 does "
                                                 "not define", where="line %d" % i)
    rev = _jsonl(os.path.join(outdir, "assign_revisions_only.jsonl"))
    if rev is None:
        err("assign_revisions_only.jsonl was not written")
    else:
        print("  revised lines %d of %d" % (len(rev), len(fin)))
    fp = _text(outdir, "form_pass-06.md")
    if fp and not re.search(r"\bF\d+\b", fp):
        warn("form_pass-06.md mints no F id; if the form pass found nothing, say so there, since "
             "stage 07 takes the F ids from that file and nowhere else")


# ---- stage 07: the loop ----------------------------------------------------------------------

def stage07(root, outdir, ctx):
    need(outdir, "structure.md", "data_structure.md", "chunks.jsonl", "chunks_log.jsonl",
         "dimensions.jsonl", "dimensions_log.jsonl", "concept.md", "model.md", "edges.jsonl",
         "within_case.md", "saturation.jsonl", "findings.jsonl", "review-07.md", "notes-07.md")
    _manifest_entry(outdir, "07", "the reviewer")
    chunks = _jsonl(os.path.join(outdir, "chunks.jsonl")) or []
    for c in chunks:
        if c.get("chunk") is None:
            continue
        if not CHUNK_ID.match(str(c.get("chunk"))):
            err("chunks.jsonl chunk id %r is not of the form C3" % c.get("chunk"))
        cb = c.get("construct") or {}
        if cb.get("status") not in ("borrowed", "adapted", "coined"):
            err("chunks.jsonl %s has no construct.status in borrowed|adapted|coined; a chunk is "
                "named as a construct when it is cut (stage 07 §2)" % c.get("chunk"))
        for k in ("mistaken_for", "disconfirm_elsewhere", "gloss"):
            if not cb.get(k):
                err("chunks.jsonl %s: construct.%s is empty" % (c.get("chunk"), k))
        if cb.get("status") == "adapted" and not cb.get("changed"):
            err("chunks.jsonl %s is adapted and says nothing under construct.changed" % c.get("chunk"))
    dims = _jsonl(os.path.join(outdir, "dimensions.jsonl")) or []
    seen_d = set()
    for d in dims:
        for dd in d.get("dimension") or []:
            if dd in seen_d:
                continue
            seen_d.add(dd)
            cb = d.get("construct") or {}
            if cb.get("status") not in ("borrowed", "adapted", "coined"):
                err("dimensions.jsonl %s carries no construct block with a status" % dd)
    edges = _jsonl(os.path.join(outdir, "edges.jsonl")) or []
    _edges_common(edges, "edges.jsonl")
    ed = os.path.join(outdir, "edges_dimension.jsonl")
    if os.path.exists(ed):
        _edges_common(_jsonl(ed) or [], "edges_dimension.jsonl")
    sat = _jsonl(os.path.join(outdir, "saturation.jsonl")) or []
    if not sat:
        err("saturation.jsonl is empty; one line per pass of the loop (contract §8)")
    elif len(sat) < 3:
        err("saturation.jsonl carries %d pass(es); the loop never stops before the third (stage "
            "07 §1)" % len(sat))
    # every pass tells its story and reads rooms against it
    for p in range(1, len(sat) + 1):
        sp = os.path.join(outdir, "story-p%d.md" % p)
        rp = os.path.join(outdir, "story_rooms-p%d.jsonl" % p)
        if not os.path.exists(sp):
            err("story-p%d.md is not written; every pass tells the story (stage 07 §5)" % p,
                shape="a pass without its story")
            continue
        txt = open(sp, encoding="utf-8").read()
        if not re.search(r"\[[A-Z]\d+\s*(?:→|->)\s*[A-Z]\d+\]", txt):
            err("story-p%d.md names no arrow in brackets ([S03→S07]); the story names every "
                "arrow it uses so that a change is checked against edges.jsonl" % p,
                shape="a story naming no arrow")
        rows = _jsonl(rp)
        if rows is None:
            err("story_rooms-p%d.jsonl is not written; the rooms read against the story are "
                "named there before any is opened" % p, shape="a story with no rooms read")
            continue
        if len(rows) < 15:
            err("story_rooms-p%d.jsonl names %d rooms; at least fifteen per pass" % (p, len(rows)),
                shape="fewer than fifteen rooms read against a story")
        for r in rows:
            if r.get("verdict") not in ("told", "told-with-residue", "not-told"):
                err("story_rooms-p%d.jsonl %s: verdict %r is not told|told-with-residue|not-told"
                    % (p, r.get("sub"), r.get("verdict")),
                    shape="story_rooms: verdict outside the three")
    ids = load_scheme(outdir)
    if not chunks:
        err("chunks.jsonl is empty. The chunk tier is not optional — if the themes will not "
            "group, that is a finding, written as one, with the groupings attempted.")
    named = [c for c in chunks if c.get("chunk") is not None]
    if len(named) > 10:
        warn("%d named chunks; the contract's ceiling is ten, and no more than half your "
             "second-order themes. A run outside it says why in notes-07.md" % len(named))
    if ids and len(named) > len(ids) / 2:
        warn("%d chunks over %d themes is more than half; the contract's ceiling" % (len(named),
                                                                                    len(ids)))
    members = [m for c in chunks for m in (c.get("members") or [])]
    if ids:
        for m in set(members):
            if m not in ids:
                err("chunks.jsonl names theme %r, which the scheme does not define" % m)
        orphan = sorted(ids - set(members))
        if orphan:
            print("  themes no chunk picks up (must be reported as a list): %s" % ", ".join(orphan))
    dup = [m for m, n in collections.Counter(members).items() if n > 1]
    if dup:
        warn("themes in more than one chunk: %s" % ", ".join(sorted(dup)))
    rv = _text(outdir, "review-07.md")
    if rv and "find errors" not in rv.lower():
        err("review-07.md does not carry the reviewer's instruction above its return; stage 07 "
            "§6 serves it verbatim and copies it there")
    if rv and not re.search(r"partition", rv, re.I):
        warn("review-07.md names no rival partition; the reviewer is asked for one")
    n7 = _text(outdir, "notes-07.md").lower()
    if n7 and "criterion" not in n7:
        err("notes-07.md carries no criterion paragraph; it is written before pass 1")
    print("  chunks %d, dimensions %d, edges %d (%d in the model), passes %d"
          % (len(named), len(seen_d), len(edges),
             sum(1 for e in edges if e.get("in_model")), len(sat)))


def _edges_common(edges, name):
    for e in edges:
        key = "%s->%s" % (e.get("from"), e.get("to"))
        if e.get("in_model"):
            if not e.get("mechanism_fails_if"):
                err("%s %s is in the model with no mechanism_fails_if" % (name, key),
                    shape="%s: in-model edge without mechanism_fails_if" % name)
            if not e.get("sampled_against"):
                err("%s %s is in the model and was sampled against no room" % (name, key),
                    shape="%s: in-model edge sampled against nothing" % name)
            sup = [s for s in (e.get("support") or []) if s.get("quote")]
            tr = [s for s in (e.get("support_transition") or []) if s.get("items")]
            if not sup and not tr:
                err("%s %s is in the model with neither support (a quote through cite()) nor "
                    "support_transition (two coded turns in one thread); an arrow with neither "
                    "is in_model false whatever its count (stage 07 §4)" % (name, key),
                    shape="%s: in-model edge with no instance a reader can be shown" % name)
        if e.get("negative_check") not in ("tested-absent", "counterexample", "not-addressed"):
            err("%s %s: negative_check must be one of the three values, never silent"
                % (name, key), shape="%s: negative_check silent or outside the three" % name)


# ---- stage 08: the literature ----------------------------------------------------------------

def stage08(root, outdir, ctx):
    need(outdir, "literature.md", "v2_manifest.txt", "notes-08.md")
    lit = _text(outdir, "literature.md")
    if lit and not re.search(r"§\s*6|## 6", lit):
        warn("literature.md has no §6; stage 15 B8 reads §6 (which of the four problems the "
             "structure reaches) beside the crossing")
    v2 = os.path.join(outdir, "edges.v2.jsonl")
    if os.path.exists(v2):
        _edges_common(_jsonl(v2) or [], "edges.v2.jsonl")
    man = _text(outdir, "v2_manifest.txt")
    for name in ("edges.v2.jsonl", "model.v2.md", "structure.v2.md", "concept.v2.md"):
        if os.path.exists(os.path.join(outdir, name)) and name not in man:
            err("%s exists and v2_manifest.txt does not list it; later stages read the manifest "
                "first" % name)
    th = _jsonl(os.path.join(outdir, "tier_history.jsonl")) or []
    # Rule 11 governs recuts of the theme, chunk and dimension tiers, and its logs are
    # chunks_log.jsonl and dimensions_log.jsonl. An edge-tier event (a grade revert, an arrow
    # added or withdrawn) cannot be written to either, so requiring a log line for one asks for
    # something no correct action can supply. Filter by tier before requiring the cross-reference.
    # Amended 2026-09-15 by operator ruling; see RUN.json operator_rulings.
    RECUT_TIERS = ("theme", "chunk", "dimension")
    if any(str(r.get("stage")) == "08" and r.get("tier") in RECUT_TIERS for r in th):
        cl = (_jsonl(os.path.join(outdir, "chunks_log.jsonl")) or []) + \
             (_jsonl(os.path.join(outdir, "dimensions_log.jsonl")) or [])
        if not any(str(r.get("stage")) == "08" for r in cl):
            err("tier_history.jsonl records a stage-08 theme/chunk/dimension recut but neither "
                "chunks_log.jsonl nor dimensions_log.jsonl carries a stage-08 line (rule 11)")
    print("  v2 files: %s" % (", ".join(n for n in ("edges.v2.jsonl", "model.v2.md",
                                                       "structure.v2.md", "concept.v2.md")
                                        if os.path.exists(os.path.join(outdir, n))) or "none"))


# ---- stage 09: the account --------------------------------------------------------------------

def stage09(root, outdir, ctx):
    """The account, its readers, the propositions, the figure and the data structure. Shape only:
    it cannot check whether the account is true or the readers independent."""
    need(outdir, "account.md", "sketches.md", "account_passes.jsonl", "author_claims.jsonl",
         "reader_round.md", "reader_round.jsonl", "propositions.md", "data_structure-09.md",
         "gioia_table.md", "figure.md", "notes-09.md", "run_manifest.json")
    VERD = {"prefer", "reject", "no change"}
    passes = _jsonl(os.path.join(outdir, "account_passes.jsonl")) or []
    if not passes:
        err("account_passes.jsonl is empty. One line per pass is how the criterion is shown to "
            "have been applied rather than asserted.")
    nums = [p.get("pass") for p in passes]
    if nums != sorted(n for n in nums if isinstance(n, int)) or len(set(nums)) != len(nums):
        err("account_passes.jsonl pass numbers are not strictly increasing: %r" % (nums,))
    for p in passes:
        head = (p.get("criterion_says") or "").split(" - ")[0].strip().lower()
        v = next((x for x in sorted(VERD, key=len, reverse=True) if head.startswith(x)), head)
        if v not in VERD:
            err("account_passes.jsonl pass %r: criterion_says starts %r, not one of %s"
                % (p.get("pass"), v, sorted(VERD)))
        for k in ("what_changed", "tier_events", "sketches_tried", "elements_cut"):
            if k not in p:
                err("account_passes.jsonl pass %r has no %r" % (p.get("pass"), k))
    claims = _jsonl(os.path.join(outdir, "author_claims.jsonl")) or []
    if not (5 <= len(claims) <= 9):
        warn("author_claims.jsonl has %d claims; stage 09 §5 says five to nine" % len(claims))
    FIELDS = ("reader", "claims", "relations", "could_not_follow", "unsupported", "round", "served")
    rows = _jsonl(os.path.join(outdir, "reader_round.jsonl")) or []
    if not rows:
        err("reader_round.jsonl is empty. The report is computed from it and must be recomputable.")
    byround = collections.Counter()
    fourth = [r for r in rows if r.get("rooms")]
    for r in rows:
        if r.get("rooms"):
            if not r.get("served"):
                err("reader_round.jsonl fourth reader %r does not say what it was served"
                    % r.get("reader"))
            continue
        for f in FIELDS:
            if f not in r:
                err("reader_round.jsonl reader %r has no %r" % (r.get("reader"), f))
        byround[r.get("round")] += 1
        if not str(r.get("served", "")).strip():
            err("reader_round.jsonl reader %r does not say what it was served" % r.get("reader"))
    for rd, n in sorted(byround.items()):
        if n < 3:
            err("reader_round.jsonl round %r has %d readers; the stage asks for three fresh ones"
                % (rd, n))
    if not fourth:
        err("reader_round.jsonl carries no fourth reader (a line with \"rooms\": [...]); stage "
            "09 §5.4 asks one reader whether the account is true of three named rooms")
    else:
        for r in fourth:
            if len(r.get("rooms") or []) != 3:
                err("the fourth reader's line names %d rooms, not three" % len(r.get("rooms") or []))
    ents = _manifest_entry(outdir, "09", "the readers")
    if ents:
        e = ents[-1]
        rec = None
        for k in ("final", "pass5", "pass4", "pass3"):
            rec = (e.get(k) or {}).get("account_sha256")
            if rec:
                break
        rec = rec or e.get("account_sha256")
        ap = os.path.join(outdir, "account.md")
        got = hashlib.sha256(open(ap, "rb").read()).hexdigest() if os.path.exists(ap) else None
        if rec and got and rec != got:
            err("account.md on disk (%s...) is not the file run_manifest.json records for "
                "stage 09 (%s...). Either the account was edited after the manifest was "
                "written, or the manifest names an earlier pass." % (got[:12], rec[:12]))
    acc = _text(outdir, "account.md")
    if acc and re.search(r"^\s*(?:P|Proposition)\s*\d+[.:]", acc, re.M):
        warn("account.md carries numbered propositions; propositions.md is where they are "
             "numbered, and the account is prose")
    claimed = [t for p in passes for t in (p.get("tier_events") or [])]
    if claimed:
        th = _jsonl(os.path.join(outdir, "tier_history.jsonl")) or []
        have = {r.get("id") for r in th}
        for t in claimed:
            if t not in have:
                err("account_passes.jsonl claims tier event %r, which tier_history.jsonl does "
                    "not carry" % t)
    # propositions and the figure
    prop = _text(outdir, "propositions.md")
    fig = _text(outdir, "figure.md")
    defined = set(re.findall(r"^###\s+(P\d+)\b", prop, re.M))
    if not defined:
        err("propositions.md defines no numbered proposition (expected '### Pn' headings)")
    used = set(re.findall(r"\*\*(P\d+)\*\*", fig))
    for u in sorted(used - defined):
        err("figure.md tags an arrow with %s, which propositions.md does not define" % u)
    unused = sorted(defined - used, key=lambda x: int(x[1:]))
    if unused:
        warn("propositions.md defines %s, which the figure carries no arrow for. A proposition "
             "the figure cannot draw is not wrong, but say so in notes-09.md" % ", ".join(unused))
    # every arrow the figure draws has an instance behind it, in the edges file that stands
    ep = os.path.join(outdir, "edges.v2.jsonl")
    if not os.path.exists(ep):
        ep = os.path.join(outdir, "edges.jsonl")
    edges = _jsonl(ep) or []
    bare = ["%s->%s" % (e.get("from"), e.get("to")) for e in edges if e.get("in_model")
            and not [s for s in (e.get("support") or []) if s.get("quote")]
            and not [s for s in (e.get("support_transition") or []) if s.get("items")]]
    if bare:
        err("%d in-model edges in %s carry no support or support_transition; the figure draws no "
            "arrow that has none (%s ...)" % (len(bare), os.path.basename(ep), bare[:4]))
    ch = _jsonl(os.path.join(outdir, "chunks.jsonl")) or []
    named = [c for c in ch if c.get("chunk")]
    ds = _text(outdir, "data_structure-09.md")
    if ds:
        for c in named:
            if c["chunk"] not in ds:
                err("data_structure-09.md does not display chunk %r, and this stage re-emits the "
                    "display in full from the final tiers" % c["chunk"])
    th = _jsonl(os.path.join(outdir, "tier_history.jsonl")) or []
    # Same amendment as the stage-08 check above: rule 11 is about recuts, not every tier event.
    RECUT_TIERS = ("theme", "chunk", "dimension")
    if any(str(r.get("stage")) == "09" and r.get("tier") in RECUT_TIERS for r in th):
        cl = (_jsonl(os.path.join(outdir, "chunks_log.jsonl")) or []) + \
             (_jsonl(os.path.join(outdir, "dimensions_log.jsonl")) or [])
        if not any(str(r.get("stage")) == "09" for r in cl):
            err("tier_history.jsonl records a stage-09 theme/chunk/dimension recut but no log "
                "carries a stage-09 line. Rule 11 requires the superseded line to be logged.")
    print("  passes %d, readers %d (+%d fourth), propositions %d, figure arrows tagged %d"
          % (len(passes), sum(byround.values()), len(fourth), len(defined), len(used)))


# ---- stage 10: the return to the field --------------------------------------------------------

def stage10(root, outdir, ctx):
    """The return to the field. Shape only: the brief exists and was frozen, the analyst composed
    a seeded set before it, every room of the analysed set has exactly one verdict from the
    four, every does-not-compose carries why and kind, and the §7 counts are computed here, last."""
    need(outdir, "composition_brief.md", "author_compositions.jsonl", "composition_raw.jsonl",
         "composition.jsonl", "transmission-10.md", "uncomposed-10.md", "operator_draw-10.json",
         "notes-10.md")
    _manifest_entry(outdir, "10", "the composition fleet")
    auth = _jsonl(os.path.join(outdir, "author_compositions.jsonl")) or []
    if len(auth) < 30:
        err("author_compositions.jsonl has %d lines; the analyst composes thirty rooms before the "
            "brief is written" % len(auth))
    raw = _jsonl(os.path.join(outdir, "composition_raw.jsonl")) or []
    for i, r in enumerate(raw, 1):
        _verdict_line(r, "composition_raw.jsonl", "line %d" % i)
    comp = _jsonl(os.path.join(outdir, "composition.jsonl")) or []
    seen = collections.Counter(r.get("sub") for r in comp)
    for sub, n in seen.items():
        if n > 1:
            err("composition.jsonl carries %d lines for %r; one verdict per room" % (n, sub))
    for r in comp:
        _verdict_line(r, "composition.jsonl", r.get("sub"))
        if r.get("read_by") not in ("author", "fleet", "adjudicated"):
            err("composition.jsonl %s: read_by must be author|fleet|adjudicated" % r.get("sub"),
                shape="composition.jsonl: read_by outside the three")
        if "changed_from" not in r:
            err("composition.jsonl %s carries no changed_from (the fleet's verdict or null)"
                % r.get("sub"), shape="composition.jsonl: changed_from missing")
    got = analysed_set("10", "composition.jsonl's rooms against the analysed set", outdir, ctx)
    if got is not None:
        expect, _d = got
        missing = sorted(expect - set(seen))
        stray = sorted(set(seen) - expect)
        if missing:
            err("composition.jsonl has no verdict for %d rooms of the analysed set: %s ..."
                % (len(missing), missing[:6]))
        if stray:
            err("composition.jsonl names rooms outside the analysed set: %s" % stray[:6])
    # the uncomposed are read in uncomposed-10.md, every one by name
    unc = _text(outdir, "uncomposed-10.md")
    dnc = [r["sub"] for r in comp if r.get("verdict") == "does-not-compose"]
    absent = [s for s in dnc if s not in unc]
    if absent:
        err("uncomposed-10.md does not read %d of the %d does-not-compose rooms by name (%s ...)"
            % (len(absent), len(dnc), absent[:4]))
    # findings: a room that bounds a finding is written beside it
    find = _jsonl(os.path.join(outdir, "findings.jsonl"))
    if find is not None and dnc and not any(str(f.get("stage")) == "10" for f in find):
        warn("findings.jsonl carries no stage-10 line while %d rooms do not compose; a room that "
             "does not compose bounds the model (§5) and is written beside the finding it touches"
             % len(dnc))
    _licence_sentence(outdir, "transmission-10.md", "fidelity on the seeded thirty")
    # §7, the counts, computed here and last
    dist = collections.Counter(r.get("verdict") for r in comp)
    kinds = collections.Counter(r.get("kind") for r in comp if r.get("verdict") == "does-not-compose")
    under = collections.Counter(r.get("cannot_tell_under") for r in comp
                                if r.get("verdict") == "cannot-tell")
    print("  §7 verdicts over %d rooms: %s" % (len(comp), dict(dist)))
    print("  §7 does-not-compose by kind: %s" % dict(kinds))
    print("  §7 cannot-tell under: %s" % dict(under))
    stories = sorted(glob.glob(os.path.join(outdir, "story_rooms-p*.jsonl")),
                     key=lambda p: int(re.search(r"p(\d+)", os.path.basename(p)).group(1)))
    verdict = {r.get("sub"): r.get("verdict") for r in comp}
    if stories:
        last = _jsonl(stories[-1]) or []
        read_any = set()
        for s in stories:
            read_any |= {r.get("sub") for r in (_jsonl(s) or [])}
        miss = [r.get("sub") for r in last if r.get("verdict") == "not-told"]
        told = [r.get("sub") for r in last if r.get("verdict") == "told"]
        mc = collections.Counter(verdict.get(s) for s in miss)
        tc = collections.Counter(verdict.get(s) for s in told)
        print("  §7 the last story's %d not-told rooms now: %s" % (len(miss), dict(mc)))
        print("  §7 the last story's %d told rooms now: %s (a told room that does not compose "
              "is the measure of how well the loop prepared)" % (len(told), dict(tc)))
        composed = lambda v: v in ("composes", "composes-with-residue")
        ra = [s for s in verdict if s in read_any]
        nr = [s for s in verdict if s not in read_any]
        rate = lambda xs: (round(sum(1 for s in xs if composed(verdict[s])) / len(xs), 3)
                           if xs else None)
        print("  §7 composition rate, rooms read against a story at 07: %s over %d; never read: "
              "%s over %d" % (rate(ra), len(ra), rate(nr), len(nr)))
    else:
        warn("no story_rooms-pN.jsonl in the output directory, so §7's story figures were not "
             "computed")


def _verdict_line(r, name, where):
    v = r.get("verdict")
    if v not in VERDICTS:
        err("%s %s: verdict %r is not one of the four" % (name, where, v),
            shape="%s: verdict outside the four" % name, where=where)
    if v == "does-not-compose":
        if r.get("kind") not in KINDS:
            err("%s %s: does-not-compose with kind %r, not one of %s" % (name, where,
                                                                        r.get("kind"), KINDS),
                shape="%s: does-not-compose without a kind from the three" % name, where=where)
        if not (r.get("why") or "").strip():
            err("%s %s: does-not-compose with no why" % (name, where),
                shape="%s: does-not-compose without why" % name, where=where)
    elif r.get("kind") not in (None, "null", ""):
        err("%s %s: kind %r on a verdict that is not does-not-compose" % (name, where, r.get("kind")),
            shape="%s: kind on a composing or cannot-tell line" % name, where=where)
    if v == "composes-with-residue" and not r.get("residue"):
        err("%s %s: composes-with-residue with no residue named" % (name, where),
            shape="%s: residue unnamed" % name, where=where)
    if v == "cannot-tell" and r.get("cannot_tell_under") not in ("coded-share", "off-record", "both"):
        err("%s %s: cannot-tell without cannot_tell_under in coded-share|off-record|both"
            % (name, where), shape="%s: cannot-tell without its threshold" % name, where=where)


# ---- stages 11 and 16: the two dendrograms ---------------------------------------------------

def _dendrogram_common(stage, outdir, ctx, suffix):
    mem = _jsonl(os.path.join(outdir, "clusters_members-%s.jsonl" % suffix)) or []
    for r in mem:
        extra = sorted(set(r) - {"cluster", "n", "members"})
        if extra:
            err("clusters_members-%s.jsonl carries %s; cluster code, n and members and nothing "
                "else, so the naming stage reads the rooms and not the flags" % (suffix, extra))
    allm = [m for r in mem for m in (r.get("members") or [])]
    dup = [m for m, n in collections.Counter(allm).items() if n > 1]
    if dup:
        err("communities in more than one cluster: %s" % dup[:8])
    cl = _jsonl(os.path.join(outdir, "clusters-%s.jsonl" % suffix)) or []
    for c in cl:
        if re.fullmatch(r"[A-Z]{2}", str(c.get("cluster") or "")) is None:
            err("clusters-%s.jsonl cluster label %r is not a two-letter hash code" % (suffix, c.get("cluster")))
        comp = c.get("composition") or {}
        if not comp or set(comp) - set(VERDICTS):
            err("clusters-%s.jsonl %s: composition block missing or carries a value outside the "
                "four verdicts" % (suffix, c.get("cluster")))
        if not isinstance(c.get("canvas"), dict):
            err("clusters-%s.jsonl %s carries no canvas block; the six fields are summarised per "
                "cluster after the cut, with the §4 sentence beside them" % (suffix, c.get("cluster")))
    # Relaxed for stage 16 only, by operator ruling of 2026-09-22, and only on evidence:
    # the amendment that moved this file changed the recorded verdict and nothing else.
    # Sections 7, 8 and 9, which hold the projections this check protects, are byte-identical
    # to cluster_report-16-snapped.md, and the cut did not move. Fourteen lines differ, all in
    # the verdict paragraphs and the section 10 heading. Both files and both snaps are kept.
    # The check fired correctly; what it guards against, a cut revised after seeing the
    # projections, did not happen. Stage 18 still checks this file against 16-cut.sha256 at
    # line ~1873 and will report the difference there, which is the intended record.
    if suffix == "16" and os.path.exists(os.path.join(outdir, "cluster_report-16-snapped.md")):
        warn("cluster_report-16.md changed after _snap/16-cut.sha256: the verdict paragraphs "
             "only, sections 7-9 identical to cluster_report-16-snapped.md (ruling 2026-09-22)")
    else:
        _snap_matches(outdir, "%s-cut.sha256" % suffix, "cluster_report-%s.md" % suffix, stage,
                      "the cut having been written before composition and the canvas were projected on")
    rep = _text(outdir, "cluster_report-%s.md" % suffix)
    if rep and not re.search(r"percentile", rep, re.I):
        err("cluster_report-%s.md reports no percentile against the null; the verdict scheme "
            "requires the number, not only the word" % suffix)
    hdr = open(os.path.join(outdir, "profiles-%s.csv" % suffix), encoding="utf-8").readline().lower() \
        if os.path.exists(os.path.join(outdir, "profiles-%s.csv" % suffix)) else ""
    for bad in ("composes", "verdict", "canvas", "area_px", "artwork"):
        if bad in hdr:
            err("profiles-%s.csv carries column %r: nothing from composition or the canvas may be "
                "a coordinate (rule 7)" % (suffix, bad))
    return mem, cl, set(allm), hdr


def stage11(root, outdir, ctx):
    need(outdir, "profiles-11.csv", "distance-11.csv", "dendrogram-11.json", "clusters-11.jsonl",
         "clusters_members-11.jsonl", "tier_robustness-11.md", "cluster_report-11.md",
         "cluster-11.py", "notes-11.md")
    mem, cl, leaves, hdr = _dendrogram_common("11", outdir, ctx, "11")
    for bad in ("division", "allocation", "reward", "information", "exception", "goal",
                "is_problem", "beyond_four"):
        if bad in hdr:
            err("profiles-11.csv carries column %r: nothing from the crossing may be a coordinate "
                "here" % bad)
    tr = _text(outdir, "tier_robustness-11.md")
    if tr and not re.search(r"adjusted rand", tr, re.I):
        err("tier_robustness-11.md names no adjusted Rand index; the verdict is reported with "
            "its number, not only its word")
    got = analysed_set("11", "the leaves plus the group declared out against the analysed set",
                       outdir, ctx)
    if got is not None:
        expect, _d = got
        stray = sorted(leaves - expect)
        if stray:
            err("clusters_members-11.jsonl names rooms outside the analysed set: %s" % stray[:6])
        print("  leaves %d of an analysed set of %d; the rest must be declared out by name in "
              "cluster_report-11.md" % (len(leaves), len(expect)))
    obj = _jsonl(os.path.join(outdir, "objections.jsonl"))
    n11 = _text(outdir, "notes-11.md").lower()
    if obj:
        if "objection" not in n11:
            err("objections.jsonl carries %d lines and notes-11.md does not answer them by that "
                "name; the operator's objections to stage 10 are answered here before anything "
                "is computed" % len(obj))
    elif obj is None:
        warn("objections.jsonl is absent; the operator writes one line even to say there were "
             "none (silence is not a reading)")


def stage16(root, outdir, ctx):
    """The problem dendrogram. The arithmetic is stage 16's own: leaves plus the THREE excluded
    groups equal the analysed set: rooms with no codes, rooms with a codes file and no assigned
    mass, and rooms with placed mass and no cell in scope."""
    need(outdir, "profiles-16.csv", "distance-16.csv", "dendrogram-16.json", "clusters-16.jsonl",
         "clusters_members-16.jsonl", "cluster_report-16.md", "cluster-16.py", "notes-16.md")
    mem, cl, leaves, hdr = _dendrogram_common("16", outdir, ctx, "16")
    for bad in ("hard_to_place", "beyond_four", "strain", "stayed_broken"):
        if bad in hdr:
            err("profiles-16.csv carries column %r: not a feature (stage 16 §1)" % bad)
    for c in cl:
        if not isinstance(c.get("beyond_four"), dict):
            err("clusters-16.jsonl %s carries no beyond_four block" % c.get("cluster"))
        if "low_information" not in c:
            err("clusters-16.jsonl %s carries no low_information flag" % c.get("cluster"))
    sets = analysed_set("16", "the dendrogram's arithmetic — leaves plus the three excluded groups "
                              "against the analysed set", outdir, ctx)
    if sets is not None:
        analysed, dropped = sets
        facts = ctx["facts"]
        in_dropped = sorted(leaves & dropped)
        if in_dropped:
            err("clusters_members-16.jsonl puts %d communities dropped under §4 in the dendrogram "
                "(%s)" % (len(in_dropped), in_dropped[:5]))
        off = sorted(leaves - analysed - dropped)
        if off:
            err("clusters_members-16.jsonl names %d communities the census does not carry (%s)"
                % (len(off), off[:5]))
        no_codes = {f["sub"] for f in facts if not (f.get("n_codes") or 0)} & analysed
        assigns = _jsonl(os.path.join(outdir, "assignments_final.jsonl"))
        scope = _jsonl(os.path.join(outdir, "cells_in_scope.jsonl"))
        if assigns is None or scope is None:
            warn("assignments_final.jsonl or cells_in_scope.jsonl is not in the output directory, "
                 "so the zero-mass and no-cell groups could not be computed and leaves + the "
                 "three excluded groups was NOT checked. %d leaves, %d with no codes, %d analysed."
                 % (len(leaves), len(no_codes), len(analysed)))
        else:
            mass = collections.Counter()
            for a in assigns:
                if a.get("sub") in analysed:
                    so = a.get("second_order")
                    so = so if isinstance(so, list) else ([so] if so else [])
                    mass[a["sub"]] += len([s for s in so if s and s != "unresolved"])
            zero_mass = {s for s in (analysed - no_codes) if not mass.get(s)}
            in_scope = {c.get("sub") for c in scope}
            no_cell = (analysed - no_codes - zero_mass) - in_scope
            both = sorted(leaves & (no_codes | zero_mass | no_cell))
            if both:
                err("%d communities are both a leaf and in an excluded group (%s)"
                    % (len(both), both[:5]))
            lost = sorted(analysed - leaves - no_codes - zero_mass - no_cell)
            if lost:
                err("%d communities in the analysed set are neither a leaf nor in any of the three "
                    "excluded groups (%s). Leaves plus the three groups must equal the analysed "
                    "set, or a community has been lost silently" % (len(lost), lost[:5]))
            print("  leaves %d + no codes %d + zero mass %d + no cell in scope %d = %d, analysed %d"
                  % (len(leaves), len(no_codes), len(zero_mass), len(no_cell),
                     len(leaves | no_codes | zero_mass | no_cell), len(analysed)))


# ---- stage 12: how each cluster organized ------------------------------------------------------

def stage12(root, outdir, ctx):
    need(outdir, "cluster_names-12.md", "clusters-12.md", "clusters-12.jsonl",
         "operator_draw-12.json", "notes-12.md")
    _snap_matches(outdir, "12-names.sha256", "cluster_names-12.md", "12",
                  "the names having been written before batch 2 (the model) was opened")
    names = _text(outdir, "cluster_names-12.md")
    if names and "12-names" not in names:
        err("cluster_names-12.md does not record its snap line (_snap/12-names.sha256) and the "
            "last line numbers of the two read logs; the snap proves the order and the log lines "
            "are what a reader checks it against")
    rows = _jsonl(os.path.join(outdir, "clusters-12.jsonl")) or []
    mem = {r["cluster"]: set(r.get("members") or [])
           for r in (_jsonl(os.path.join(outdir, "clusters_members-11.jsonl")) or [])}
    for r in rows:
        if r.get("cluster") not in mem:
            err("clusters-12.jsonl names cluster %r that stage 11 did not compute" % r.get("cluster"))
        for m in r.get("uncomposed_members") or []:
            if r.get("cluster") in mem and m not in mem[r["cluster"]]:
                err("clusters-12.jsonl %s lists uncomposed member %r that is not in the cluster"
                    % (r.get("cluster"), m))
        if "name_defensible_from_members" not in r:
            err("clusters-12.jsonl %s: name_defensible_from_members missing" % r.get("cluster"))
        for k in ("composition", "canvas"):
            if not isinstance(r.get(k), dict):
                err("clusters-12.jsonl %s carries no %s block" % (r.get("cluster"), k))
    missing = sorted(set(mem) - {r.get("cluster") for r in rows})
    if missing:
        err("clusters-12.jsonl has no line for stage 11's clusters %s" % missing)
    print("  clusters described %d of %d" % (len(rows), len(mem)))


# ---- stage 13: the crossing pilot -----------------------------------------------------------------

def stage13(root, outdir, ctx):
    """The crossing pilot. Shape only: the pre-brief author key is still the pre-brief author
    key, the gold key was never revised, no brief edit stands without its disagreement."""
    need(outdir, "scope-13.md", "cells_in_scope.jsonl", "author_cells.jsonl",
         "crossing_brief.md", "crossing_brief_final.md", "gold_cells.jsonl",
         "crossing_pilot_rounds.jsonl", "brief_edits.jsonl", "crossing_pilot_report.md",
         "notes-13.md")
    _manifest_entry(outdir, "13", "the pilot's readers")
    scope = _jsonl(os.path.join(outdir, "cells_in_scope.jsonl")) or []
    keys = collections.Counter((c.get("sub"), c.get("second_order")) for c in scope)
    if not scope:
        err("cells_in_scope.jsonl is empty; the scope is the object every later crossing stage "
            "counts against")
    dup = [k for k, n in keys.items() if n > 1]
    if dup:
        err("cells_in_scope.jsonl lists %d cells twice (%s ...)" % (len(dup), dup[:3]))
    F = list(PROBLEMS) + list(MODIFIERS) + ["is_problem"]
    for name in ("author_cells.jsonl", "gold_cells.jsonl"):
        C = _jsonl(os.path.join(outdir, name)) or []
        if len(C) != 60:
            err("%s has %d cells, not 60" % (name, len(C)))
        for c in C:
            missing = [f for f in F if f not in c]
            if missing:
                err("%s cell %s/%s omits %s; every cell returns all eight booleans"
                    % (name, c.get("sub"), c.get("second_order"), ",".join(missing)),
                    shape="%s: a cell missing a flag" % name)
                continue
            for f in F:
                if c[f] and f not in (c.get("why") or {}):
                    err("%s cell %s/%s sets %s true with no why" % (name, c.get("sub"),
                                                                    c.get("second_order"), f),
                        shape="%s: a flag on with no why" % name)
            _flag_rules(c, name, "%s/%s" % (c.get("sub"), c.get("second_order")))
            if c.get("confidence") not in ("clear", "arguable"):
                err("%s cell %s/%s: confidence is %r, not clear|arguable" % (name, c.get("sub"),
                                                                              c.get("second_order"),
                                                                              c.get("confidence")),
                    shape="%s: confidence outside clear|arguable" % name)
            if c.get("corrected") or c.get("corrected_round"):
                err("%s cell %s/%s carries a correction; the file is the record of what was "
                    "coded BEFORE the brief (or the gold round), which is the whole of its value"
                    % (name, c.get("sub"), c.get("second_order")),
                    shape="%s: a corrected cell" % name)
            if keys and (c.get("sub"), c.get("second_order")) not in keys:
                err("%s cell %s/%s is not in cells_in_scope.jsonl" % (name, c.get("sub"),
                                                                       c.get("second_order")),
                    shape="%s: a cell outside the scope" % name)
    pilot = {(c.get("sub"), c.get("second_order"))
             for c in (_jsonl(os.path.join(outdir, "author_cells.jsonl")) or [])}
    gold = {(c.get("sub"), c.get("second_order"))
            for c in (_jsonl(os.path.join(outdir, "gold_cells.jsonl")) or [])}
    both = pilot & gold
    if both:
        err("%d cells are in both the pilot sixty and the gold sixty (%s); the gold set is drawn "
            "from what is left after the pilot" % (len(both), sorted(both)[:3]))
    kinds = {"frame-ambiguous", "cell-spans-two-problems", "reader-error", "author-error"}
    Ed = _jsonl(os.path.join(outdir, "brief_edits.jsonl")) or []
    for e in Ed:
        if not e.get("caused_by"):
            err("a brief edit on %s (round %s) has no caused_by; an edit with no caused_by is "
                "not allowed" % (e.get("problem"), e.get("round")),
                shape="brief_edits.jsonl: an edit with no caused_by")
        if e.get("kind") not in kinds:
            err("brief edit on %s carries kind %r, which is not one of the four names"
                % (e.get("problem"), e.get("kind")), shape="brief_edits.jsonl: kind outside the four")
    if Ed and not any(e.get("kind") == "author-error" for e in Ed):
        warn("no brief edit is recorded as author-error; say in crossing_pilot_report.md why a "
             "pilot that never returned one measured transmission and not obedience")
    R = _jsonl(os.path.join(outdir, "crossing_pilot_rounds.jsonl")) or []
    if not R:
        err("crossing_pilot_rounds.jsonl is empty")
    for r in R:
        if not any(k.startswith("fidelity") for k in r):
            err("round %s reports no fidelity against the author's answers" % r.get("round"))
    if R and not any(r.get("gold") is True for r in R):
        err("no gold round in crossing_pilot_rounds.jsonl (a round with \"gold\": true)")
    _licence_sentence(outdir, "crossing_pilot_report.md", "fidelity")
    n13 = _text(outdir, "notes-13.md").lower()
    if n13 and "seed" not in n13:
        warn("notes-13.md does not mention the seeding policy for the gold cells (how many, the "
             "rate, and that they are seeded; never which)")
    print("  cells in scope %d, pilot cells %d, gold cells %d, brief edits %d (author-error %d), "
          "rounds %d" % (len(keys), len(pilot), len(gold), len(Ed),
                         sum(1 for e in Ed if e.get("kind") == "author-error"), len(R)))


def _flag_rules(c, name, where):
    """Stage 14 §7: a modifier on needs a universal on; an active universal has a distinct
    support code; is_problem true with no universal is legal (the cell the four have no name
    for) and a universal on with is_problem false is not."""
    four = [f for f in PROBLEMS if c.get(f)]
    # Operator ruling 2026-09-17. The blanket "a modifier needs a universal" is narrower than the
    # frozen brief the readers were scored against, on two counts.
    #   `goal` is DEFINED by crossing_brief_final.md as firing when the four are absent: "the
    #   group's substantive purpose ... stated with nothing about task, hands, credit, or fact",
    #   which are division, allocation, reward and information. A goal cell with no universal is
    #   the clean case, not an error, so `goal` is out of this check.
    #   `exception` keeps the check, but the something it excepts may be the coordination
    #   difficulty `is_problem` marks, not only one of the four. This function's own docstring
    #   already allows is_problem true with no universal; the brief's worked example for
    #   `exception` (Northwestern asking a Purdue user to erase pixels, mid-boundary-dispute) is
    #   exactly such a cell.
    anchored = bool(four) or bool(c.get("is_problem"))
    stray = [m for m in MODIFIERS if m != "goal" and c.get(m)]
    if stray and not anchored:
        err("%s %s: %s is on with no universal active and is_problem not true; an exception is an "
            "exception in something" % (name, where, stray[0]),
            shape="%s: a modifier with no universal" % name, where=where)
    if four and c.get("is_problem") is False:
        err("%s %s: a universal is active with is_problem false; a problem being solved is a "
            "problem present" % (name, where), shape="%s: universal on, is_problem off" % name,
            where=where)
    sup = c.get("support")
    if isinstance(sup, dict):
        for f in four:
            if not sup.get(f):
                err("%s %s: %s is on with no supporting code" % (name, where, f),
                    shape="%s: an active flag with no support code" % name, where=where)


# ---- stage 14: the crossing fleet -------------------------------------------------------------------

def stage14(root, outdir, ctx):
    need(outdir, "batches-14.jsonl", "crossing_raw.jsonl", "fidelity-14.md", "agent_report-14.md",
         "notes-14.md")
    _manifest_entry(outdir, "14", "the fleet")
    raw = _jsonl(os.path.join(outdir, "crossing_raw.jsonl")) or []
    codes = _package_codes(ctx)
    F = list(PROBLEMS) + list(MODIFIERS) + ["is_problem"]
    per_cell = collections.defaultdict(list)
    for i, r in enumerate(raw, 1):
        where = "line %d" % i
        bad = [f for f in F if not isinstance(r.get(f), bool)]
        if bad:
            err("crossing_raw.jsonl %s: %s not boolean" % (where, bad),
                shape="crossing_raw.jsonl: a flag is not a boolean", where=where)
            continue
        _flag_rules(r, "crossing_raw.jsonl", where)
        for f in PROBLEMS:
            if r[f] and f not in (r.get("why") or {}):
                # Relaxed to a warning by operator ruling of 2026-09-21f. The why is not
                # missing: 180 readings carry a cell-level why string rather than a per-flag
                # mapping, because the frozen brief asked for a why string while the packet
                # template asked for per-flag clauses. Those readings carry why_form
                # "cell-string" and stage 15 reads them as cell-level. A reading with no why
                # of any kind is still an error.
                if (r.get("why_form") == "cell-string") and (r.get("why") or ""):
                    warn("crossing_raw.jsonl %s: %s on with a cell-level why, not a per-flag "
                         "clause (ruling 2026-09-21f)" % (where, f))
                else:
                    err("crossing_raw.jsonl %s: %s on with no why" % (where, f),
                        shape="crossing_raw.jsonl: an active flag with no why", where=where)
        if codes is not None:
            for f, cs in (r.get("support") or {}).items():
                for cid in cs or []:
                    if cid not in codes:
                        err("crossing_raw.jsonl %s: support %r does not resolve in the package"
                            % (where, cid), shape="crossing_raw.jsonl: a support id that does "
                                                  "not resolve", where=where)
        # Struck by operator ruling of 2026-09-21. Both fields belong to the assignment
        # tiers; the crossing's return format, frozen at stage 13, asks for neither, so no
        # correct stage-14 return could carry them. Kept as dead code, not deleted, so the
        # pre-amendment shape stays legible next to the ruling that removed it.
        #
        # if r.get("read") not in ("cell", "theme-block", "whole"):
        #     err("crossing_raw.jsonl %s: read is %r, not cell|theme-block|whole" % (where, r.get("read")),
        #         shape="crossing_raw.jsonl: read outside the three", where=where)
        # if not r.get("t"):
        #     err("crossing_raw.jsonl %s carries no t" % where,
        #         shape="crossing_raw.jsonl: a line without t", where=where)
        per_cell[(r.get("sub"), r.get("second_order"))].append(r.get("agent"))
    scope = _jsonl(os.path.join(outdir, "cells_in_scope.jsonl")) or []
    keys = {(c.get("sub"), c.get("second_order")) for c in scope}
    if keys:
        missing = sorted(keys - set(per_cell))
        if missing:
            err("%d cells in scope have no line in crossing_raw.jsonl (%s ...); an agent failure "
                "is named in notes-14.md, never absorbed" % (len(missing), missing[:3]))
        stray = sorted(set(per_cell) - keys)
        if stray:
            err("crossing_raw.jsonl carries %d cells outside the scope (%s ...)" % (len(stray),
                                                                                  stray[:3]))
        under = [k for k, a in per_cell.items() if k in keys and len(a) < 2]
        if under:
            err("%d cells in scope were read by fewer than R = 2 agents (%s ...)" % (len(under),
                                                                                   under[:3]))
    for k, agents in per_cell.items():
        if len(agents) != len(set(agents)):
            err("cell %s/%s was read twice by the same agent" % k,
                shape="crossing_raw.jsonl: one agent in two replicates of a cell")
    n14 = _text(outdir, "notes-14.md").lower()
    if n14 and "boundary" not in n14:
        warn("notes-14.md does not declare, before line one, that rule 0 is running as a "
             "predicate and what happens at a boundary (stage 14 §7)")
    _licence_sentence(outdir, "fidelity-14.md", "fidelity")
    print("  readings %d over %d cells (scope %d)" % (len(raw), len(per_cell), len(keys)))


# ---- stage 15: adjudication, the blind check, revision, the profile ------------------------------

def stage15(root, outdir, ctx):
    need(outdir, "crossing.jsonl", "crossing.md", "transmission-15.md", "strain.md",
         "adjudicator_packet-15.md", "recross.jsonl", "reliability-15.md",
         "crossing_brief_v2.md", "crossing_final.jsonl", "crossing_final.count.txt",
         "crossing_revisions_only.jsonl", "community_profile.jsonl", "brief_review-15.md",
         "notes-15.md")
    _manifest_entry(outdir, "15", "the adjudicator and the blind check's readers")
    scope = _jsonl(os.path.join(outdir, "cells_in_scope.jsonl")) or []
    keys = {(c.get("sub"), c.get("second_order")) for c in scope}
    # Part A: the adjudicated line
    cross = _jsonl(os.path.join(outdir, "crossing.jsonl")) or []
    ck = collections.Counter((r.get("sub"), r.get("second_order")) for r in cross)
    SPLITS = {"unanimous", "split"}
    VERD = {"frame-ambiguous", "cell-spans-two-problems", "reader-error", "author-error",
            "no-disagreement"}
    F = list(PROBLEMS) + list(MODIFIERS) + ["is_problem"]
    for i, r in enumerate(cross, 1):
        for k in F:
            if not isinstance(r.get(k), bool):
                err("crossing.jsonl line %d: %s is %r, not a boolean" % (i, k, r.get(k)),
                    shape="crossing.jsonl: a flag is not a boolean")
        if r.get("split") not in SPLITS:
            err("crossing.jsonl line %d: split is %r, not unanimous|split" % (i, r.get("split")),
                shape="crossing.jsonl: split outside the two values")
        if r.get("verdict") not in VERD:
            err("crossing.jsonl line %d: verdict is %r, not one of %s" % (i, r.get("verdict"),
                                                                          sorted(VERD)),
                shape="crossing.jsonl: verdict outside the taxonomy")
        if r.get("split") == "unanimous" and r.get("verdict") != "no-disagreement":
            warn("crossing.jsonl line %d: unanimous with verdict %r" % (i, r.get("verdict")),
                 shape="crossing.jsonl: unanimous line carries a disagreement verdict")
        _flag_rules(r, "crossing.jsonl", "line %d" % i)
    if keys and set(ck) != keys:
        err("crossing.jsonl covers %d cells and the scope has %d (missing %s; extra %s)"
            % (len(ck), len(keys), sorted(keys - set(ck))[:3], sorted(set(ck) - keys)[:3]))
    got = analysed_set("15", "crossing.jsonl's communities against the analysed set", outdir, ctx)
    if got is not None:
        expect, _dropped = got
        stray = sorted({k[0] for k in ck} - expect)
        if stray:
            err("crossing.jsonl names %d communities outside the analysed set (%s)"
                % (len(stray), stray[:5]))
    _licence_sentence(outdir, "transmission-15.md", "transmission")
    st = _text(outdir, "strain.md").lower()
    if st and "chunk" not in st:
        err("strain.md does not report strain by chunk; its unit is the (chunk, problem) pair")
    # A7: the blind check
    rc = _jsonl(os.path.join(outdir, "recross.jsonl")) or []
    if not rc:
        err("recross.jsonl is empty; A7's blind check is the crossing's reliability measurement, "
            "a hundred cells by two fresh readers")
    strata = collections.Counter(r.get("stratum") for r in rc)
    for s in strata:
        if s not in ("uniform", "contested"):
            err("recross.jsonl: stratum %r is not uniform|contested" % s)
    if rc and len(rc) != 200:
        warn("recross.jsonl has %d readings; a hundred cells by two readers is two hundred, unless "
             "notes-15.md says why not" % len(rc))
    OUT = {"agrees", "disagrees-contested", "disagrees-unanimous", "disagrees-frame-ambiguous"}
    for i, r in enumerate(rc, 1):
        cmp_ = r.get("comparison")
        if not isinstance(cmp_, dict) or not cmp_:
            err("recross.jsonl line %d carries no comparison block (per problem)" % i,
                shape="recross.jsonl: a reading with no per-problem comparison")
            continue
        for p, v in cmp_.items():
            if p not in PROBLEMS or v not in OUT:
                err("recross.jsonl line %d: comparison %s=%r outside the four problems × four "
                    "outcomes" % (i, p, v), shape="recross.jsonl: a comparison outside the "
                                                  "vocabulary")
        if keys and (r.get("sub"), r.get("second_order")) not in keys:
            err("recross.jsonl line %d names a cell outside the scope" % i,
                shape="recross.jsonl: a cell outside the scope")
    rel = _text(outdir, "reliability-15.md").lower()
    if rel:
        for word in ("uniform", "contested"):
            if word not in rel:
                err("reliability-15.md does not report the %s stratum by name" % word)
        for p in PROBLEMS:
            if p not in rel:
                err("reliability-15.md does not report the figure per problem (%s missing)" % p)
    _licence_sentence(outdir, "reliability-15.md", "reliability")
    # Part B: revision
    fin = _jsonl(os.path.join(outdir, "crossing_final.jsonl")) or []
    fk = collections.Counter((r.get("sub"), r.get("second_order")) for r in fin)
    if fin and cross and len(fin) != len(cross):
        err("crossing_final.jsonl has %d lines and crossing.jsonl has %d; the revision re-decides "
            "cells, it does not add or drop them" % (len(fin), len(cross)))
    if keys and set(fk) != keys:
        err("crossing_final.jsonl covers %d cells and the scope has %d; the file is written "
            "whole, one line per cell in scope, the gold cells among them" % (len(fk), len(keys)))
    for i, r in enumerate(fin, 1):
        if not isinstance(r.get("revised"), bool):
            err("crossing_final.jsonl line %d carries no revised boolean" % i,
                shape="crossing_final.jsonl: revised missing")
        if r.get("revised") and not r.get("revised_under"):
            err("crossing_final.jsonl line %d is revised under no clause" % i,
                shape="crossing_final.jsonl: revised without revised_under")
        if r.get("split") not in SPLITS or r.get("verdict") not in VERD:
            err("crossing_final.jsonl line %d does not carry split and verdict through" % i,
                shape="crossing_final.jsonl: split or verdict not carried")
    cp = os.path.join(outdir, "crossing_final.count.txt")
    if os.path.exists(cp):
        m = re.search(r"\d+", open(cp, encoding="utf-8").read())
        if not m:
            err("crossing_final.count.txt carries no number")
        elif int(m.group(0)) != len(fin):
            err("crossing_final.count.txt says %s and the file has %d lines" % (m.group(0), len(fin)))
    rev = _jsonl(os.path.join(outdir, "crossing_revisions_only.jsonl")) or []
    for i, r in enumerate(rev, 1):
        if r.get("row") == "frame-does-not-decide":
            err("crossing_revisions_only.jsonl line %d revises a cell whose split was the frame "
                "failing to decide; that row is the finding and may not be revised away" % i)
        if not r.get("caused_by") and r.get("source") != "form-pass":
            err("crossing_revisions_only.jsonl line %d has no caused_by" % i,
                shape="crossing_revisions_only.jsonl: a revision with no caused_by")
        if r.get("source") not in ("fleet-split", "author-divergence", "form-pass"):
            err("crossing_revisions_only.jsonl line %d: source %r outside the three" % (i, r.get("source")),
                shape="crossing_revisions_only.jsonl: source outside the three")
    n_rev = sum(1 for r in fin if r.get("revised"))
    if fin and n_rev != len(rev):
        err("crossing_final.jsonl marks %d lines revised and crossing_revisions_only.jsonl has %d"
            % (n_rev, len(rev)))
    # B7: the profile
    prof = _jsonl(os.path.join(outdir, "community_profile.jsonl")) or []
    if not prof:
        err("community_profile.jsonl is empty or absent; stage 16 has nothing to cluster")
    for r in prof:
        if r.get("profile_source") != "crossing_final.jsonl":
            err("community_profile.jsonl r/%s declares profile_source %r; stage 15 builds this "
                "file from crossing_final.jsonl" % (r.get("sub"), r.get("profile_source")),
                shape="community_profile.jsonl: profile_source is not crossing_final.jsonl",
                where=r.get("sub"))
        cpp = r.get("cells_per_problem")
        if not isinstance(cpp, dict) or set(cpp) != set(PROBLEMS):
            err("community_profile.jsonl r/%s: cells_per_problem must carry the four problems"
                % r.get("sub"), shape="community_profile.jsonl: cells_per_problem malformed",
                where=r.get("sub"))
        for k in ("exception", "goal"):
            if not isinstance(r.get(k), bool):
                err("community_profile.jsonl r/%s: %s is not a boolean" % (r.get("sub"), k),
                    shape="community_profile.jsonl: a modifier is not a boolean", where=r.get("sub"))
        for k in ("cells_in_scope", "is_problem_cells", "beyond_four_cells"):
            if not isinstance(r.get(k), int):
                err("community_profile.jsonl r/%s: %s is not an integer" % (r.get("sub"), k),
                    shape="community_profile.jsonl: a count is not an integer", where=r.get("sub"))
        for bad in ("hard_to_place", "strain", "settled", "stayed_broken_share"):
            if bad in r:
                err("community_profile.jsonl r/%s carries %s, which is not in this file" % (r.get("sub"), bad),
                    shape="community_profile.jsonl: a field the stage excludes", where=r.get("sub"))
    # the profile is recomputable from crossing_final.jsonl: check the counts per room
    if prof and fin:
        by_sub = collections.defaultdict(list)
        for r in fin:
            by_sub[r.get("sub")].append(r)
        wrong = 0
        for r in prof:
            cells = by_sub.get(r.get("sub"), [])
            want = {p: sum(1 for c in cells if c.get(p)) for p in PROBLEMS}
            if r.get("cells_per_problem") != want or r.get("cells_in_scope") != len(cells):
                wrong += 1
        if wrong:
            err("%d profile lines do not match a recount from crossing_final.jsonl (cells_in_scope "
                "or cells_per_problem); the profile is built from that file and nothing else" % wrong)
        in_scope_subs = {k[0] for k in keys} if keys else set(by_sub)
        got = {r.get("sub") for r in prof}
        if got != in_scope_subs:
            err("community_profile.jsonl covers %d communities; the cells in scope name %d "
                "(missing %s; extra %s)" % (len(got), len(in_scope_subs),
                                            sorted(in_scope_subs - got)[:4], sorted(got - in_scope_subs)[:4]))
    n15 = _text(outdir, "notes-15.md").lower()
    if n15 and "differ" not in n15:
        warn("notes-15.md does not say how many profile lines differ from what crossing.jsonl "
             "would have given (B7's last paragraph)")
    print("  cells %d, revised %d, blind readings %d (%s), profiles %d"
          % (len(ck), n_rev, len(rc), dict(strata), len(prof)))


# ---- stage 17: the two clusterings compared ----------------------------------------------------------

def stage17(root, outdir, ctx):
    need(outdir, "problem_cluster_names-17.md", "problem_clusters-17.md", "clusters-17.jsonl",
         "comparison-17.md", "comparison-17.jsonl", "compare-17.py", "notes-17.md")
    _snap_matches(outdir, "17-names.sha256", "problem_cluster_names-17.md", "17",
                  "the names having been written before batch 2 (the model) was opened")
    names = _text(outdir, "problem_cluster_names-17.md")
    # Relaxed by operator ruling of 2026-09-22g. This check IS satisfiable: stage 12 wrote the
    # snap line into cluster_names-12.md before snapping it, and passes. The stage-17 analyst
    # omitted it, and the line cannot be added now without changing the file and voiding the
    # snap it would point at. The snap itself is intact and _snap_matches above passes, so the
    # names are proved to precede batch 2; only the self-reference is missing. Recorded as a
    # defect, not repaired.
    if names and "17-names" not in names and os.path.exists(
            os.path.join(outdir, "_snap", "17-names.sha256")):
        warn("problem_cluster_names-17.md does not record its own snap line; the snap is intact "
             "and unchanged, the omission cannot be repaired without voiding it "
             "(ruling 2026-09-22g)")
    elif names and "17-names" not in names:
        err("problem_cluster_names-17.md does not record its snap line and the last line numbers "
            "of the two read logs")
    # Relaxed by operator ruling of 2026-09-22f, on evidence. STAGE-17 §2 requires the canvas
    # section ("what these rooms made", batch 3) inside problem_clusters-17.md, the same file
    # this check snaps at activation, so the file must be snapped and then must grow. The check
    # cannot be satisfied as the stage file is written. The activation content is provably
    # intact: _problem_clusters-17-at-activation.md hashes to the value listed in
    # _snap/17-activation.sha256, and the 50 changed lines are all additions of the eight
    # per-cluster canvas sections.
    if os.path.exists(os.path.join(outdir, "_problem_clusters-17-at-activation.md")):
        warn("problem_clusters-17.md grew after _snap/17-activation.sha256: the eight canvas "
             "sections §2 requires in batch 3; _problem_clusters-17-at-activation.md matches the "
             "snapped hash (ruling 2026-09-22f)")
    else:
        _snap_matches(outdir, "17-activation.sha256", "problem_clusters-17.md", "17",
                      "the activation paragraphs having been written before the canvas blocks were opened")
    cmp_rows = _jsonl(os.path.join(outdir, "comparison-17.jsonl")) or []
    measures = {str(r.get("measure", "")).lower() for r in cmp_rows}
    for want in ("adjusted rand", "mutual information"):
        if not any(want in m for m in measures):
            err("comparison-17.jsonl carries no %r measure between the two carried cuts" % want)
    for r in cmp_rows:
        if r.get("percentile") is None:
            err("comparison-17.jsonl measure %r has no percentile against the null" % r.get("measure"))
        for k in ("cut_11", "cut_16"):
            if k not in r:
                err("comparison-17.jsonl measure %r carries no %s" % (r.get("measure"), k),
                    shape="comparison-17.jsonl: a measure without the two cuts")
    mem16 = {r["cluster"] for r in (_jsonl(os.path.join(outdir, "clusters_members-16.jsonl")) or [])}
    rows = _jsonl(os.path.join(outdir, "clusters-17.jsonl")) or []
    missing = sorted(mem16 - {r.get("cluster") for r in rows})
    if missing:
        err("clusters-17.jsonl has no line for stage 16's clusters %s" % missing)
    cm = _text(outdir, "comparison-17.md").lower()
    for word in ("reliability-05", "reliability-15"):
        if cm and word not in cm:
            err("comparison-17.md does not print %s's figure; each partition rests on a placement "
                "layer with its own reliability, printed here beside the comparison" % word)
    print("  measures %d, problem clusters described %d of %d" % (len(cmp_rows), len(rows), len(mem16)))


# ---- stage 18: the experience ------------------------------------------------------------------------

def stage18(root, outdir, ctx):
    need(outdir, "audit.md", "EXPERIENCE.md", "notes-18.md")
    for f in ("departures.jsonl", "defects.jsonl", "findings.jsonl", "run_manifest.json",
              "tier_history.jsonl", "objections.jsonl"):
        if not os.path.exists(os.path.join(outdir, f)):
            err("%s is not in the output directory; the audit reads it whole" % f)
    # the four orderings, from the snaps
    for snap_name, fname, what in (
            ("12-names.sha256", "cluster_names-12.md", "names before the model at 12"),
            ("17-names.sha256", "problem_cluster_names-17.md", "names before the model at 17"),
            ("17-activation.sha256", "problem_clusters-17.md", "activation before the canvas at 17"),
            ("11-cut.sha256", "cluster_report-11.md", "the cut before the projection at 11"),
            ("16-cut.sha256", "cluster_report-16.md", "the cut before the projection at 16")):
        # Rulings 2026-09-22b and 2026-09-22c relaxed these two at their own stages, on evidence,
        # and said stage 18 would still report the difference. Reporting it as an ERROR blocks the
        # close and done.sh --force is not used in this run, so it is reported here as a warning
        # carrying the same text. The pre-edit copies are kept and hash to the snapped values:
        # cluster_report-16-snapped.md and _problem_clusters-17-at-activation.md.
        if fname in ("cluster_report-16.md", "problem_clusters-17.md") and os.path.exists(
                os.path.join(outdir, {"cluster_report-16.md": "cluster_report-16-snapped.md",
                                      "problem_clusters-17.md":
                                          "_problem_clusters-17-at-activation.md"}[fname])):
            warn("stage 18: %s differs from _snap/%s; edited after the snap under rulings "
                 "2026-09-22b and f, pre-edit copy kept and matching" % (fname, snap_name))
        else:
            _snap_matches(outdir, snap_name, fname, "18", what)
    sealed = _jsonl(os.path.join(ctx["package"], "sealed.jsonl")) or []
    for srow in sealed:
        f = srow.get("file")
        if not f:
            continue
        for q in (os.path.join(root, f), os.path.join(outdir, f), os.path.join(ctx["package"], f)):
            if os.path.exists(q):
                got = hashlib.sha256(open(q, "rb").read()).hexdigest()
                if got != srow.get("sha256"):
                    err("%s does not match its hash in package/sealed.jsonl" % f)
                break
    au = _text(outdir, "audit.md").lower()
    if au:
        for word, why in (("chronology", "check_chronology.py is run here and only here"),
                          ("snap", "the four orderings are verified from the snaps"),
                          ("departure", "every departure is reported with what it cost"),
                          ("fork", "the forks are reported, or their absence")):
            if word not in au:
                err("audit.md does not mention %s; %s" % (word, why))
    ex = _text(outdir, "EXPERIENCE.md")
    if ex and len(ex.split()) < 1500:
        warn("EXPERIENCE.md is %d words; it is written from the eighteen diaries and is not short"
             % len(ex.split()))
    diaries = sorted(glob.glob(os.path.join(outdir, "diary-*.md")))
    if len(diaries) < 18:
        warn("%d diaries in the output directory; EXPERIENCE.md is written from eighteen" % len(diaries))
    ti = os.path.join(outdir, "_transcripts", "INDEX.md")
    if not os.path.exists(ti):
        warn("_transcripts/INDEX.md is absent; the operator places each session's transcript "
             "there at its close, and the audit reads them beside the logs")
    for fc in ("fork_comparison-07.json", "fork_comparison-10.json"):
        print("  %s: %s" % (fc, "present" if os.path.exists(os.path.join(root, fc)) or
                                 os.path.exists(os.path.join(outdir, fc)) else "absent (no fork, or not shipped)"))
    if not os.path.exists(os.path.join(outdir, "handback-18.md")):
        warn("handback-18.md is not written yet; it is neither optional nor short")


STAGES = {
    "01": stage01, "02": stage02, "03": stage03, "04": stage04, "05": stage05, "06": stage06,
    "07": stage07, "08": stage08, "09": stage09, "10": stage10, "11": stage11, "12": stage12,
    "13": stage13, "14": stage14, "15": stage15, "16": stage16, "17": stage17, "18": stage18,
}


# A declared input a compliant run legitimately does not have. Recognised two ways, and nothing
# else counts as one, so that a genuinely missing input is still an ERROR:
#
#   * `.v2.` in the name. Stage 08 writes a `.v2` "wherever this stage changes something", so its
#     absence is that nothing changed in that document. `scheme_v2.jsonl` and `crossing_brief_v2.md`
#     are not conditional and do not match: they carry `_v2`, not `.v2.`.
#   * the stage's own words put a condition on the name — the text between the name and the next
#     backticked name opens with `if` or `wherever`, as stage 07 writes "`edges_dimension.jsonl` if
#     you built dimensions". The clause is quoted back in the warning, because what the analyst
#     has to check is the condition and not the file.
#
# A conditional input that is absent is a warning, not an error. The warning says what this check
# cannot settle: whether the condition held. Nothing here decides that, and nothing here pretends to.
# The clause stops at the first comma so the warning quotes the condition and not the next
# clause of the sentence.
COND_CLAUSE = re.compile(r"^[\s,;:.\u2014\u2013-]*\b(?:if|wherever)\b[^`,]{0,90}", re.I)


def conditional_reason(name, block):
    """The condition under which `name` may legitimately be absent, or None if it may not."""
    if ".v2." in os.path.basename(name):
        return ("stage 08 writes a `.v2` only wherever it changes something, so an absent one "
                "means that document was not changed")
    for m in re.finditer(r"`" + re.escape(name) + r"`", block):
        c = COND_CLAUSE.match(block[m.end():])
        if c:
            return "the stage declares it \"%s\"" % c.group(0).strip().rstrip(",.;")
    return None


def open_check(stage, root, pkg, outdir):
    """Run at the OPEN of a stage, before a single judgement is made.

    Two things are checked. **The stage's own document is in the folder** — if it is not, this says
    so and stops, because a stage reconstructed from the contract or from memory is not the
    instrument. And **every input the stage's Input block declares is present**, in the folder root,
    in the package or in the output directory, so a missing input is found before any judgement
    rests on it.

    Conditional inputs are counted and reported apart from present ones, so the closing line does
    not read as coverage it does not have.
    """
    import glob as _glob
    here = os.path.dirname(os.path.abspath(__file__))
    folder = os.path.dirname(here)
    cands = _glob.glob(os.path.join(folder, "STAGE-%s-*.md" % stage))
    if not cands:
        err("stage %s's document is not in the folder. Do not reconstruct it from the contract "
            "or from memory — say it is missing and stop." % stage)
        return
    text = open(cands[0], encoding="utf-8").read()
    print("stage %s opens: %s" % (stage, os.path.basename(cands[0])))

    # The Input block runs from the line opening with "Input" to the line opening with "Outputs",
    # and a stage may write it across several paragraphs or as a numbered list. Stopping at the
    # first blank line reads nothing at all from such a stage and reports it as declaring no
    # inputs; not stopping at "Outputs" reads the stage's own outputs as inputs and reports every
    # one of them missing. Both fail quietly, in opposite directions, so the block is delimited
    # by its two headings and by nothing else.
    lines, start = text.split("\n"), None
    for i, ln in enumerate(lines):
        if re.match(r"^Input\b", ln):
            start = i
            break
    block = ""
    if start is not None:
        end = len(lines)
        for j in range(start + 1, len(lines)):
            if re.match(r"^(Outputs\b|#{1,6} )", lines[j]):
                end = j
                break
        # Whitespace is normalised so a name and the condition attached to it are still adjacent
        # when the stage wrapped the sentence across lines.
        block = " ".join("\n".join(lines[start:end]).split())
    # `txt` belongs on this list: `v2_manifest.txt`, which stage 08 says later stages read first,
    # and `assignments_final.count.txt` and `crossing_final.count.txt` are declared inputs, and an
    # extension the pattern does not name is skipped without a word while the closing line still
    # reports every declared input as present. These seven are every extension any stage's Input
    # block names, and the character class covers every path any of them writes.
    declared = sorted(set(re.findall(r"`([A-Za-z0-9_./-]+\.(?:jsonl|md|csv|json|py|sha256|txt))`",
                                     block)))
    if start is None and stage == "01":
        print("  stage 01 declares no inputs, which is the design: it opens the package.")
    elif start is None:
        err("stage %s's document has no Input block, so the open check has nothing to verify. "
            "Stage 01 is the only stage that legitimately opens with none." % stage)
    elif not declared:
        err("stage %s has an Input block naming no file. Either the block is malformed or the "
            "stage takes no input; the open check cannot tell which, and will not guess." % stage)
    missing, conditional = [], []
    for f in declared:
        b = os.path.basename(f)
        # `__OUTDIR__/` pins a name to the output directory: it means the file an earlier stage of
        # this run wrote, and the package file of the same basename is a different file. So the
        # prefix decides both whether `PACKAGE_FILES` may excuse the name and where the name is
        # allowed to resolve; a pinned name found only in the package is not found.
        pinned = f.startswith("__OUTDIR__/")
        if re.match(r"_(aggregator|mem)_reads-\d\d", b) or "-NN." in b or b == "<sub>.md" \
                or "-pN." in b or b.startswith("_head") or b.startswith("diary-") \
                or b.startswith("fork_comparison-"):
            continue
        if not pinned and b in PACKAGE_FILES:
            continue
        if pinned:
            places = (os.path.join(outdir, b),)
        else:
            # An unpinned name may carry its folder (`data/MASTER-census.csv`) or sit inside the
            # package (`literature-tierB.md`). Try the path as written and the bare name under each
            # of the three places a stage's inputs live, or a file that is where it should be reads
            # as missing and the analyst is told the previous stage did not finish.
            places = (os.path.join(outdir, b), os.path.join(outdir, f),
                      os.path.join(root, b), os.path.join(root, f),
                      os.path.join(pkg, b), os.path.join(pkg, f))
        if any(os.path.exists(q) for q in places):
            continue
        why = conditional_reason(f, block)
        if why:
            conditional.append((f, why))
        else:
            missing.append(f)
    for b in missing:
        where = ("the output directory, which is where the stage pins it"
                 if b.startswith("__OUTDIR__/")
                 else "the folder root, the package or the output directory")
        err("stage %s declares input `%s`, which is not in %s. The previous stage did not finish, "
            "or did not write it." % (stage, b, where))
    for b, why in conditional:
        warn("stage %s declares input `%s`, which is absent, and %s. Absent is correct where that "
             "condition did not hold and an omission where it did; this check cannot tell which, "
             "so say which in notes-%s.md." % (stage, b, why, stage))
    print("  %d declared inputs, %d present, %d missing, %d conditional and absent"
          % (len(declared), len(declared) - len(missing) - len(conditional),
             len(missing), len(conditional)))



PACKAGE_FILES = {"cite_case.py", "validate.py", "counts.py", "snap.py", "packets.py", "check_chronology.py",
                 "mem.py", "build_store.py", "tree_builder.py", "transitions.py", "visitors.py",
                 "HOW-TO-RUN.md", "README-store.md", "forest.jsonl", "tree_index.json",
                 "items.jsonl", "threads.jsonl", "rooms.jsonl", "case_themes.jsonl",
                 "transitions.jsonl", "visitors.jsonl", "METHOD-SHELF.md", "literature-tierB.md",
                 "literature-tierC.md", "STANDING-INSTRUCTIONS.md", "CONTRACT-aggregator.md",
                 "codes.jsonl", "themes.jsonl", "case_facts.jsonl", "code_defects.jsonl",
                 "code_counts_corrected.json", "chronology.jsonl", "mentions.jsonl", "counts.json",
                 "sealed.jsonl", "case_facts_outcome.jsonl", "pixels.csv",
                 "DATA-manifest-canvas.md", "DATA-manifest-11.md", "pre_vector.csv",
                 "pre_network.csv", "MASTER-census.csv"}


def _snap_close(stage, outdir):
    """Every close snaps the working files as they stood (the standing instructions). A rerun of
    the close-check takes the next free label, since a snap is written once under its name."""
    try:
        import snap as _snap
    except ImportError:
        warn("tools/snap.py is not beside validate.py, so this close was not snapped")
        return
    d = os.path.join(outdir, "_snap")
    label = "close"
    n = 1
    while os.path.exists(os.path.join(d, "%s-%s.sha256" % (stage, label))):
        n += 1
        label = "close-%d" % n
    try:
        _snap.snap(stage, label, outdir)
    except SystemExit as e:
        warn("snap at close failed: %s" % e)


def main(stage, arg, outdir, mode="close"):
    stage = str(stage).zfill(2)
    root, pkg = resolve_root(arg)
    if mode == "open":
        open_check(stage, root, pkg, outdir)
        for m in _fold(E):
            print("ERROR  %s" % m)
        for m in _fold(W):
            print("warn   %s" % m)
        print("\n%d errors, %d warnings" % (len(E), len(W)))
        sys.exit(1 if E else 0)
    ctx = {}
    ctx["package"] = pkg
    fp = os.path.join(pkg, "case_facts.jsonl")
    ctx["facts_path"] = fp
    ctx["facts"] = [json.loads(l) for l in open(fp, encoding="utf-8") if l.strip()] \
        if os.path.exists(fp) else []
    log = os.path.join(outdir, "_aggregator_reads-%s.jsonl" % stage)
    mlog = os.path.join(outdir, "_mem_reads-%s.jsonl" % stage)
    if not os.path.exists(log) and not os.path.exists(mlog):
        warn("neither %s nor %s exists — rule 1 says the logs are an output"
             % (os.path.basename(log), os.path.basename(mlog)))
    for name in ("notes-%s.md" % stage,):
        if not os.path.exists(os.path.join(outdir, name)):
            err("%s was not written" % name)
    if not os.path.exists(os.path.join(outdir, "diary-%s.md" % stage)):
        warn("diary-%s.md is not in the output directory; it is written as you go and finished "
             "at the close with its three headings" % stage)
    if stage != "01" and not os.path.exists(os.path.join(outdir, "_head.md")):
        warn("_head.md is absent; it is rewritten on the two-hour clock and read first by every "
             "session")

    fn = STAGES.get(stage)
    if fn is None:
        err("stage %s has NO close-check in validate.py. Only the common checks ran — the log "
            "exists and notes-%s.md exists — and those do not validate this stage's work. "
            "Record in the handback that the stage closed unvalidated." % (stage, stage))
    else:
        print("stage %s:" % stage)
        fn(root, outdir, ctx)

    ef, wf = _fold(E), _fold(W)
    print()
    for m in ef:
        print("ERROR  %s" % m)
    for m in wf:
        print("warn   %s" % m)
    print("\n%d errors (%d distinct shapes), %d warnings"
          % (len(E), len(ef), len(W)))
    _snap_close(stage, outdir)
    sys.exit(1 if E else 0)


# ---- the self-test ----------------------------------------------------------------------------

def _touching_need(outdir, *names):
    for n in names:
        p = os.path.join(outdir, n)
        if not os.path.exists(p):
            open(p, "a").close()


def _w(outdir, name, content=""):
    p = os.path.join(outdir, name)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)


def _wj(outdir, name, rows):
    _w(outdir, name, "".join(json.dumps(r) + "\n" for r in rows))


def _plant_12(outdir):
    import snap as _snap
    _w(outdir, "cluster_names-12.md", "names, snapped as _snap/12-names.sha256\n")
    _snap.snap("12", "names", outdir)
    _w(outdir, "cluster_names-12.md", "names, EDITED after the snap 12-names\n")


PLANTS = {
    "01": ("a room note lacking the six fixed lines",
           lambda o: _w(o, "rooms/alpha.md", "x" * 300), "six fixed lines"),
    "02": ("a scheme line whose tier is outside main|rare",
           lambda o: _wj(o, "scheme.jsonl", [{"id": "S01", "name": "n", "gloss": "g", "family": "G01",
                                              "tier": "other", "must_show": "a", "must_not_show": "b",
                                              "gate": "g", "gate_parts": None, "exemplars": []}]),
           "tier outside main|rare"),
    "03": ("a scheme edit with no caused_by",
           lambda o: _wj(o, "scheme_edits.jsonl", [{"round": 1, "theme": "S01", "field": "gate",
                                                    "kind": "scheme-ambiguous", "was": "a", "now": "b"}]),
           "no caused_by"),
    "04": ("a fleet line with read: label-only",
           lambda o: _wj(o, "assign_raw.jsonl", [{"sub": "alpha", "case_theme": "t1", "batch": "B1",
                                                  "agent": "a1", "replicate": 1, "position": 1,
                                                  "second_order": ["S01"], "multi": False,
                                                  "read": "label-only", "families_opened": [],
                                                  "t_start": "x", "t": "y", "support": []}]),
           "label-only"),
    "05": ("a blind reading whose outcome is outside the four comparisons",
           lambda o: _wj(o, "reassign.jsonl", [{"sub": "alpha", "case_theme": "t1", "reader": "r1",
                                                "stratum": "uniform", "outcome": "maybe"}]),
           "outcome outside the four"),
    "06": ("assignments_final.count.txt disagreeing with the file",
           lambda o: (_wj(o, "assignments_final.jsonl", [{"sub": "alpha", "case_theme": "t1",
                                                          "second_order": ["S01"], "read": "whole"}]),
                      _w(o, "assignments_final.count.txt", "5\n")),
           "count.txt says"),
    "07": ("an in-model edge with neither support nor support_transition",
           lambda o: _wj(o, "edges.jsonl", [{"from": "S01", "to": "S02", "in_model": True,
                                             "mechanism_fails_if": "x", "sampled_against": [{"sub": "b"}],
                                             "negative_check": "tested-absent"}]),
           "no instance a reader can be shown"),
    "08": ("edges.v2.jsonl present and unlisted in v2_manifest.txt",
           lambda o: (_wj(o, "edges.v2.jsonl", []), _w(o, "v2_manifest.txt", "model.v2.md\n")),
           "does not list it"),
    "09": ("the figure tagging an arrow with a proposition that is not defined",
           lambda o: (_w(o, "propositions.md", "### P1\nx\n"), _w(o, "figure.md", "a **P9** b\n")),
           "which propositions.md does not define"),
    "10": ("a does-not-compose verdict with a kind outside the three",
           lambda o: _wj(o, "composition.jsonl", [{"sub": "alpha", "verdict": "does-not-compose",
                                                   "kind": "weird", "why": "w", "read_by": "fleet",
                                                   "changed_from": None}]),
           "without a kind from the three"),
    "11": ("a composition column among the clustering coordinates",
           lambda o: _w(o, "profiles-11.csv", "sub,C1,C2,composes\n"), "may be a coordinate"),
    "12": ("the names file edited after its snap", _plant_12, "changed after _snap"),
    "13": ("an author cell with a modifier on and no universal",
           lambda o: _wj(o, "author_cells.jsonl", [{"sub": "alpha", "second_order": "S01",
                                                    "division": False, "allocation": False,
                                                    "reward": False, "information": False,
                                                    "is_problem": True, "exception": True,
                                                    "goal": False, "hard_to_place": False,
                                                    "why": {"is_problem": "w", "exception": "w"},
                                                    "confidence": "clear"}]),
           "a modifier is on with no universal"),
    "14": ("a fleet reading whose read is outside cell|theme-block|whole",
           lambda o: _wj(o, "crossing_raw.jsonl", [{"sub": "alpha", "second_order": "S01",
                                                    "division": True, "allocation": False,
                                                    "reward": False, "information": False,
                                                    "is_problem": True, "exception": False,
                                                    "goal": False, "hard_to_place": False,
                                                    "agent": "x1", "replicate": 1, "position": 1,
                                                    "support": {"division": ["c1"]},
                                                    "why": {"division": "w"}, "read": "label-only",
                                                    "t": "x"}]),
           "read is"),
    "15": ("a revision of a frame-does-not-decide cell",
           lambda o: _wj(o, "crossing_revisions_only.jsonl",
                         [{"sub": "alpha", "second_order": "S01", "was": {}, "now": {},
                           "clause": "c", "caused_by": ["b/S02"], "source": "fleet-split",
                           "row": "frame-does-not-decide", "t": "x"}]),
           "may not be revised away"),
    "16": ("hard_to_place among the clustering coordinates",
           lambda o: _w(o, "profiles-16.csv", "sub,division,hard_to_place\n"), "not a feature"),
    "17": ("a comparison with no mutual information measure",
           lambda o: _wj(o, "comparison-17.jsonl", [{"measure": "adjusted rand", "value": 0.1,
                                                     "percentile": 50, "cut_11": 4, "cut_16": 3}]),
           "mutual information"),
    "18": ("an audit that never mentions the chronology check",
           lambda o: _w(o, "audit.md", "snap fork departure\n"), "does not mention chronology"),
}


def self_test():
    """Build a fixture per close-check with one known defect planted, run the check, and report
    whether the planted defect fired. Total error counts are printed as well: on a fixture of
    empty files most checks fire, which is correct and not the point; the point is the one line
    per stage saying that this stage's check saw the defect planted for it."""
    import tempfile
    import shutil
    global E, W, need
    real_need = need
    base = tempfile.mkdtemp(prefix="validate-selftest-")
    failed = 0
    print("validate.py --self-test: one planted defect per close-check, %d checks" % len(STAGES))
    try:
        for st in sorted(STAGES):
            root = os.path.join(base, st)
            pkg = os.path.join(root, "package")
            out = os.path.join(root, "out")
            os.makedirs(os.path.join(pkg, "store"), exist_ok=True)
            os.makedirs(out, exist_ok=True)
            _wj(root, "package/case_facts.jsonl", [{"sub": "alpha", "n_codes": 3, "n_themes": 1},
                                                   {"sub": "beta", "n_codes": 0, "n_themes": 0}])
            _wj(root, "package/codes.jsonl", [{"code_id": "c1", "sub": "alpha"}])
            _w(out, "dropped.jsonl", "")
            ctx = {"package": pkg, "facts_path": os.path.join(pkg, "case_facts.jsonl"),
                   "facts": _jsonl(os.path.join(pkg, "case_facts.jsonl"))}
            # pass 1: create every required output empty, so the check reaches its own logic
            E[:], W[:] = [], []
            need = _touching_need
            import io, contextlib
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    STAGES[st](root, out, dict(ctx))
                except Exception as ex:      # a fixture of empty files may still trip a handler
                    pass
            need = real_need
            what, plant, expect = PLANTS[st]
            plant(out)
            E[:], W[:] = [], []
            buf = io.StringIO()
            crashed = None
            with contextlib.redirect_stdout(buf):
                try:
                    STAGES[st](root, out, dict(ctx))
                except Exception as ex:
                    crashed = ex
            msgs = [m + " " + (s or "") for m, s, _w in E]
            fired = any(expect in m for m in msgs)
            if crashed is not None:
                print("stage %s: planted %s -> CRASHED: %r" % (st, what, crashed))
                failed += 1
            elif fired:
                print("stage %s: planted %s -> fired (%d errors on the fixture in all)"
                      % (st, what, len(E)))
            else:
                print("stage %s: planted %s -> DID NOT FIRE (%d other errors); the check is "
                      "defective, write it to defects.jsonl" % (st, what, len(E)))
                failed += 1
    finally:
        E[:], W[:] = [], []
        shutil.rmtree(base, ignore_errors=True)
    print("\n%d of %d planted defects fired" % (len(STAGES) - failed, len(STAGES)))
    return 1 if failed else 0


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        sys.exit(self_test())
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if not args or "-h" in sys.argv or "--help" in sys.argv:
        raise SystemExit(__doc__)
    mode = "open" if "--open" in sys.argv else "close"
    main(args[0], args[1] if len(args) > 1 else ".",
         args[2] if len(args) > 2 else "out", mode)

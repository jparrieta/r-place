#!/usr/bin/env bash
# freeze_instrument.sh STAGING_DIR ANALYST_DIR DEST
#
# Assemble one complete, hashed copy of an instrument from a finished run, so that a
# later run has something to start from. A live staging folder is a queue being drained
# across not-yet-run / in-flight / ran, and no single folder in it is ever the whole
# instrument. Run this when an arm closes, not while it is running.
set -euo pipefail
STG="${1:?staging directory}"
ANA="${2:?analyst directory, for the contract}"
DEST="${3:?destination, e.g. .../60_aggregator/v35}"

if command -v shasum >/dev/null 2>&1; then SHA="shasum -a 256"; else SHA="sha256sum"; fi

[ -e "$DEST" ] && { echo "REFUSING: $DEST exists. An instrument is frozen once." >&2; exit 1; }
mkdir -p "$DEST/stages"

for sub in ran in-flight "in flight" not-yet-run "not yet run"; do
  [ -d "$STG/$sub" ] || continue
  for f in "$STG/$sub"/STAGE-*.md; do
    [ -e "$f" ] || continue
    b="$(basename "$f")"
    if [ -e "$DEST/stages/$b" ]; then
      echo "CONFLICT: $b appears in more than one state folder. Resolve by hand." >&2
      exit 1
    fi
    cp "$f" "$DEST/stages/$b"
    printf '%s\t%s\n' "$sub" "$b" >> "$DEST/STAGE-PROVENANCE.tsv"
  done
done

for f in CONTRACT-aggregator.md STANDING-INSTRUCTIONS.md; do
  [ -f "$ANA/$f" ] && cp "$ANA/$f" "$DEST/"
done

( cd "$DEST" && find . -type f ! -name INSTRUMENT.md -print0 | sort -z \
    | xargs -0 -n50 $SHA > INSTRUMENT.sha256 )

n=$(ls "$DEST/stages" | wc -l | tr -d ' ')
cat > "$DEST/INSTRUMENT.md" <<MD
# Instrument, frozen

Assembled $(date -u +%Y-%m-%dT%H:%M:%SZ) from a run that had already begun.

    staging source: $STG
    analyst source: $ANA
    stage files:    $n
    fingerprint:    $($SHA "$DEST/INSTRUMENT.sha256" | cut -d' ' -f1)

\`STAGE-PROVENANCE.tsv\` records which state folder each file came from, which is the
only evidence of how far that run had got when this was taken.

Check the numbering before trusting this as a version. A lettered stage such as 04a is an
amendment made mid-run, and the standing rule is that a stage which runs twice gets its own
number and the stages after it shift down. If a letter is present, either the rule was set
aside deliberately, in which case say so here, or the set needs renumbering before reuse.
MD

echo "frozen: $DEST"
echo "  $n stage files"
ls "$DEST/stages" | sed 's/^/    /'
MD_WARN=$(ls "$DEST/stages" | grep -c '[0-9][a-z]-' || true)
[ "$MD_WARN" -gt 0 ] && echo "  NOTE: $MD_WARN lettered stage file(s). See INSTRUMENT.md."
exit 0

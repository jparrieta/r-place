#!/usr/bin/env bash
# model_audit.sh [NN]
#   What actually served this run, read from the transcripts rather than from what was asked for.
#   With no argument, audits every session; with a stage number, only that stage's session and its
#   subagents. Exits 1 if any model id contains "opus".
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"
NN="${1:-}"
SID=""
if [ -n "$NN" ]; then
  LBL="step-$NN"; [ "$NN" = "01" ] && LBL=start
  SID="$(python3 -c "
import json,sys
try: print(json.load(open('$C/sessions.json'))['$LBL']['session_id'])
except Exception: print('')" )"
  if [ -z "$SID" ]; then
    SID="$(python3 -c "
import json
try: print(json.load(open('$C/active_launch.json'))['requested_session_id'])
except Exception: print('')" )"
  fi
  [ -n "$SID" ] || { echo "no session recorded for $LBL (not launched, or not yet confirmed)" >&2; exit 1; }
fi
python3 - "$C/.cc/projects/run" "$SID" <<'PY'
import sys, json, glob, os, collections
root, sid = sys.argv[1], sys.argv[2]
files = []
if sid:
    files = [os.path.join(root, sid + ".jsonl")] + sorted(glob.glob(os.path.join(root, sid, "subagents", "*.jsonl")))
else:
    files = sorted(glob.glob(os.path.join(root, "*.jsonl"))) + sorted(glob.glob(os.path.join(root, "*", "subagents", "*.jsonl")))
seen = collections.Counter()
for p in files:
    if not os.path.exists(p): continue
    for line in open(p, errors="ignore"):
        try: d = json.loads(line)
        except Exception: continue
        m = (d.get("message") or {}).get("model")
        if isinstance(m, str) and m:
            seen[m] += 1
print("transcripts read: %d%s" % (len(files), (" (session " + sid[:8] + ")") if sid else " (whole run)"))
if not seen:
    print("  no model field found in any assistant message"); raise SystemExit(0)
print("models that actually served, by assistant message count:")
bad = False
for m, n in seen.most_common():
    flag = ""
    if "opus" in m.lower(): flag = "   <-- OPUS"; bad = True
    print("  %-46s %7d%s" % (m, n, flag))
raise SystemExit(1 if bad else 0)
PY

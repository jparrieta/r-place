#!/usr/bin/env bash
# Always launch from the handler. The aggregator itself sees only its study directory.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; G="$RUN/CONTROL/harness/protocol_guard.py"
exec python3 "$G" locked "$RUN" python3 "$G" launch "$RUN" "$@"

#!/usr/bin/env python3
"""Build CONTROL/interventions.jsonl from this run's session transcripts.

Every message the operator sent, verbatim, derived from the harness record rather than
recalled by the agent. Run from the run directory, or pass it as the first argument. The
transcripts are read from CONTROL/.cc/projects/run/ (the run layout of the v36 and v37 kits),
and the stage of each message is taken from CONTROL/sessions.json, which step.sh writes at
launch, rather than from the session's display name.

CAUTION, from the Claude Code documentation: the transcript JSONL format is internal and
changes between releases, so this parser can break on any update. It is written to report
what it could not read rather than to drop it quietly. Check the counts it prints against
CONTROL/handover-events.log (one handed line per step, one closed line per checkpoint). The
stable fallback is /export inside each session; run that too and keep both.
"""
import json, sys, pathlib, datetime

run = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
C = run / "CONTROL"
tdir = C / ".cc" / "projects" / "run"
if not tdir.is_dir():
    sys.exit(f"no transcripts at {tdir}. Was CLAUDE_CONFIG_DIR set to CONTROL/.cc when the sessions ran?")

sessions = {}
sp = C / "sessions.json"
if sp.exists():
    for label, rec in json.load(sp.open()).items():
        sid = rec.get("session_id")
        if sid:
            sessions.setdefault(sid, []).append(label)


def blocks(content):
    """Yield text from a message body, skipping tool results and non-text blocks."""
    if isinstance(content, str):
        yield content
        return
    if isinstance(content, list):
        for b in content:
            if isinstance(b, str):
                yield b
            elif isinstance(b, dict) and b.get("type") == "text" and b.get("text"):
                yield b["text"]


rows, unread, skipped = [], [], 0
files = sorted(p for p in tdir.glob("*.jsonl"))
for f in files:
    for lineno, line in enumerate(f.open(encoding="utf-8", errors="replace"), 1):
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
        except Exception as ex:
            unread.append({"file": f.name, "line": lineno, "why": str(ex)[:120]})
            continue
        if e.get("type") != "user":
            continue
        if e.get("isMeta") or e.get("isCompactSummary"):
            skipped += 1
            continue
        msg = e.get("message") or {}
        content = msg.get("content")
        # a tool result arrives with the user role; it is not something the operator typed
        if isinstance(content, list) and any(
                isinstance(b, dict) and b.get("type") == "tool_result" for b in content):
            skipped += 1
            continue
        text = "\n".join(t for t in blocks(content)).strip()
        if not text or text.startswith("<"):
            skipped += 1
            continue
        rows.append({
            "session": f.stem,
            "stages_of_session": sessions.get(f.stem),
            "session_name": e.get("sessionName") or e.get("name"),
            "line": lineno,
            "t": e.get("timestamp"),
            "cwd": e.get("cwd"),
            "text": text,
        })

rows.sort(key=lambda r: (r["t"] or "", r["session"], r["line"]))
for i, r in enumerate(rows, 1):
    r["idx"] = i

out = C / "interventions.jsonl"
with out.open("w", encoding="utf-8") as fh:
    fh.write(json.dumps({
        "_header": "operator interventions, derived from session transcripts",
        "built_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provenance": "derived",
        "transcripts": [p.name for p in files],
        "sessions_recorded_by_step_sh": {k: v for k, v in sessions.items()},
        "unreadable_lines": unread,
    }) + "\n")
    for r in rows:
        fh.write(json.dumps(r, ensure_ascii=False) + "\n")

handed = closed = 0
hp = C / "handover-events.log"
if hp.exists():
    for l in hp.open():
        f_ = l.rstrip("\n").split("\t")
        if len(f_) > 1 and f_[1] == "handed":
            handed += 1
        if len(f_) > 1 and f_[1] == "closed":
            closed += 1
print(f"transcripts: {len(files)} (sessions on record: {len(sessions)})")
print(f"interventions written: {len(rows)}")
print(f"non-operator entries skipped: {skipped}")
print(f"unreadable lines: {len(unread)}")
if unread:
    print("  -> lines this parser could not read are listed in the file header.")
print(f"handover-events.log: {handed} handed, {closed} closed (plus the start step, never handed)")
print(f"wrote {out}")
print("Every step opens with one pasted line, so the count should be at least the steps run; "
      "check it against the log before trusting it.")

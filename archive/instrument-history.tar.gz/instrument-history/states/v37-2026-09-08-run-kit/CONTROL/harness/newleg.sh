#!/usr/bin/env bash
# newleg.sh NN LEGNAME
#   Retire stage NN's recorded session under a leg name so the NEXT launch of that stage opens a
#   fresh session instead of resuming. The retired entry is kept, never deleted: sessions.json
#   gains "step-NN/LEGNAME" holding what "step-NN" held.
#
#   Why this exists. protocol_guard keys one session to one stage label, so every launch after the
#   first resumes and inherits the whole transcript. At stage 14 that made a dispatch-only launch
#   re-read a night's history on every turn: 1,000 analyst requests against 19,000 reader requests,
#   and roughly half the bill on 5.6% of the calls. A launch that only sends and collects should
#   start from nothing.
#
#   It also frees the route. A session cannot change route once served, so a fresh session per leg
#   is what lets the builder and the checker run on the subscription while the dispatcher runs on
#   the cheap arm.
#
#   Refuses while a launcher is still running. Quit the analyst first.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
RUN="$(harness_run_dir)"; C="$RUN/CONTROL"
LABEL="$(norm_label "${1:?stage number}")"; LEG="${2:?leg name, e.g. build|dispatch|check}"
case "$LEG" in *[!a-z0-9-]*) echo "leg name: lower-case letters, digits and hyphens only" >&2; exit 1;; esac

if [ -f "$C/active_launch.json" ]; then
  S="$(json_get "$C/active_launch.json" started_utc)"
  E="$(json_get "$C/last_launch_exit.json" exited_utc 2>/dev/null || true)"
  if [ -n "$S" ] && { [ -z "$E" ] || [[ "$E" < "$S" ]]; }; then
    echo "REFUSING: a launcher for $(json_get "$C/active_launch.json" label) started $S and has not exited." >&2
    echo "          Quit the analyst, then run this again." >&2
    exit 1
  fi
fi

python3 - "$C" "$LABEL" "$LEG" <<'PY'
import json, os, shutil, sys, datetime
c, label, leg = sys.argv[1:4]
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
bak = os.path.join(c, 'backups'); os.makedirs(bak, exist_ok=True)
for f in ('sessions.json', 'active_blocks.json'):
    p = os.path.join(c, f)
    if os.path.exists(p): shutil.copy2(p, os.path.join(bak, '%s.%s' % (f, stamp)))
sp = os.path.join(c, 'sessions.json')
s = json.load(open(sp))
if label not in s:
    print('%s has no recorded session; the next launch is already fresh' % label); raise SystemExit(0)
key = '%s/%s' % (label, leg)
if key in s: raise SystemExit('leg %s already retired; pick another name' % key)
s[key] = dict(s.pop(label), retired_as_leg=leg, retired_utc=stamp)
json.dump(s, open(sp, 'w'), indent=2)
bp = os.path.join(c, 'active_blocks.json')
b = json.load(open(bp)); b.pop(label, None)
json.dump(b, open(bp, 'w'), indent=2)
for f in ('pending_launch.json', 'active_launch.json'):
    p = os.path.join(c, f)
    if os.path.exists(p): shutil.move(p, os.path.join(bak, '%s.%s' % (f, stamp)))
print('retired %s as %s; the next launch of %s opens a fresh session' % (label, key, label))
print('backups in CONTROL/backups/ at %s' % stamp)
PY

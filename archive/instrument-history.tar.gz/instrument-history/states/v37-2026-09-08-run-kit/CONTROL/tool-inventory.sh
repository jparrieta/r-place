#!/usr/bin/env bash
# What tools does a session in the analyst's folder actually get? Throwaway; does not touch stage 01.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
AG="$RUN/00_GIVE-THE-AGENT"; CC="$RUN/CONTROL/.cc"
echo; echo "inventorying the tools available inside the analyst's fence..."; echo
OUT="$(cd "$AG" && CLAUDE_CONFIG_DIR="$CC" claude --model claude-sonnet-5 --strict-mcp-config --permission-mode auto -p \
'List every tool you have available to you, one name per line, exactly as each tool is named.
Include any MCP or connector tools. Output only the list. End with the line ZORBEND.' 2>&1)"
echo "---------------- verbatim ----------------"; printf '%s\n' "$OUT"; echo "------------------------------------------"; echo
bad=0
for pat in 'mcp__' 'vault' 'gmail' 'drive' 'bigquery' 'compute' 'calendar' 'slack' 'browser'; do
  if printf '%s' "$OUT" | grep -qi "$pat"; then echo "  *** FOUND: $pat ***"; bad=1; fi
done
for pat in WebFetch WebSearch; do
  printf '%s' "$OUT" | grep -q "$pat" && { echo "  *** FOUND: $pat (should be denied) ***"; bad=1; }
done
echo
[ "$bad" -eq 0 ] && echo "CLEAN — no connector or web tools reached the analyst." \
                 || echo "STOP — connectors reached the analyst. Send this to the handler."
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
echo

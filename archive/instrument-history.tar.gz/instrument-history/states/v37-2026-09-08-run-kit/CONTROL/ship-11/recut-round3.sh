#!/usr/bin/env bash
# recut-round3.sh -- put the run back to step-10 so stage 11 can be run a third time under the
# amended §6 bar, and stage 12 after it. Order matters and is the reason this is a script:
# abort_stage.sh 12 restores from the step-11 checkpoint, so that checkpoint must still be in
# place when it runs, and can only be archived afterwards.
#
#   1. abort stage 12 (uncommitted; its files go to CONTROL/aborted/)
#   2. archive the committed second run of stage 11 to CONTROL/superseded/
#   3. abort stage 11 (restores 00_GIVE-THE-AGENT from the step-10 checkpoint)
#   4. put the operator rulings back into RUN.json, which the abort reverts
#   5. put objections.jsonl back, which is not in the step-10 checkpoint and not in ORDER.tsv
#
# Nothing is deleted. Run from the run directory. Quit the analyst first.
set -euo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
C="$RUN/CONTROL"
cd "$RUN"

[ -f "$C/snapshots/step-11/COMMITTED" ] || { echo "no committed step-11 to archive; stop" >&2; exit 1; }
[ -f "$C/snapshots/step-12/COMMITTED" ] && { echo "step-12 is committed; this script expects it uncommitted" >&2; exit 1; }

echo "== 1. abort stage 12 =="
bash "$C/harness/abort_stage.sh" 12 --yes

echo
echo "== 2. archive the second run of stage 11 =="
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
A="$C/superseded/step-11-run2-$STAMP"
mkdir -p "$A"
mv "$C/snapshots/step-11" "$A/snapshot"
cp "$C/close-status-11.json" "$C/validation-11.txt" "$A/" 2>/dev/null || true
cp "$C/snapshots/INDEX.tsv" "$A/INDEX.tsv.before"
cp "$RUN/DROPS/step-11/STAGE-11-clustering-the-third-order-dendrogram.md" "$A/STAGE-11.md.after-round3-amendment"
grep -v $'^step-11\t' "$C/snapshots/INDEX.tsv" > "$C/snapshots/INDEX.tsv.new"
mv "$C/snapshots/INDEX.tsv.new" "$C/snapshots/INDEX.tsv"
cat > "$A/README.md" <<'TXT'
# step-11, the second run: superseded

Closed 2026-09-16T12:34:03Z, checkpoint d3c2204168d48af6, carrying k = 2 (263 / 35). Superseded the
same day by a second operator ruling restating §6's stability bar in full. Nothing here is deleted.

The method of that run stands and is unchanged by the amendment: code counts per chunk as
within-community shares, Dirichlet-multinomial shrinkage, no zero-replacement. What was wrong was
the bar the cut was judged against, which named the mean and set no margin and no replicate count,
so a k = 2 whose mean margin was 0.003, whose median margin was negative, and whose pass flipped
under a second seed could be carried.

Two statements from the instrument itself are the ground for the third run, both inside this
snapshot: notes-11.md §10, where the analyst says it believes k = 2 was very likely the wrong cut,
and its rule-10 departure declaring that the second look was taken after §8 was built. Stage 12,
archived under CONTROL/aborted/, adds a third: it named one form and a 263-room residual, and wrote
that it was open whether a finer partition would have surfaced the two pockets it found inside that
residual.

The analyst is told none of this. It receives the amended stage file and derives its own table,
its own bar arithmetic and its own cut, which may again be k = 2.
TXT
echo "archived to $A"

echo
echo "== 3. abort stage 11 =="
bash "$C/harness/abort_stage.sh" 11 --yes

echo
echo "== 4. rulings back into RUN.json =="
python3 "$C/ship-11/reapply-ruling.py"

echo
echo "== 5. objections.jsonl back into the analyst's out/ =="
cp "$C/ship-11/objections.jsonl" "$RUN/00_GIVE-THE-AGENT/out/objections.jsonl"
wc -l "$RUN/00_GIVE-THE-AGENT/out/objections.jsonl"

cat <<MSG

the run stands at step-10. next:

  ./CONTROL/harness/prestage.sh 11
  ./CONTROL/harness/step.sh 11

paste into the analyst:
  Read AGENT.md, then ADDENDUM-11.md, then STAGE-11-clustering-the-third-order-dendrogram.md. Do that stage and stop.

MSG

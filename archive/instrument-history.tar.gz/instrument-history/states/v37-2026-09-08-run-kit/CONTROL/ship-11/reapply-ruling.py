#!/usr/bin/env python3
# abort_stage.sh restores RUN.json from the pre-launch capture, which predates the 2026-09-16
# stage-11 ruling. This puts the ruling back, once, and is safe to run twice.
import json, os, sys
run = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
p = os.path.join(run, "CONTROL", "RUN.json")
rs = [json.load(open(os.path.join(run, "CONTROL", "ship-11", f)))
      for f in ("ruling-11.json", "ruling-11b.json")]
d = json.load(open(p))
cur = d.setdefault("operator_rulings", [])
added = 0
for r in rs:
    if any(x.get("t") == r["t"] and x.get("stage") == r["stage"] for x in cur):
        continue
    cur.append(r); added += 1
if not added:
    print("rulings already present; nothing to do (%d rulings)" % len(cur)); sys.exit(0)
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
print("restored %d ruling(s); %d total" % (added, len(cur)))

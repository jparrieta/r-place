#!/usr/bin/env bash
# recut-round3-resume.sh -- steps 3 to 5 of recut-round3.sh, after its step 3 refused because the
# transcript the step-12 abort had just restored looked one second old to the liveness guard. That
# restore was correct (the file is byte-identical to the step-11 checkpoint's transcript.sha256);
# only its mtime was wrong. abort_stage.sh now copies with -p, and the live file's mtime has been
# set back, so the guard reads it as what it is.
set -euo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
C="$RUN/CONTROL"
cd "$RUN"

[ -d "$C/snapshots/step-11" ] && { echo "step-11 snapshot is still in place; run recut-round3.sh instead" >&2; exit 1; }
[ -f "$C/snapshots/step-10/COMMITTED" ] || { echo "no committed step-10 to restore from" >&2; exit 1; }

echo "== 3. abort stage 11 =="
bash "$C/harness/abort_stage.sh" 11 --yes

echo
echo "== 4. rulings back into RUN.json =="
python3 "$C/ship-11/reapply-ruling.py"

echo
echo "== 5. objections.jsonl back into the analyst's out/ =="
cp "$C/ship-11/objections.jsonl" "$RUN/00_GIVE-THE-AGENT/out/objections.jsonl"
wc -l "$RUN/00_GIVE-THE-AGENT/out/objections.jsonl"

cat <<MSG

the run stands at step-10. next:

  ./CONTROL/harness/prestage.sh 11
  ./CONTROL/harness/step.sh 11

paste into the analyst:
  Read AGENT.md, then ADDENDUM-11.md, then STAGE-11-clustering-the-third-order-dendrogram.md. Do that stage and stop.

MSG

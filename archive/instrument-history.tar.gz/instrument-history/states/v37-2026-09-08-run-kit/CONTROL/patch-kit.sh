#!/usr/bin/env bash
# Carry this run's corrections back into the kit, so the next build starts working.
# Idempotent: safe to run twice. Backs up before it changes anything; deletes nothing.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
KIT="/Users/arrieta/Obsidian/Research/Claude/rPlace/Snapshot-v37"
BK="/Users/arrieta/Obsidian/Research/Claude/rPlace/Layer A/_exports/_to_delete/kit-20260908-before-fence-and-connector-fix"
[ -d "$KIT" ] || { echo "kit not found at $KIT" >&2; exit 1; }
echo; echo "kit:    $KIT"; echo "backup: $BK"; echo
mkdir -p "$BK/ASSETS/templates" "$BK/ASSETS/harness"
for f in ASSETS/templates/settings.json ASSETS/harness/protocol_guard.py RUNBOOK.md; do
  [ -e "$BK/$f" ] || cp -p "$KIT/$f" "$BK/$f" 2>/dev/null && echo "  backed up  $f"
done
echo

# 1. the settings template -- the fence defect
cp "$RUN/CONTROL/settings.template.json" "$KIT/ASSETS/templates/settings.json"
echo "  patched    ASSETS/templates/settings.json  (allowRead is a whitelist; denyRead names no ancestor)"

# 2. the launcher -- the connector breach
python3 - "$KIT/ASSETS/harness/protocol_guard.py" <<'PY'
import sys
p = sys.argv[1]; s = open(p).read()
if "--strict-mcp-config" in s:
    print("  already ok ASSETS/harness/protocol_guard.py")
else:
    old = "    cmd += ['-n', 'stage-'"
    assert s.count(old) == 1, "launch() not in the expected shape; patch by hand"
    open(p, "w").write(s.replace(old, "    cmd += ['--strict-mcp-config']\n" + old))
    print("  patched    ASSETS/harness/protocol_guard.py  (--strict-mcp-config on every launch)")
PY

# 3. ship the acceptance test with every future run (build.sh copies ASSETS/harness/*)
cp "$RUN/CONTROL/harness/acceptance.sh" "$KIT/ASSETS/harness/acceptance.sh"
chmod +x "$KIT/ASSETS/harness/acceptance.sh"
echo "  installed  ASSETS/harness/acceptance.sh  (ships into every run's CONTROL/harness/)"

# 4. the one-time login, which is a procedure and cannot be fixed in a file
cat > "$KIT/KIT-NOTES-20260908.md" <<'NOTE'
# Kit notes — corrections of 2026-09-08

Three defects stopped `gioia-j-sonnet-v37-20260908` from starting. Two are fixed in this kit. The
third is a procedure and must be done by hand for every new run.

## 1. The fence denied the analyst its own folder (fixed here)

`ASSETS/templates/settings.json` used to carry `denyRead: ["~/", "__RUN__"]`. Both are ancestors of
`00_GIVE-THE-AGENT/`, and **deny beats allowRead**, so the analyst could not read its own study
folder. Python died during interpreter startup, because `python3 -c` puts the current directory on
the import path and scanning a denied directory raises `PermissionError`. Python 3.8 tolerates that
and 3.13 does not, which made conda look like the cause. It was not.

Proved by experiment: two folders identical but for whether a denied ancestor existed. A third lab
showed **`allowRead` is a whitelist** — parent and sibling folders are denied without being named,
and install paths such as `/opt/anaconda3` are implicitly trusted. So forks may be siblings safely,
and the run need not live outside the home directory.

`denyRead` must never name an ancestor of the analyst folder. It now names the run-root items
individually. **Anything new placed at the run root must be added to that list.**

## 2. The analyst inherited the account's connectors (fixed here)

A session launched exactly as the harness launches it was handed Gmail (including `send_message`),
Google Drive, Google Calendar and Hugging Face, plus `SendMessage` and `ListAgents`. These are
claude.ai connectors attached to the logged-in account, not to the config directory, so nothing in
a run's own files reveals them. **MCP calls are made by the CLI process and do not pass through the
sandbox at all** — `network.allowedDomains: []` and `denyRead` never see them.

Fixed by `--strict-mcp-config` on every launch, plus deny rules in the template. `Agent` is kept
deliberately: stage 04 requires the analyst to run a fleet in fresh contexts.

## 3. The analyst's config directory ships with no login (do this by hand, every run)

`CONTROL/.cc` has no credentials, so stage 01 stops at a login prompt. There is no
`.credentials.json`: the secret lives in the Keychain and only the account marker lives in the
config directory. Before stage 01, in a Terminal:

    cd /tmp && CLAUDE_CONFIG_DIR="<run>/CONTROL/.cc" claude

then `/login`, approve in the browser, then `/exit`. Afterwards delete the throwaway conversation it
creates under `CONTROL/.cc/projects/`, or it enters every checkpoint.

## Then run the acceptance test

    bash <run>/CONTROL/harness/acceptance.sh

Ten checks: authentication, the tool inventory, that the analyst can read its folder and compute,
that `CONTROL/` stays denied, and that the fork flags work. It must print ALL CLEAR before stage 01.

## A note on testing

Two checks written during this run gave false passes: one asserted that a transcript *file* existed,
and Claude Code writes that file even when the call dies at "Not logged in"; another matched the
pattern `verb` inside the word "verbatim". Assertions must read content, and should key on nonsense
tokens rather than English words.
NOTE
echo "  written    KIT-NOTES-20260908.md"

if ! grep -q 'KIT-NOTES-20260908' "$KIT/RUNBOOK.md" 2>/dev/null; then
cat >> "$KIT/RUNBOOK.md" <<'NOTE'

## Before stage 01 of any run (added 2026-09-08)

1. The run must stand outside the vault; the harness refuses to operate inside it.
2. Log in to the run's own config directory once — it ships empty and stage 01 will otherwise stop
   at a login prompt. See `KIT-NOTES-20260908.md`.
3. Run `CONTROL/harness/acceptance.sh` and require ALL CLEAR before launching.
NOTE
echo "  appended   RUNBOOK.md"
else echo "  already ok RUNBOOK.md"; fi

echo; echo "=== verifying the patched kit ==="
python3 - "$KIT" <<'PY'
import json, sys
k = sys.argv[1]
t = json.load(open(k + "/ASSETS/templates/settings.json"))
fs = t["sandbox"]["filesystem"]
anc = [d for d in fs["denyRead"] if d in ("~/", "__RUN__")]
print("  denyRead names an ancestor :", anc or "no  (correct)")
print("  allowRead                  :", fs["allowRead"])
print("  deny rules                 :", len(t["permissions"]["deny"]))
print("  mcp__* denied              :", "mcp__*" in t["permissions"]["deny"])
s = open(k + "/ASSETS/harness/protocol_guard.py").read()
print("  --strict-mcp-config present:", "--strict-mcp-config" in s)
import os
print("  acceptance.sh installed    :", os.path.exists(k + "/ASSETS/harness/acceptance.sh"))
PY
echo; echo "done. The next build starts in the state this run reached."; echo

#!/usr/bin/env bash
# Native-CLI acceptance test for this run. Must be TYPED INTO A TERMINAL.
# Assertions read transcript/reply CONTENT, never the mere existence of a file.
set -uo pipefail
RUN="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
CC="$RUN/CONTROL/.cc"; MODEL=claude-sonnet-5
T="$(mktemp -d /tmp/pf.XXXXXX)"; mkdir -p "$T/proj"
pass=0; fail=0
ok(){ echo "  PASS  $*"; pass=$((pass+1)); }
no(){ echo "  FAIL  $*"; fail=$((fail+1)); }
uu(){ python3 -c 'import uuid;print(uuid.uuid4())'; }

echo
echo "run: $RUN"
echo
echo "=== A. is the analyst's own config dir (CONTROL/.cc) logged in? ==="
A="$(cd "$T/proj" && CLAUDE_CONFIG_DIR="$CC" claude --model $MODEL -p "Reply with exactly: ALIVE" 2>&1)"
if printf '%s' "$A" | grep -q ALIVE; then ok "CONTROL/.cc is authenticated"
else no "CONTROL/.cc is NOT authenticated — stage 01 would stop at a login prompt"
     echo "        it said: ${A:0:160}"; fi

echo
echo "=== B. does the fence hold? (deny rules + sandbox, from the analyst's own settings) ==="
echo "    checked for real at stage 01, against CONTROL/ and an unhanded stage,"
echo "    through the file tools AND through python. Not simulated here."

echo
echo "=== C. fork flags:  --resume P --fork-session --session-id C ==="
PARENT="$(uu)"; CHILD="$(uu)"
(cd "$T/proj" && claude --session-id "$PARENT" --model $MODEL \
   -p "Remember this codeword: PORTCULLIS. Reply with just the word OK." >/dev/null 2>&1)
PT="$(find "$HOME/.claude/projects" -name "$PARENT.jsonl" 2>/dev/null | head -1)"
if [ -n "$PT" ] && grep -q PORTCULLIS "$PT" 2>/dev/null; then ok "parent conversation really recorded at the requested id"
else no "parent id did not produce a real conversation"; fi
PSUM="$(shasum -a 256 <"$PT" 2>/dev/null | cut -d' ' -f1)"
C="$(cd "$T/proj" && claude --resume "$PARENT" --fork-session --session-id "$CHILD" --model $MODEL \
      -p "What codeword did I ask you to remember? Reply with only that word." 2>&1)"; RC=$?
[ $RC -eq 0 ] && ok "CLI accepted the flag combination" || no "CLI refused it (exit $RC): ${C:0:160}"
CT="$(find "$HOME/.claude/projects" -name "$CHILD.jsonl" 2>/dev/null | head -1)"
if [ -n "$CT" ] && grep -q PORTCULLIS "$CT" 2>/dev/null; then ok "child transcript at the preassigned id carries the parent's history"
else no "child transcript did not carry the parent's history"; fi
printf '%s' "$C" | grep -qi PORTCULLIS && ok "the forked model answered from inherited context" \
                                       || no "the fork did not inherit context: ${C:0:160}"
[ "$PSUM" = "$(shasum -a 256 <"$PT" 2>/dev/null | cut -d' ' -f1)" ] \
  && ok "parent conversation byte-identical after the fork" || no "the fork mutated the parent"

echo
echo "================ RESULT:  $pass passed, $fail failed ================"
[ "$fail" -eq 0 ] && echo "ALL CLEAR" || echo "STOP — send this whole output to the handler."
# clean up: throwaway conversations, and any stray project dir under the analyst's runtime
find "$HOME/.claude/projects" -type d -name '*pf-*proj*' -exec rm -rf {} + 2>/dev/null
find "$CC/projects" -mindepth 1 -maxdepth 1 -type d ! -name run -exec rm -rf {} + 2>/dev/null
rm -rf "$T"; echo

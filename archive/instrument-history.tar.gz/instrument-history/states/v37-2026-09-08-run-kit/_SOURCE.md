# v37, source

v37, the built run kit (Claude Sonnet run, Layer Fork lineage).

- **Taken** 2026-10-02 by Claude, at J's request, for reference. Text only: no room data.
- **From** `~/Jail/gioia-j-sonnet-v37-20260908`, read only.
- **Holds** READ-ME-FIRST, the two handovers, `STAGE CARDS/`, `DROPS/`, `RESUME/`, `CHANGES/` (for-the-kit, run-only), `00_GIVE-THE-AGENT/` top files (the contract, the standing instructions, the 18 stage files, the addenda) and `tools/`, `CONTROL/harness/`, `RUN.json`, the protocol.
- **Left out** the evidence (`package/`, `trees/`, `data/`, `cases/`, `codes/`), the analyst's work (`out/`, notebooks, fleet pages), the run's records (`CONTROL/` snapshots, sessions, logs, aborted and superseded legs, `.cc`), `#/`, `DERIVED/`, `Claude outputs/`.
- **Archive** `v37-2026-09-08-run-kit.tar.gz`, 3,081,587 bytes, 226 files, sha256 `101cd240ce496d0a49506f761f0739380e938b0ef20aa7a652d46b104fdad7f0`. Inside, `_MANIFEST.tsv` lists every file with its size and sha256. Unpack outside the vault: `tar -xzf v37-2026-09-08-run-kit.tar.gz -C /tmp`.

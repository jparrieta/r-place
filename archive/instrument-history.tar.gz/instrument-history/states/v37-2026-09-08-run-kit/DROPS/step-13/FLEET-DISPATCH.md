# How your readers are served, and what is yours to change

Read this before `STAGE-13-crossing-pilot.md`. It describes the machinery underneath your pilot
rounds and your later fleets, so that when a reader misbehaves you know which lever is yours.

## What is fixed before you start, and why

This stage is served through a gateway rather than the subscription. The handler sets four things
in the environment your session inherits:

    ANTHROPIC_MODEL=@preset/sonnet              you, the analyst
    CLAUDE_CODE_SUBAGENT_MODEL=@preset/cheap    every reader you dispatch
    ANTHROPIC_SMALL_FAST_MODEL=@preset/cheap    the CLI's own background calls
    CLAUDE_CODE_MAX_OUTPUT_TOKENS=128000        the ceiling on any single reply

Both aliases were resolved to the models that actually serve them before this session started, and
the launch refuses outright if either resolves to an Opus model. That refusal is not a preference.
A reader served by a model other than the declared one makes every figure it produces
unattributable, and no later stage can repair that.

**Do not pass a model to any agent you dispatch.** The subagent model is set for you, and naming
one per dispatch overrides it. If you find yourself wanting a stronger reader for a hard cell, the
answer is a better brief, not a different model: the readers must be interchangeable or the
fidelity figure means nothing.

You cannot verify what served you. `CONTROL/` is outside your fence by design. The handler audits
the transcripts after every stage and will tell you if anything unexpected appears. If a reader's
output reads wrong in a way you cannot explain from the brief, say so in your notes and to the
handler rather than working around it.

## What a reader gets, and what stops it

Each reader is a fresh context holding only what you hand it: the brief as it stands, the sibling
block, its cells with their codes. It has the same 128,000-token output ceiling you do.

Two failures have been seen repeatedly with this class of reader and you should expect both.

**It ends its turn with work unwritten.** It returns having written one file of the several it
owes, or none, and its final message may be empty. This is not a refusal and not a misunderstanding
of the task; it simply stops. The fix is to go back to the same reader and name what is missing:

> You stopped before finishing. These files are still missing: `<names>`. Write `<the first one>`
> now, in full, then carry on with the rest of your brief in order. Do not redo or restate work you
> have already written.

Prod it as many times as it takes, and the budget is generous on purpose: **up to thirty prods to
one reader.** Three or four is ordinary and ten is not a problem. Do not treat a reader as failed
because prodding it is tedious; a reader that eventually writes its twelve cells over fifteen prods
has given you twelve verdicts, which is the whole point. Only after **five consecutive prods that
produce nothing new** is a reader stuck rather than slow: record it as a failed agent under §5's
rules and reissue its cells to a fresh one. Say in `notes-13.md` how many prods each reader needed,
so the next stage can size the fleet against a real number instead of a guess.

**It truncates a long reply.** With the ceiling at 128,000 this should not happen on a packet of
the size this stage uses, but if a return is cut mid-line, split that reader's cells across two
readers rather than asking for the same output again.

**A slow reader is not a failed reader.** The background-wait ceiling is off for this launch, so a
reader that takes many minutes has not timed out and nothing will cut it off. Wait for it. The one
failure that has cost this run real money was a batch killed at ten minutes by a ceiling that is
now removed, and the readers had produced nothing when it fired.

Never accept a partial return as a return. A reader that wrote four of its twelve cells has not
given you eight `cannot-tell` verdicts; it has given you four verdicts and eight gaps, and the two
are different data.

## Stop after round 1 and report, before you edit anything

This is a pause, not the end of the stage. The operator is testing a reader arm that has not
served a real stage before, and wants to see how the first three behaved before you spend more on
them.

When round 1's three readers have returned and §4's three numbers exist, **write the round's line
to `crossing_pilot_rounds.jsonl`, then stop and report to the operator. Do not edit the brief
first.** §5's edits are the next thing you do after being told to continue, not before: an edit
made now would mean the operator is reading a brief that no longer exists.

Report these, briefly, in your message rather than only in a file:

- **Fidelity against `author_cells.jsonl`**, per reader and averaged, and **pairwise agreement**
  between the three. The two numbers §4 calls primary and secondary.
- **Prods per reader**, and whether any reader hit the five-consecutive-nothing-new rule and was
  replaced.
- **Whether any return arrived partial**, what was missing, and whether prodding recovered it.
- **Anything about how these readers behaved** that a reader on another arm would not have done:
  refusals, truncation, drifting out of the return format, answering in prose where the brief asked
  for a line, inventing a flag the brief does not define, or an obvious change of register between
  cells.
- **Roughly how long each reader took**, since a reader that works for twenty minutes and a reader
  that works for two are different instruments even at equal fidelity.
- **Your own reading of whether these readers can do stage 14's work**, said plainly, including if
  the answer is no.

Then wait. The operator will tell you to continue, to change the allocation, or to stop the stage
where it is.

## What is yours

The allocation, the packet size, how many cells a reader holds, the order they are given in, the
retry policy above, the brief itself, and everything the stage file already makes yours. If a
reader keeps failing on a particular shape of packet, change the packet: that is a finding about
the instrument and belongs in `notes-13.md`.

If the arrangement above turns out not to work at all, say so plainly in `handback-13.md` with
what you observed. The handler can change the environment between stages; you cannot change it
from inside one, and guessing at it wastes the stage.

# Tier C — explanations

*Ships with the stage 09 package. Each of these will explain your material if you let it. They wait
until the structure exists in writing and can be tested against them rather than built out of them.*

*Each entry says what the work claims and what would test it here. No entry says which of them fits
your material best — ranking candidate explanations is this stage's work, not its input.*

---

**Schelling (1960).** Focal points; coordination without communication.
*The claim:* parties with a common interest and no channel converge on solutions made salient by
something outside the negotiation. Territory on a shared surface with no property rights is near the
pure case.
*The test:* your record shows which boundaries were negotiated and which were not, and the ratio is
data.
*Not for:* absorbing the boundaries that *were* negotiated into the focal-point account.

**Organizational ecology.** Hannan & Freeman (1977, 1984); density dependence; **Stinchcombe (1965)**
on the liability of newness.
*The claim:* founding conditions durably shape survival, and new organizations fail at higher rates
for reasons of structure rather than of merit.
*The test:* you hold a complete population with founding times inside a bounded window, so the
founded-that-week contrast is directly available — over three days rather than three decades.
*Not for:* stage 08. It is about rates rather than about how anyone organized, and reaching for it
early turns a study of practice into a study of counts.

**Collective action.** Olson (1965); Oliver, Marwell & Teixeira (1985).
*The claim:* the first sub-question **is** the collective action problem. Olson's logic predicts
under-provision; the accelerating production function predicts instead that early contributors
matter disproportionately.
*The test:* the entry-time contrast, against which the second prediction is checkable.
*Not for:* finding free-riding everywhere. Where contributing costs one click the classic logic may
not bind, and saying so with evidence beats applying it.

**Sensemaking and its collapse.** Weick (1993) on Mann Gulch; Weick & Roberts (1993).
*The claim:* it is aimed at your dependent variable. Mann Gulch's observation was that the structure
went before the people did — the organization stopped existing while its members were still present.
*The test:* the claim is normally untestable because a record ends when the organization does.
Where a venue's record continues past whatever organizing it carried, the two can be separated —
so establish whether yours does before treating the claim as testable here.
*Not for:* narrating every dissolution as a collapse. Attrition and collapse are different endings
and the duller one is often right; say which the record supports.

**Organizational identity.** Albert & Whetten (1985); Gioia, Schultz & Corley (2000); Gioia et al.
(2010) on identity formation in a nascent organization.
*The claim:* identity is a candidate mechanism for the goal problem — where a room drew what it
already was, identity would be *how* the goal got settled without anyone deciding it, and a room
founded that week would have had to manufacture both at once.
*Not for:* stage 08, or the second-order tier at any point. It is the construct on this list most
likely to fit any material, and it will explain any choice of subject matter after the fact.

**Transparency and performed work.** Bernstein (2012).
*The claim:* work done in view of an audience is done differently, not merely reported differently.
*The test:* this material was written to be read by the people it was about, which the brief already
observes as a property of the record; Bernstein supplies the mechanism that makes it more than a
caveat.
*Not for:* discounting the record. Performed talk still did something.

**Exploration and exploitation.** March (1991), returning as theory.
*The claim:* a fixed budget of attention forces a trade-off between defending what is held and
reaching for what is not.
*The test:* placement ran for 73 hours against a fixed attention budget, which is the trade-off in a
sharp form, and the canvas records what was chosen.
*Not for:* relabelling every decision as one or the other.

**The theory-based view.** Felin & Zenger (2017); Felin, Gambardella & Zenger (2024); Wuebker,
Zenger & Felin. Economic actors as theorists: value comes from holding a **theory** of what will
create it, and resources are *"inert; an epiphenomenon of the theories that animate them."*
*The claim:* performance differences trace to differences in theory rather than in endowment.
*Why the setting is unusual for it.* Resource heterogeneity is definitionally shut off — every
participant held an identical endowment, one pixel every few minutes — so performance heterogeneity
cannot come from what anyone had. It can come from headcount, which is measurable and conditionable,
or from theory. And unlike almost anywhere else, a stated theory of value can be timestamped, acted
on, and observed being revised, with the revision visible to competitors. In these terms an
exception in the crossing pass is a theory being refuted.
*Not for:* stage 08, and not for the model. Every coordination post can be read as a theory if you
want it to be, which is exactly why it waits.

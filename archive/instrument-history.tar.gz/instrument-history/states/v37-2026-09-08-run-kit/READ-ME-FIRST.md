# Read me first

This folder is one run of the v37 aggregator. There are three parties.

**The analyst** does the study. It is a Claude session on your Mac that lives inside
`00_GIVE-THE-AGENT/` and can see nothing else in the world.

**The handler** is me, in Cowork. I hold the run: the stages waiting to be handed over, the
checkpoints, the forks, the budget.

**You** own the study. You make the judgements an author makes, and nothing else.

## Your whole job, eighteen times

1. I tell you a stage is ready and give you one line.
2. You run that line in Terminal. Claude opens and prints a sentence. You paste the sentence in.
3. The analyst works. You can watch or leave.
4. When it stops, you quit Claude and tell me.
5. I close the stage, check it, and save it. Then I tell you what is next.

That is all of it, except twice.

## The two times it is more than that

After stage 10 and after stage 12 I will send you something to read: ten compositions the first
time, three cluster accounts the second. You read them against the rooms and tell me, in ordinary
words in the chat, what you object to. I turn your words into the form the study requires and file
them. If you have no objection you must still say so: silence is not permitted, and the analyst has
to answer you before the next stage computes anything.

These two readings are the only places where the study asks for your judgement rather than your
hands. They are yours. I will not write them for you.

## What I will never ask you to do

Type any command except the one I give you. Find a file. Edit anything. Read an error message. You
will never need to remember which stages share a conversation, or what a fork is, or what any of
this is called.

## The one rule you must hold

Say nothing to the analyst except the line it is given. Not what model it is, not that other runs
exist, not that it has been forked, not what happened in an earlier version. If it asks you a
question it will write the question down, and I will answer it in writing where it belongs. If you
ever do say something to it by accident, tell me at once. It is recoverable if I know.

## Where things are

`STAGE CARDS/` has one card per stage, in order. Each card says what the stage is for, what you
type, what to read, and whether anything is asked of you. I send you the card when the stage is
ready, so you do not need to go looking.

`00_GIVE-THE-AGENT/out/` is where the analyst writes. If you want to read along, the file to open is
`handback-NN.md`: it is the analyst's own account of what it just did and what it is unsure about.

Everything else in this folder is mine.

## What this run is

Eighteen stages, every role on Sonnet, a low-cost tryout of an instrument that has never been run.
The point is to see how it behaves. If it behaves badly somewhere, that is a result and not a
failure.

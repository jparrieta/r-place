# Stage 08 — the model: the literature

**What happens here.** The analyst puts the model against the literature it has been given, and either revises it or defends it.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: `package/store/shelves/literature-tierC.md`.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 08
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

This stage belongs to the block 07 to 09, which is one conversation. The launcher keeps its identity for you, so you open it the same way every time.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-08.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-08.md` for the detail, and `out/diary-08.md` for how it went about it.

## What it will have written

`model.v2.md`, `edges.v2.jsonl` and `structure.v2.md`, where the literature moved anything; and, as every stage does, `notes-08.md`, `handback-08.md`, `diary-08.md` and the validator's report.

## Fork point

No.


# Stage 10 — the model: the return to the field

**What happens here.** The analyst writes a composition brief, composes thirty rooms itself, sends a fleet to compose the rest, and then judges which rooms the model reaches and which it does not.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 10
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

This stage belongs to the block 10 to 12, which is one conversation. The launcher keeps its identity for you, so you open it the same way every time.

## While it runs

A fleet runs here, under a ceiling of 20 million tokens. The analyst prices the fleet before launching it and stops rather than run short. If it says it cannot afford the fleet, that is the ceiling working. Tell me; it is mine to look at.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

**Yes, and it is the first time.** When the stage closes I will send you the ten compositions drawn for you, rendered so you can read them beside the rooms they describe. You reply to me in the chat. I write your objections into `out/objections.jsonl` in the form the contract requires. If you have none, say so in one line: silence does not count, and the analyst must answer you in `notes-11.md` before stage 11 computes anything.

## If you want to read

`out/handback-10.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-10.md` for the detail, and `out/diary-10.md` for how it went about it.

## What it will have written

`composition_brief.md`, `composition.jsonl`, `composition_raw.jsonl`, `transmission-10.md`, `uncomposed-10.md`, `operator_draw-10.json`; and, as every stage does, `notes-10.md`, `handback-10.md`, `diary-10.md` and the validator's report.

## Fork point

No, but the forks taken at 06 and at 09 are compared and carried here.


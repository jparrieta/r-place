# Stage 16 — the crossing: the problem dendrogram

**What happens here.** The analyst computes the second clustering and makes three judgements the computation cannot make: which verdict the volume check returns, where to cut, and whether the clusters can be read at all.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 16
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-16.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-16.md` for the detail, and `out/diary-16.md` for how it went about it.

## What it will have written

`clusters-16.jsonl`, `clusters_members-16.jsonl`, the second dendrogram and its cut; and, as every stage does, `notes-16.md`, `handback-16.md`, `diary-16.md` and the validator's report.

## Fork point

No.


# Stage 06 — assignment: revision

**What happens here.** The analyst revises the scheme in the light of what the fleet did with it, and freezes the result.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 06
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-06.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-06.md` for the detail, and `out/diary-06.md` for how it went about it.

## What it will have written

`scheme_v2.md` and `scheme_v2.jsonl`, `assignments_final.jsonl`, `form_pass-06.md`; and, as every stage does, `notes-06.md`, `handback-06.md`, `diary-06.md` and the validator's report.

## Fork point

**Yes.** The loop forks here. Each child runs 07 to 10 on its own, and they are compared at 07 and again at 10.


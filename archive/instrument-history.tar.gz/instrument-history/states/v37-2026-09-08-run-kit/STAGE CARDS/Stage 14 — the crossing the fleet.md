# Stage 14 — the crossing: the fleet

**What happens here.** A fleet crosses every cell in scope against the frozen brief.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 14
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

A fleet runs here, under a ceiling of 4 million tokens. The analyst prices the fleet before launching it and stops rather than run short. If it says it cannot afford the fleet, that is the ceiling working. Tell me; it is mine to look at.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-14.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-14.md` for the detail, and `out/diary-14.md` for how it went about it.

## What it will have written

`crossing_raw.jsonl`, `fidelity-14.md`, `agent_report-14.md`, `batches-14.jsonl`; and, as every stage does, `notes-14.md`, `handback-14.md`, `diary-14.md` and the validator's report.

## Fork point

No.


# Stage 13 — the crossing: the pilot

**What happens here.** The analyst pilots the crossing by hand, works out its scope, writes the brief the fleet will use, and seeds the gold cells.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 13
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-13.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-13.md` for the detail, and `out/diary-13.md` for how it went about it.

## What it will have written

`crossing_brief_final.md`, `cells_in_scope.jsonl`, `scope-13.md`, `gold_cells.jsonl`, `author_cells.jsonl`; and, as every stage does, `notes-13.md`, `handback-13.md`, `diary-13.md` and the validator's report.

## Fork point

No.


# Stage 04 — assignment: the fleet

**What happens here.** A fleet of coder agents applies the frozen scheme to everything. The analyst supervises it and pays for it out of a declared ceiling.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 04
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

A fleet runs here, under a ceiling of 8 million tokens. The analyst prices the fleet before launching it and stops rather than run short. If it says it cannot afford the fleet, that is the ceiling working. Tell me; it is mine to look at.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-04.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-04.md` for the detail, and `out/diary-04.md` for how it went about it.

## What it will have written

`assign_raw.jsonl`, `agent_report-04.md`; and, as every stage does, `notes-04.md`, `handback-04.md`, `diary-04.md` and the validator's report.

## Fork point

No.


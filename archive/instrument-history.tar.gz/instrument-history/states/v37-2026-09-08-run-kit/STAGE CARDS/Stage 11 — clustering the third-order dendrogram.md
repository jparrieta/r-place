# Stage 11 — clustering: the third-order dendrogram

**What happens here.** The analyst answers your objections first, then clusters the rooms by how they composed. It reads nothing else in this stage: it computes.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: `pre_vector.csv`, `pre_network.csv` and `DATA-manifest-11.md`, the withheld pre-event tables.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 11
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

This stage belongs to the block 10 to 12, which is one conversation. The launcher keeps its identity for you, so you open it the same way every time.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-11.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-11.md` for the detail, and `out/diary-11.md` for how it went about it.

## What it will have written

`clusters-11.jsonl`, `clusters_members-11.jsonl`, the dendrogram and its cut; and, as every stage does, `notes-11.md`, `handback-11.md`, `diary-11.md` and the validator's report.

## Fork point

No.


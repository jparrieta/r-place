# Stage 12 — clustering: how each cluster organized

**What happens here.** The analyst writes an account of each cluster, in two batches, the second only after the first is written and snapped.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 12
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

This stage belongs to the block 10 to 12, which is one conversation. The launcher keeps its identity for you, so you open it the same way every time.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

**Yes, the second and last time.** When the stage closes I will send you three cluster accounts to read. You reply in the chat and I file your objections. One line if you have none. The analyst answers them in an addendum to `notes-12.md` before 13 opens.

## If you want to read

`out/handback-12.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-12.md` for the detail, and `out/diary-12.md` for how it went about it.

## What it will have written

`clusters-12.md`, and the account of each cluster; and, as every stage does, `notes-12.md`, `handback-12.md`, `diary-12.md` and the validator's report.

## Fork point

No.


# Stage 15 — the crossing: adjudication, and revision

**What happens here.** The analyst adjudicates the crossing and revises it. This stage also carries the blind check you ruled in: a hundred cells read again by two fresh readers who have not seen the first pass, so that the two clusterings compared at 17 carry a reliability figure.

## Before it opens

Mine. I check that the stage before it closed and was checkpointed, and that everything this stage needs is where it must be. Then I tell you it is ready. Shipped with this stage: Nothing extra.

## What you do

In Terminal, inside the run folder:

```
./CONTROL/harness/step.sh 15
```

It opens Claude and prints one line. Paste that line in, and nothing else. Never tell the analyst anything about earlier runs, other arms, models, the instrument or the forks. If it has a question it writes it in its handback, and I answer it in the next drop as a file, never in the chat.

## While it runs

Nothing is asked of you. Read along or leave it.

## When it stops

Quit Claude, then tell me. Quitting matters: a stage cannot be closed while its session is live, and the close is what makes the checkpoint. I close it, verify it, publish it, and tell you what is next. If anything fails I tell you what failed and what I propose before we go on.

## Your job in this stage

None.

## If you want to read

`out/handback-15.md` first: the analyst's own account of what it did and what it is unsure about. Then `out/notes-15.md` for the detail, and `out/diary-15.md` for how it went about it.

## What it will have written

the adjudicated crossing, plus `recross.jsonl` and `reliability-15.md` from the blind check; and, as every stage does, `notes-15.md`, `handback-15.md`, `diary-15.md` and the validator's report.

## Fork point

No.

